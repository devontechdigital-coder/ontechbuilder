import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface IndexTemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

/** Sample content so the homepage looks complete immediately after installation — every value is editable via each section's schema.ts. */
export const defaultIndexSections: SectionInstance[] = [
  {
    id: "hero-1",
    type: "hero",
    props: {
      eyebrowBadge: "Firm of the Year 2025",
      heading: "Driving business growth through expert strategy",
      description: "Unlock your company's full potential with expert guidance, tailored solutions, and proven results from our seasoned consultants.",
      primaryButtonLabel: "See all case studies",
      primaryButtonHref: "/case-studies",
      secondaryImageBadge: "Build a business growth",
      testimonialQuote: "The consultants helped us shape a sustainable strategy that emphasized performance, retention, and employee well-being.",
      testimonialName: "Sofia Grant",
      testimonialRole: "Director of Strategy",
      trustLabel: "Based in",
      trustLogoBlocks: [],
    },
  },
  {
    id: "logo-cloud-1",
    type: "logo-cloud",
    props: { heading: "Companies who rely on our expertise", logoBlocks: [] },
  },
  {
    id: "service-cards-1",
    type: "service-cards",
    props: {
      eyebrow: "What we offer",
      heading: "Our core consulting services",
      description: "We provide tailored consulting solutions to help businesses overcome challenges, seize opportunities, and achieve sustainable growth.",
      columns: 4,
      blocks: [
        block("service", { title: "Business strategy" }),
        block("service", { title: "Process optimization" }),
        block("service", { title: "Financial advisory" }),
        block("service", { title: "Marketing Research" }),
      ],
    },
  },
  {
    id: "stats-row-1",
    type: "stats-row",
    props: {
      blocks: [
        block("stat", { eyebrow: "Business transformed", value: "260+", description: "Helping companies grow and perform better.", tone: "surface" }),
        block("stat", { eyebrow: "Client satisfaction rate", value: "95%", description: "Trusted and recommended by our clients.", tone: "dark" }),
        block("stat", { eyebrow: "Revenue growth generated", value: "$150M", description: "Delivering measurable financial impact.", tone: "surface" }),
      ],
    },
  },
  {
    id: "split-content-1",
    type: "split-content",
    props: {
      eyebrow: "About Copora",
      heading: "Driven by insight. Focused on results",
      description: "We provide tailored consulting solutions to help businesses overcome challenges, seize opportunities, and achieve sustainable growth.",
      buttonLabel: "More about us",
      buttonHref: "/about",
      imagePosition: "right",
      imageAspectRatio: "4:3",
    },
  },
  {
    id: "process-dark-1",
    type: "process-dark",
    props: {
      eyebrow: "How we work",
      heading: "Smart steps to business growth",
      description: "We follow a strategic four-step approach designed to drive measurable results. From deep discovery to ongoing optimization, every step is focused on moving your business forward with clarity, efficiency, and impact.",
      teaserText: "Want to know what's possible?",
      teaserLinkLabel: "Get in touch now",
      teaserLinkHref: "/contact",
      blocks: [
        block("step", { number: "01", title: "Discovery", description: "We begin by listening closely to your challenges and goals. Through research and deep business analysis, we uncover insights. This foundation shapes every strategy we build moving forward." }),
        block("step", { number: "02", title: "Strategy", description: "We translate insight into a clear, actionable roadmap tailored to your business and market." }),
        block("step", { number: "03", title: "Execution", description: "Our consultants work alongside your team to implement the plan with precision and pace." }),
        block("step", { number: "04", title: "Optimization", description: "We measure outcomes continuously and refine the approach to compound results over time." }),
      ],
    },
  },
  {
    id: "featured-case-study-1",
    type: "featured-case-study",
    props: {
      eyebrow: "Our case studies",
      heading: "Futured case study",
      title: "Market entry strategy for a fintech startup",
    },
  },
  {
    id: "case-study-list-1",
    type: "case-study-list",
    props: {
      eyebrow: "Recent case studies",
      footerLinkLabel: "Let's work together",
      footerLinkHref: "/contact",
      blocks: [
        block("case_study", { tag: "Healthcare", title: "Digital transformation for a healthcare provider", excerpt: "A phased rollout of digital patient services across a multi-site provider network.", highlighted: true }),
        block("case_study", { tag: "Retail", title: "International expansion strategy for a retail brand", excerpt: "Market-entry research and go-to-market planning across three new regions." }),
        block("case_study", { tag: "Website Design", title: "Corporate website for a green energy company", excerpt: "A full brand and website relaunch aligned to a new sustainability positioning." }),
        block("case_study", { tag: "SaaS Product", title: "Product redesign for a SaaS analytics platform", excerpt: "An end-to-end UX overhaul that lifted activation and reduced churn.", highlighted: true }),
      ],
    },
  },
  {
    id: "testimonial-showcase-1",
    type: "testimonial-showcase",
    props: {
      eyebrow: "Testimonials",
      heading: "Proven impact, shared experiences",
      description: "From startups to enterprises, our clients share how our strategic consulting helped them achieve lasting success.",
      ratingValue: "4.5",
      reviewCount: "450+",
      blocks: [block("testimonial", { quote: "Our company was growing fast, but our culture couldn't keep pace.", name: "Amanda Lewis", role: "Director of Strategy" })],
    },
  },
  {
    id: "blog-grid-1",
    type: "blog-grid",
    props: {
      eyebrow: "Our blog",
      heading: "Insights & Ideas",
      seeAllLabel: "See all blog",
      seeAllHref: "/blog",
      columns: 2,
      blocks: [
        block("post", { tag: "Growth", date: "June 20, 2025", title: "5 growth strategies every modern business should know", linkHref: "/blog/growth-strategies-2025" }),
        block("post", { tag: "Strategy", date: "June 20, 2025", title: "From goals to KPIs: turning vision into measurable success", linkHref: "/blog/goals-to-kpis" }),
      ],
    },
  },
  {
    id: "cta-banner-1",
    type: "cta-banner",
    props: {
      heading: "Let's build something that moves your business forward",
      avatarLabel: "Talk to our experts",
      buttonLabel: "Get started now",
      buttonHref: "/contact",
      avatarBlocks: [],
    },
  },
];

export default function IndexTemplate({ sections = defaultIndexSections }: IndexTemplateProps) {
  return <RenderSections sections={sections} />;
}
