import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-intro",
  name: "Realty intro",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Trusted builders creating modern" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "spaces with integrity" },
    { type: "text", id: "linkLabel", label: "Link label", default: "Learn More About" },
    { type: "url", id: "linkHref", label: "Link URL", default: "/about" },
  ],
  blocks: [
    {
      type: "card",
      name: "Feature card",
      settings: [
        {
          type: "select",
          id: "style",
          label: "Style",
          options: [
            { value: "accent", label: "Accent color (icon only)" },
            { value: "image", label: "Photo" },
          ],
          default: "image",
        },
        { type: "image", id: "image", label: "Image (photo style only)" },
        { type: "text", id: "caption", label: "Caption badge (photo style only)", default: "" },
      ],
    },
    {
      type: "stat",
      name: "Stat",
      settings: [
        { type: "text", id: "value", label: "Value", default: "25+" },
        { type: "text", id: "label", label: "Label", default: "Residential Projects" },
      ],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "card", settings: { style: "accent" } },
    { type: "card", settings: { style: "image" } },
    { type: "card", settings: { style: "image", caption: "Modern Design Solution" } },
    { type: "stat", settings: { value: "25+", label: "Residential Projects" } },
    { type: "stat", settings: { value: "50+", label: "Expert Team Members" } },
    { type: "stat", settings: { value: "500+", label: "Projects Completed" } },
  ],
};

export default schema;
