import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-stats",
  name: "Realty stats",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Facts that showcase experience" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "quality and reliability" },
    { type: "image", id: "image", label: "Main image" },
    { type: "image", id: "thumbImage", label: "Thumbnail image" },
  ],
  blocks: [
    {
      type: "stat",
      name: "Stat",
      settings: [
        { type: "text", id: "value", label: "Value", default: "25+" },
        { type: "text", id: "label", label: "Label", default: "Year Experience" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "stat", settings: { value: "25+", label: "Year Experience" } },
    { type: "stat", settings: { value: "50+", label: "Expert Team Members" } },
    { type: "stat", settings: { value: "500+", label: "Projects Completed" } },
    { type: "stat", settings: { value: "300+", label: "Happy Clients" } },
  ],
};

export default schema;
