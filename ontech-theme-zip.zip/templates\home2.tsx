import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface Home2TemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

/** Every image in this template's sample content points at the theme's bundled placeholder graphic. */
function img(alt: string) {
  return { src: "assets/img/default.svg", alt };
}

/**
 * Sample content for the "Skyvilla" real-estate/construction homepage
 * — a third homepage living alongside `index` and `home1`. Every value
 * is editable via each section's schema.ts; this template uses its own
 * Header/Footer partials (`header-skyvilla` / `footer-skyvilla`, see
 * layout/defaultPartials.ts) rather than the default Header/Footer —
 * though which header/footer actually renders on any given page is
 * controlled by the site-wide "Header style" / "Footer layout" global
 * settings, not hardcoded per template.
 */
export const defaultHome2Sections: SectionInstance[] = [
  {
    id: "realty-hero-1",
    type: "realty-hero",
    props: {
      heading: "Smart real estate",
      headingItalic: "reliable construction",
      image: img("Modern residential tower"),
      primaryButtonLabel: "Get Free Consultation",
      primaryButtonHref: "/contact",
      ratingValue: "4.9",
      ratingLabel: "500+ Happy Clients",
      blocks: [
        block("stat", { value: "25+", label: "Years Experience" }),
        block("stat", { value: "50+", label: "Expert Team Members" }),
        block("stat", { value: "500+", label: "Projects Completed" }),
        block("avatar", { image: img("Client portrait") }),
        block("avatar", { image: img("Client portrait") }),
        block("avatar", { image: img("Client portrait") }),
      ],
    },
  },
  {
    id: "realty-intro-1",
    type: "realty-intro",
    props: {
      heading: "Trusted builders creating modern",
      headingItalic: "spaces with integrity",
      linkLabel: "Learn More About",
      linkHref: "/about",
      blocks: [
        block("card", { style: "accent" }),
        block("card", { style: "image", image: img("Modern tower exterior") }),
        block("card", { style: "image", image: img("Construction blueprint grid"), caption: "Modern Design Solution" }),
        block("stat", { value: "25+", label: "Residential Projects" }),
        block("stat", { value: "50+", label: "Expert Team Members" }),
        block("stat", { value: "500+", label: "Projects Completed" }),
      ],
    },
  },
  {
    id: "realty-services-1",
    type: "realty-services",
    props: {
      heading: "Reliable services for real estate and",
      headingItalic: "construction",
      noteHeading: "Complete Real Estate Solutions",
      noteText: "Get 100% Satisfaction",
      ratingValue: "4.9",
      blocks: [
        block("service", { title: "Residential Construction", description: "We build lasting, high-quality residential communities with attention to detail.", linkLabel: "View Details", linkHref: "#" }),
        block("service", { title: "Commercial Construction", description: "Scalable commercial builds engineered for performance and durability.", linkLabel: "View Details", linkHref: "#" }),
        block("service", { title: "Project Development", dark: true, image: img("Night skyline"), linkLabel: "View All Services", linkHref: "#" }),
        block("service", { title: "Design & Planning", description: "Full-service design and architectural planning for every project stage.", linkLabel: "View Details", linkHref: "#" }),
      ],
    },
  },
  {
    id: "realty-about-1",
    type: "realty-about",
    props: {
      heading: "Shaping residential and commercial",
      headingItalic: "spaces with expertise",
      ctaLabel: "Contact Us",
      ctaHref: "/contact",
      phone: "+1 (234) 567-890",
      image: img("Residential towers"),
      badgeValue: "100%+",
      badgeLabel: "Satisfaction Rate",
      blocks: [
        block("feature", { title: "Industry Experts", description: "Decades of combined experience across residential and commercial builds." }),
        block("feature", { title: "Trusted Builders", description: "Strong safety standards and rigorous quality control on every site." }),
        block("feature", { title: "Modern Designers", description: "Client-focused design that balances form, function, and budget." }),
        block("thumb", { image: img("Poolside villa") }),
        block("thumb", { image: img("Interior lobby") }),
      ],
    },
  },
  {
    id: "realty-video-banner-1",
    type: "realty-video-banner",
    props: {
      heading: "Watch how we build",
      headingItalic: "modern quality living spaces",
      image: img("Modern house exterior at dusk"),
      videoHref: "#",
    },
  },
  {
    id: "realty-why-us-1",
    type: "realty-why-us",
    props: {
      heading: "Dedicated to honest &",
      headingItalic: "reliable construction",
      description: "We combine craftsmanship, transparency, and modern building methods to deliver spaces our clients trust for decades.",
      ctaLabel: "Contact Us",
      ctaHref: "/contact",
      ratingValue: "4.9",
      ratingLabel: "500+ Happy Clients",
      quoteText: "Creating modern homes and commercial spaces precision construction and trusted real estate expertise.",
      quoteButtonLabel: "Get a Quote",
      quoteButtonHref: "/contact",
      blocks: [
        block("avatar", { image: img("Client portrait") }),
        block("avatar", { image: img("Client portrait") }),
        block("avatar", { image: img("Client portrait") }),
        block("point", { number: "01", title: "Quality Craftsmanship", description: "Superior construction with attention to detail on every build." }),
        block("point", { number: "02", title: "Sustainability", description: "Durable and environmentally conscious construction practices." }),
        block("point", { number: "03", title: "Modern Techniques", description: "Innovative construction and design methods on every project." }),
        block("quote_avatar", { image: img("Client portrait") }),
        block("quote_avatar", { image: img("Client portrait") }),
      ],
    },
  },
  {
    id: "realty-projects-1",
    type: "realty-projects",
    props: {
      heading: "Our work defined by precision",
      headingItalic: "strength and Integrity",
      footerLinkLabel: "Get a Free Quote",
      footerLinkHref: "/contact",
      blocks: [
        block("project", { image: img("The Vertex Place tower"), title: "The Vertex Place", linkHref: "#" }),
        block("project", { image: img("Aurella Business Park"), title: "Aurella Business Park", linkHref: "#" }),
        block("project", { image: img("Crown Point Residences"), title: "Crown Point Residences", linkHref: "#" }),
      ],
    },
  },
  {
    id: "realty-stats-1",
    type: "realty-stats",
    props: {
      heading: "Facts that showcase experience",
      headingItalic: "quality and reliability",
      image: img("Villa exterior"),
      thumbImage: img("Site plan overhead"),
      blocks: [
        block("stat", { value: "25+", label: "Year Experience" }),
        block("stat", { value: "50+", label: "Expert Team Members" }),
        block("stat", { value: "500+", label: "Projects Completed" }),
        block("stat", { value: "300+", label: "Happy Clients" }),
      ],
    },
  },
  {
    id: "realty-contact-split-1",
    type: "realty-contact-split",
    props: {
      heading: "Quick support when you",
      headingItalic: "need it most",
      phone: "+1 (234) 567-890",
      email: "hello@skyvilla.com",
      formHeading: "Send us a",
      formHeadingItalic: "message",
      submitLabel: "Send Message",
    },
  },
  {
    id: "realty-faq-1",
    type: "realty-faq",
    props: {
      heading: "Frequently Asked Questions",
      ctaLabel: "View All FAQs",
      ctaHref: "/faq",
      blocks: [
        block("avatar", { image: img("Client portrait") }),
        block("avatar", { image: img("Client portrait") }),
        block("avatar", { image: img("Client portrait") }),
        block("faq", {
          question: "Do you handle commercial and residential projects?",
          answer:
            "Yes — our team handles projects of every scale, from single-family homes to large commercial developments, offering flexible service plans, tailored budgeting, and dedicated project management throughout.",
        }),
        block("faq", { question: "Can you customize projects based on client needs?", answer: "Absolutely — every project starts with a discovery session so the design and scope match your goals and budget." }),
        block("faq", { question: "Do you provide free consultations and site visits?", answer: "Yes, we offer a free initial consultation and, where useful, an on-site walkthrough before any proposal." }),
        block("faq", { question: "Do you work with architects and interior designers?", answer: "We regularly partner with independent architects and designers, or can bring our own in-house team." }),
        block("faq", { question: "How can I get started with my project?", answer: "Reach out through our contact form or give us a call — we'll schedule a consultation within a few business days." }),
      ],
    },
  },
  {
    id: "realty-testimonials-1",
    type: "realty-testimonials",
    props: {
      heading: "What our clients say about our",
      headingItalic: "construction services",
      linkLabel: "View All Reviews",
      linkHref: "#",
      blocks: [
        block("testimonial", { avatar: img("Client portrait"), quote: "The team delivered exactly what we envisioned, on time and on budget.", name: "Parul Dhupar", role: "Homeowner" }),
        block("testimonial", { avatar: img("Client portrait"), quote: "Professional from the first call to the final walkthrough — highly recommended.", name: "Amrita Patel", role: "Property Developer" }),
        block("testimonial", {
          avatar: img("Client portrait"),
          quote: "Their attention to detail and communication set them apart from every other builder we spoke to.",
          name: "Rahul Mehta",
          role: "Commercial Client",
        }),
        block("logo", { image: img("Partner logo") }),
        block("logo", { image: img("Partner logo") }),
        block("logo", { image: img("Partner logo") }),
        block("logo", { image: img("Partner logo") }),
      ],
    },
  },
  {
    id: "realty-blog-grid-1",
    type: "realty-blog-grid",
    props: {
      heading: "Latest insights from real estate and",
      headingItalic: "construction",
      blocks: [
        block("post", { image: img("Modern urban apartments"), title: "Modern Construction Trends Shaping Urban Living", linkLabel: "Read More", linkHref: "/blog/post" }),
        block("post", { image: img("Quality construction site"), title: "Benefits Of Quality Construction For Long Term Value", linkLabel: "Read More", linkHref: "/blog/post" }),
        block("post", { image: img("Sustainable building"), title: "Sustainable Building Practices For Future-Ready Spaces", linkLabel: "Read More", linkHref: "/blog/post" }),
      ],
    },
  },
];

export default function Home2Template({ sections = defaultHome2Sections }: Home2TemplateProps) {
  return <RenderSections sections={sections} />;
}
