import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "blog-grid",
  name: "Blog grid",
  category: "Blog",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our blog" },
    { type: "text", id: "heading", label: "Heading", default: "Insights & Ideas" },
    { type: "text", id: "seeAllLabel", label: "\"See all\" button label", default: "See all blog" },
    { type: "url", id: "seeAllHref", label: "\"See all\" button link", default: "/blog" },
    {
      type: "select",
      id: "columns",
      label: "Columns",
      options: [
        { value: "2", label: "2" },
        { value: "3", label: "3" },
      ],
      default: "2",
    },
  ],
  blocks: [
    {
      type: "post",
      name: "Post",
      settings: [
        { type: "image", id: "image", label: "Image" },
        { type: "text", id: "tag", label: "Tag", default: "Growth" },
        { type: "text", id: "date", label: "Date", default: "June 20, 2025" },
        { type: "text", id: "title", label: "Title", default: "Post title" },
        { type: "url", id: "linkHref", label: "Link URL", default: "#" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "post", settings: { tag: "Growth", date: "June 20, 2025", title: "5 growth strategies every modern business should know" } },
    { type: "post", settings: { tag: "Strategy", date: "June 20, 2025", title: "From goals to KPIs: turning vision into measurable success" } },
  ],
};

export default schema;
