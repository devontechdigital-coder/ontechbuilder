import * as React from "react";
import { Container } from "../../components/Container";
import { Button } from "../../components/Button";
import { ThemeImg } from "../../components/ThemeImg";
import { Avatar } from "../../components/Avatar";
import { asImage, asString, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface HeroProps {
  eyebrowBadge?: string;
  heading: string;
  description?: string;
  primaryButtonLabel?: string;
  primaryButtonHref?: string;
  image?: ThemeImage;
  secondaryImage?: ThemeImage;
  secondaryImageBadge?: string;
  testimonialQuote?: string;
  testimonialName?: string;
  testimonialRole?: string;
  testimonialAvatar?: ThemeImage;
  trustLabel?: string;
  /** Raw trust_logo blocks — each block's `image` field is pulled out internally. */
  trustLogoBlocks: RawBlock[];
}

/**
 * The home hero: a headline/CTA on the left and an image collage on
 * the right — a wide hero photo, a floating testimonial card, and a
 * small secondary image with a rotated badge. A trust row (eyebrow
 * badge + partner logos) sits underneath.
 */
export function Hero({
  eyebrowBadge,
  heading,
  description,
  primaryButtonLabel,
  primaryButtonHref,
  image,
  secondaryImage,
  secondaryImageBadge,
  testimonialQuote,
  testimonialName,
  testimonialRole,
  testimonialAvatar,
  trustLabel,
  trustLogoBlocks,
}: HeroProps) {
  const primaryButton = optionalLink(primaryButtonLabel, primaryButtonHref);
  const hasTestimonial = Boolean(testimonialQuote && testimonialName);
  const trustLogos = trustLogoBlocks.map((block) => asImage(block.image)).filter((img): img is ThemeImage => Boolean(img));

  return (
    <section className="cop-hero">
      <Container width="wide" className="cop-hero__grid">
        <div className="cop-hero__content">
          <h1 className="cop-hero__heading">{heading}</h1>
          {description && <p className="cop-hero__description">{description}</p>}
          {primaryButton && (
            <Button href={primaryButton.href} variant="primary" size="lg">
              {primaryButton.label}
            </Button>
          )}
        </div>

        <div className="cop-hero__media">
          <ThemeImg image={image} ratio="4:3" placeholderLabel="Hero image" className="cop-hero__media-main" />
          {hasTestimonial && (
            <div className="cop-hero__testimonial">
              <p>{testimonialQuote}</p>
              <div className="cop-hero__testimonial-person">
                <Avatar image={testimonialAvatar} size={34} />
                <span>
                  <strong>{asString(testimonialName)}</strong>
                  <em>{asString(testimonialRole)}</em>
                </span>
              </div>
            </div>
          )}
          {secondaryImage?.src && (
            <div className="cop-hero__media-secondary">
              <ThemeImg image={secondaryImage} ratio="4:3" placeholderLabel="Secondary image" />
              {secondaryImageBadge && <span className="cop-hero__badge">{secondaryImageBadge}</span>}
            </div>
          )}
        </div>
      </Container>

      {(eyebrowBadge || trustLogos.length > 0) && (
        <Container width="wide" className="cop-hero__trust">
          {eyebrowBadge && <span className="cop-hero__trust-badge">{eyebrowBadge}</span>}
          {trustLogos.length > 0 && (
            <div className="cop-hero__trust-logos">
              {trustLabel && <span className="cop-hero__trust-label">{trustLabel}</span>}
              <div className="cop-hero__trust-row">
                {trustLogos.map((logo, index) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={logo.src + index} src={logo.src} alt={logo.alt} />
                ))}
              </div>
            </div>
          )}
        </Container>
      )}
    </section>
  );
}
