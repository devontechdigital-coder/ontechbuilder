import * as React from "react";
import { Container } from "../../components/Container";
import { Button } from "../../components/Button";
import { asString, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface StatsRowProps {
  /** Raw blocks mixing "stat" and "cta" block types — this component switches on block.type itself. */
  blocks: RawBlock[];
}

/**
 * A flexible tile row. On the homepage every tile is a `stat` block; on
 * the About page the middle tile is a `cta` block instead — either
 * layout is a content choice (which block types are present), not a
 * different section.
 */
export function StatsRow({ blocks }: StatsRowProps) {
  return (
    <section className="cop-section cop-stats">
      <Container width="wide" className={`cop-stats__grid cop-grid--cols-${blocks.length}`}>
        {blocks.map((block) => {
          if (block.type === "cta") {
            const button = optionalLink(block.buttonLabel, block.buttonHref);
            return (
              <div key={block.id} className="cop-stats__tile cop-stats__tile--dark">
                <h3>{asString(block.heading)}</h3>
                {button && (
                  <Button href={button.href} variant="light" size="sm">
                    {button.label}
                  </Button>
                )}
              </div>
            );
          }
          const tone = block.tone === "dark" ? "dark" : "surface";
          return (
            <div key={block.id} className={`cop-stats__tile cop-stats__tile--${tone}`}>
              {typeof block.eyebrow === "string" && block.eyebrow && <span className="cop-stats__eyebrow">{block.eyebrow}</span>}
              <strong className="cop-stats__value">{asString(block.value)}</strong>
              {typeof block.description === "string" && block.description && <p>{block.description}</p>}
            </div>
          );
        })}
      </Container>
    </section>
  );
}
