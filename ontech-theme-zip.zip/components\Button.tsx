import * as React from "react";

export type ButtonVariant = "primary" | "light" | "outline" | "ghost";
export type ButtonSize = "sm" | "md" | "lg";

interface ButtonProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: React.ReactNode;
}

/** Renders as an anchor so it works for in-page and external links without a router dependency. */
export function Button({ variant = "primary", size = "md", icon, className = "", children, ...rest }: ButtonProps) {
  return (
    <a className={`cop-btn cop-btn--${variant} cop-btn--${size} ${className}`.trim()} {...rest}>
      {children}
      {icon}
    </a>
  );
}
