import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import type { AspectRatio, ThemeImage } from "../../components/types";

export interface PageIntroProps {
  heading: string;
  description?: string;
  image?: ThemeImage;
  imageAspectRatio: AspectRatio;
}

/** Simple centered page intro used at the top of About, Blog and similar interior pages. */
export function PageIntro({ heading, description, image, imageAspectRatio }: PageIntroProps) {
  return (
    <section className="cop-section cop-page-intro">
      <Container width="default" className="cop-page-intro__text">
        <h1>{heading}</h1>
        {description && <p>{description}</p>}
      </Container>
      {image && (
        <Container width="wide">
          <ThemeImg image={image} ratio={imageAspectRatio} placeholderLabel="Banner image" className="cop-page-intro__image" />
        </Container>
      )}
    </section>
  );
}
