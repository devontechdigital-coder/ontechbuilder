import type { PartialInstance } from "../components/partialRegistry";

/**
 * layout/defaultPartials.ts
 *
 * Header and Footer are usually composed once per page by the host and
 * passed into ThemeLayout's `header`/`footer` slots (see README) —
 * unlike body sections, they don't normally appear in a page's
 * reorderable section list. Because of that, no `templates/*.tsx` file
 * naturally provides sample content for them the way `defaultIndexSections`
 * does for the homepage body. This file fills that gap: ready-to-use
 * instances matching each schema's own `defaultBlocks`, for a host to
 * seed a new site with (or fall back to if a website has no header/
 * footer configuration saved yet).
 */

export const defaultHeaderPartial: PartialInstance = {
  id: "header-1",
  type: "header",
  props: {
    logoText: "Copora",
    phone: "+123 456 7891",
    ctaLabel: "Contact now",
    ctaHref: "/contact",
    sticky: true,
    transparentOnHero: false,
    navBlocks: [
      { id: "nav-home", type: "nav_link", label: "Home", href: "/" },
      {
        id: "nav-about",
        type: "nav_menu",
        label: "About",
        style: "simple",
        items: [
          {
            label: "Company",
            href: "/about",
            children: [
              { label: "Our Story", href: "/about#story" },
              { label: "Mission & Vision", href: "/about#mission" },
              {
                label: "Our Team",
                href: "/about#team",
                children: [
                  { label: "Leadership", href: "/about#leadership" },
                  { label: "Consultants", href: "/about#consultants" },
                ],
              },
            ],
          },
        ],
      },
      {
        id: "nav-case-studies",
        type: "nav_menu",
        label: "Case Studies",
        style: "simple",
        items: [
          { label: "All Case Studies", href: "/case-studies" },
          { label: "Featured", href: "/case-studies#featured" },
          {
            label: "By Industry",
            href: "/case-studies#industry",
            children: [
              { label: "Healthcare", href: "/case-studies/healthcare" },
              { label: "Retail", href: "/case-studies/retail" },
              { label: "SaaS", href: "/case-studies/saas" },
            ],
          },
        ],
      },
      {
        id: "nav-blog",
        type: "nav_menu",
        label: "Blog",
        style: "simple",
        items: [
          { label: "All Posts", href: "/blog" },
          {
            label: "Topics",
            href: "/blog",
            children: [
              { label: "Growth", href: "/blog?tag=growth" },
              { label: "Strategy", href: "/blog?tag=strategy" },
              { label: "Marketing", href: "/blog?tag=marketing" },
            ],
          },
        ],
      },
      {
        id: "nav-pages",
        type: "nav_menu",
        label: "Pages",
        style: "mega",
        items: [
          {
            label: "Pages",
            children: [
              { label: "Home", href: "/" },
              { label: "About", href: "/about" },
              {
                label: "Services",
                href: "/services",
                children: [
                  { label: "Business Strategy", href: "/services/strategy" },
                  { label: "Process Optimization", href: "/services/process" },
                  { label: "Financial Advisory", href: "/services/financial" },
                ],
              },
              { label: "Blog", href: "/blog" },
              { label: "Blog Details", href: "/blog/post" },
            ],
          },
          {
            label: "Other Pages",
            children: [
              { label: "Case Studies", href: "/case-studies" },
              { label: "Contact", href: "/contact" },
              { label: "Error 404", href: "/404" },
              { label: "Password Protected", href: "/protected" },
              { label: "Support", href: "/support" },
            ],
          },
        ],
        featuredTitle: "Book a free consultation",
        featuredDescription: "Talk to our consultants about your growth strategy.",
        featuredLinkLabel: "Get in touch",
        featuredLinkHref: "/contact",
      },
    ],
  },
};

export const defaultFooterPartial: PartialInstance = {
  id: "footer-1",
  type: "footer",
  props: {
    logoText: "Copora",
    contactLabel: "Say hello to us!",
    email: "hello@example.com",
    phone: "+123 456 7890",
    showNewsletter: true,
    newsletterHeading: "Stay informed.",
    newsletterPlaceholder: "Enter email address",
    showRecentWorks: true,
    recentWorksHeading: "Recent works",
    credit: "Developed by Aster Theme Studio",
    style: "dark",
    blocks: [
      {
        id: "footer-col-company",
        type: "link_column",
        heading: "Company",
        links: [
          {
            label: "About",
            href: "/about",
            children: [
              { label: "Our Story", href: "/about#story" },
              {
                label: "Our Team",
                href: "/about#team",
                children: [
                  { label: "Leadership", href: "/about#leadership" },
                  { label: "Consultants", href: "/about#consultants" },
                ],
              },
            ],
          },
          { label: "Case Studies", href: "/case-studies" },
          { label: "Blog", href: "/blog" },
        ],
      },
      {
        id: "footer-col-services",
        type: "link_column",
        heading: "Services",
        links: [
          { label: "Business Strategy", href: "/services/strategy" },
          { label: "Process Optimization", href: "/services/process" },
          { label: "Financial Advisory", href: "/services/financial" },
          { label: "Marketing Research", href: "/services/marketing" },
        ],
      },
      {
        id: "footer-col-support",
        type: "link_column",
        heading: "Support",
        links: [
          {
            label: "Contact",
            href: "/contact",
            children: [
              { label: "General Enquiries", href: "/contact?topic=general" },
              { label: "Partnerships", href: "/contact?topic=partnership" },
            ],
          },
          { label: "Error 404", href: "/404" },
          { label: "Password Protected", href: "/protected" },
        ],
      },
      { id: "footer-social-facebook", type: "social_link", icon: "facebook", href: "#", label: "Facebook" },
      { id: "footer-social-instagram", type: "social_link", icon: "instagram", href: "#", label: "Instagram" },
      { id: "footer-social-linkedin", type: "social_link", icon: "linkedin", href: "#", label: "LinkedIn" },
    ],
  },
};

/**
 * `home1` (the Dentora dental-clinic homepage) uses its own Header/
 * Footer partials — `header-dentora` / `footer-dentora`, defined
 * alongside the default Header/Footer in partials/Header/ and
 * partials/Footer/ — rather than the default Header/Footer above,
 * since its nav/CTA/footer layout is a different design entirely.
 * Every image points at the theme's bundled placeholder graphic
 * (assets/img/default.svg) so the sample page looks complete
 * immediately.
 */
export const defaultHeaderDentoraPartial: PartialInstance = {
  id: "header-dentora-1",
  type: "header-dentora",
  props: {
    logoText: "Dentora",
    activeHref: "/",
    ctaLabel: "Book a Call",
    ctaHref: "/contact",
    sticky: true,
    navBlocks: [
      { id: "nav-home", type: "nav_link", label: "Home", href: "/" },
      { id: "nav-services", type: "nav_link", label: "Services", href: "/services" },
      { id: "nav-about", type: "nav_link", label: "About Us", href: "/about" },
      { id: "nav-testimonial", type: "nav_link", label: "Testimonial", href: "/#testimonial" },
      { id: "nav-contact", type: "nav_link", label: "Contact", href: "/contact" },
    ],
  },
};

export const defaultFooterDentoraPartial: PartialInstance = {
  id: "footer-dentora-1",
  type: "footer-dentora",
  props: {
    logoText: "Dentora",
    headingLine1: "Your smile matters",
    headingLine2: "Connect with us today",
    email: "dentora@doc.com",
    contactHeading: "We'd love to help you",
    showNewsletter: true,
    newsletterHeading: "Join our newsletter to receive the latest oral health tips, special offers and clinic updates.",
    newsletterPlaceholder: "Your Email Address",
    newsletterButtonLabel: "Subscribe",
    termsLabel: "Terms & Conditions",
    termsHref: "/terms",
    privacyLabel: "Privacy Policy",
    privacyHref: "/privacy",
    creditLine: "© 2026 Dentora. All rights reserved.",
    blocks: [
      {
        id: "footer-dentora-col-company",
        type: "link_column",
        heading: "Company",
        linksJson: JSON.stringify([
          { label: "Home", href: "/" },
          { label: "Services", href: "/services" },
          { label: "About Us", href: "/about" },
          { label: "Dentist", href: "/about#dentist" },
        ]),
      },
      {
        id: "footer-dentora-col-resources",
        type: "link_column",
        heading: "Resources",
        linksJson: JSON.stringify([
          { label: "Contact Us", href: "/contact" },
          { label: "Blog", href: "/blog" },
          { label: "Faq", href: "/faq" },
          { label: "404 Error", href: "/404" },
        ]),
      },
      {
        id: "footer-dentora-col-legal",
        type: "link_column",
        heading: "Legal",
        linksJson: JSON.stringify([
          { label: "Privacy Policy", href: "/privacy" },
          { label: "Terms and Conditions", href: "/terms" },
          { label: "License", href: "/license" },
        ]),
      },
      { id: "footer-dentora-social-facebook", type: "social_link", icon: "facebook", href: "#", label: "Facebook" },
      { id: "footer-dentora-social-instagram", type: "social_link", icon: "instagram", href: "#", label: "Instagram" },
      { id: "footer-dentora-social-x", type: "social_link", icon: "x", href: "#", label: "X (Twitter)" },
      { id: "footer-dentora-social-linkedin", type: "social_link", icon: "linkedin", href: "#", label: "LinkedIn" },
    ],
  },
};

/**
 * `home2` (the Skyvilla real-estate/construction homepage) uses its
 * own Header/Footer partials — `header-skyvilla` / `footer-skyvilla`,
 * defined alongside the others in partials/Header/ and partials/Footer/.
 * As with the Dentora partials above, which header/footer actually
 * renders on a page is controlled by the "Header style" / "Footer
 * layout" global settings, not hardcoded per template.
 */
export const defaultHeaderSkyvillaPartial: PartialInstance = {
  id: "header-skyvilla-1",
  type: "header-skyvilla",
  props: {
    logoText: "Skyvilla",
    ctaLabel: "Get Free Quote",
    ctaHref: "/contact",
    showSearch: true,
    sticky: true,
    navBlocks: [
      { id: "nav-home", type: "nav_link", label: "Home", href: "/" },
      { id: "nav-about", type: "nav_link", label: "About Us", href: "/about" },
      { id: "nav-services", type: "nav_link", label: "Services", href: "/services" },
      { id: "nav-blog", type: "nav_link", label: "Blog", href: "/blog" },
      {
        id: "nav-pages",
        type: "nav_menu",
        label: "Pages",
        items: [
          { label: "Projects", href: "/projects" },
          { label: "FAQs", href: "/faq" },
          { label: "Contact", href: "/contact" },
        ],
      },
    ],
  },
};

export const defaultFooterSkyvillaPartial: PartialInstance = {
  id: "footer-skyvilla-1",
  type: "footer-skyvilla",
  props: {
    logoText: "Skyvilla",
    heading: "Begin your construction journey with",
    headingItalic: "trusted experts",
    description: "Explore our social media for the latest project updates and behind-the-scenes moments.",
    ratingValue: "4.9",
    ratingLabel: "Client Rating",
    primaryButtonLabel: "Explore Our Social Media",
    primaryButtonHref: "#",
    socialHeading: "Follow us",
    phone: "+1 (234) 567-890",
    email: "hello@skyvilla.com",
    address: "123 Skyline Ave, Los Angeles, CA",
    termsLabel: "Terms & Conditions",
    termsHref: "/terms",
    privacyLabel: "Privacy Policy",
    privacyHref: "/privacy",
    creditLine: "© 2026 Skyvilla. All rights reserved.",
    blocks: [
      {
        id: "footer-skyvilla-col-quick",
        type: "link_column",
        heading: "Quick Links",
        linksJson: JSON.stringify([
          { label: "Home", href: "/" },
          { label: "About Us", href: "/about" },
          { label: "Services", href: "/services" },
          { label: "Blog", href: "/blog" },
          { label: "Contact Us", href: "/contact" },
        ]),
      },
      {
        id: "footer-skyvilla-col-services",
        type: "link_column",
        heading: "Services",
        linksJson: JSON.stringify([
          { label: "Residential Construction", href: "/services/residential" },
          { label: "Commercial Construction", href: "/services/commercial" },
          { label: "Design & Planning", href: "/services/design" },
          { label: "Project Management", href: "/services/management" },
        ]),
      },
      { id: "footer-skyvilla-social-facebook", type: "social_link", icon: "facebook", href: "#", label: "Facebook" },
      { id: "footer-skyvilla-social-instagram", type: "social_link", icon: "instagram", href: "#", label: "Instagram" },
      { id: "footer-skyvilla-social-x", type: "social_link", icon: "x", href: "#", label: "X (Twitter)" },
      { id: "footer-skyvilla-social-linkedin", type: "social_link", icon: "linkedin", href: "#", label: "LinkedIn" },
    ],
  },
};
