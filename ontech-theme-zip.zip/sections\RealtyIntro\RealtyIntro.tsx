import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface RealtyIntroProps {
  heading: string;
  headingItalic?: string;
  linkLabel?: string;
  linkHref?: string;
  /** Raw blocks mixing "card" (the 3-up feature row) and "stat" (the row of figures beneath it). */
  blocks: RawBlock[];
}

/**
 * Intro heading + link, a 3-up card row (one accent card, two photo
 * cards — the last with a caption badge), and a stat row beneath it.
 */
export function RealtyIntro({ heading, headingItalic, linkLabel, linkHref, blocks }: RealtyIntroProps) {
  const link = optionalLink(linkLabel, linkHref);
  const cardBlocks = blocksOfType(blocks, "card");
  const statBlocks = blocksOfType(blocks, "stat");

  return (
    <section className="sv-intro">
      <Container width="wide">
        <div className="sv-intro__header">
          <h2>
            {heading} {headingItalic && <em>{headingItalic}</em>}
          </h2>
          {link && (
            <a href={link.href} className="sv-text-link">
              {link.label}
              <Icon name="arrow-up-right" size={14} />
            </a>
          )}
        </div>

        {cardBlocks.length > 0 && (
          <div className="sv-intro__cards">
            {cardBlocks.map((block) => {
              const style = asString(block.style, "image");
              if (style === "accent") {
                return (
                  <div key={block.id} className="sv-intro__card sv-intro__card--accent">
                    <span className="sv-intro__card-icon">
                      <Icon name="sparkle" size={22} />
                    </span>
                  </div>
                );
              }
              const caption = typeof block.caption === "string" ? block.caption : "";
              return (
                <div key={block.id} className={`sv-intro__card sv-intro__card--image ${caption ? "sv-intro__card--caption" : ""}`.trim()}>
                  <ThemeImg image={asImage(block.image)} ratio="auto" placeholderLabel="Feature image" className="sv-intro__card-image" />
                  {caption && <span className="sv-intro__card-caption">{caption}</span>}
                </div>
              );
            })}
          </div>
        )}

        {statBlocks.length > 0 && (
          <div className="sv-intro__stats">
            {statBlocks.map((block) => (
              <div key={block.id} className="sv-intro__stat">
                <strong>{asString(block.value)}</strong>
                <span>{asString(block.label)}</span>
              </div>
            ))}
          </div>
        )}
      </Container>
    </section>
  );
}
