import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "dental-intro",
  name: "Dental intro statement",
  category: "Content",
  settings: [
    { type: "textarea", id: "boldText", label: "Bold lead-in text", default: "We deliver personalized dental treatments with" },
    {
      type: "textarea",
      id: "mutedText",
      label: "Muted supporting text",
      default: "modern technology and gentle care ensuring healthy confident smiles for every patient.",
    },
  ],
};

export default schema;
