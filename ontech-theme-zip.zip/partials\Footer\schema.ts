import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "footer",
  name: "Footer",
  category: "Footer",
  settings: [
    { type: "text", id: "logoText", label: "Wordmark text", default: "Copora" },
    { type: "text", id: "contactLabel", label: "Contact label", default: "Say hello to us!" },
    { type: "text", id: "email", label: "Email", default: "hello@example.com" },
    { type: "text", id: "phone", label: "Phone number", default: "+123 456 7890" },
    { type: "checkbox", id: "showNewsletter", label: "Show newsletter form", default: true },
    { type: "text", id: "newsletterHeading", label: "Newsletter heading", default: "Stay informed." },
    { type: "text", id: "newsletterPlaceholder", label: "Email field placeholder", default: "Enter email address" },
    { type: "checkbox", id: "showRecentWorks", label: "Show recent works grid", default: true },
    { type: "text", id: "recentWorksHeading", label: "Recent works heading", default: "Recent works" },
    { type: "text", id: "credit", label: "Credit line", default: "Developed by Aster Theme Studio" },
    {
      type: "select",
      id: "style",
      label: "Style",
      options: [
        { value: "dark", label: "Dark" },
        { value: "light", label: "Light" },
      ],
      default: "dark",
    },
  ],
  blocks: [
    {
      type: "link_column",
      name: "Link column",
      settings: [
        { type: "text", id: "heading", label: "Column heading", default: "Pages" },
        {
          type: "textarea",
          id: "linksJson",
          label: "Links",
          info: "JSON array of links. Each link supports label, href, and children for unlimited nested levels.",
          default: '[{"label":"Home","href":"/"},{"label":"About","href":"/about"},{"label":"Blog","href":"/blog"}]',
        },
      ],
    },
    {
      type: "social_link",
      name: "Social link",
      settings: [
        { type: "icon", id: "icon", label: "Icon" },
        { type: "url", id: "href", label: "URL", default: "#" },
        { type: "text", id: "label", label: "Accessible label", default: "Follow us" },
      ],
    },
    {
      type: "recent_work",
      name: "Recent work image",
      settings: [{ type: "image", id: "image", label: "Image" }],
    },
  ],
  maxBlocks: 16,
  defaultBlocks: [
    {
      type: "link_column",
      settings: {
        heading: "Company",
        links: [
          {
            label: "About",
            href: "/about",
            children: [
              { label: "Our Story", href: "/about#story" },
              {
                label: "Our Team",
                href: "/about#team",
                children: [
                  { label: "Leadership", href: "/about#leadership" },
                  { label: "Consultants", href: "/about#consultants" },
                ],
              },
            ],
          },
          { label: "Case Studies", href: "/case-studies" },
          { label: "Blog", href: "/blog" },
        ],
      },
    },
    {
      type: "link_column",
      settings: {
        heading: "Services",
        links: [
          { label: "Business Strategy", href: "/services/strategy" },
          { label: "Process Optimization", href: "/services/process" },
          { label: "Financial Advisory", href: "/services/financial" },
          { label: "Marketing Research", href: "/services/marketing" },
        ],
      },
    },
    {
      type: "link_column",
      settings: {
        heading: "Support",
        links: [
          {
            label: "Contact",
            href: "/contact",
            children: [
              { label: "General Enquiries", href: "/contact?topic=general" },
              { label: "Partnerships", href: "/contact?topic=partnership" },
            ],
          },
          { label: "Error 404", href: "/404" },
          { label: "Password Protected", href: "/protected" },
        ],
      },
    },
    { type: "social_link", settings: { icon: "facebook", href: "#", label: "Facebook" } },
    { type: "social_link", settings: { icon: "instagram", href: "#", label: "Instagram" } },
    { type: "social_link", settings: { icon: "linkedin", href: "#", label: "LinkedIn" } },
  ],
};

export default schema;
