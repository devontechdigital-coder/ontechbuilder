"use client";

import * as React from "react";
import { Container } from "../../components/Container";
import { Icon } from "../../components/Icon";
import { asBoolean, asString, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface CaseStudyListProps {
  eyebrow?: string;
  footerLinkLabel?: string;
  footerLinkHref?: string;
  /** Raw case_study blocks. */
  blocks: RawBlock[];
}

/**
 * "Recent case studies" — a list of expandable rows. A `highlighted`
 * row renders as a filled panel; the rest expand in place to show an excerpt.
 */
export function CaseStudyList({ eyebrow, footerLinkLabel, footerLinkHref, blocks }: CaseStudyListProps) {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);
  const footerLink = optionalLink(footerLinkLabel, footerLinkHref);

  return (
    <section className="cop-section cop-case-list">
      <Container width="wide">
        <div className="cop-case-list__header">
          {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
          {footerLink && (
            <a href={footerLink.href} className="cop-case-list__footer-link">
              {footerLink.label}
              <Icon name="arrow-up-right" size={14} />
            </a>
          )}
        </div>

        <div className="cop-case-list__rows">
          {blocks.map((block, index) => {
            const highlighted = asBoolean(block.highlighted, false);
            const tag = asString(block.tag);
            const title = asString(block.title);
            const excerpt = typeof block.excerpt === "string" ? block.excerpt : "";

            if (highlighted) {
              return (
                <div key={block.id} className="cop-case-list__featured">
                  <span className="cop-case-list__tag">{tag}</span>
                  <span className="cop-case-list__title">{title}</span>
                  <Icon name="arrow-up-right" size={18} />
                </div>
              );
            }
            return (
              <div key={block.id} className="cop-case-list__row">
                <button
                  type="button"
                  className="cop-case-list__row-trigger"
                  aria-expanded={openIndex === index}
                  onClick={() => setOpenIndex((current) => (current === index ? null : index))}
                >
                  <span className="cop-case-list__tag">{tag}</span>
                  <span className="cop-case-list__title">{title}</span>
                  <Icon name={openIndex === index ? "minus" : "plus"} size={18} />
                </button>
                {openIndex === index && excerpt && <p className="cop-case-list__excerpt">{excerpt}</p>}
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
