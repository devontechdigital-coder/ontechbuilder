# Copora

A bold, editorial theme for consulting agencies and professional
service businesses — confident grotesk typography, image-led
storytelling, a keyboard-accessible mega-menu header, and rich proof
sections (stats, case studies, testimonials, team). Built to match a
business-consulting reference design, with every color, font, image
and line of copy left fully reconfigurable.

- **Theme name:** Copora
- **Version:** 1.2.0
- **Required theme engine:** ^1.0.0

This package is a **portable frontend theme only** — no backend,
database, authentication, or infrastructure code. The host platform
handles installation, versioning, publishing, preview, and content
storage.

## Structure

```
copora/
├── theme.config.ts             Theme manifest read by the host platform
├── config/
│   ├── settings.schema.ts      Global settings exposed to the visual editor
│   └── settings.default.ts     Default values + the ThemeSettings type
├── layout/
│   ├── ThemeLayout.tsx          Injects design tokens, wraps header/footer/floating action
│   └── defaultPartials.ts       Ready-to-use default Header/Footer partial instances
├── partials/                    Header/Footer template partials, not body sections
│   ├── Header/                   Nav + advanced mega menu
│   └── Footer/
├── templates/
│   ├── index.tsx                Homepage
│   ├── about.tsx                 About page
│   ├── case-studies.tsx          Case studies index (grid + pagination)
│   ├── blog.tsx                  Blog index
│   ├── contact.tsx               Contact page
│   ├── page.tsx                  Generic content page
│   ├── search.tsx                Search results
│   └── 404.tsx                   Not found
├── sections/                    One folder per body section, each with Section.tsx + schema.ts
│   ├── AnnouncementBar/
│   ├── Hero/
│   ├── PageIntro/
│   ├── LogoCloud/
│   ├── ServiceCards/
│   ├── StatsRow/
│   ├── SplitContent/
│   ├── ProcessDark/
│   ├── FeaturedCaseStudy/
│   ├── CaseStudyList/
│   ├── CaseStudyGrid/
│   ├── TestimonialShowcase/
│   ├── TeamGrid/
│   ├── MissionVision/
│   ├── BlogGrid/
│   ├── ContactForm/
│   ├── LocationCard/
│   └── CtaBanner/
├── components/                  Shared, presentation-only building blocks
│   ├── Button.tsx, Container.tsx, ThemeImg.tsx, Avatar.tsx, Icon.tsx, FloatingActions.tsx
│   ├── ScrollRevealController.tsx  Fades/rises sections into view once (see Motion setting)
│   ├── blockHelpers.ts          Turns raw settings/blocks into display data — see below
│   ├── sectionRegistry.tsx      Maps a section schema id → its component
│   └── types.ts                 Local content-shape types
├── assets/styles/theme.css      Design tokens (CSS variables) + all section styles
├── locales/en.json              Reusable UI strings
└── README.md
```

## Templates

Every template is a thin, editable composition of sections (an ordered
`{ id, type, props }` array rendered through `RenderSections`) with
sample content matching the reference design — nothing is hardcoded
into a single monolithic page component.

| Template | Purpose |
| --- | --- |
| `index.tsx` | Homepage: hero → logo cloud → services → stats → about split → process → featured case study → case study list → testimonials → blog → CTA. |
| `about.tsx` | Page intro → stats/CTA row → about split (with signature) → mission & vision → team grid → CTA. |
| `case-studies.tsx` | Case study grid with pagination. |
| `blog.tsx` | Page intro → blog grid. |
| `contact.tsx` | Contact form → location card → CTA. |
| `page.tsx` | Generic interior page — title, rich body, optional trailing sections. |
| `search.tsx` | Search results, driven entirely by host-supplied results. |
| `404.tsx` | Not found page. |

## Sections

Every section's props mirror its own `schema.ts` fields and `blocks`
directly — flat settings (`buttonLabel`/`buttonHref`, not a pre-built
`button` object) and, where a section has blocks, a raw
`blocks: RawBlock[]` array (`{ id, type, ...settings }`, exactly as
stored). Each component composes whatever nested shape it actually
needs — a link, an extracted image, a filtered sub-list — internally,
using the small helpers in `components/blockHelpers.ts`
(`optionalLink`, `asImage`, `blocksOfType`, `parseNestedLinks`, …).
**A host only needs to forward a section's `settings` and `blocks` as
stored — no per-section adapter or pre-processing is required for any
section in this theme.**

| Section | What it covers |
| --- | --- |
| Header | Partial: logo, nav blocks, **submenus in two styles** (simple dropdown or full mega panel with columns + a featured promo), phone, CTA button, mobile menu |
| Hero | Headline/CTA + image collage with an overlaid testimonial card and a trust-logo row |
| Page intro | Centered heading/description + full-width banner image (About, Blog) |
| Logo cloud | Partner/client logo row |
| Service cards | Image-led service card grid with label pills |
| Stats row | Mixed stat tiles and an optional dark CTA tile (same section powers both the homepage's 3-stat row and the About page's stat/CTA/stat row) |
| Split content | Reusable image+text split, with an optional secondary image and signature block |
| Process (dark) | Dark intro + an accessible accordion of process steps |
| Featured case study | One large banner image with a title overlay |
| Case study list | Expandable rows, with a "highlighted" row style for direct links |
| Case study grid | Grid listing with prev/next pagination |
| Testimonial showcase | Rating summary + quote card + supporting photo grid, with next/prev |
| Team grid | Photo cards with a name/role tag overlay |
| Mission & vision | Plain card next to an image card with a bullet list |
| Blog grid | Heading + "See all" action + post card grid |
| Contact form | Real, accessible form using native browser submission (`<form action>` — no client-side network call from the theme itself) |
| Location card | Image + address/email card |
| CTA banner | Closing call-to-action with an avatar stack and an image button overlay |
| Footer | Partial: newsletter signup, link columns with recursive nested links, social icons, recent-works thumbnail grid |

## Submenus, specifically

Both `Header` and `Footer` support real submenus:

- **Header** — a `nav_menu` block's `style` field picks the
  presentation: `simple` is a compact, left-aligned dropdown (the
  default — About/Case Studies/Blog in the sample content each use
  it); `mega` is the full-width panel with grouped columns and an
  optional featured image/title/description/link (used by the sample
  "Pages" item). Submenu data is a recursive `items` array, where each
  item can contain `label`, `href`, and `children`; there is no fixed
  depth limit. Visual editors can use the `itemsJson` textarea for the
  same shape.
- **Footer** — link columns use recursive `links` arrays with
  `label`, `href`, and `children`, matching the header menu shape.
  Visual editors can use the `linksJson` textarea for the same nested
  JSON shape. See `partials/Footer/schema.ts` for a working example.

Both close on outside click and `Escape`; the header's is additionally
keyboard-operable (`aria-expanded`/`aria-haspopup`) and degrades to a
per-item accordion inside the mobile slide-down menu. Toggle
`enableMegaMenu` in global settings to force every Header menu block
down to a plain link site-wide (e.g. for a minimal build).

## Global settings

Defined in `config/settings.schema.ts` / `settings.default.ts`, 38
settings across 9 groups:

- **Color palette** — primary, secondary/highlight, text-link,
  background, card surface, alternate-section surface, dark-section,
  text, muted text, border (10 colors total, so light/dark rhythm and
  accent contrast are real choices, not one accent color reused
  everywhere).
- **Layout** — container width, section spacing, corner radius.
- **Typography** — heading/body font are real **pickers** (Sora, Space
  Grotesk, Manrope, Plus Jakarta Sans, Poppins, Playfair Display,
  Inter, IBM Plex Sans — every option is `@import`ed in `theme.css`),
  plus weight, base size, scale ratio, letter spacing, line height.
- **Buttons** — style, corner radius, size, hover effect (fade / lift / none).
- **Cards & imagery** — shadow intensity (none/soft/medium/strong) and
  a hover-lift toggle, applied theme-wide via `data-card-shadow` /
  `data-card-hover-lift` on the root element.
- **Header** — sticky, transparent-over-hero, height, logo width,
  submenu toggle.
- **Footer** — style, newsletter, recent-works grid.
- **Motion** — scroll-reveal toggle + transition speed (see below).
- **Floating actions** — scroll-to-top visibility.

All become `--cop-*` CSS custom properties (or `data-*` attributes for
the non-color toggles) in `layout/ThemeLayout.tsx`.

## Motion

`components/ScrollRevealController.tsx` is a small, dependency-free
client component mounted once by `ThemeLayout`. It observes the direct
children of `<main>` (i.e. each top-level section) and adds
`.cop-in-view` the first time each one enters the viewport, which
`theme.css` uses to fade + rise it into place — one observer for the
whole page, not per-section logic, and it unobserves after the first
reveal so it never re-triggers. Respects `prefers-reduced-motion:
reduce` (skips the effect entirely) and the "Fade + rise sections in on
scroll" global setting.

## Responsive behavior

Handled entirely in `theme.css`: the header collapses to a slide-down
menu (mega menus become in-place accordions) under 860px, every
split/grid layout stacks to one column, the hero's floating testimonial
card and secondary image drop out of absolute positioning into normal
flow, and the footer's four columns collapse to one.

## Accessibility

Semantic landmarks, a single `h1` per page, `aria-expanded` /
`aria-haspopup` / `role="menu"` on the mega menu, full keyboard support
(Enter/Space to open a menu, Escape and outside-click to close),
required `alt` text on every image, visible focus rings, and a contact
form built from real `<label>`-associated fields rather than
placeholder-only inputs.

## Performance notes

No animation, carousel, or icon-library dependency. The mega menu,
accordions, testimonial paging and mobile menu all use plain
`useState` — no state-management library. The contact form submits via
a native HTML `<form>` (`action`/`method`), so no client-side network
call is embedded in the theme itself; the host wires `actionUrl` to
its own endpoint.

## Changelog

**1.2.0**
- **Systemic fix, every section:** every section's props now mirror its
  own schema/blocks directly (flat fields like `buttonLabel`/`buttonHref`,
  raw `blocks: RawBlock[]` arrays) and compose whatever nested shape it
  needs — a `LinkValue`, an extracted image, a filtered sub-list —
  *internally*, using the new `components/blockHelpers.ts`. Previously
  most sections (Footer, StatsRow, TestimonialShowcase, Hero, LogoCloud,
  MissionVision, CtaBanner, CaseStudyList/Grid, BlogGrid, ContactForm,
  ServiceCards, TeamGrid, ProcessDark — in addition to Header, fixed in
  1.1.0) expected a host to pre-compose that shape before rendering,
  which nothing did. A host that forwards a section's `settings` and
  `blocks` as stored now works correctly for every section, with zero
  bespoke per-section adapter code required.
- **Submenus everywhere, two styles:** `Header`'s `nav_menu` block now
  has a `style` field — `simple` (a compact classic dropdown, the new
  default for ordinary items) or `mega` (the full-width panel with
  columns + a featured promo card, for a hub-like item). The default
  nav now demonstrates both: Home is a plain link, About/Case Studies/
  Blog each carry a real "simple" submenu, and Pages is the full mega
  menu.
- **Footer submenus:** `Footer` link columns now support recursive
  `links` arrays, where each link can contain `label`, `href`, and
  `children`. Visual editors can use the `linksJson` textarea for the
  same shape; older indented text is still accepted as a fallback.
- **`layout/defaultPartials.ts`** (new): ready-to-use `defaultHeaderPartial`
  / `defaultFooterPartial` instances matching the new raw-blocks
  contract, for a host that has no header/footer configuration saved
  yet, or wants a concrete example of the expected shape.
- **Settings roughly doubled** (14 → 38, across 9 groups): a full color
  palette (added secondary/link/alt-surface colors), curated font
  *pickers* for heading/body (Sora, Space Grotesk, Manrope, Plus
  Jakarta Sans, Poppins, Playfair Display, Inter, IBM Plex Sans — all
  `@import`ed in `theme.css` so every option renders correctly), a
  button hover-effect setting, a new "Cards & imagery" group (shadow
  intensity + hover-lift), and a "Motion" group (scroll-reveal toggle +
  transition speed).
- **Scroll reveal:** a small, dependency-free `ScrollRevealController`
  (`components/ScrollRevealController.tsx`) fades + rises each
  top-level section into place the first time it enters the viewport —
  one observer, respects `prefers-reduced-motion`, and needs no
  per-section code.
- Default heading font changed from Inter (matching body) to Sora, so
  headings and body text read as a deliberate pairing rather than one
  face doing double duty.

**1.1.0**
- Fixed `Header`'s `navItems`/mega-menu prop mismatch (see 1.2.0 note
  above — the same class of bug, fixed there first and then applied
  theme-wide).
- `header` and `footer` added to `components/sectionRegistry.tsx` for
  hosts that render every section through one generic registry.
- Theme now loads its own Inter font file instead of assuming the host
  bundles it.
- Default heading weight raised from Semibold to Bold (`700`).

**1.0.0**
- Initial release.

## Runtime safety

No `eval`, no dynamic `Function` construction, no filesystem or
`child_process` access, no `process.env`, and no database client
anywhere in this package — sections and templates only render props
handed to them by the host platform.
