import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-about",
  name: "Realty about",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Shaping residential and commercial" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "spaces with expertise" },
    { type: "text", id: "ctaLabel", label: "CTA button label", default: "Contact Us" },
    { type: "url", id: "ctaHref", label: "CTA button link", default: "/contact" },
    { type: "text", id: "phone", label: "Phone number", default: "+1 (234) 567-890" },
    { type: "image", id: "image", label: "Main image" },
    { type: "text", id: "badgeValue", label: "Badge value", default: "100%+" },
    { type: "text", id: "badgeLabel", label: "Badge label", default: "Satisfaction Rate" },
  ],
  blocks: [
    {
      type: "feature",
      name: "Feature",
      settings: [
        { type: "text", id: "title", label: "Title", default: "Industry Experts" },
        { type: "textarea", id: "description", label: "Description", default: "Decades of combined experience across residential and commercial builds." },
      ],
    },
    {
      type: "thumb",
      name: "Collage thumbnail",
      settings: [{ type: "image", id: "image", label: "Image" }],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "feature", settings: { title: "Industry Experts", description: "Decades of combined experience across residential and commercial builds." } },
    { type: "feature", settings: { title: "Trusted Builders", description: "Strong safety standards and rigorous quality control on every site." } },
    { type: "feature", settings: { title: "Modern Designers", description: "Client-focused design that balances form, function, and budget." } },
    { type: "thumb", settings: {} },
    { type: "thumb", settings: {} },
  ],
};

export default schema;
