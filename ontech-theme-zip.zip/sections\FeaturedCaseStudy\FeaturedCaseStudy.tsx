import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import type { ThemeImage } from "../../components/types";

export interface FeaturedCaseStudyProps {
  eyebrow?: string;
  heading: string;
  image?: ThemeImage;
  title: string;
}

/** "Featured case study" - one large banner image with a title overlay card. */
export function FeaturedCaseStudy({ eyebrow, heading, image, title }: FeaturedCaseStudyProps) {
  return (
    <section className="cop-section cop-featured-case">
      <Container width="wide">
        {(eyebrow || heading) && (
          <div className="cop-section__heading">
            {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
            {heading && <h2>{heading}</h2>}
          </div>
        )}
        <div className="cop-featured-case__banner">
          <ThemeImg image={image} ratio="16:9" placeholderLabel="Case study image" />
          <span className="cop-featured-case__card">
            <span className="cop-featured-case__title">{title}</span>
          </span>
        </div>
      </Container>
    </section>
  );
}
