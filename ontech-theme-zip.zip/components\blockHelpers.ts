import type { LinkValue, ThemeImage } from "./types";

/**
 * components/blockHelpers.ts
 *
 * The theme's schemas intentionally store flat, primitive fields
 * (`buttonLabel` + `buttonHref`, a `blocks` array mixing several block
 * `type`s) because that is what a visual editor's generic controls
 * produce. Section components, however, often want a composed shape
 * (`button: { label, href }`, "just the testimonial blocks", "just the
 * image out of each block"). These helpers do that composition INSIDE
 * the theme package, so no host integration needs bespoke per-section
 * adapter code — a host that forwards a section's `settings` and
 * `blocks` verbatim is enough for every section in this theme.
 */

/** A block in its raw stored shape: an id, a type, and its settings spread flat. */
export interface RawBlock {
  id: string;
  type: string;
  [field: string]: unknown;
}

/** Builds a LinkValue from a label/href pair only when both are present — otherwise undefined (nothing renders a half-formed link). */
export function optionalLink(label: unknown, href: unknown): LinkValue | undefined {
  const l = typeof label === "string" ? label.trim() : "";
  const h = typeof href === "string" ? href.trim() : "";
  return l && h ? { label: l, href: h } : undefined;
}

/** Same as optionalLink, but a link is valid with just an href (label is supplied separately, e.g. a card title). */
export function hrefOnly(href: unknown): string | undefined {
  const h = typeof href === "string" ? href.trim() : "";
  return h || undefined;
}

export function asImage(value: unknown): ThemeImage | undefined {
  if (value && typeof value === "object" && typeof (value as ThemeImage).src === "string" && (value as ThemeImage).src) {
    return value as ThemeImage;
  }
  return undefined;
}

export function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

export function asNumber(value: unknown, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function asBoolean(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}

/** Filters a mixed blocks array down to one type, keeping full type inference on the result. */
export function blocksOfType(blocks: RawBlock[], type: string): RawBlock[] {
  return blocks.filter((block) => block.type === type);
}

export interface NestedLink extends LinkValue {
  children?: LinkValue[];
}

/**
 * Parses the footer's "Links" textarea format:
 *   Label|/url
 *     Label|/url      (indented with 2+ leading spaces = a submenu item under the line above)
 *   Label|/url
 *
 * This is what gives footer columns real, nested sub-links from plain
 * text, with no extra field type — indentation depth beyond one level
 * is flattened into the immediate parent rather than erroring, so a
 * mis-indented line still renders (as a slightly-wrong but visible
 * link) instead of disappearing.
 */
export function parseNestedLinks(text: unknown): NestedLink[] {
  if (typeof text !== "string" || !text.trim()) return [];
  const links: NestedLink[] = [];
  let lastTopLevel: NestedLink | null = null;

  for (const rawLine of text.split("\n")) {
    if (!rawLine.trim()) continue;
    const indented = /^\s{2,}/.test(rawLine);
    const [labelRaw, hrefRaw] = rawLine.trim().split("|");
    const label = labelRaw?.trim();
    const href = hrefRaw?.trim();
    if (!label || !href) continue;

    if (indented && lastTopLevel) {
      lastTopLevel.children = [...(lastTopLevel.children ?? []), { label, href }];
    } else {
      const link: NestedLink = { label, href };
      links.push(link);
      lastTopLevel = link;
    }
  }
  return links;
}
