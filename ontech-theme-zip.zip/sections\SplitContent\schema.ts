import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "split-content",
  name: "Image + text split",
  category: "Content",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "About Copora" },
    { type: "text", id: "heading", label: "Heading", default: "Driven by insight. Focused on results" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "We provide tailored consulting solutions to help businesses overcome challenges, seize opportunities, and achieve sustainable growth.",
    },
    { type: "text", id: "buttonLabel", label: "Button label", default: "More about us" },
    { type: "url", id: "buttonHref", label: "Button link", default: "/about" },
    { type: "image", id: "image", label: "Main image" },
    {
      type: "select",
      id: "imagePosition",
      label: "Image position",
      options: [
        { value: "right", label: "Right" },
        { value: "left", label: "Left" },
      ],
      default: "right",
    },
    {
      type: "select",
      id: "imageAspectRatio",
      label: "Image aspect ratio",
      options: [
        { value: "4:3", label: "4:3" },
        { value: "1:1", label: "Square" },
        { value: "3:4", label: "3:4" },
        { value: "16:9", label: "16:9" },
      ],
      default: "4:3",
    },
    { type: "image", id: "secondaryImage", label: "Secondary image (optional)" },
    { type: "text", id: "signatureName", label: "Signature name (optional)", default: "" },
    { type: "text", id: "signatureRole", label: "Signature role (optional)", default: "" },
  ],
};

export default schema;
