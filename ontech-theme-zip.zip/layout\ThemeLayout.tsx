import * as React from "react";
import type { ThemeSettings } from "../config/settings.default";
import { FloatingActions } from "../components/FloatingActions";
import { ScrollRevealController } from "../components/ScrollRevealController";

export interface ThemeLayoutProps {
  settings: ThemeSettings;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  children: React.ReactNode;
}

/**
 * The single place global settings become CSS custom properties. Every
 * section reads colors, spacing and typography through these variables
 * (see assets/styles/theme.css) rather than hardcoding values, so a
 * merchant editing global settings updates the whole site at once.
 */
export function ThemeLayout({ settings, header, footer, children }: ThemeLayoutProps) {
  const styleVars: React.CSSProperties = {
    ["--cop-color-primary" as string]: settings.colorPrimary,
    ["--cop-color-primary-contrast" as string]: settings.colorPrimaryContrast,
    ["--cop-color-secondary" as string]: settings.colorSecondary,
    ["--cop-color-link" as string]: settings.colorLink,
    ["--cop-color-background" as string]: settings.colorBackground,
    ["--cop-color-surface" as string]: settings.colorSurface,
    ["--cop-color-surface-alt" as string]: settings.colorSurfaceAlt,
    ["--cop-color-dark" as string]: settings.colorDark,
    ["--cop-color-text" as string]: settings.colorText,
    ["--cop-color-muted" as string]: settings.colorMutedText,
    ["--cop-color-border" as string]: settings.colorBorder,
    ["--cop-container-width" as string]:
      settings.containerWidth === "narrow"
        ? "960px"
        : settings.containerWidth === "wide"
        ? "1400px"
        : settings.containerWidth === "full"
        ? "100%"
        : "1240px",
    ["--cop-section-spacing" as string]: `${settings.sectionSpacing}px`,
    ["--cop-radius" as string]: `${settings.borderRadius}px`,
    ["--cop-font-heading" as string]: settings.headingFont,
    ["--cop-font-body" as string]: settings.bodyFont,
    ["--cop-heading-weight" as string]: settings.headingWeight,
    ["--cop-base-font-size" as string]: `${settings.baseFontSize}px`,
    ["--cop-heading-font-size" as string]: `${settings.headingFontSize}px`,
    ["--cop-heading-scale" as string]: `${settings.headingScale}`,
    ["--cop-heading-tracking" as string]: `${settings.headingLetterSpacing}px`,
    ["--cop-line-height" as string]: `${settings.lineHeight}`,
    ["--cop-button-radius" as string]: `${settings.buttonRadius}px`,
    ["--cop-header-height" as string]: `${settings.headerHeight}px`,
    ["--cop-logo-width" as string]: `${settings.logoWidth}px`,
    ["--cop-mobile-logo-width" as string]: `${settings.mobileLogoWidth}px`,
    ["--cop-transition-speed" as string]: `${settings.transitionSpeed}ms`,
  } as React.CSSProperties;

  return (
    <div
      id="top"
      className="cop-theme"
      data-button-style={settings.buttonStyle}
      data-button-hover={settings.buttonHoverEffect}
      data-card-shadow={settings.cardShadow}
      data-card-hover-lift={settings.cardHoverLift ? "true" : "false"}
      data-scroll-reveal={settings.enableScrollReveal ? "true" : "false"}
      style={styleVars}
    >
      {header}
      <main className="cop-main">{children}</main>
      {footer}
      <FloatingActions show={settings.showScrollTop} />
      <ScrollRevealController enabled={settings.enableScrollReveal} />
    </div>
  );
}
