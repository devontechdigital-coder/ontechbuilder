import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "header",
  name: "Header",
  category: "Header",
  settings: [
    { type: "image", id: "logoImage", label: "Logo image (desktop)", info: "Leave empty to use the text wordmark below." },
    { type: "image", id: "mobileLogoImage", label: "Logo image (mobile)", info: "Optional — a simplified mark for small screens. Falls back to the desktop logo image (or wordmark) when empty." },
    { type: "text", id: "logoText", label: "Wordmark text", default: "Copora" },
    { type: "text", id: "phone", label: "Phone number", default: "+123 456 7891" },
    { type: "text", id: "ctaLabel", label: "CTA button label", default: "Contact now" },
    { type: "url", id: "ctaHref", label: "CTA button link", default: "#contact" },
    {
      type: "select",
      id: "layout",
      label: "Header layout",
      options: [
        { value: "classic", label: "Classic (logo left, nav center, actions right)" },
        { value: "centered", label: "Centered (logo center, nav split around it)" },
      ],
      default: "classic",
    },
    {
      type: "select",
      id: "mobileMenuStyle",
      label: "Mobile menu style",
      options: [
        { value: "inline", label: "Inline dropdown (below header)" },
        { value: "overlay", label: "Full-screen overlay" },
      ],
      default: "inline",
    },
    { type: "checkbox", id: "sticky", label: "Stick to top on scroll", default: true },
    { type: "checkbox", id: "transparentOnHero", label: "Transparent over the hero section", default: false },
    { type: "checkbox", id: "showBorder", label: "Show bottom border", default: true },
    { type: "color", id: "backgroundColor", label: "Background color override", info: "Leave empty to use the theme's global background/text colors." },
    { type: "color", id: "textColor", label: "Text color override", info: "Leave empty to use the theme's global background/text colors." },
  ],
  blocks: [
    {
      type: "nav_link",
      name: "Nav link",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Menu item" },
        { type: "url", id: "href", label: "Link", default: "#" },
      ],
    },
    {
      type: "nav_menu",
      name: "Nav item with submenu",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Pages" },
        {
          type: "select",
          id: "style",
          label: "Submenu style",
          options: [
            { value: "simple", label: "Simple dropdown" },
            { value: "mega", label: "Full mega menu (columns + featured panel)" },
          ],
          default: "simple",
        },
        {
          type: "textarea",
          id: "itemsJson",
          label: "Submenu links",
          info: "JSON array of menu items. Each item supports label, href, and children for unlimited nested levels.",
          default: '[{"label":"Overview","href":"/"}]',
        },
        { type: "image", id: "featuredImage", label: "Featured panel image (mega style only)" },
        { type: "text", id: "featuredTitle", label: "Featured panel title (mega style only)", default: "" },
        { type: "textarea", id: "featuredDescription", label: "Featured panel description (mega style only)", default: "" },
        { type: "text", id: "featuredLinkLabel", label: "Featured panel link label (mega style only)", default: "" },
        { type: "url", id: "featuredLinkHref", label: "Featured panel link URL (mega style only)", default: "" },
      ],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    {
      type: "nav_link",
      settings: { label: "Home", href: "/" },
    },
    {
      type: "nav_menu",
      settings: {
        label: "About",
        style: "simple",
        items: [
          {
            label: "Company",
            href: "/about",
            children: [
              { label: "Our Story", href: "/about#story" },
              { label: "Mission & Vision", href: "/about#mission" },
              {
                label: "Our Team",
                href: "/about#team",
                children: [
                  { label: "Leadership", href: "/about#leadership" },
                  { label: "Consultants", href: "/about#consultants" },
                ],
              },
            ],
          },
        ],
      },
    },
    {
      type: "nav_menu",
      settings: {
        label: "Case Studies",
        style: "simple",
        items: [
          { label: "All Case Studies", href: "/case-studies" },
          { label: "Featured", href: "/case-studies#featured" },
          {
            label: "By Industry",
            href: "/case-studies#industry",
            children: [
              { label: "Healthcare", href: "/case-studies/healthcare" },
              { label: "Retail", href: "/case-studies/retail" },
              { label: "SaaS", href: "/case-studies/saas" },
            ],
          },
        ],
      },
    },
    {
      type: "nav_menu",
      settings: {
        label: "Blog",
        style: "simple",
        items: [
          { label: "All Posts", href: "/blog" },
          {
            label: "Topics",
            href: "/blog",
            children: [
              { label: "Growth", href: "/blog?tag=growth" },
              { label: "Strategy", href: "/blog?tag=strategy" },
              { label: "Marketing", href: "/blog?tag=marketing" },
            ],
          },
        ],
      },
    },
    {
      type: "nav_menu",
      settings: {
        label: "Pages",
        style: "mega",
        items: [
          {
            label: "Pages",
            children: [
              { label: "Home", href: "/" },
              { label: "About", href: "/about" },
              {
                label: "Services",
                href: "/services",
                children: [
                  { label: "Business Strategy", href: "/services/strategy" },
                  { label: "Process Optimization", href: "/services/process" },
                  { label: "Financial Advisory", href: "/services/financial" },
                ],
              },
              { label: "Blog", href: "/blog" },
              { label: "Blog Details", href: "/blog/post" },
            ],
          },
          {
            label: "Other Pages",
            children: [
              { label: "Case Studies", href: "/case-studies" },
              { label: "Contact", href: "/contact" },
              { label: "Error 404", href: "/404" },
              { label: "Password Protected", href: "/protected" },
              { label: "Support", href: "/support" },
            ],
          },
        ],
        featuredTitle: "Book a free consultation",
        featuredDescription: "Talk to our consultants about your growth strategy.",
        featuredLinkLabel: "Get in touch",
        featuredLinkHref: "/contact",
      },
    },
  ],
};

export default schema;
