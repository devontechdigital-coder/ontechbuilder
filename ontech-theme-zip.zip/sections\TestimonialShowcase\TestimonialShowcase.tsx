"use client";

import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Avatar } from "../../components/Avatar";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface TestimonialShowcaseProps {
  eyebrow?: string;
  heading: string;
  description?: string;
  ratingValue: string;
  reviewCount: string;
  /** Raw blocks mixing "testimonial" and "gallery_image" types — filtered internally. */
  blocks: RawBlock[];
}

/** "Proven impact, shared experiences" — rating summary + a quote card next to a photo grid. */
export function TestimonialShowcase({ eyebrow, heading, description, ratingValue, reviewCount, blocks }: TestimonialShowcaseProps) {
  const [index, setIndex] = React.useState(0);
  const testimonialBlocks = blocksOfType(blocks, "testimonial");
  const galleryImages = blocksOfType(blocks, "gallery_image")
    .map((block) => asImage(block.image))
    .filter((image): image is ThemeImage => Boolean(image));

  const current = testimonialBlocks[index];

  return (
    <section className="cop-section cop-testimonial-showcase">
      <Container width="wide">
        <div className="cop-section__heading cop-section__heading--center">
          {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
          <h2>{heading}</h2>
          {description && <p className="cop-section__description">{description}</p>}
          <div className="cop-testimonial-showcase__rating">
            <strong>{ratingValue}</strong>
            <span className="cop-testimonial-showcase__stars">
              {Array.from({ length: 5 }).map((_, i) => (
                <Icon key={i} name="star" size={14} />
              ))}
            </span>
            <span>{reviewCount} reviews</span>
          </div>
        </div>

        {current && (
          <div className="cop-testimonial-showcase__row">
            <div className="cop-testimonial-showcase__quote">
              <p>&ldquo;{asString(current.quote)}&rdquo;</p>
              <div className="cop-testimonial-showcase__person">
                <Avatar image={asImage(current.avatar)} size={40} />
                <span>
                  <strong>{asString(current.name)}</strong>
                  <em>{asString(current.role)}</em>
                </span>
              </div>
              {testimonialBlocks.length > 1 && (
                <div className="cop-testimonial-showcase__nav">
                  <button type="button" aria-label="Previous testimonial" onClick={() => setIndex((i) => (i - 1 + testimonialBlocks.length) % testimonialBlocks.length)}>
                    <Icon name="chevron-left" size={16} />
                  </button>
                  <button type="button" aria-label="Next testimonial" onClick={() => setIndex((i) => (i + 1) % testimonialBlocks.length)}>
                    <Icon name="chevron-right" size={16} />
                  </button>
                </div>
              )}
            </div>
            {galleryImages.length > 0 && (
              <div className="cop-testimonial-showcase__gallery">
                {galleryImages.map((image, i) => (
                  <ThemeImg key={image.src + i} image={image} ratio="1:1" placeholderLabel="Photo" />
                ))}
              </div>
            )}
          </div>
        )}
      </Container>
    </section>
  );
}
