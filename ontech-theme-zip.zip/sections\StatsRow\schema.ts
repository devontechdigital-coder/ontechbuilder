import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "stats-row",
  name: "Stats row",
  category: "Content",
  settings: [],
  blocks: [
    {
      type: "stat",
      name: "Stat tile",
      settings: [
        { type: "text", id: "eyebrow", label: "Eyebrow", default: "Business transformed" },
        { type: "text", id: "value", label: "Value", default: "260+" },
        { type: "textarea", id: "description", label: "Description", default: "Helping companies grow and perform better." },
        {
          type: "select",
          id: "tone",
          label: "Tone",
          options: [
            { value: "surface", label: "Light surface" },
            { value: "dark", label: "Dark" },
          ],
          default: "surface",
        },
      ],
    },
    {
      type: "cta",
      name: "CTA tile",
      settings: [
        { type: "text", id: "heading", label: "Heading", default: "24/7 support to keep your business moving forward" },
        { type: "text", id: "buttonLabel", label: "Button label", default: "Get in touch" },
        { type: "url", id: "buttonHref", label: "Button link", default: "/contact" },
      ],
    },
  ],
  maxBlocks: 3,
  defaultBlocks: [
    { type: "stat", settings: { eyebrow: "Business transformed", value: "260+", description: "Helping companies grow and perform better.", tone: "surface" } },
    { type: "stat", settings: { eyebrow: "Client satisfaction rate", value: "95%", description: "Trusted and recommended by our clients.", tone: "dark" } },
    { type: "stat", settings: { eyebrow: "Revenue growth generated", value: "$150M", description: "Delivering measurable financial impact.", tone: "surface" } },
  ],
};

export default schema;
