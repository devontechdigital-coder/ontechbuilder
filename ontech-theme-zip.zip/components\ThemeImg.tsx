import * as React from "react";
import type { AspectRatio, ThemeImage } from "./types";

interface ThemeImgProps extends React.HTMLAttributes<HTMLDivElement> {
  image?: ThemeImage;
  ratio?: AspectRatio;
  placeholderLabel?: string;
}

const ratioClass: Record<AspectRatio, string> = {
  auto: "",
  "1:1": "cop-ratio--1-1",
  "4:3": "cop-ratio--4-3",
  "3:4": "cop-ratio--3-4",
  "3:2": "cop-ratio--3-2",
  "16:9": "cop-ratio--16-9",
  "9:16": "cop-ratio--9-16",
};

/**
 * Renders a host-supplied image inside a ratio-constrained frame. Falls
 * back to a labeled placeholder before an image is chosen — never
 * hardcodes an external image URL.
 */
export function ThemeImg({ image, ratio = "auto", placeholderLabel = "Image", className = "", ...rest }: ThemeImgProps) {
  return (
    <div className={`cop-image-frame ${ratioClass[ratio]} ${className}`.trim()} {...rest}>
      {image?.src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={image.src} alt={image.alt} loading="lazy" />
      ) : (
        <div className="cop-image-frame__placeholder" role="img" aria-label={placeholderLabel}>
          <span>{placeholderLabel}</span>
        </div>
      )}
    </div>
  );
}
