import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Avatar } from "../../components/Avatar";
import { asImage, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface CtaBannerProps {
  heading: string;
  description?: string;
  avatarLabel?: string;
  image?: ThemeImage;
  buttonLabel?: string;
  buttonHref?: string;
  /** Raw avatar blocks — each block's `image` field is pulled out internally. */
  avatarBlocks: RawBlock[];
}

/** The closing "Let's build something that moves your business forward" banner. */
export function CtaBanner({ heading, description, avatarLabel, image, buttonLabel, buttonHref, avatarBlocks }: CtaBannerProps) {
  const button = optionalLink(buttonLabel, buttonHref);
  const avatars = avatarBlocks.map((block) => asImage(block.image)).filter((img): img is ThemeImage => Boolean(img));
  return (
    <section className="cop-section cop-cta-banner">
      <Container width="wide" className="cop-cta-banner__grid">
        <div className="cop-cta-banner__content">
          <h2>{heading}</h2>
          {description && <p>{description}</p>}
          {avatars.length > 0 && (
            <div className="cop-cta-banner__avatars">
              {avatarLabel && <span>{avatarLabel}</span>}
              <span className="cop-cta-banner__avatar-stack">
                {avatars.map((avatar, index) => (
                  <Avatar key={avatar.src + index} image={avatar} size={32} />
                ))}
              </span>
            </div>
          )}
        </div>
        <div className="cop-cta-banner__media">
          <ThemeImg image={image} ratio="4:3" placeholderLabel="CTA image" />
          {button && (
            <a href={button.href} className="cop-cta-banner__pill">
              {button.label}
            </a>
          )}
        </div>
      </Container>
    </section>
  );
}
