import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface CaseStudiesTemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

export const defaultCaseStudiesSections: SectionInstance[] = [
  {
    id: "case-studies-grid",
    type: "case-study-grid",
    props: {
      heading: "Our case studies",
      columns: 3,
      currentPage: 1,
      totalPages: 2,
      nextPageHref: "/case-studies?page=2",
      blocks: [
        block("case_study_card", { tag: "Growth", date: "June 20, 2025", title: "Why your company needs a strategic roadmap in 2025", linkHref: "/blog/strategic-roadmap-2025" }),
        block("case_study_card", { tag: "Strategy", date: "June 20, 2025", title: "From goals to KPIs: turning vision into measurable success", linkHref: "/blog/goals-to-kpis" }),
        block("case_study_card", { tag: "Marketing", date: "June 20, 2025", title: "5 growth strategies every modern business should know", linkHref: "/blog/growth-strategies-2025" }),
        block("case_study_card", { tag: "Growth", date: "June 20, 2025", title: "Digital transformation for service-based businesses", linkHref: "/blog/digital-transformation-services" }),
        block("case_study_card", { tag: "Strategy", date: "June 20, 2025", title: "Customer experience: turning satisfaction into loyalty", linkHref: "/blog/cx-satisfaction-loyalty" }),
        block("case_study_card", { tag: "Marketing", date: "June 20, 2025", title: "A/B testing the modern homepage", linkHref: "/blog/ab-testing-homepage" }),
      ],
    },
  },
];

export default function CaseStudiesTemplate({ sections = defaultCaseStudiesSections }: CaseStudiesTemplateProps) {
  return <RenderSections sections={sections} />;
}
