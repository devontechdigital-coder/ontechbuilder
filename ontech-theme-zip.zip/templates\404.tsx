import * as React from "react";
import { Container } from "../components/Container";
import { Button } from "../components/Button";

export interface NotFoundTemplateProps {
  heading?: string;
  description?: string;
  homeHref?: string;
  homeLabel?: string;
}

export default function NotFoundTemplate({
  heading = "Page not found",
  description = "The page you're looking for may have been moved or no longer exists.",
  homeHref = "/",
  homeLabel = "Back to homepage",
}: NotFoundTemplateProps) {
  return (
    <section className="cop-section cop-not-found">
      <Container width="narrow" className="cop-not-found__inner">
        <p className="cop-eyebrow">404</p>
        <h1>{heading}</h1>
        <p>{description}</p>
        <Button href={homeHref} variant="primary" size="lg">
          {homeLabel}
        </Button>
      </Container>
    </section>
  );
}
