import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface Home1TemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

/** Every image in this template's sample content points at the theme's bundled placeholder graphic. */
function img(alt: string) {
  return { src: "assets/img/default.svg", alt };
}

/**
 * Sample content for the "Dentora" dental-clinic homepage — a second,
 * differently-styled homepage living alongside the default `index`
 * template. Every value is editable via each section's schema.ts; this
 * template uses its own Header/Footer partials (`header-dentora` /
 * `footer-dentora`, see layout/defaultPartials.ts) rather than the
 * default Header/Footer.
 */
export const defaultHome1Sections: SectionInstance[] = [
  {
    id: "dental-hero-1",
    type: "dental-hero",
    props: {
      heading: "Family-Friendly Dental Care",
      description: "Permanent, natural-looking solutions to replace missing teeth and restore confident, healthy smiles.",
      primaryButtonLabel: "Book an Appointment",
      primaryButtonHref: "/contact",
      image: img("Dentist treating a patient"),
      ratingText: "Restoring natural, healthy, confident dental growth.",
      ratingValue: "4.9",
      ratingLabel: "Rating",
      ratingAvatar: img("Patient portrait"),
      blocks: [
        block("tag", { label: "Teeth Cleaning" }),
        block("tag", { label: "Dental Checkup" }),
        block("tag", { label: "Tooth Filling" }),
        block("tag", { label: "Gum Treatment" }),
        block("tag", { label: "Retainers" }),
      ],
    },
  },
  {
    id: "dental-intro-1",
    type: "dental-intro",
    props: {
      boldText: "We deliver personalized dental treatments with",
      mutedText: "modern technology and gentle care ensuring healthy confident smiles for every patient.",
    },
  },
  {
    id: "dental-feature-showcase-1",
    type: "dental-feature-showcase",
    props: {
      clinicImage: img("Dental treatment room"),
      doctorImage: img("Dr. Daniel Carter"),
      doctorImageBadgeLabel: "Book Appointment",
      doctorImageBadgeHref: "/contact",
      featureEyebrow: "Feature Treatment",
      featureHeading: "Advanced Dental Care for a Healthier Smile",
      featureDescription: "Join hundreds of patients achieving healthier, brighter smiles through expert dental care and personalized treatments.",
      doctorName: "Dr. Daniel Carter",
      doctorRole: "Lead Dental Specialist",
      doctorRatingValue: "4.9",
      doctorReviewCount: "(40+ reviews)",
      doctorDescription: "Join hundreds of patients achieving healthier, brighter smiles through expert dental care and personalized treatments.",
      blocks: [
        block("stat", { value: "98%", label: "Satisfaction Rate" }),
        block("stat", { value: "2k+", label: "Smiles Transformed" }),
        block("stat", { value: "4.9", label: "Customer Rating" }),
      ],
    },
  },
  {
    id: "dental-insights-intro-1",
    type: "dental-insights-intro",
    props: {
      eyebrowBadge: "Our Insights",
      heading: "Advanced dental care ensures precision, comfort and long lasting healthy smiles.",
      blocks: [block("thumb", { image: img("Dental procedure") }), block("thumb", { image: img("Dentist reviewing a chart") }), block("thumb", { image: img("Dental team at work") })],
    },
  },
  {
    id: "dental-blog-grid-1",
    type: "dental-blog-grid",
    props: {
      blocks: [
        block("post", {
          image: img("Professional cleaning"),
          tag: "Dental Health",
          date: "March 12, 2026",
          title: "Professional Cleaning vs. Regular Brushing",
          author: "Cody Fisher",
          readTime: "6 Min read",
          linkLabel: "Learn More",
          linkHref: "/blog/post",
        }),
        block("post", {
          image: img("Dentist consultation"),
          tag: "Dental Health",
          date: "March 12, 2026",
          title: "Important signs that indicate it's time to visit dentist",
          author: "Nataly Birch",
          readTime: "10 Min read",
          linkLabel: "Learn More",
          linkHref: "/blog/post",
        }),
        block("post", {
          image: img("Modern dental technology"),
          tag: "Dental Health",
          date: "March 12, 2026",
          title: "How modern technology makes treatment painless",
          author: "Sarah Johnson",
          readTime: "10 Min read",
          linkLabel: "Learn More",
          linkHref: "/blog/post",
        }),
      ],
    },
  },
];

export default function Home1Template({ sections = defaultHome1Sections }: Home1TemplateProps) {
  return <RenderSections sections={sections} />;
}
