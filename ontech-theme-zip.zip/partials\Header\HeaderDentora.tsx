import * as React from "react";
import { Container } from "../../components/Container";
import { Icon } from "../../components/Icon";
import { asString, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface HeaderDentoraProps {
  logoImage?: ThemeImage;
  logoText: string;
  /** Raw "nav_link" blocks — this header has no submenus, unlike the mega-menu Header partial. */
  navBlocks: RawBlock[];
  activeHref?: string;
  ctaLabel?: string;
  ctaHref?: string;
  sticky?: boolean;
}

/**
 * Pill-nav header for the Dentora home1 template: a rounded active-link
 * pill inside a soft nav bar, a solid dark "Book a Call" button, and a
 * plain slide-down mobile menu (no mega menu — this design doesn't use one).
 */
export function HeaderDentora({ logoImage, logoText, navBlocks, activeHref = "/", ctaLabel, ctaHref, sticky = true }: HeaderDentoraProps) {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  return (
    <header className={`d1-header ${sticky ? "d1-header--sticky" : ""}`.trim()}>
      <Container width="wide" className="d1-header__inner">
        <a href="/" className="d1-header__logo" aria-label={logoText}>
          {logoImage?.src ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoImage.src} alt={logoImage.alt} className="d1-header__logo-img" />
          ) : (
            <span className="d1-header__logo-mark" aria-hidden="true">
              <span />
              <span />
            </span>
          )}
          <span className="d1-header__logo-text">{logoText}</span>
        </a>

        <nav className="d1-header__nav d1-header__nav--desktop" aria-label="Primary">
          {navBlocks.map((block) => {
            const href = asString(block.href, "#");
            const isActive = href === activeHref;
            return (
              <a key={block.id} href={href} className={isActive ? "d1-header__nav-link d1-header__nav-link--active" : "d1-header__nav-link"}>
                {asString(block.label)}
              </a>
            );
          })}
        </nav>

        <div className="d1-header__actions">
          {ctaLabel && ctaHref && (
            <a href={ctaHref} className="d1-header__cta">
              {ctaLabel}
            </a>
          )}
          <button
            type="button"
            className="d1-header__icon-btn d1-header__icon-btn--mobile"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((v) => !v)}
          >
            <Icon name={mobileOpen ? "close" : "menu"} size={20} />
          </button>
        </div>
      </Container>

      {mobileOpen && (
        <nav className="d1-header__nav d1-header__nav--mobile" aria-label="Primary mobile">
          <Container width="wide">
            {navBlocks.map((block) => (
              <a key={block.id} href={asString(block.href, "#")} onClick={() => setMobileOpen(false)}>
                {asString(block.label)}
              </a>
            ))}
            {ctaLabel && ctaHref && (
              <a href={ctaHref} className="d1-header__cta d1-header__cta--mobile" onClick={() => setMobileOpen(false)}>
                {ctaLabel}
              </a>
            )}
          </Container>
        </nav>
      )}
    </header>
  );
}
