import * as React from "react";
import { Header } from "../partials/Header/Header";
import { Footer } from "../partials/Footer/Footer";
import { HeaderDentora } from "../partials/Header/HeaderDentora";
import { FooterDentora } from "../partials/Footer/FooterDentora";
import { HeaderSkyvilla } from "../partials/Header/HeaderSkyvilla";
import { FooterSkyvilla } from "../partials/Footer/FooterSkyvilla";

export const partialRegistry: Record<string, React.ComponentType<any>> = {
  header: Header,
  footer: Footer,
  "header-dentora": HeaderDentora,
  "footer-dentora": FooterDentora,
  "header-skyvilla": HeaderSkyvilla,
  "footer-skyvilla": FooterSkyvilla,
};

export interface PartialInstance {
  type: keyof typeof partialRegistry | string;
  props: Record<string, unknown>;
  id: string;
}

interface RenderPartialsProps {
  partials: PartialInstance[];
}

/** Renders ordered partial instances supplied by the host platform. Unknown types are skipped safely. */
export function RenderPartials({ partials }: RenderPartialsProps) {
  return (
    <>
      {partials.map((item) => {
        const Component = partialRegistry[item.type];
        if (!Component) return null;
        return <Component key={item.id} {...item.props} />;
      })}
    </>
  );
}
