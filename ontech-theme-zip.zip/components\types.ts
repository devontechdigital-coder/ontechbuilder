/**
 * components/types.ts
 *
 * Small, local type abstractions shared across sections/templates. No
 * coupling to the host platform's backend/domain models — the host
 * maps its own content into these shapes before handing props down.
 */

export interface ThemeImage {
  src: string;
  alt: string;
  width?: number;
  height?: number;
}

export type ImagePosition = "left" | "right" | "top" | "bottom";
export type AspectRatio = "auto" | "1:1" | "4:3" | "3:4" | "16:9" | "9:16" | "3:2";
export type ContentAlignment = "left" | "center" | "right";
export type ContainerWidth = "narrow" | "default" | "wide" | "full";

export interface LinkValue {
  label: string;
  href: string;
  external?: boolean;
}

export interface IconValue {
  name: string;
}
