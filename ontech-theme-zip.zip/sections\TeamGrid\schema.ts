import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "team-grid",
  name: "Team grid",
  category: "Content",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our team" },
    { type: "text", id: "heading", label: "Heading", default: "Our team of problem solvers" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "Our diverse team of experienced consultants, analysts, and industry specialists work together to deliver real results.",
    },
  ],
  blocks: [
    {
      type: "member",
      name: "Team member",
      settings: [
        { type: "image", id: "photo", label: "Photo" },
        { type: "text", id: "name", label: "Name", default: "Team member" },
        { type: "text", id: "role", label: "Role", default: "Consultant" },
      ],
    },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "member", settings: { name: "Rachel Kim", role: "Chief Strategy Officer" } },
    { type: "member", settings: { name: "Hannah Brooks", role: "Chief Strategy Officer" } },
    { type: "member", settings: { name: "Amira Chen", role: "Operations Consultant" } },
    { type: "member", settings: { name: "David Hassan", role: "Business Analyst" } },
    { type: "member", settings: { name: "Elena Novak", role: "Market Research Lead" } },
  ],
};

export default schema;
