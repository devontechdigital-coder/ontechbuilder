import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-testimonials",
  name: "Realty testimonials",
  category: "Testimonials",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "What our clients say about our" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "construction services" },
    { type: "text", id: "linkLabel", label: "Link label", default: "View All Reviews" },
    { type: "url", id: "linkHref", label: "Link URL", default: "#" },
  ],
  blocks: [
    {
      type: "testimonial",
      name: "Testimonial",
      settings: [
        { type: "image", id: "avatar", label: "Avatar" },
        { type: "textarea", id: "quote", label: "Quote", default: "The team delivered exactly what we envisioned, on time and on budget." },
        { type: "text", id: "name", label: "Name", default: "Parul Dhupar" },
        { type: "text", id: "role", label: "Role", default: "Homeowner" },
      ],
    },
    { type: "logo", name: "Partner logo", settings: [{ type: "image", id: "image", label: "Logo image" }] },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "testimonial", settings: { quote: "The team delivered exactly what we envisioned, on time and on budget.", name: "Parul Dhupar", role: "Homeowner" } },
    { type: "testimonial", settings: { quote: "Professional from the first call to the final walkthrough — highly recommended.", name: "Amrita Patel", role: "Property Developer" } },
    { type: "testimonial", settings: { quote: "Their attention to detail and communication set them apart from every other builder we spoke to.", name: "Rahul Mehta", role: "Commercial Client" } },
  ],
};

export default schema;
