import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "featured-case-study",
  name: "Featured case study",
  category: "Case studies",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our case studies" },
    { type: "text", id: "heading", label: "Heading", default: "Futured case study" },
    { type: "image", id: "image", label: "Image" },
    { type: "text", id: "title", label: "Title", default: "Market entry strategy for a fintech startup" },
  ],
};

export default schema;
