import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { asString, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface RealtyStatsProps {
  heading: string;
  headingItalic?: string;
  image?: ThemeImage;
  thumbImage?: ThemeImage;
  /** Raw "stat" blocks — rendered as a 2x2 grid. */
  blocks: RawBlock[];
}

/** Centered heading, a large image with a small overlapping collage thumbnail on the left, and a 2x2 stat grid on the right. */
export function RealtyStats({ heading, headingItalic, image, thumbImage, blocks }: RealtyStatsProps) {
  return (
    <section className="sv-section sv-stats">
      <Container width="wide">
        <h2 className="sv-section__heading sv-section__heading--center">
          {heading} {headingItalic && <em>{headingItalic}</em>}
        </h2>

        <div className="sv-stats__grid">
          <div className="sv-stats__media">
            <ThemeImg image={image} ratio="auto" placeholderLabel="Project image" className="sv-stats__media-main" />
            <ThemeImg image={thumbImage} ratio="auto" placeholderLabel="Thumbnail" className="sv-stats__media-thumb" />
          </div>

          <div className="sv-stats__figures">
            {blocks.map((block) => (
              <div key={block.id} className="sv-stats__stat">
                <strong>{asString(block.value)}</strong>
                <span>{asString(block.label)}</span>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
