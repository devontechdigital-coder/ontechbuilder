import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "cta-banner",
  name: "CTA banner",
  category: "Call to action",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Let's build something that moves your business forward" },
    { type: "textarea", id: "description", label: "Description", default: "" },
    { type: "text", id: "avatarLabel", label: "Avatar label", default: "Talk to our experts" },
    { type: "image", id: "image", label: "Image" },
    { type: "text", id: "buttonLabel", label: "Button label", default: "Get started now" },
    { type: "url", id: "buttonHref", label: "Button link", default: "/contact" },
  ],
  blocks: [
    { type: "avatar", name: "Avatar", settings: [{ type: "image", id: "image", label: "Photo" }] },
  ],
  maxBlocks: 6,
  defaultBlocks: [{ type: "avatar", settings: {} }, { type: "avatar", settings: {} }, { type: "avatar", settings: {} }],
};

export default schema;
