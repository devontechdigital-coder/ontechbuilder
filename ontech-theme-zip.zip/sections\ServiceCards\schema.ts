import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "service-cards",
  name: "Service cards",
  category: "Content",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "What we offer" },
    { type: "text", id: "heading", label: "Heading", default: "Our core consulting services" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "We provide tailored consulting solutions to help businesses overcome challenges, seize opportunities, and achieve sustainable growth.",
    },
    {
      type: "select",
      id: "columns",
      label: "Columns",
      options: [
        { value: "2", label: "2" },
        { value: "3", label: "3" },
        { value: "4", label: "4" },
      ],
      default: "4",
    },
  ],
  blocks: [
    {
      type: "service",
      name: "Service",
      settings: [
        { type: "text", id: "title", label: "Title", default: "Business strategy" },
        { type: "image", id: "image", label: "Image" },
      ],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "service", settings: { title: "Business strategy" } },
    { type: "service", settings: { title: "Process optimization" } },
    { type: "service", settings: { title: "Financial advisory" } },
    { type: "service", settings: { title: "Marketing Research" } },
  ],
};

export default schema;
