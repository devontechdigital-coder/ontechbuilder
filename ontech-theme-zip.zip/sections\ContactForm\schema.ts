import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "contact-form",
  name: "Contact form",
  category: "Forms",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Have a business challenge? We're ready to help" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "Whether you're ready to scale, solve a business challenge, or explore a partnership - we're here to help.",
    },
    { type: "text", id: "submitLabel", label: "Submit button label", default: "Submit" },
    { type: "url", id: "actionUrl", label: "Form action URL", info: "Set by the host to its form-handling endpoint.", default: "" },
    { type: "image", id: "image", label: "Image" },
  ],
  blocks: [
    {
      type: "service_option",
      name: "Service option",
      settings: [{ type: "text", id: "label", label: "Label", default: "Business strategy" }],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "service_option", settings: { label: "Business strategy" } },
    { type: "service_option", settings: { label: "Process optimization" } },
    { type: "service_option", settings: { label: "Financial advisory" } },
    { type: "service_option", settings: { label: "Marketing research" } },
  ],
};

export default schema;
