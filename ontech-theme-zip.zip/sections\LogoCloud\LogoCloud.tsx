import * as React from "react";
import { Container } from "../../components/Container";
import { asImage, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface LogoCloudProps {
  heading?: string;
  /** Raw logo blocks — each block's `image` field is pulled out internally. */
  logoBlocks: RawBlock[];
}

/** "Companies who rely on our expertise" — a simple, quiet logo row. */
export function LogoCloud({ heading, logoBlocks }: LogoCloudProps) {
  const logos = logoBlocks.map((block) => asImage(block.image)).filter((image): image is ThemeImage => Boolean(image));
  if (logos.length === 0) return null;

  return (
    <section className="cop-section cop-logo-cloud">
      <Container width="wide">
        {heading && <p className="cop-logo-cloud__heading">{heading}</p>}
        <div className="cop-logo-cloud__row">
          {logos.map((logo, index) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={logo.src + index} src={logo.src} alt={logo.alt} loading="lazy" />
          ))}
        </div>
      </Container>
    </section>
  );
}
