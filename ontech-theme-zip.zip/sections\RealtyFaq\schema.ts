import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-faq",
  name: "Realty FAQ",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Frequently Asked Questions" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "" },
    { type: "text", id: "ctaLabel", label: "CTA button label", default: "View All FAQs" },
    { type: "url", id: "ctaHref", label: "CTA button link", default: "/faq" },
  ],
  blocks: [
    { type: "avatar", name: "Intro avatar", settings: [{ type: "image", id: "image", label: "Avatar image" }] },
    {
      type: "faq",
      name: "Question",
      settings: [
        { type: "text", id: "question", label: "Question", default: "Do you handle commercial and residential projects?" },
        {
          type: "textarea",
          id: "answer",
          label: "Answer",
          default: "Yes — our team handles projects of every scale, from single-family homes to large commercial developments, offering flexible service plans, tailored budgeting, and dedicated project management throughout.",
        },
      ],
    },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    {
      type: "faq",
      settings: {
        question: "Do you handle commercial and residential projects?",
        answer:
          "Yes — our team handles projects of every scale, from single-family homes to large commercial developments, offering flexible service plans, tailored budgeting, and dedicated project management throughout.",
      },
    },
    { type: "faq", settings: { question: "Can you customize projects based on client needs?", answer: "Absolutely — every project starts with a discovery session so the design and scope match your goals and budget." } },
    { type: "faq", settings: { question: "Do you provide free consultations and site visits?", answer: "Yes, we offer a free initial consultation and, where useful, an on-site walkthrough before any proposal." } },
    { type: "faq", settings: { question: "Do you work with architects and interior designers?", answer: "We regularly partner with independent architects and designers, or can bring our own in-house team." } },
    { type: "faq", settings: { question: "How can I get started with my project?", answer: "Reach out through our contact form or give us a call — we'll schedule a consultation within a few business days." } },
  ],
};

export default schema;
