import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, type RawBlock } from "../../components/blockHelpers";

export interface DentalBlogGridProps {
  eyebrowBadge?: string;
  heading?: string;
  /** Raw "post" blocks. */
  blocks: RawBlock[];
}

/** Three-up blog/insights card grid: tag badge over the image, date, title, and an author/read-time + "Learn More" footer row. */
export function DentalBlogGrid({ eyebrowBadge, heading, blocks }: DentalBlogGridProps) {
  const postBlocks = blocksOfType(blocks, "post");

  return (
    <section className="d1-blog-grid">
      <Container width="wide">
        {(eyebrowBadge || heading) && (
          <div className="d1-blog-grid__header">
            {heading && <h2>{heading}</h2>}
            {eyebrowBadge && <span className="d1-pill">{eyebrowBadge}</span>}
          </div>
        )}
        <div className="d1-blog-grid__grid">
          {postBlocks.map((block) => (
            <a key={block.id} href={asString(block.linkHref, "#")} className="d1-blog-grid__card">
              <div className="d1-blog-grid__media">
                <ThemeImg image={asImage(block.image)} ratio="auto" placeholderLabel="Post image" className="d1-blog-grid__image" />
                {typeof block.tag === "string" && block.tag && <span className="d1-blog-grid__tag">{block.tag}</span>}
              </div>
              {typeof block.date === "string" && block.date && <span className="d1-blog-grid__date">{block.date}</span>}
              <h3 className="d1-blog-grid__title">{asString(block.title)}</h3>
              <div className="d1-blog-grid__footer">
                <span className="d1-blog-grid__author">
                  {asString(block.author)} · {asString(block.readTime)}
                </span>
                <span className="d1-blog-grid__link">
                  {asString(block.linkLabel, "Learn More")}
                  <Icon name="arrow-up-right" size={13} />
                </span>
              </div>
            </a>
          ))}
        </div>
      </Container>
    </section>
  );
}
