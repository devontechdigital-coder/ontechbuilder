import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Avatar } from "../../components/Avatar";
import { Icon } from "../../components/Icon";
import { asString, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface DentalHeroProps {
  heading: string;
  description?: string;
  primaryButtonLabel?: string;
  primaryButtonHref?: string;
  image?: ThemeImage;
  ratingText?: string;
  ratingValue?: string;
  ratingLabel?: string;
  ratingAvatar?: ThemeImage;
  /** Raw "tag" blocks — the small treatment labels beneath the banner. */
  blocks: RawBlock[];
}

/**
 * Full-bleed banner hero: headline/CTA overlaid bottom-left on the
 * photo, a floating rating card bottom-right, and a plain-text row of
 * treatment tags underneath.
 */
export function DentalHero({
  heading,
  description,
  primaryButtonLabel,
  primaryButtonHref,
  image,
  ratingText,
  ratingValue,
  ratingLabel,
  ratingAvatar,
  blocks,
}: DentalHeroProps) {
  const primaryButton = optionalLink(primaryButtonLabel, primaryButtonHref);
  const hasRating = Boolean(ratingText);

  return (
    <section className="d1-hero">
      <Container width="wide">
        <div className="d1-hero__frame">
          <ThemeImg image={image} ratio="auto" placeholderLabel="Hero image" className="d1-hero__image" />
          <div className="d1-hero__overlay">
            <h1 className="d1-hero__heading">{heading}</h1>
            {description && <p className="d1-hero__description">{description}</p>}
            {primaryButton && (
              <a href={primaryButton.href} className="d1-btn">
                {primaryButton.label}
                <span className="d1-btn__icon">
                  <Icon name="arrow-up-right" size={14} />
                </span>
              </a>
            )}
          </div>
          {hasRating && (
            <div className="d1-hero__rating-card">
              <Avatar image={ratingAvatar} size={40} />
              <div className="d1-hero__rating-body">
                <p>{ratingText}</p>
                <span className="d1-hero__rating-stars">
                  <Icon name="star" size={13} />
                  {asString(ratingValue)} {asString(ratingLabel, "Rating")}
                </span>
              </div>
            </div>
          )}
        </div>

        {blocks.length > 0 && (
          <ul className="d1-hero__tags">
            {blocks.map((block) => (
              <li key={block.id}>{asString(block.label)}</li>
            ))}
          </ul>
        )}
      </Container>
    </section>
  );
}
