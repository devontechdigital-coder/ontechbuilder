import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "announcement-bar",
  name: "Announcement bar",
  category: "Header",
  settings: [
    { type: "text", id: "message", label: "Message", default: "Free strategy call for new clients this month." },
    { type: "text", id: "linkLabel", label: "Link label", default: "Book now" },
    { type: "url", id: "linkHref", label: "Link URL", default: "/contact" },
    { type: "color", id: "backgroundColor", label: "Background color", default: "#0B0B0D" },
    { type: "color", id: "textColor", label: "Text color", default: "#FFFFFF" },
    { type: "checkbox", id: "dismissible", label: "Let visitors dismiss it", default: true },
  ],
};

export default schema;
