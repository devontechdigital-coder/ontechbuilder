import * as React from "react";
import { Container } from "../../components/Container";
import { Button } from "../../components/Button";
import { ThemeImg } from "../../components/ThemeImg";
import { optionalLink } from "../../components/blockHelpers";
import type { AspectRatio, ImagePosition, ThemeImage } from "../../components/types";

export interface SplitContentProps {
  eyebrow?: string;
  heading: string;
  description?: string;
  buttonLabel?: string;
  buttonHref?: string;
  image?: ThemeImage;
  imagePosition: ImagePosition;
  imageAspectRatio: AspectRatio;
  secondaryImage?: ThemeImage;
  signatureName?: string;
  signatureRole?: string;
}

/**
 * A general-purpose image/text split. Reused for the homepage's "Driven
 * by insight" block and the About page's "Built on expertise" block —
 * the only difference between them is content (a signature + secondary
 * image on About), which is why this is one configurable section
 * rather than two near-duplicate ones.
 */
export function SplitContent({
  eyebrow,
  heading,
  description,
  buttonLabel,
  buttonHref,
  image,
  imagePosition,
  imageAspectRatio,
  secondaryImage,
  signatureName,
  signatureRole,
}: SplitContentProps) {
  const button = optionalLink(buttonLabel, buttonHref);
  return (
    <section className="cop-section cop-split">
      <Container width="wide" className={`cop-split__inner cop-split__inner--img-${imagePosition}`}>
        <div className="cop-split__content">
          {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
          <h2>{heading}</h2>
          {description && <p>{description}</p>}
          {button && (
            <Button href={button.href} variant="primary" size="md">
              {button.label}
            </Button>
          )}
          {(signatureName || signatureRole) && (
            <div className="cop-split__signature">
              {signatureName && <strong>{signatureName}</strong>}
              {signatureRole && <span>{signatureRole}</span>}
            </div>
          )}
        </div>
        <div className="cop-split__media">
          <ThemeImg image={image} ratio={imageAspectRatio} placeholderLabel="Image" className="cop-split__media-main" />
          {secondaryImage && <ThemeImg image={secondaryImage} ratio="1:1" placeholderLabel="Secondary image" className="cop-split__media-secondary" />}
        </div>
      </Container>
    </section>
  );
}
