import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "dental-blog-grid",
  name: "Dental blog grid",
  category: "Blog",
  settings: [
    { type: "text", id: "eyebrowBadge", label: "Eyebrow badge", default: "Our Insights" },
    { type: "text", id: "heading", label: "Heading", default: "" },
  ],
  blocks: [
    {
      type: "post",
      name: "Post",
      settings: [
        { type: "image", id: "image", label: "Image" },
        { type: "text", id: "tag", label: "Tag", default: "Dental Health" },
        { type: "text", id: "date", label: "Date", default: "March 12, 2026" },
        { type: "text", id: "title", label: "Title", default: "Professional Cleaning vs. Regular Brushing" },
        { type: "text", id: "author", label: "Author", default: "Cody Fisher" },
        { type: "text", id: "readTime", label: "Read time", default: "6 Min read" },
        { type: "text", id: "linkLabel", label: "Link label", default: "Learn More" },
        { type: "url", id: "linkHref", label: "Link URL", default: "/blog/post" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    {
      type: "post",
      settings: { tag: "Dental Health", date: "March 12, 2026", title: "Professional Cleaning vs. Regular Brushing", author: "Cody Fisher", readTime: "6 Min read", linkLabel: "Learn More", linkHref: "/blog/post" },
    },
    {
      type: "post",
      settings: {
        tag: "Dental Health",
        date: "March 12, 2026",
        title: "Important signs that indicate it's time to visit dentist",
        author: "Nataly Birch",
        readTime: "10 Min read",
        linkLabel: "Learn More",
        linkHref: "/blog/post",
      },
    },
    {
      type: "post",
      settings: {
        tag: "Dental Health",
        date: "March 12, 2026",
        title: "How modern technology makes treatment painless",
        author: "Sarah Johnson",
        readTime: "10 Min read",
        linkLabel: "Learn More",
        linkHref: "/blog/post",
      },
    },
  ],
};

export default schema;
