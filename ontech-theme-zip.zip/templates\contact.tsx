import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface ContactTemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

export const defaultContactSections: SectionInstance[] = [
  {
    id: "contact-form-1",
    type: "contact-form",
    props: {
      heading: "Have a business challenge? We're ready to help",
      description: "Whether you're ready to scale, solve a business challenge, or explore a partnership - we're here to help.",
      submitLabel: "Submit",
      serviceOptionBlocks: [
        block("service_option", { label: "Business strategy" }),
        block("service_option", { label: "Process optimization" }),
        block("service_option", { label: "Financial advisory" }),
        block("service_option", { label: "Marketing research" }),
      ],
    },
  },
  {
    id: "contact-location",
    type: "location-card",
    props: {
      title: "Business consulting agency Copora",
      address: "Chicago HQ Estica Cop.\nMacomb, MI 48042",
      email: "contact@copora.com",
    },
  },
  {
    id: "contact-cta",
    type: "cta-banner",
    props: {
      heading: "Let's build something that moves your business forward",
      avatarLabel: "Talk to our experts",
      buttonLabel: "Get started now",
      buttonHref: "/contact",
      avatarBlocks: [],
    },
  },
];

export default function ContactTemplate({ sections = defaultContactSections }: ContactTemplateProps) {
  return <RenderSections sections={sections} />;
}
