import * as React from "react";
import { AnnouncementBar } from "../sections/AnnouncementBar/AnnouncementBar";
import { Hero } from "../sections/Hero/Hero";
import { PageIntro } from "../sections/PageIntro/PageIntro";
import { LogoCloud } from "../sections/LogoCloud/LogoCloud";
import { ServiceCards } from "../sections/ServiceCards/ServiceCards";
import { StatsRow } from "../sections/StatsRow/StatsRow";
import { SplitContent } from "../sections/SplitContent/SplitContent";
import { ProcessDark } from "../sections/ProcessDark/ProcessDark";
import { FeaturedCaseStudy } from "../sections/FeaturedCaseStudy/FeaturedCaseStudy";
import { CaseStudyList } from "../sections/CaseStudyList/CaseStudyList";
import { CaseStudyGrid } from "../sections/CaseStudyGrid/CaseStudyGrid";
import { TestimonialShowcase } from "../sections/TestimonialShowcase/TestimonialShowcase";
import { TeamGrid } from "../sections/TeamGrid/TeamGrid";
import { MissionVision } from "../sections/MissionVision/MissionVision";
import { BlogGrid } from "../sections/BlogGrid/BlogGrid";
import { ContactForm } from "../sections/ContactForm/ContactForm";
import { LocationCard } from "../sections/LocationCard/LocationCard";
import { CtaBanner } from "../sections/CtaBanner/CtaBanner";
import { DentalHero } from "../sections/DentalHero/DentalHero";
import { DentalIntro } from "../sections/DentalIntro/DentalIntro";
import { DentalFeatureShowcase } from "../sections/DentalFeatureShowcase/DentalFeatureShowcase";
import { DentalInsightsIntro } from "../sections/DentalInsightsIntro/DentalInsightsIntro";
import { DentalBlogGrid } from "../sections/DentalBlogGrid/DentalBlogGrid";
import { RealtyHero } from "../sections/RealtyHero/RealtyHero";
import { RealtyIntro } from "../sections/RealtyIntro/RealtyIntro";
import { RealtyServices } from "../sections/RealtyServices/RealtyServices";
import { RealtyAbout } from "../sections/RealtyAbout/RealtyAbout";
import { RealtyVideoBanner } from "../sections/RealtyVideoBanner/RealtyVideoBanner";
import { RealtyWhyUs } from "../sections/RealtyWhyUs/RealtyWhyUs";
import { RealtyProjects } from "../sections/RealtyProjects/RealtyProjects";
import { RealtyStats } from "../sections/RealtyStats/RealtyStats";
import { RealtyContactSplit } from "../sections/RealtyContactSplit/RealtyContactSplit";
import { RealtyFaq } from "../sections/RealtyFaq/RealtyFaq";
import { RealtyTestimonials } from "../sections/RealtyTestimonials/RealtyTestimonials";
import { RealtyBlogGrid } from "../sections/RealtyBlogGrid/RealtyBlogGrid";

/** Maps a body section's schema `id` to the component that renders it. Header and footer live in `partials/`. */
export const sectionRegistry: Record<string, React.ComponentType<any>> = {
  "announcement-bar": AnnouncementBar,
  hero: Hero,
  "page-intro": PageIntro,
  "logo-cloud": LogoCloud,
  "service-cards": ServiceCards,
  "stats-row": StatsRow,
  "split-content": SplitContent,
  "process-dark": ProcessDark,
  "featured-case-study": FeaturedCaseStudy,
  "case-study-list": CaseStudyList,
  "case-study-grid": CaseStudyGrid,
  "testimonial-showcase": TestimonialShowcase,
  "team-grid": TeamGrid,
  "mission-vision": MissionVision,
  "blog-grid": BlogGrid,
  "contact-form": ContactForm,
  "location-card": LocationCard,
  "cta-banner": CtaBanner,
  "dental-hero": DentalHero,
  "dental-intro": DentalIntro,
  "dental-feature-showcase": DentalFeatureShowcase,
  "dental-insights-intro": DentalInsightsIntro,
  "dental-blog-grid": DentalBlogGrid,
  "realty-hero": RealtyHero,
  "realty-intro": RealtyIntro,
  "realty-services": RealtyServices,
  "realty-about": RealtyAbout,
  "realty-video-banner": RealtyVideoBanner,
  "realty-why-us": RealtyWhyUs,
  "realty-projects": RealtyProjects,
  "realty-stats": RealtyStats,
  "realty-contact-split": RealtyContactSplit,
  "realty-faq": RealtyFaq,
  "realty-testimonials": RealtyTestimonials,
  "realty-blog-grid": RealtyBlogGrid,
};

export interface SectionInstance {
  type: keyof typeof sectionRegistry | string;
  props: Record<string, unknown>;
  id: string;
}

interface RenderSectionsProps {
  sections: SectionInstance[];
}

/** Renders an ordered list of section instances supplied by the host platform. Unknown types are skipped safely. */
export function RenderSections({ sections }: RenderSectionsProps) {
  return (
    <>
      {sections.map((section) => {
        const Component = sectionRegistry[section.type];
        if (!Component) return null;
        return <Component key={section.id} {...section.props} />;
      })}
    </>
  );
}
