import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, type RawBlock } from "../../components/blockHelpers";

export interface CaseStudyGridProps {
  heading: string;
  columns: 2 | 3;
  currentPage: number;
  totalPages: number;
  prevPageHref?: string;
  nextPageHref?: string;
  /** Raw case_study_card blocks. */
  blocks: RawBlock[];
}

/** The "Our case studies" index page grid, with simple prev/next pagination links. */
export function CaseStudyGrid({ heading, columns, currentPage, totalPages, prevPageHref, nextPageHref, blocks }: CaseStudyGridProps) {
  return (
    <section className="cop-section cop-case-grid">
      <Container width="wide">
        <h1 className="cop-case-grid__heading">{heading}</h1>

        <div className={`cop-case-grid__grid cop-grid--cols-${columns}`}>
          {blocks.map((block) => {
            const title = asString(block.title);
            return (
              <a key={block.id} href={asString(block.linkHref, "#")} className="cop-case-grid__card">
                <ThemeImg image={asImage(block.image)} ratio="4:3" placeholderLabel={title} />
                {Boolean(block.tag || block.date) && (
                  <div className="cop-case-grid__meta">
                    {typeof block.tag === "string" && block.tag && <span className="cop-case-grid__tag">{block.tag}</span>}
                    {typeof block.date === "string" && block.date && <span className="cop-case-grid__date">{block.date}</span>}
                  </div>
                )}
                <div className="cop-case-grid__title-row">
                  <span>{title}</span>
                  <Icon name="arrow-up-right" size={16} />
                </div>
              </a>
            );
          })}
        </div>

        {totalPages > 1 && (
          <nav className="cop-case-grid__pagination" aria-label="Case studies pagination">
            <span>
              {currentPage} / {totalPages}
            </span>
            {nextPageHref ? (
              <a href={nextPageHref} className="cop-btn cop-btn--primary cop-btn--md">
                Next
                <Icon name="chevron-right" size={16} />
              </a>
            ) : (
              <span className="cop-btn cop-btn--primary cop-btn--md cop-btn--disabled" aria-disabled="true">
                Next
                <Icon name="chevron-right" size={16} />
              </span>
            )}
            {prevPageHref && (
              <a href={prevPageHref} className="cop-case-grid__prev">
                <Icon name="chevron-left" size={16} />
                Previous
              </a>
            )}
          </nav>
        )}
      </Container>
    </section>
  );
}
