import * as React from "react";
import { Container } from "../components/Container";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface PageTemplateProps {
  title: string;
  bodyHtml?: string;
  sections?: SectionInstance[];
}

/** Generic interior page: title + rich body, with optional trailing sections (e.g. a closing CTA). */
export default function PageTemplate({ title, bodyHtml, sections = [] }: PageTemplateProps) {
  return (
    <>
      <section className="cop-section cop-page-header">
        <Container width="default">
          <h1>{title}</h1>
        </Container>
      </section>

      {bodyHtml && (
        <section className="cop-section cop-page-body">
          <Container width="narrow">
            {/* eslint-disable-next-line react/no-danger */}
            <div className="cop-prose" dangerouslySetInnerHTML={{ __html: bodyHtml }} />
          </Container>
        </section>
      )}

      <RenderSections sections={sections} />
    </>
  );
}
