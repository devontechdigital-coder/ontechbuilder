import * as React from "react";
import { Container } from "../components/Container";
import { Icon } from "../components/Icon";

export interface SearchResultItem {
  title: string;
  excerpt?: string;
  href: string;
  imageSrc?: string;
}

export interface SearchTemplateProps {
  query: string;
  results: SearchResultItem[];
  resultCount: number;
}

export default function SearchTemplate({ query, results, resultCount }: SearchTemplateProps) {
  return (
    <section className="cop-section cop-search">
      <Container width="default">
        <p className="cop-eyebrow">Search results</p>
        <h1>
          {resultCount} result{resultCount === 1 ? "" : "s"} for &ldquo;{query}&rdquo;
        </h1>

        {results.length === 0 ? (
          <div className="cop-search__empty">
            <Icon name="search" size={32} />
            <p>No results matched your search. Try a different term.</p>
          </div>
        ) : (
          <ul className="cop-search__results">
            {results.map((result) => (
              <li key={result.href} className="cop-search__result">
                {result.imageSrc && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={result.imageSrc} alt="" loading="lazy" />
                )}
                <div>
                  <a href={result.href}>{result.title}</a>
                  {result.excerpt && <p>{result.excerpt}</p>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Container>
    </section>
  );
}
