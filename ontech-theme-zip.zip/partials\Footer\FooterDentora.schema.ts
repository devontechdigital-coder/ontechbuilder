import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "footer-dentora",
  name: "Footer (Dentora)",
  category: "Footer",
  settings: [
    { type: "text", id: "logoText", label: "Watermark / wordmark text", default: "Dentora" },
    { type: "text", id: "headingLine1", label: "Heading line 1", default: "Your smile matters" },
    { type: "text", id: "headingLine2", label: "Heading line 2", default: "Connect with us today" },
    { type: "text", id: "email", label: "Email", default: "dentora@doc.com" },
    { type: "text", id: "contactHeading", label: "Contact column heading", default: "We'd love to help you" },
    { type: "checkbox", id: "showNewsletter", label: "Show newsletter form", default: true },
    {
      type: "textarea",
      id: "newsletterHeading",
      label: "Newsletter heading",
      default: "Join our newsletter to receive the latest oral health tips, special offers and clinic updates.",
    },
    { type: "text", id: "newsletterPlaceholder", label: "Email field placeholder", default: "Your Email Address" },
    { type: "text", id: "newsletterButtonLabel", label: "Subscribe button label", default: "Subscribe" },
    { type: "text", id: "termsLabel", label: "Terms link label", default: "Terms & Conditions" },
    { type: "url", id: "termsHref", label: "Terms link URL", default: "/terms" },
    { type: "text", id: "privacyLabel", label: "Privacy link label", default: "Privacy Policy" },
    { type: "url", id: "privacyHref", label: "Privacy link URL", default: "/privacy" },
    { type: "text", id: "creditLine", label: "Bottom credit line", default: "© 2026 Dentora. All rights reserved." },
  ],
  blocks: [
    {
      type: "link_column",
      name: "Link column",
      settings: [
        { type: "text", id: "heading", label: "Column heading", default: "Company" },
        { type: "textarea", id: "linksJson", label: "Links", info: "JSON array of {label, href} links.", default: '[{"label":"Home","href":"/"}]' },
      ],
    },
    {
      type: "social_link",
      name: "Social link",
      settings: [
        { type: "icon", id: "icon", label: "Icon" },
        { type: "url", id: "href", label: "URL", default: "#" },
        { type: "text", id: "label", label: "Accessible label", default: "Follow us" },
      ],
    },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    {
      type: "link_column",
      settings: {
        heading: "Company",
        linksJson: '[{"label":"Home","href":"/"},{"label":"Services","href":"/services"},{"label":"About Us","href":"/about"},{"label":"Dentist","href":"/about#dentist"}]',
      },
    },
    {
      type: "link_column",
      settings: { heading: "Resources", linksJson: '[{"label":"Contact Us","href":"/contact"},{"label":"Blog","href":"/blog"},{"label":"Faq","href":"/faq"},{"label":"404 Error","href":"/404"}]' },
    },
    {
      type: "link_column",
      settings: { heading: "Legal", linksJson: '[{"label":"Privacy Policy","href":"/privacy"},{"label":"Terms and Conditions","href":"/terms"},{"label":"License","href":"/license"}]' },
    },
    { type: "social_link", settings: { icon: "facebook", href: "#", label: "Facebook" } },
    { type: "social_link", settings: { icon: "instagram", href: "#", label: "Instagram" } },
    { type: "social_link", settings: { icon: "x", href: "#", label: "X (Twitter)" } },
    { type: "social_link", settings: { icon: "linkedin", href: "#", label: "LinkedIn" } },
  ],
};

export default schema;
