import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "logo-cloud",
  name: "Logo cloud",
  category: "Social proof",
  settings: [{ type: "text", id: "heading", label: "Heading", default: "Companies who rely on our expertise" }],
  blocks: [{ type: "logo", name: "Logo", settings: [{ type: "image", id: "image", label: "Logo image" }] }],
  maxBlocks: 8,
};

export default schema;
