import * as React from "react";
import { Container } from "../../components/Container";
import { Icon } from "../../components/Icon";

export interface RealtyContactSplitProps {
  heading: string;
  headingItalic?: string;
  phone?: string;
  email?: string;
  formHeading?: string;
  formHeadingItalic?: string;
  submitLabel?: string;
  actionUrl?: string;
}

/**
 * Two-panel contact section: a dark "quick support" panel with
 * phone/email, next to a light contact-form panel. The form submits
 * via a native `<form action>` — no client-side network call.
 */
export function RealtyContactSplit({ heading, headingItalic, phone, email, formHeading, formHeadingItalic, submitLabel = "Send Message", actionUrl }: RealtyContactSplitProps) {
  return (
    <section className="sv-section sv-contact-split">
      <Container width="wide" className="sv-contact-split__grid">
        <div className="sv-contact-split__panel sv-contact-split__panel--dark">
          <h2>
            {heading} {headingItalic && <em>{headingItalic}</em>}
          </h2>
          <div className="sv-contact-split__info">
            {phone && (
              <a href={`tel:${phone}`}>
                <Icon name="phone" size={16} />
                {phone}
              </a>
            )}
            {email && (
              <a href={`mailto:${email}`}>
                <Icon name="mail" size={16} />
                {email}
              </a>
            )}
          </div>
        </div>

        <div className="sv-contact-split__panel sv-contact-split__panel--light">
          <h3>
            {formHeading} {formHeadingItalic && <em>{formHeadingItalic}</em>}
          </h3>
          <form className="sv-contact-split__form" method="post" action={actionUrl || undefined}>
            <div className="sv-contact-split__row">
              <label>
                <span className="cop-visually-hidden">Name</span>
                <input type="text" name="name" placeholder="Your Name" required />
              </label>
              <label>
                <span className="cop-visually-hidden">Email</span>
                <input type="email" name="email" placeholder="Email Address" required />
              </label>
            </div>
            <label>
              <span className="cop-visually-hidden">Phone</span>
              <input type="tel" name="phone" placeholder="Phone Number" />
            </label>
            <label>
              <span className="cop-visually-hidden">Message</span>
              <textarea name="message" placeholder="Your Message" rows={4} />
            </label>
            <button type="submit" className="sv-btn">
              {submitLabel}
              <span className="sv-btn__icon">
                <Icon name="arrow-up-right" size={14} />
              </span>
            </button>
          </form>
        </div>
      </Container>
    </section>
  );
}
