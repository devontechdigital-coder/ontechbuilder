import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "page-intro",
  name: "Page intro",
  category: "Hero",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Building better businesses with smart strategy" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "We're a forward-thinking consulting agency helping businesses grow smarter, scale faster, and lead with clarity.",
    },
    { type: "image", id: "image", label: "Banner image" },
    {
      type: "select",
      id: "imageAspectRatio",
      label: "Banner aspect ratio",
      options: [
        { value: "16:9", label: "16:9" },
        { value: "3:2", label: "3:2" },
        { value: "4:3", label: "4:3" },
      ],
      default: "16:9",
    },
  ],
};

export default schema;
