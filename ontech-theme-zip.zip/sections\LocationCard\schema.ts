import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "location-card",
  name: "Location card",
  category: "Content",
  settings: [
    { type: "image", id: "image", label: "Image" },
    { type: "text", id: "title", label: "Title", default: "Business consulting agency Copora" },
    { type: "textarea", id: "address", label: "Address", default: "Chicago HQ Estica Cop.\nMacomb, MI 48042" },
    { type: "text", id: "email", label: "Email", default: "contact@copora.com" },
  ],
};

export default schema;
