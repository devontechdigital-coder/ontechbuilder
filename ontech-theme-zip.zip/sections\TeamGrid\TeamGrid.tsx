import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { asImage, asString, type RawBlock } from "../../components/blockHelpers";

export interface TeamGridProps {
  eyebrow?: string;
  heading: string;
  description?: string;
  /** Raw member blocks. */
  blocks: RawBlock[];
}

/** "Our team of problem solvers" — photo cards with a name/role tag overlay. */
export function TeamGrid({ eyebrow, heading, description, blocks }: TeamGridProps) {
  return (
    <section className="cop-section cop-team">
      <Container width="wide">
        <div className="cop-section__heading cop-section__heading--center">
          {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
          <h2>{heading}</h2>
          {description && <p className="cop-section__description">{description}</p>}
        </div>
        <div className="cop-team__grid">
          {blocks.map((block) => (
            <div key={block.id} className="cop-team__card">
              <ThemeImg image={asImage(block.photo)} ratio="3:4" placeholderLabel={asString(block.name)} />
              <span className="cop-team__tag">
                <strong>{asString(block.name)}</strong>
                <em>{asString(block.role)}</em>
              </span>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
