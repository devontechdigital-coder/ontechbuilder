import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import type { ThemeImage } from "../../components/types";

export interface RealtyVideoBannerProps {
  heading: string;
  headingItalic?: string;
  image?: ThemeImage;
  videoHref?: string;
}

/** Full-width photo banner with a headline overlay and a decorative circular play button (no video dependency — links out via `videoHref`). */
export function RealtyVideoBanner({ heading, headingItalic, image, videoHref = "#" }: RealtyVideoBannerProps) {
  return (
    <section className="sv-video">
      <Container width="wide">
        <div className="sv-video__frame">
          <ThemeImg image={image} ratio="auto" placeholderLabel="Video banner image" className="sv-video__image" />
          <div className="sv-video__overlay">
            <h2>
              {heading} {headingItalic && <em>{headingItalic}</em>}
            </h2>
            <a href={videoHref} className="sv-video__play" aria-label="Watch video">
              <Icon name="play" size={22} />
            </a>
          </div>
        </div>
      </Container>
    </section>
  );
}
