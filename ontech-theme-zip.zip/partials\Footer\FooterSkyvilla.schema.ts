import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "footer-skyvilla",
  name: "Footer (Skyvilla)",
  category: "Footer",
  settings: [
    { type: "text", id: "logoText", label: "Wordmark text", default: "Skyvilla" },
    { type: "text", id: "heading", label: "Heading", default: "Begin your construction journey with" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "trusted experts" },
    { type: "textarea", id: "description", label: "Description", default: "Explore our social media for the latest project updates and behind-the-scenes moments." },
    { type: "text", id: "ratingValue", label: "Rating value", default: "4.9" },
    { type: "text", id: "ratingLabel", label: "Rating label", default: "Client Rating" },
    { type: "text", id: "primaryButtonLabel", label: "CTA button label", default: "Explore Our Social Media" },
    { type: "url", id: "primaryButtonHref", label: "CTA button link", default: "#" },
    { type: "text", id: "socialHeading", label: "Social row label", default: "Follow us" },
    { type: "text", id: "phone", label: "Phone", default: "+1 (234) 567-890" },
    { type: "text", id: "email", label: "Email", default: "hello@skyvilla.com" },
    { type: "text", id: "address", label: "Address", default: "123 Skyline Ave, Los Angeles, CA" },
    { type: "text", id: "termsLabel", label: "Terms link label", default: "Terms & Conditions" },
    { type: "url", id: "termsHref", label: "Terms link URL", default: "/terms" },
    { type: "text", id: "privacyLabel", label: "Privacy link label", default: "Privacy Policy" },
    { type: "url", id: "privacyHref", label: "Privacy link URL", default: "/privacy" },
    { type: "text", id: "creditLine", label: "Bottom credit line", default: "© 2026 Skyvilla. All rights reserved." },
  ],
  blocks: [
    {
      type: "link_column",
      name: "Link column",
      settings: [
        { type: "text", id: "heading", label: "Column heading", default: "Quick Links" },
        { type: "textarea", id: "linksJson", label: "Links", info: "JSON array of {label, href} links.", default: '[{"label":"Home","href":"/"}]' },
      ],
    },
    {
      type: "social_link",
      name: "Social link",
      settings: [
        { type: "icon", id: "icon", label: "Icon" },
        { type: "url", id: "href", label: "URL", default: "#" },
        { type: "text", id: "label", label: "Accessible label", default: "Follow us" },
      ],
    },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    {
      type: "link_column",
      settings: { heading: "Quick Links", linksJson: '[{"label":"Home","href":"/"},{"label":"About Us","href":"/about"},{"label":"Services","href":"/services"},{"label":"Blog","href":"/blog"},{"label":"Contact Us","href":"/contact"}]' },
    },
    {
      type: "link_column",
      settings: {
        heading: "Services",
        linksJson: '[{"label":"Residential Construction","href":"/services/residential"},{"label":"Commercial Construction","href":"/services/commercial"},{"label":"Design & Planning","href":"/services/design"},{"label":"Project Management","href":"/services/management"}]',
      },
    },
    { type: "social_link", settings: { icon: "facebook", href: "#", label: "Facebook" } },
    { type: "social_link", settings: { icon: "instagram", href: "#", label: "Instagram" } },
    { type: "social_link", settings: { icon: "x", href: "#", label: "X (Twitter)" } },
    { type: "social_link", settings: { icon: "linkedin", href: "#", label: "LinkedIn" } },
  ],
};

export default schema;
