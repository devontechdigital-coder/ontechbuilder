import * as React from "react";
import type { ThemeImage } from "./types";

export function Avatar({ image, size = 36 }: { image?: ThemeImage; size?: number }) {
  return (
    <span className="cop-avatar" style={{ width: size, height: size }}>
      {image?.src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={image.src} alt={image.alt} />
      ) : (
        <span className="cop-avatar__placeholder" aria-hidden="true" />
      )}
    </span>
  );
}
