import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-why-us",
  name: "Realty why choose us",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Dedicated to honest &" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "reliable construction" },
    { type: "textarea", id: "description", label: "Description", default: "We combine craftsmanship, transparency, and modern building methods to deliver spaces our clients trust for decades." },
    { type: "text", id: "ctaLabel", label: "CTA button label", default: "Contact Us" },
    { type: "url", id: "ctaHref", label: "CTA button link", default: "/contact" },
    { type: "text", id: "ratingValue", label: "Rating value", default: "4.9" },
    { type: "text", id: "ratingLabel", label: "Rating label", default: "500+ Happy Clients" },
    {
      type: "textarea",
      id: "quoteText",
      label: "Quote strip text",
      default: "Creating modern homes and commercial spaces precision construction and trusted real estate expertise.",
    },
    { type: "text", id: "quoteButtonLabel", label: "Quote strip button label", default: "Get a Quote" },
    { type: "url", id: "quoteButtonHref", label: "Quote strip button link", default: "/contact" },
  ],
  blocks: [
    { type: "avatar", name: "Rating avatar", settings: [{ type: "image", id: "image", label: "Avatar image" }] },
    {
      type: "point",
      name: "Point",
      settings: [
        { type: "text", id: "number", label: "Number", default: "01" },
        { type: "text", id: "title", label: "Title", default: "Quality Craftsmanship" },
        { type: "textarea", id: "description", label: "Description", default: "Superior construction with attention to detail on every build." },
      ],
    },
    { type: "quote_avatar", name: "Quote strip avatar", settings: [{ type: "image", id: "image", label: "Avatar image" }] },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "point", settings: { number: "01", title: "Quality Craftsmanship", description: "Superior construction with attention to detail on every build." } },
    { type: "point", settings: { number: "02", title: "Sustainability", description: "Durable and environmentally conscious construction practices." } },
    { type: "point", settings: { number: "03", title: "Modern Techniques", description: "Innovative construction and design methods on every project." } },
  ],
};

export default schema;
