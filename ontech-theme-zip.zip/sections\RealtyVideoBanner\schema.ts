import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-video-banner",
  name: "Realty video banner",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Watch how we build" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "modern quality living spaces" },
    { type: "image", id: "image", label: "Banner image" },
    { type: "url", id: "videoHref", label: "Play button link", default: "#" },
  ],
};

export default schema;
