import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "testimonial-showcase",
  name: "Testimonial showcase",
  category: "Social proof",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Testimonials" },
    { type: "text", id: "heading", label: "Heading", default: "Proven impact, shared experiences" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "From startups to enterprises, our clients share how our strategic consulting helped them achieve lasting success.",
    },
    { type: "text", id: "ratingValue", label: "Rating value", default: "4.5" },
    { type: "text", id: "reviewCount", label: "Review count", default: "450+" },
  ],
  blocks: [
    {
      type: "testimonial",
      name: "Testimonial",
      settings: [
        { type: "textarea", id: "quote", label: "Quote", default: "Our company was growing fast, but our culture couldn't keep pace." },
        { type: "text", id: "name", label: "Name", default: "Amanda Lewis" },
        { type: "text", id: "role", label: "Role", default: "Director of Strategy" },
        { type: "image", id: "avatar", label: "Avatar" },
      ],
    },
    {
      type: "gallery_image",
      name: "Gallery image",
      settings: [{ type: "image", id: "image", label: "Image" }],
    },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "testimonial", settings: { quote: "Our company was growing fast, but our culture couldn't keep pace.", name: "Amanda Lewis", role: "Director of Strategy" } },
    { type: "gallery_image", settings: {} },
    { type: "gallery_image", settings: {} },
    { type: "gallery_image", settings: {} },
  ],
};

export default schema;
