/**
 * config/settings.schema.ts
 *
 * Declarative schema of every global setting the visual editor should
 * render. No UI code here — the host platform reads this and generates
 * controls (color pickers, sliders, image pickers, etc).
 */

export type SettingType =
  | "text"
  | "textarea"
  | "richtext"
  | "url"
  | "image"
  | "color"
  | "select"
  | "checkbox"
  | "range"
  | "font"
  | "icon";

export interface SelectOption {
  value: string;
  label: string;
}

export interface SettingField {
  type: SettingType;
  id: string;
  label: string;
  default?: string | number | boolean;
  info?: string;
  placeholder?: string;
  options?: SelectOption[];
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
}

export interface SettingGroup {
  header: string;
  settings: SettingField[];
}

export interface BlockSchema {
  type: string;
  name: string;
  settings: SettingField[];
}

export interface SectionSchema {
  id: string;
  name: string;
  category: string;
  settings: SettingField[];
  blocks?: BlockSchema[];
  maxBlocks?: number;
  defaultBlocks?: { type: string; settings: Record<string, string | number | boolean> }[];
}

export interface ThemeSettingsSchema {
  groups: SettingGroup[];
}

/**
 * Curated heading/body font stacks. Kept as `select` (not free text) so
 * the editor can offer a real font picker instead of an empty field —
 * every option here is also `@import`ed in assets/styles/theme.css so
 * it renders correctly regardless of what the host bundles elsewhere.
 */
const headingFontOptions: SelectOption[] = [
  { value: "'Sora', 'Inter', sans-serif", label: "Sora (geometric display)" },
  { value: "'Space Grotesk', 'Inter', sans-serif", label: "Space Grotesk (technical display)" },
  { value: "'Manrope', 'Inter', sans-serif", label: "Manrope (rounded grotesk)" },
  { value: "'Plus Jakarta Sans', 'Inter', sans-serif", label: "Plus Jakarta Sans (friendly grotesk)" },
  { value: "'Poppins', 'Inter', sans-serif", label: "Poppins (geometric sans)" },
  { value: "'Playfair Display', Georgia, serif", label: "Playfair Display (editorial serif)" },
  { value: "'Inter', -apple-system, sans-serif", label: "Inter (matches body)" },
];

const bodyFontOptions: SelectOption[] = [
  { value: "'Inter', -apple-system, sans-serif", label: "Inter" },
  { value: "'Manrope', -apple-system, sans-serif", label: "Manrope" },
  { value: "'Plus Jakarta Sans', -apple-system, sans-serif", label: "Plus Jakarta Sans" },
  { value: "'IBM Plex Sans', -apple-system, sans-serif", label: "IBM Plex Sans" },
  { value: "Georgia, 'Times New Roman', serif", label: "Georgia (serif body)" },
];

const settingsSchema: ThemeSettingsSchema = {
  groups: [
    {
      header: "Color palette",
      settings: [
        { type: "color", id: "colorPrimary", label: "Primary (accent) color", default: "#3A1B63", info: "Buttons, links, eyebrows, active states." },
        { type: "color", id: "colorPrimaryContrast", label: "Text on primary", default: "#FFFFFF" },
        { type: "color", id: "colorSecondary", label: "Secondary (highlight) color", default: "#C9A24D", info: "Used sparingly for emphasis — e.g. inline highlights, chart accents." },
        { type: "color", id: "colorLink", label: "Text link color", default: "#3A1B63" },
        { type: "color", id: "colorBackground", label: "Page background", default: "#FFFFFF" },
        { type: "color", id: "colorSurface", label: "Card / surface background", default: "#F4F3F1" },
        { type: "color", id: "colorSurfaceAlt", label: "Alternate section background", default: "#FBF9F5", info: "Used to alternate light sections for rhythm without a hard border." },
        { type: "color", id: "colorDark", label: "Dark section background", default: "#0B0B0D" },
        { type: "color", id: "colorText", label: "Body text color", default: "#111113" },
        { type: "color", id: "colorMutedText", label: "Muted / secondary text color", default: "#6B6B70" },
        { type: "color", id: "colorBorder", label: "Border color", default: "#E7E5E1" },
      ],
    },
    {
      header: "Layout",
      settings: [
        {
          type: "select",
          id: "containerWidth",
          label: "Container width",
          options: [
            { value: "narrow", label: "Narrow (960px)" },
            { value: "default", label: "Default (1240px)" },
            { value: "wide", label: "Wide (1400px)" },
            { value: "full", label: "Full width" },
          ],
          default: "default",
        },
        { type: "range", id: "sectionSpacing", label: "Section vertical spacing", min: 32, max: 160, step: 8, unit: "px", default: 104 },
        { type: "range", id: "borderRadius", label: "Corner radius", min: 0, max: 32, step: 2, unit: "px", default: 14 },
      ],
    },
    {
      header: "Typography",
      settings: [
        { type: "select", id: "headingFont", label: "Heading font family", options: headingFontOptions, default: "'Sora', 'Inter', sans-serif" },
        { type: "select", id: "bodyFont", label: "Body font family", options: bodyFontOptions, default: "'Inter', -apple-system, sans-serif" },
        {
          type: "select",
          id: "headingWeight",
          label: "Heading weight",
          options: [
            { value: "500", label: "Medium" },
            { value: "600", label: "Semibold" },
            { value: "700", label: "Bold" },
            { value: "800", label: "Extrabold" },
          ],
          default: "700",
        },
        { type: "range", id: "baseFontSize", label: "Body font size", min: 14, max: 20, step: 1, unit: "px", default: 16 },
        { type: "range", id: "headingFontSize", label: "Heading font size (H2 baseline)", min: 26, max: 60, step: 1, unit: "px", default: 42, info: "H1/H3 scale from this using the ratio below." },
        { type: "range", id: "headingScale", label: "Heading scale ratio", min: 1.1, max: 1.6, step: 0.05, default: 1.3, info: "Spread between H1, H2 and H3 sizes — higher means a bigger jump between heading levels." },
        { type: "range", id: "headingLetterSpacing", label: "Heading letter spacing", min: -3, max: 1, step: 0.5, unit: "px", default: -1 },
        { type: "range", id: "lineHeight", label: "Body line height", min: 1.2, max: 1.9, step: 0.05, default: 1.6 },
      ],
    },
    {
      header: "Buttons",
      settings: [
        {
          type: "select",
          id: "buttonStyle",
          label: "Button style",
          options: [
            { value: "solid", label: "Solid" },
            { value: "outline", label: "Outline" },
          ],
          default: "solid",
        },
        { type: "range", id: "buttonRadius", label: "Button corner radius", min: 0, max: 40, step: 2, unit: "px", default: 999 },
        {
          type: "select",
          id: "buttonSize",
          label: "Default button size",
          options: [
            { value: "sm", label: "Small" },
            { value: "md", label: "Medium" },
            { value: "lg", label: "Large" },
          ],
          default: "md",
        },
        {
          type: "select",
          id: "buttonHoverEffect",
          label: "Hover effect",
          options: [
            { value: "fade", label: "Fade" },
            { value: "lift", label: "Lift (subtle raise + shadow)" },
            { value: "none", label: "None" },
          ],
          default: "lift",
        },
      ],
    },
    {
      header: "Cards & imagery",
      settings: [
        {
          type: "select",
          id: "cardShadow",
          label: "Card shadow",
          options: [
            { value: "none", label: "None (border only)" },
            { value: "soft", label: "Soft" },
            { value: "medium", label: "Medium" },
            { value: "strong", label: "Strong" },
          ],
          default: "soft",
        },
        { type: "checkbox", id: "cardHoverLift", label: "Lift cards slightly on hover", default: true },
      ],
    },
    {
      header: "Header",
      settings: [
        {
          type: "select",
          id: "headerVariant",
          label: "Header style",
          options: [
            { value: "classic", label: "Classic (mega menu, phone number)" },
            { value: "dentora", label: "Dentora (pill nav, no mega menu)" },
            { value: "skyvilla", label: "Skyvilla (centered nav, search icon)" },
          ],
          default: "classic",
          info: "Which Header partial the site uses on every page — set once here rather than choosing a different header per template.",
        },
        { type: "checkbox", id: "stickyHeader", label: "Sticky header on scroll", default: true, info: "Also set per-header in the Header section's own settings — that one wins if the two disagree." },
        { type: "checkbox", id: "transparentOnHero", label: "Transparent header over the hero", default: false, info: "Also set per-header in the Header section's own settings — that one wins if the two disagree." },
        { type: "range", id: "headerHeight", label: "Header height", min: 56, max: 120, step: 4, unit: "px", default: 80 },
        { type: "range", id: "logoWidth", label: "Desktop logo width", min: 80, max: 240, step: 8, unit: "px", default: 132 },
        { type: "range", id: "mobileLogoWidth", label: "Mobile logo width", min: 60, max: 180, step: 4, unit: "px", default: 104 },
        { type: "checkbox", id: "enableMegaMenu", label: "Enable submenus on nav items", default: true, info: "Turn off to force every nav item down to a plain link, e.g. for a minimal build." },
      ],
    },
    {
      header: "Footer",
      settings: [
        {
          type: "select",
          id: "footerVariant",
          label: "Footer layout",
          options: [
            { value: "classic", label: "Classic (four-column, recent works)" },
            { value: "dentora", label: "Dentora (big heading + watermark)" },
            { value: "skyvilla", label: "Skyvilla (dark navy, contact columns)" },
          ],
          default: "classic",
          info: "Which Footer partial the site uses on every page — set once here rather than choosing a different footer per template.",
        },
        {
          type: "select",
          id: "footerStyle",
          label: "Footer style",
          options: [
            { value: "dark", label: "Dark" },
            { value: "light", label: "Light" },
          ],
          default: "dark",
          info: "Classic footer variant only.",
        },
        { type: "checkbox", id: "showNewsletter", label: "Show newsletter signup", default: true },
        { type: "checkbox", id: "showRecentWorks", label: "Show recent works thumbnail grid", default: true },
      ],
    },
    {
      header: "Motion",
      settings: [
        { type: "checkbox", id: "enableScrollReveal", label: "Fade + rise sections in on scroll", default: true },
        { type: "range", id: "transitionSpeed", label: "Transition speed", min: 100, max: 500, step: 25, unit: "ms", default: 200 },
      ],
    },
    {
      header: "Floating actions",
      settings: [{ type: "checkbox", id: "showScrollTop", label: "Show floating scroll-to-top button", default: true }],
    },
  ],
};

export default settingsSchema;
