import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-hero",
  name: "Realty hero",
  category: "Hero",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Smart real estate" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "reliable construction" },
    { type: "image", id: "image", label: "Banner image" },
    { type: "text", id: "primaryButtonLabel", label: "Primary button label", default: "Get Free Consultation" },
    { type: "url", id: "primaryButtonHref", label: "Primary button link", default: "/contact" },
    { type: "text", id: "ratingValue", label: "Rating value", default: "4.9" },
    { type: "text", id: "ratingLabel", label: "Rating label", default: "500+ Happy Clients" },
  ],
  blocks: [
    {
      type: "stat",
      name: "Stat",
      settings: [
        { type: "text", id: "value", label: "Value", default: "25+" },
        { type: "text", id: "label", label: "Label", default: "Years Experience" },
      ],
    },
    {
      type: "avatar",
      name: "Rating avatar",
      settings: [{ type: "image", id: "image", label: "Avatar image" }],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "stat", settings: { value: "25+", label: "Years Experience" } },
    { type: "stat", settings: { value: "50+", label: "Expert Team Members" } },
    { type: "stat", settings: { value: "500+", label: "Projects Completed" } },
  ],
};

export default schema;
