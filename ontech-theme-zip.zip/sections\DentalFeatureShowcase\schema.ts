import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "dental-feature-showcase",
  name: "Dental feature showcase",
  category: "Content",
  settings: [
    { type: "image", id: "clinicImage", label: "Clinic image" },
    { type: "image", id: "doctorImage", label: "Doctor image" },
    { type: "text", id: "doctorImageBadgeLabel", label: "Doctor image badge label", default: "Book Appointment" },
    { type: "url", id: "doctorImageBadgeHref", label: "Doctor image badge link", default: "/contact" },
    { type: "text", id: "featureEyebrow", label: "Feature card eyebrow", default: "Feature Treatment" },
    { type: "text", id: "featureHeading", label: "Feature card heading", default: "Advanced Dental Care for a Healthier Smile" },
    {
      type: "textarea",
      id: "featureDescription",
      label: "Feature card description",
      default: "Join hundreds of patients achieving healthier, brighter smiles through expert dental care and personalized treatments.",
    },
    { type: "text", id: "doctorName", label: "Doctor name", default: "Dr. Daniel Carter" },
    { type: "text", id: "doctorRole", label: "Doctor role", default: "Lead Dental Specialist" },
    { type: "text", id: "doctorRatingValue", label: "Doctor rating value", default: "4.9" },
    { type: "text", id: "doctorReviewCount", label: "Doctor review count", default: "(40+ reviews)" },
    {
      type: "textarea",
      id: "doctorDescription",
      label: "Doctor description",
      default: "Join hundreds of patients achieving healthier, brighter smiles through expert dental care and personalized treatments.",
    },
  ],
  blocks: [
    {
      type: "stat",
      name: "Stat",
      settings: [
        { type: "text", id: "value", label: "Value", default: "98%" },
        { type: "text", id: "label", label: "Label", default: "Satisfaction Rate" },
      ],
    },
  ],
  maxBlocks: 4,
  defaultBlocks: [
    { type: "stat", settings: { value: "98%", label: "Satisfaction Rate" } },
    { type: "stat", settings: { value: "2k+", label: "Smiles Transformed" } },
    { type: "stat", settings: { value: "4.9", label: "Customer Rating" } },
  ],
};

export default schema;
