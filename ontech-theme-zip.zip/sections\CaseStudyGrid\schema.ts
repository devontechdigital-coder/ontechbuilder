import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "case-study-grid",
  name: "Case study grid",
  category: "Case studies",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Our case studies" },
    {
      type: "select",
      id: "columns",
      label: "Columns",
      options: [
        { value: "2", label: "2" },
        { value: "3", label: "3" },
      ],
      default: "3",
    },
    { type: "range", id: "currentPage", label: "Current page", min: 1, max: 20, step: 1, default: 1 },
    { type: "range", id: "totalPages", label: "Total pages", min: 1, max: 20, step: 1, default: 2 },
    { type: "url", id: "prevPageHref", label: "Previous page URL", default: "" },
    { type: "url", id: "nextPageHref", label: "Next page URL", default: "" },
  ],
  blocks: [
    {
      type: "case_study_card",
      name: "Case study card",
      settings: [
        { type: "image", id: "image", label: "Image" },
        { type: "text", id: "tag", label: "Tag", default: "Growth" },
        { type: "text", id: "date", label: "Date", default: "June 20, 2025" },
        { type: "text", id: "title", label: "Title", default: "Case study title" },
        { type: "url", id: "linkHref", label: "Link URL", default: "#" },
      ],
    },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "case_study_card", settings: { tag: "Growth", date: "June 20, 2025", title: "Why your company needs a strategic roadmap in 2025" } },
    { type: "case_study_card", settings: { tag: "Strategy", date: "June 20, 2025", title: "From goals to KPIs: turning vision into measurable success" } },
    { type: "case_study_card", settings: { tag: "Marketing", date: "June 20, 2025", title: "5 growth strategies every modern business should know" } },
    { type: "case_study_card", settings: { tag: "Growth", date: "June 20, 2025", title: "Digital transformation for service-based businesses" } },
    { type: "case_study_card", settings: { tag: "Strategy", date: "June 20, 2025", title: "Customer experience: turning satisfaction into loyalty" } },
    { type: "case_study_card", settings: { tag: "Marketing", date: "June 20, 2025", title: "A/B testing the modern homepage: several underperforming areas of our operation." } },
  ],
};

export default schema;
