import * as React from "react";
import { Container } from "../../components/Container";
import { Icon, type IconName } from "../../components/Icon";
import { asImage, asString, blocksOfType, parseNestedLinks, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface FooterProps {
  logoText: string;
  contactLabel?: string;
  email?: string;
  phone?: string;
  showNewsletter: boolean;
  newsletterHeading?: string;
  newsletterPlaceholder?: string;
  showRecentWorks: boolean;
  recentWorksHeading?: string;
  credit?: string;
  style: "dark" | "light";
  /** Raw blocks straight from storage; this component sorts them out itself. */
  blocks: RawBlock[];
}

interface FooterLink {
  label: string;
  href: string;
  children?: FooterLink[];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function parseFooterLinks(value: unknown): FooterLink[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (!isRecord(item)) return null;
      const label = asString(item.label).trim();
      const href = asString(item.href).trim();
      if (!label || !href) return null;
      const children = parseFooterLinks(item.children);
      return { label, href, ...(children.length > 0 ? { children } : {}) };
    })
    .filter((item): item is FooterLink => Boolean(item));
}

function parseFooterLinksJson(value: unknown): FooterLink[] {
  if (typeof value !== "string" || !value.trim()) return [];
  try {
    return parseFooterLinks(JSON.parse(value));
  } catch {
    return [];
  }
}

function getFooterLinks(block: RawBlock): FooterLink[] {
  const directLinks = parseFooterLinks(block.links);
  if (directLinks.length > 0) return directLinks;

  const jsonLinks = parseFooterLinksJson(block.linksJson);
  if (jsonLinks.length > 0) return jsonLinks;

  return parseNestedLinks(block.linksJson) as FooterLink[];
}

/**
 * Four-column footer with newsletter signup, a recent-works thumbnail
 * grid, and recursive link columns.
 */
export function Footer({
  logoText,
  contactLabel,
  email,
  phone,
  showNewsletter,
  newsletterHeading,
  newsletterPlaceholder = "Enter your email",
  showRecentWorks,
  recentWorksHeading,
  credit,
  style,
  blocks,
}: FooterProps) {
  const linkColumnBlocks = blocksOfType(blocks, "link_column");
  const socialBlocks = blocksOfType(blocks, "social_link");
  const recentWorkBlocks = blocksOfType(blocks, "recent_work");
  const recentWorks = recentWorkBlocks.map((block) => asImage(block.image)).filter((image): image is ThemeImage => Boolean(image));

  return (
    <footer className={`cop-footer cop-footer--${style}`}>
      <Container width="wide" className="cop-footer__grid">
        <div className="cop-footer__brand">
          <span className="cop-footer__logo-mark" aria-hidden="true" />
          {contactLabel && <p className="cop-footer__contact-label">{contactLabel}</p>}
          {email && (
            <a href={`mailto:${email}`} className="cop-footer__contact-link">
              {email}
            </a>
          )}
          {phone && (
            <a href={`tel:${phone}`} className="cop-footer__contact-link">
              {phone}
            </a>
          )}
          {socialBlocks.length > 0 && (
            <div className="cop-footer__social">
              {socialBlocks.map((block) => (
                <a
                  key={block.id}
                  href={asString(block.href, "#")}
                  aria-label={asString(block.label, "Social link")}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Icon name={(asString(block.icon, "facebook") as IconName) || "facebook"} size={15} />
                </a>
              ))}
            </div>
          )}
        </div>

        {linkColumnBlocks.map((block) => (
          <div key={block.id} className="cop-footer__column">
            <h3>{asString(block.heading, "Links")}</h3>
            <FooterLinkList links={getFooterLinks(block)} />
          </div>
        ))}

        {showRecentWorks && recentWorks.length > 0 && (
          <div className="cop-footer__column cop-footer__column--works">
            {recentWorksHeading && <h3>{recentWorksHeading}</h3>}
            <div className="cop-footer__works-grid">
              {recentWorks.map((image, index) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={image.src + index} src={image.src} alt={image.alt} loading="lazy" />
              ))}
            </div>
          </div>
        )}
      </Container>

      {showNewsletter && (
        <Container width="wide" className="cop-footer__newsletter-row">
          {newsletterHeading && <span>{newsletterHeading}</span>}
          <form className="cop-footer__newsletter" onSubmit={(event) => event.preventDefault()} aria-label="Newsletter signup">
            <label className="cop-visually-hidden" htmlFor="footer-newsletter-email">
              Email address
            </label>
            <input id="footer-newsletter-email" type="email" placeholder={newsletterPlaceholder} required />
            <button type="submit" aria-label="Subscribe">
              <Icon name="arrow-up-right" size={16} />
            </button>
          </form>
        </Container>
      )}

      <div className="cop-footer__bottom">
        <Container width="wide" className="cop-footer__bottom-inner">
          <span>{logoText}</span>
          {credit && <span>{credit}</span>}
        </Container>
      </div>
    </footer>
  );
}

function FooterLinkList({ links }: { links: FooterLink[] }) {
  return (
    <ul>
      {links.map((link) => (
        <li key={link.href + link.label}>
          <a href={link.href}>{link.label}</a>
          {link.children && link.children.length > 0 && (
            <div className="cop-footer__submenu">
              <FooterLinkList links={link.children} />
            </div>
          )}
        </li>
      ))}
    </ul>
  );
}
