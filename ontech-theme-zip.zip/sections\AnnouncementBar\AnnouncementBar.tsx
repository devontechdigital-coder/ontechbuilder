import * as React from "react";
import { Icon } from "../../components/Icon";
import { asString } from "../../components/blockHelpers";

export interface AnnouncementBarProps {
  message?: string;
  linkLabel?: string;
  linkHref?: string;
  backgroundColor?: string;
  textColor?: string;
  dismissible?: boolean;
}

/** A thin bar above the header for a time-boxed message or promo — the same role as an "AnnouncementBar" section in other themes, added here as an opt-in section (add it via the Header group) rather than baked into every page. */
export function AnnouncementBar({ message, linkLabel, linkHref, backgroundColor, textColor, dismissible = true }: AnnouncementBarProps) {
  const [dismissed, setDismissed] = React.useState(false);
  const text = asString(message);
  if (!text || dismissed) return null;

  return (
    <div className="cop-announcement-bar" style={{ backgroundColor: backgroundColor || undefined, color: textColor || undefined }}>
      <div className="cop-announcement-bar__inner">
        <span>{text}</span>
        {linkLabel && linkHref && (
          <a href={linkHref}>{linkLabel}</a>
        )}
      </div>
      {dismissible && (
        <button type="button" className="cop-announcement-bar__close" aria-label="Dismiss" onClick={() => setDismissed(true)}>
          <Icon name="close" size={14} />
        </button>
      )}
    </div>
  );
}
