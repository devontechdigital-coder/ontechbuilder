import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface RealtyServicesProps {
  heading: string;
  headingItalic?: string;
  noteHeading?: string;
  noteText?: string;
  ratingValue?: string;
  /** Raw "service" blocks. */
  blocks: RawBlock[];
}

/** Centered heading, a 4-up service card grid (one dark/highlighted card), and a rating/note row beneath it. */
export function RealtyServices({ heading, headingItalic, noteHeading, noteText, ratingValue, blocks }: RealtyServicesProps) {
  return (
    <section className="sv-section sv-services">
      <Container width="wide">
        <h2 className="sv-section__heading sv-section__heading--center">
          {heading} {headingItalic && <em>{headingItalic}</em>}
        </h2>

        <div className="sv-services__grid">
          {blocks.map((block) => {
            const dark = Boolean(block.dark);
            const link = optionalLink(block.linkLabel, block.linkHref);
            return (
              <div key={block.id} className={`sv-services__card ${dark ? "sv-services__card--dark" : ""}`.trim()}>
                {dark ? (
                  <ThemeImg image={asImage(block.image)} ratio="auto" placeholderLabel="Service image" className="sv-services__card-image" />
                ) : (
                  <span className="sv-services__card-icon">
                    <Icon name="sparkle" size={20} />
                  </span>
                )}
                <h3>{asString(block.title)}</h3>
                {!dark && typeof block.description === "string" && block.description && <p>{block.description}</p>}
                {link && (
                  <a href={link.href} className="sv-services__card-link">
                    {link.label}
                    <Icon name="arrow-up-right" size={13} />
                  </a>
                )}
              </div>
            );
          })}
        </div>

        {(noteHeading || noteText) && (
          <div className="sv-services__note">
            {ratingValue && (
              <span className="sv-services__note-rating">
                <Icon name="star" size={14} />
                {ratingValue}
              </span>
            )}
            {noteHeading && <strong>{noteHeading}</strong>}
            {noteText && <span>{noteText}</span>}
          </div>
        )}
      </Container>
    </section>
  );
}
