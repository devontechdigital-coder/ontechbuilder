import * as React from "react";
import { Container } from "../../components/Container";
import { Avatar } from "../../components/Avatar";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface RealtyFaqProps {
  heading: string;
  headingItalic?: string;
  ctaLabel?: string;
  ctaHref?: string;
  /** Raw blocks mixing "avatar" (left-column stack) and "faq" (the accordion). */
  blocks: RawBlock[];
}

/** Left column: heading + avatar stack + a "view all" CTA. Right column: an accessible FAQ accordion (one item open at a time). */
export function RealtyFaq({ heading, headingItalic, ctaLabel, ctaHref, blocks }: RealtyFaqProps) {
  const ctaButton = optionalLink(ctaLabel, ctaHref);
  const avatars = blocksOfType(blocks, "avatar")
    .map((block) => asImage(block.image))
    .filter((img): img is ThemeImage => Boolean(img));
  const faqBlocks = blocksOfType(blocks, "faq");
  const [openId, setOpenId] = React.useState<string | null>(faqBlocks[0]?.id ?? null);

  return (
    <section className="sv-section sv-faq">
      <Container width="wide" className="sv-faq__grid">
        <div className="sv-faq__intro">
          <h2>
            {heading} {headingItalic && <em>{headingItalic}</em>}
          </h2>
          {avatars.length > 0 && (
            <div className="sv-hero__avatars">
              {avatars.map((avatar, index) => (
                <Avatar key={avatar.src + index} image={avatar} size={34} />
              ))}
            </div>
          )}
          {ctaButton && (
            <a href={ctaButton.href} className="sv-btn sv-btn--sm">
              {ctaButton.label}
            </a>
          )}
        </div>

        <div className="sv-faq__accordion">
          {faqBlocks.map((block) => {
            const isOpen = openId === block.id;
            return (
              <div key={block.id} className="sv-faq__item">
                <button type="button" className="sv-faq__item-trigger" aria-expanded={isOpen} onClick={() => setOpenId(isOpen ? null : block.id)}>
                  {asString(block.question)}
                  <Icon name={isOpen ? "minus" : "plus"} size={16} />
                </button>
                {isOpen && <p className="sv-faq__item-answer">{asString(block.answer)}</p>}
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
