"use client";

import * as React from "react";

/**
 * components/ScrollRevealController.tsx
 *
 * Renders nothing — it only observes the direct children of `<main>`
 * (i.e. each top-level section) and adds `.cop-in-view` the first time
 * each one enters the viewport, which assets/styles/theme.css uses to
 * fade + rise it into place. One IntersectionObserver, no per-section
 * code, and it unobserves each element after its first reveal so it
 * never re-triggers on scroll-back.
 *
 * A single controller mounted once in ThemeLayout is deliberately
 * simpler than teaching all eighteen section components their own
 * animation logic — the "orchestrated moment" is the whole page
 * settling in together, not eighteen independent effects.
 */
export function ScrollRevealController({ enabled }: { enabled: boolean }) {
  React.useEffect(() => {
    if (!enabled) return;
    if (typeof window === "undefined" || !("IntersectionObserver" in window)) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;

    const main = document.querySelector(".cop-main");
    if (!main) return;
    const targets = Array.from(main.children);
    if (targets.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("cop-in-view");
            observer.unobserve(entry.target);
          }
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" },
    );

    targets.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [enabled]);

  return null;
}
