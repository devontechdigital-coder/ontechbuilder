import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "mission-vision",
  name: "Mission & vision",
  category: "Content",
  settings: [
    { type: "text", id: "missionTitle", label: "Mission title", default: "Our Mission" },
    {
      type: "textarea",
      id: "missionDescription",
      label: "Mission description",
      default: "To empower businesses of all sizes to unlock their full potential through strategic insight, tailored consulting, and measurable results. We are committed to delivering innovative solutions that drive sustainable growth, operational excellence, and long-term success for our clients.",
    },
    { type: "text", id: "visionTitle", label: "Vision title", default: "Our Vision" },
    { type: "image", id: "visionImage", label: "Vision image" },
  ],
  blocks: [
    {
      type: "bullet",
      name: "Vision bullet",
      settings: [{ type: "text", id: "text", label: "Text", default: "Global impact" }],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "bullet", settings: { text: "Global impact" } },
    { type: "bullet", settings: { text: "Innovative thinking" } },
    { type: "bullet", settings: { text: "Empowering growth" } },
  ],
};

export default schema;
