import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-services",
  name: "Realty services",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Reliable services for real estate and" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "construction" },
    { type: "text", id: "noteHeading", label: "Note heading", default: "Complete Real Estate Solutions" },
    { type: "text", id: "noteText", label: "Note text", default: "Get 100% Satisfaction" },
    { type: "text", id: "ratingValue", label: "Note rating value", default: "4.9" },
  ],
  blocks: [
    {
      type: "service",
      name: "Service",
      settings: [
        { type: "text", id: "title", label: "Title", default: "Residential Construction" },
        { type: "textarea", id: "description", label: "Description", default: "We build lasting, high-quality residential communities with attention to detail." },
        { type: "checkbox", id: "dark", label: "Highlighted (dark, image card)", default: false },
        { type: "image", id: "image", label: "Image (highlighted card only)" },
        { type: "text", id: "linkLabel", label: "Link label", default: "View Details" },
        { type: "url", id: "linkHref", label: "Link URL", default: "#" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "service", settings: { title: "Residential Construction", description: "We build lasting, high-quality residential communities with attention to detail.", linkLabel: "View Details", linkHref: "#" } },
    { type: "service", settings: { title: "Commercial Construction", description: "Scalable commercial builds engineered for performance and durability.", linkLabel: "View Details", linkHref: "#" } },
    { type: "service", settings: { title: "Project Development", dark: true, linkLabel: "View Details", linkHref: "#" } },
    { type: "service", settings: { title: "Design & Planning", description: "Full-service design and architectural planning for every project stage.", linkLabel: "View Details", linkHref: "#" } },
  ],
};

export default schema;
