import * as React from "react";
import { Container } from "../../components/Container";

export interface DentalIntroProps {
  boldText: string;
  mutedText?: string;
}

/** Large two-tone intro statement: a bold lead-in followed by muted supporting copy, in one flowing line. */
export function DentalIntro({ boldText, mutedText }: DentalIntroProps) {
  return (
    <section className="d1-intro">
      <Container width="wide">
        <p className="d1-intro__text">
          <span className="d1-intro__bold">{boldText} </span>
          {mutedText && <span className="d1-intro__muted">{mutedText}</span>}
        </p>
      </Container>
    </section>
  );
}
