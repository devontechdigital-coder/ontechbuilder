/**
 * theme.config.ts
 *
 * Portable manifest describing this theme package to the host platform.
 * Plain, serializable data only — no side effects, no React imports —
 * so the host can parse and validate it without executing app code.
 */

export interface ThemeConfig {
  id: string;
  name: string;
  version: string;
  engineVersion: string;
  description: string;
  author: string;
  templates: Record<string, string>;
  partials: Record<string, string>;
  sections: Record<string, string>;
  capabilities: {
    settingsSchema: boolean;
    sectionSchemas: boolean;
    blocks: boolean;
    localization: boolean;
    imageFields: boolean;
    responsivePreview: boolean;
    megaMenu: boolean;
  };
}

const themeConfig: ThemeConfig = {
  id: "copora",
  name: "Copora",
  version: "1.2.0",
  engineVersion: "^1.0.0",
  description:
    "A bold, editorial theme for consulting agencies and professional services — confident grotesk typography, image-led storytelling, an advanced mega-menu header, and rich proof sections (stats, case studies, testimonials, team).",
  author: "Aster Theme Studio",
  templates: {
    index: "templates/index.tsx",
    home1: "templates/home1.tsx",
    home2: "templates/home2.tsx",
    page: "templates/page.tsx",
    about: "templates/about.tsx",
    "case-studies": "templates/case-studies.tsx",
    blog: "templates/blog.tsx",
    contact: "templates/contact.tsx",
    search: "templates/search.tsx",
    "404": "templates/404.tsx",
  },
  partials: {
    header: "partials/Header/Header.tsx",
    footer: "partials/Footer/Footer.tsx",
    "header-dentora": "partials/Header/HeaderDentora.tsx",
    "footer-dentora": "partials/Footer/FooterDentora.tsx",
    "header-skyvilla": "partials/Header/HeaderSkyvilla.tsx",
    "footer-skyvilla": "partials/Footer/FooterSkyvilla.tsx",
  },
  sections: {
    "announcement-bar": "sections/AnnouncementBar/AnnouncementBar.tsx",
    hero: "sections/Hero/Hero.tsx",
    "page-intro": "sections/PageIntro/PageIntro.tsx",
    "logo-cloud": "sections/LogoCloud/LogoCloud.tsx",
    "service-cards": "sections/ServiceCards/ServiceCards.tsx",
    "stats-row": "sections/StatsRow/StatsRow.tsx",
    "split-content": "sections/SplitContent/SplitContent.tsx",
    "process-dark": "sections/ProcessDark/ProcessDark.tsx",
    "featured-case-study": "sections/FeaturedCaseStudy/FeaturedCaseStudy.tsx",
    "case-study-list": "sections/CaseStudyList/CaseStudyList.tsx",
    "case-study-grid": "sections/CaseStudyGrid/CaseStudyGrid.tsx",
    "testimonial-showcase": "sections/TestimonialShowcase/TestimonialShowcase.tsx",
    "team-grid": "sections/TeamGrid/TeamGrid.tsx",
    "mission-vision": "sections/MissionVision/MissionVision.tsx",
    "blog-grid": "sections/BlogGrid/BlogGrid.tsx",
    "contact-form": "sections/ContactForm/ContactForm.tsx",
    "location-card": "sections/LocationCard/LocationCard.tsx",
    "cta-banner": "sections/CtaBanner/CtaBanner.tsx",
    "dental-hero": "sections/DentalHero/DentalHero.tsx",
    "dental-intro": "sections/DentalIntro/DentalIntro.tsx",
    "dental-feature-showcase": "sections/DentalFeatureShowcase/DentalFeatureShowcase.tsx",
    "dental-insights-intro": "sections/DentalInsightsIntro/DentalInsightsIntro.tsx",
    "dental-blog-grid": "sections/DentalBlogGrid/DentalBlogGrid.tsx",
    "realty-hero": "sections/RealtyHero/RealtyHero.tsx",
    "realty-intro": "sections/RealtyIntro/RealtyIntro.tsx",
    "realty-services": "sections/RealtyServices/RealtyServices.tsx",
    "realty-about": "sections/RealtyAbout/RealtyAbout.tsx",
    "realty-video-banner": "sections/RealtyVideoBanner/RealtyVideoBanner.tsx",
    "realty-why-us": "sections/RealtyWhyUs/RealtyWhyUs.tsx",
    "realty-projects": "sections/RealtyProjects/RealtyProjects.tsx",
    "realty-stats": "sections/RealtyStats/RealtyStats.tsx",
    "realty-contact-split": "sections/RealtyContactSplit/RealtyContactSplit.tsx",
    "realty-faq": "sections/RealtyFaq/RealtyFaq.tsx",
    "realty-testimonials": "sections/RealtyTestimonials/RealtyTestimonials.tsx",
    "realty-blog-grid": "sections/RealtyBlogGrid/RealtyBlogGrid.tsx",
  },
  capabilities: {
    settingsSchema: true,
    sectionSchemas: true,
    blocks: true,
    localization: true,
    imageFields: true,
    responsivePreview: true,
    megaMenu: true,
  },
};

export default themeConfig;
