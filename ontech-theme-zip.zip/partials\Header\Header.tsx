import * as React from "react";
import { Icon } from "../../components/Icon";
import { Container } from "../../components/Container";
import { Button } from "../../components/Button";
import { asString, type RawBlock } from "../../components/blockHelpers";
import type { LinkValue, ThemeImage } from "../../components/types";

export interface HeaderProps {
  logoImage?: ThemeImage;
  mobileLogoImage?: ThemeImage;
  logoText: string;
  /** Raw nav blocks, mixing "nav_link" and "nav_menu" types. Submenus can use recursive `items`. */
  navBlocks: RawBlock[];
  phone?: string;
  ctaLabel?: string;
  ctaHref?: string;
  layout?: "classic" | "centered";
  mobileMenuStyle?: "inline" | "overlay";
  sticky?: boolean;
  transparentOnHero?: boolean;
  showBorder?: boolean;
  backgroundColor?: string;
  textColor?: string;
  enableMegaMenu?: boolean;
}

interface NavMenuItem {
  label: string;
  href?: string;
  children?: NavMenuItem[];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function parseMenuItems(value: unknown): NavMenuItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (!isRecord(item)) return null;
      const label = asString(item.label).trim();
      if (!label) return null;
      const href = asString(item.href).trim() || undefined;
      const children = parseMenuItems(item.children);
      return { label, href, ...(children.length > 0 ? { children } : {}) };
    })
    .filter((item): item is NavMenuItem => Boolean(item));
}

function parseMenuItemsJson(value: unknown): NavMenuItem[] {
  if (typeof value !== "string" || !value.trim()) return [];
  try {
    return parseMenuItems(JSON.parse(value));
  } catch {
    return [];
  }
}

function parseLegacyColumnsText(text: unknown): NavMenuItem[] {
  if (typeof text !== "string" || !text.trim()) return [];
  const items: NavMenuItem[] = [];
  let currentColumn: NavMenuItem | null = null;

  for (const rawLine of text.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith("##")) {
      currentColumn = { label: line.replace(/^##\s*/, ""), children: [] };
      items.push(currentColumn);
      continue;
    }
    if (!line.includes("|")) continue;
    const [label, href] = line.split("|").map((part) => part.trim());
    if (!label || !href) continue;
    const link = { label, href };
    if (currentColumn) {
      currentColumn.children = [...(currentColumn.children ?? []), link];
    } else {
      items.push(link);
    }
  }

  return items;
}

function getMenuItems(block: RawBlock): NavMenuItem[] {
  const directItems = parseMenuItems(block.items);
  if (directItems.length > 0) return directItems;

  const jsonItems = parseMenuItemsJson(block.itemsJson);
  if (jsonItems.length > 0) return jsonItems;

  return parseLegacyColumnsText(block.columnsText);
}

function MenuTree({
  items,
  className = "",
  onNavigate,
}: {
  items: NavMenuItem[];
  className?: string;
  onNavigate?: () => void;
}) {
  return (
    <ul className={`cop-menu-tree ${className}`.trim()}>
      {items.map((item, index) => (
        <li key={`${item.label}-${item.href ?? "group"}-${index}`} className={item.children?.length ? "cop-menu-tree__item--parent" : undefined}>
          {item.href ? (
            <a href={item.href} role="menuitem" onClick={onNavigate}>
              {item.label}
              {item.children?.length ? <Icon name="chevron-right" size={13} /> : null}
            </a>
          ) : (
            <span className="cop-menu-tree__label">
              {item.label}
              {item.children?.length ? <Icon name="chevron-right" size={13} /> : null}
            </span>
          )}
          {item.children?.length ? <MenuTree items={item.children} onNavigate={onNavigate} /> : null}
        </li>
      ))}
    </ul>
  );
}

/**
 * Header with recursive submenus. Each `nav_menu` can provide an
 * `items` tree (or JSON in `itemsJson`) where every item may have
 * `children`, with no depth limit imposed by the component.
 */
export function Header({
  logoImage,
  mobileLogoImage,
  logoText,
  navBlocks,
  phone,
  ctaLabel,
  ctaHref,
  layout = "classic",
  mobileMenuStyle = "inline",
  sticky = true,
  transparentOnHero = false,
  showBorder = true,
  backgroundColor,
  textColor,
  enableMegaMenu = true,
}: HeaderProps) {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [openMenuId, setOpenMenuId] = React.useState<string | null>(null);
  const [mobileMenuOpenId, setMobileMenuOpenId] = React.useState<string | null>(null);
  const closeTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const headerRef = React.useRef<HTMLElement | null>(null);

  const ctaButton: LinkValue | undefined = ctaLabel && ctaHref ? { label: ctaLabel, href: ctaHref } : undefined;

  const clearCloseTimer = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
  };
  const scheduleClose = () => {
    clearCloseTimer();
    closeTimer.current = setTimeout(() => setOpenMenuId(null), 150);
  };

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (headerRef.current && !headerRef.current.contains(event.target as Node)) setOpenMenuId(null);
    }
    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape") setOpenMenuId(null);
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  const headerStyle: React.CSSProperties | undefined =
    backgroundColor || textColor ? { backgroundColor: backgroundColor || undefined, color: textColor || undefined } : undefined;

  return (
    <header
      ref={headerRef}
      className={[
        "cop-header",
        sticky ? "cop-header--sticky" : "",
        transparentOnHero ? "cop-header--transparent" : "",
        layout === "centered" ? "cop-header--centered" : "",
        showBorder ? "" : "cop-header--no-border",
      ]
        .filter(Boolean)
        .join(" ")}
      style={headerStyle}
    >
      <Container width="wide" className="cop-header__inner">
        <a href="/" className="cop-header__logo" aria-label={logoText}>
          {logoImage?.src ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoImage.src} alt={logoImage.alt} className={`cop-header__logo-img ${mobileLogoImage?.src ? "cop-header__logo-img--desktop" : ""}`} />
          ) : (
            <>
              <span className="cop-header__logo-mark" aria-hidden="true" />
              <span className="cop-header__logo-text">{logoText}</span>
            </>
          )}
          {mobileLogoImage?.src && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={mobileLogoImage.src} alt={mobileLogoImage.alt || logoText} className="cop-header__logo-img cop-header__logo-img--mobile" />
          )}
        </a>

        <nav className="cop-header__nav cop-header__nav--desktop" aria-label="Primary">
          {navBlocks.map((block) => {
            if (block.type === "nav_link") {
              return (
                <a key={block.id} href={asString(block.href, "#")}>
                  {asString(block.label)}
                </a>
              );
            }

            const style = block.style === "mega" ? "mega" : "simple";
            const menuItems = getMenuItems(block);
            const hasFeatured = style === "mega" && Boolean(block.featuredTitle || block.featuredImage);
            const isOpen = openMenuId === block.id;

            return (
              <div
                key={block.id}
                className="cop-mega"
                onMouseEnter={() => {
                  if (!enableMegaMenu) return;
                  clearCloseTimer();
                  setOpenMenuId(block.id);
                }}
                onMouseLeave={scheduleClose}
              >
                <button
                  type="button"
                  className="cop-mega__trigger"
                  aria-haspopup="true"
                  aria-expanded={isOpen}
                  onClick={() => setOpenMenuId((current) => (current === block.id ? null : block.id))}
                >
                  {asString(block.label)}
                  <Icon name="chevron-down" size={14} />
                </button>
                {enableMegaMenu && isOpen && (menuItems.length > 0 || hasFeatured) && (
                  <div className={`cop-mega__panel cop-mega__panel--${style}`} role="menu">
                    {menuItems.length > 0 && (
                      <div className="cop-mega__columns">
                        {style === "mega" ? (
                          menuItems.map((item, itemIndex) => (
                            <div key={`${item.label}-${itemIndex}`} className="cop-mega__column">
                              {item.children?.length ? (
                                <>
                                  <p className="cop-mega__column-heading">{item.label}</p>
                                  <MenuTree items={item.children} />
                                </>
                              ) : (
                                <MenuTree items={[item]} />
                              )}
                            </div>
                          ))
                        ) : (
                          <div className="cop-mega__column">
                            <MenuTree items={menuItems} />
                          </div>
                        )}
                      </div>
                    )}
                    {hasFeatured && (
                      <a href={asString(block.featuredLinkHref, "#")} className="cop-mega__featured">
                        {(block.featuredImage as ThemeImage | undefined)?.src && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={(block.featuredImage as ThemeImage).src} alt={(block.featuredImage as ThemeImage).alt} />
                        )}
                        {typeof block.featuredTitle === "string" && block.featuredTitle && (
                          <span className="cop-mega__featured-title">{block.featuredTitle}</span>
                        )}
                        {typeof block.featuredDescription === "string" && block.featuredDescription && (
                          <span className="cop-mega__featured-desc">{block.featuredDescription}</span>
                        )}
                        {typeof block.featuredLinkLabel === "string" && block.featuredLinkLabel && (
                          <span className="cop-mega__featured-link">
                            {block.featuredLinkLabel}
                            <Icon name="arrow-up-right" size={13} />
                          </span>
                        )}
                      </a>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        <div className="cop-header__actions">
          {phone && (
            <a href={`tel:${phone}`} className="cop-header__phone">
              {phone}
            </a>
          )}
          {ctaButton && (
            <Button href={ctaButton.href} variant="primary" size="sm" className="cop-header__cta">
              {ctaButton.label}
            </Button>
          )}
          <button
            type="button"
            className="cop-header__icon-btn cop-header__icon-btn--mobile"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((v) => !v)}
          >
            <Icon name={mobileOpen ? "close" : "menu"} size={20} />
          </button>
        </div>
      </Container>

      {mobileOpen &&
        (() => {
          const mobileNavItems = (
            <>
              {navBlocks.map((block) => {
                if (block.type === "nav_link") {
                  return (
                    <a key={block.id} href={asString(block.href, "#")} onClick={() => setMobileOpen(false)}>
                      {asString(block.label)}
                    </a>
                  );
                }
                const menuItems = getMenuItems(block);
                const isOpen = mobileMenuOpenId === block.id;
                return (
                  <div key={block.id} className="cop-header__mobile-menu">
                    <button
                      type="button"
                      className="cop-header__mobile-menu-trigger"
                      aria-expanded={isOpen}
                      onClick={() => setMobileMenuOpenId((current) => (current === block.id ? null : block.id))}
                    >
                      {asString(block.label)}
                      <Icon name="chevron-down" size={14} />
                    </button>
                    {isOpen && (
                      <div className="cop-header__mobile-submenu">
                        <MenuTree items={menuItems} onNavigate={() => setMobileOpen(false)} />
                      </div>
                    )}
                  </div>
                );
              })}
              {ctaButton && (
                <Button href={ctaButton.href} variant="primary" size="md" className="cop-header__mobile-cta">
                  {ctaButton.label}
                </Button>
              )}
            </>
          );

          if (mobileMenuStyle === "overlay") {
            return (
              <nav className="cop-header__nav cop-header__nav--mobile-overlay" aria-label="Primary mobile">
                <Container width="wide">
                  <button type="button" className="cop-header__mobile-overlay-close" aria-label="Close menu" onClick={() => setMobileOpen(false)}>
                    <Icon name="close" size={22} />
                  </button>
                  {mobileNavItems}
                </Container>
              </nav>
            );
          }

          return (
            <nav className="cop-header__nav cop-header__nav--mobile" aria-label="Primary mobile">
              <Container width="wide">{mobileNavItems}</Container>
            </nav>
          );
        })()}
    </header>
  );
}
