import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Avatar } from "../../components/Avatar";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface RealtyHeroProps {
  heading: string;
  headingItalic?: string;
  image?: ThemeImage;
  primaryButtonLabel?: string;
  primaryButtonHref?: string;
  ratingValue?: string;
  ratingLabel?: string;
  /** Raw blocks mixing "stat" (the floating stat card) and "avatar" (the rating avatar stack). */
  blocks: RawBlock[];
}

/**
 * Full-bleed banner hero: a floating dark stat card top-right over the
 * photo, and a headline + CTA + avatar-stack rating overlaid bottom-left.
 */
export function RealtyHero({ heading, headingItalic, image, primaryButtonLabel, primaryButtonHref, ratingValue, ratingLabel, blocks }: RealtyHeroProps) {
  const primaryButton = optionalLink(primaryButtonLabel, primaryButtonHref);
  const statBlocks = blocksOfType(blocks, "stat");
  const avatars = blocksOfType(blocks, "avatar")
    .map((block) => asImage(block.image))
    .filter((img): img is ThemeImage => Boolean(img));

  return (
    <section className="sv-hero">
      <Container width="wide">
        <div className="sv-hero__frame">
          <ThemeImg image={image} ratio="auto" placeholderLabel="Hero image" className="sv-hero__image" />

          {statBlocks.length > 0 && (
            <div className="sv-hero__stats">
              {statBlocks.map((block) => (
                <div key={block.id} className="sv-hero__stat">
                  <strong>{asString(block.value)}</strong>
                  <span>{asString(block.label)}</span>
                </div>
              ))}
            </div>
          )}

          <div className="sv-hero__overlay">
            <h1>
              {heading} {headingItalic && <em>{headingItalic}</em>}
            </h1>
            <div className="sv-hero__actions">
              {primaryButton && (
                <a href={primaryButton.href} className="sv-btn">
                  {primaryButton.label}
                  <span className="sv-btn__icon">
                    <Icon name="arrow-up-right" size={14} />
                  </span>
                </a>
              )}
              {(avatars.length > 0 || ratingValue) && (
                <div className="sv-hero__rating">
                  {avatars.length > 0 && (
                    <div className="sv-hero__avatars">
                      {avatars.map((avatar, index) => (
                        <Avatar key={avatar.src + index} image={avatar} size={34} />
                      ))}
                    </div>
                  )}
                  {ratingValue && (
                    <div className="sv-hero__rating-text">
                      <span className="sv-hero__rating-stars">
                        <Icon name="star" size={13} />
                        {ratingValue}
                      </span>
                      {ratingLabel && <span>{ratingLabel}</span>}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
