import * as React from "react";
import { Container } from "../../components/Container";
import { Avatar } from "../../components/Avatar";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface RealtyWhyUsProps {
  heading: string;
  headingItalic?: string;
  description?: string;
  ctaLabel?: string;
  ctaHref?: string;
  ratingValue?: string;
  ratingLabel?: string;
  quoteText?: string;
  quoteButtonLabel?: string;
  quoteButtonHref?: string;
  /** Raw blocks mixing "avatar" (rating stack), "point" (right-column numbered rows) and "quote_avatar" (quote strip stack). */
  blocks: RawBlock[];
}

/** Left: heading/description/CTA + rating avatars. Right: a numbered list of differentiators. Beneath: a quote strip with its own avatar stack and CTA. */
export function RealtyWhyUs({ heading, headingItalic, description, ctaLabel, ctaHref, ratingValue, ratingLabel, quoteText, quoteButtonLabel, quoteButtonHref, blocks }: RealtyWhyUsProps) {
  const ctaButton = optionalLink(ctaLabel, ctaHref);
  const quoteButton = optionalLink(quoteButtonLabel, quoteButtonHref);
  const avatars = blocksOfType(blocks, "avatar")
    .map((block) => asImage(block.image))
    .filter((img): img is ThemeImage => Boolean(img));
  const pointBlocks = blocksOfType(blocks, "point");
  const quoteAvatars = blocksOfType(blocks, "quote_avatar")
    .map((block) => asImage(block.image))
    .filter((img): img is ThemeImage => Boolean(img));

  return (
    <section className="sv-section sv-whyus">
      <Container width="wide" className="sv-whyus__grid">
        <div className="sv-whyus__content">
          <h2>
            {heading} {headingItalic && <em>{headingItalic}</em>}
          </h2>
          {description && <p>{description}</p>}
          <div className="sv-whyus__actions">
            {ctaButton && (
              <a href={ctaButton.href} className="sv-btn">
                {ctaButton.label}
                <span className="sv-btn__icon">
                  <Icon name="arrow-up-right" size={14} />
                </span>
              </a>
            )}
            {(avatars.length > 0 || ratingValue) && (
              <div className="sv-whyus__rating">
                {avatars.length > 0 && (
                  <div className="sv-hero__avatars">
                    {avatars.map((avatar, index) => (
                      <Avatar key={avatar.src + index} image={avatar} size={32} />
                    ))}
                  </div>
                )}
                {ratingValue && (
                  <span>
                    <strong>{ratingValue}</strong> {ratingLabel}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="sv-whyus__points">
          {pointBlocks.map((block) => (
            <div key={block.id} className="sv-whyus__point">
              <span className="sv-whyus__point-number">{asString(block.number)}</span>
              <div>
                <h3>{asString(block.title)}</h3>
                {typeof block.description === "string" && block.description && <p>{block.description}</p>}
              </div>
            </div>
          ))}
        </div>
      </Container>

      {quoteText && (
        <Container width="wide">
          <div className="sv-whyus__quote">
            <p>“{quoteText}”</p>
            <div className="sv-whyus__quote-footer">
              {quoteAvatars.length > 0 && (
                <div className="sv-hero__avatars">
                  {quoteAvatars.map((avatar, index) => (
                    <Avatar key={avatar.src + index} image={avatar} size={32} />
                  ))}
                </div>
              )}
              {quoteButton && (
                <a href={quoteButton.href} className="sv-btn sv-btn--sm">
                  {quoteButton.label}
                </a>
              )}
            </div>
          </div>
        </Container>
      )}
    </section>
  );
}
