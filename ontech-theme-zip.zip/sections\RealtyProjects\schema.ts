import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-projects",
  name: "Realty project gallery",
  category: "Content",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Our work defined by precision" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "strength and Integrity" },
    { type: "text", id: "footerLinkLabel", label: "Footer link label", default: "Get a Free Quote" },
    { type: "url", id: "footerLinkHref", label: "Footer link URL", default: "/contact" },
  ],
  blocks: [
    {
      type: "project",
      name: "Project",
      settings: [
        { type: "image", id: "image", label: "Image" },
        { type: "text", id: "title", label: "Title", default: "The Vertex Place" },
        { type: "url", id: "linkHref", label: "Link URL", default: "#" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "project", settings: { title: "The Vertex Place", linkHref: "#" } },
    { type: "project", settings: { title: "Aurella Business Park", linkHref: "#" } },
    { type: "project", settings: { title: "Crown Point Residences", linkHref: "#" } },
  ],
};

export default schema;
