import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "dental-insights-intro",
  name: "Dental insights intro",
  category: "Content",
  settings: [
    { type: "text", id: "eyebrowBadge", label: "Eyebrow badge", default: "Our Insights" },
    {
      type: "textarea",
      id: "heading",
      label: "Heading",
      default: "Advanced dental care ensures precision, comfort and long lasting healthy smiles.",
    },
  ],
  blocks: [
    {
      type: "thumb",
      name: "Procedure image",
      settings: [{ type: "image", id: "image", label: "Image" }],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [{ type: "thumb", settings: {} }, { type: "thumb", settings: {} }, { type: "thumb", settings: {} }],
};

export default schema;
