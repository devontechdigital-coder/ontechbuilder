import * as React from "react";
import { Container } from "../../components/Container";
import { Icon, type IconName } from "../../components/Icon";
import { asString, blocksOfType, type RawBlock } from "../../components/blockHelpers";

export interface FooterDentoraProps {
  logoText: string;
  headingLine1?: string;
  headingLine2?: string;
  email?: string;
  contactHeading?: string;
  showNewsletter?: boolean;
  newsletterHeading?: string;
  newsletterPlaceholder?: string;
  newsletterButtonLabel?: string;
  termsLabel?: string;
  termsHref?: string;
  privacyLabel?: string;
  privacyHref?: string;
  creditLine?: string;
  /** Raw blocks mixing "link_column" and "social_link" — this component sorts them out itself. */
  blocks: RawBlock[];
}

interface FooterLink {
  label: string;
  href: string;
}

function parseLinks(value: unknown): FooterLink[] {
  if (typeof value !== "string" || !value.trim()) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((item) => (item && typeof item === "object" ? { label: asString((item as Record<string, unknown>).label).trim(), href: asString((item as Record<string, unknown>).href).trim() } : null))
      .filter((item): item is FooterLink => Boolean(item && item.label && item.href));
  } catch {
    return [];
  }
}

/**
 * Bespoke Dentora footer: a two-line "connect with us" heading paired
 * with a newsletter form, three link columns plus a contact/social
 * column, a giant background wordmark, and a bottom credit bar.
 */
export function FooterDentora({
  logoText,
  headingLine1,
  headingLine2,
  email,
  contactHeading,
  showNewsletter = true,
  newsletterHeading,
  newsletterPlaceholder = "Your Email Address",
  newsletterButtonLabel = "Subscribe",
  termsLabel,
  termsHref,
  privacyLabel,
  privacyHref,
  creditLine,
  blocks,
}: FooterDentoraProps) {
  const linkColumnBlocks = blocksOfType(blocks, "link_column");
  const socialBlocks = blocksOfType(blocks, "social_link");

  return (
    <footer className="d1-footer">
      <Container width="wide" className="d1-footer__top">
        <div className="d1-footer__heading">
          {headingLine1 && <h2>{headingLine1}</h2>}
          {headingLine2 && <h2>{headingLine2}</h2>}
        </div>
        {showNewsletter && (
          <div className="d1-footer__newsletter">
            {newsletterHeading && <p>{newsletterHeading}</p>}
            <form className="d1-footer__newsletter-form" onSubmit={(event) => event.preventDefault()} aria-label="Newsletter signup">
              <label className="cop-visually-hidden" htmlFor="d1-footer-newsletter-email">
                Email address
              </label>
              <Icon name="mail" size={16} />
              <input id="d1-footer-newsletter-email" type="email" placeholder={newsletterPlaceholder} required />
              <button type="submit">{newsletterButtonLabel}</button>
            </form>
          </div>
        )}
      </Container>

      <Container width="wide">
        <div className="d1-footer__divider" />
      </Container>

      <Container width="wide" className="d1-footer__grid">
        {linkColumnBlocks.map((block) => (
          <div key={block.id} className="d1-footer__column">
            <h3>{asString(block.heading, "Links")}</h3>
            <ul>
              {parseLinks(block.linksJson).map((link) => (
                <li key={link.href + link.label}>
                  <a href={link.href}>{link.label}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div className="d1-footer__column d1-footer__column--contact">
          {contactHeading && <h3>{contactHeading}</h3>}
          {email && (
            <a href={`mailto:${email}`} className="d1-footer__email">
              {email}
            </a>
          )}
          {socialBlocks.length > 0 && (
            <div className="d1-footer__social">
              {socialBlocks.map((block) => (
                <a key={block.id} href={asString(block.href, "#")} aria-label={asString(block.label, "Social link")} target="_blank" rel="noopener noreferrer">
                  <Icon name={(asString(block.icon, "facebook") as IconName) || "facebook"} size={16} />
                </a>
              ))}
            </div>
          )}
        </div>
      </Container>

      <div className="d1-footer__watermark" aria-hidden="true">
        {logoText}
      </div>

      <div className="d1-footer__bottom">
        <Container width="wide" className="d1-footer__bottom-inner">
          <span>{creditLine}</span>
          <span className="d1-footer__bottom-links">
            {termsLabel && termsHref && <a href={termsHref}>{termsLabel}</a>}
            {privacyLabel && privacyHref && <a href={privacyHref}>{privacyLabel}</a>}
          </span>
        </Container>
      </div>
    </footer>
  );
}
