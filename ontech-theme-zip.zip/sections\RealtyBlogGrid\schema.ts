import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-blog-grid",
  name: "Realty blog grid",
  category: "Blog",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Latest insights from real estate and" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "construction" },
  ],
  blocks: [
    {
      type: "post",
      name: "Post",
      settings: [
        { type: "image", id: "image", label: "Image" },
        { type: "text", id: "title", label: "Title", default: "Modern Construction Trends Shaping Urban Living" },
        { type: "text", id: "linkLabel", label: "Link label", default: "Read More" },
        { type: "url", id: "linkHref", label: "Link URL", default: "/blog/post" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "post", settings: { title: "Modern Construction Trends Shaping Urban Living", linkLabel: "Read More", linkHref: "/blog/post" } },
    { type: "post", settings: { title: "Benefits Of Quality Construction For Long Term Value", linkLabel: "Read More", linkHref: "/blog/post" } },
    { type: "post", settings: { title: "Sustainable Building Practices For Future-Ready Spaces", linkLabel: "Read More", linkHref: "/blog/post" } },
  ],
};

export default schema;
