import * as React from "react";
import { Icon } from "./Icon";

/**
 * The recurring dark-purple circular button seen bottom-right on every
 * section in the reference screenshots. Pure CSS position: fixed — no
 * animation library.
 */
export function FloatingActions({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <a href="#top" className="cop-floating" aria-label="Back to top">
      <Icon name="sparkle" size={18} />
    </a>
  );
}
