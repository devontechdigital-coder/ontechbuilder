import * as React from "react";
import { Container } from "../../components/Container";
import { Icon } from "../../components/Icon";
import { asString, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface HeaderSkyvillaProps {
  logoImage?: ThemeImage;
  logoText: string;
  /** Raw blocks mixing "nav_link" (plain) and "nav_menu" (flat hover dropdown, no recursion). */
  navBlocks: RawBlock[];
  ctaLabel?: string;
  ctaHref?: string;
  showSearch?: boolean;
  sticky?: boolean;
}

interface DropdownItem {
  label: string;
  href: string;
}

function parseDropdownItems(value: unknown): DropdownItem[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => (item && typeof item === "object" ? { label: asString((item as Record<string, unknown>).label).trim(), href: asString((item as Record<string, unknown>).href).trim() } : null))
    .filter((item): item is DropdownItem => Boolean(item && item.label && item.href));
}

/**
 * Header for the "Skyvilla" real-estate/construction home2 template: a
 * centered flat nav with one optional hover dropdown, a search icon,
 * and a solid dark "Get Free Quote" pill with a lime accent circle.
 */
export function HeaderSkyvilla({ logoImage, logoText, navBlocks, ctaLabel, ctaHref, showSearch = true, sticky = true }: HeaderSkyvillaProps) {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [openMenuId, setOpenMenuId] = React.useState<string | null>(null);

  return (
    <header className={`sv-header ${sticky ? "sv-header--sticky" : ""}`.trim()}>
      <Container width="wide" className="sv-header__inner">
        <a href="/" className="sv-header__logo" aria-label={logoText}>
          {logoImage?.src ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoImage.src} alt={logoImage.alt} className="sv-header__logo-img" />
          ) : (
            <span className="sv-header__logo-mark" aria-hidden="true">
              <Icon name="sparkle" size={16} />
            </span>
          )}
          <span className="sv-header__logo-text">{logoText}</span>
        </a>

        <nav className="sv-header__nav sv-header__nav--desktop" aria-label="Primary">
          {navBlocks.map((block) => {
            if (block.type === "nav_menu") {
              const items = parseDropdownItems(block.items);
              const isOpen = openMenuId === block.id;
              return (
                <div key={block.id} className="sv-header__dropdown" onMouseEnter={() => setOpenMenuId(block.id)} onMouseLeave={() => setOpenMenuId(null)}>
                  <button type="button" className="sv-header__nav-link" aria-expanded={isOpen} onClick={() => setOpenMenuId((v) => (v === block.id ? null : block.id))}>
                    {asString(block.label)}
                    <Icon name="chevron-down" size={13} />
                  </button>
                  {isOpen && items.length > 0 && (
                    <div className="sv-header__dropdown-panel" role="menu">
                      {items.map((item) => (
                        <a key={item.href + item.label} href={item.href}>
                          {item.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              );
            }
            return (
              <a key={block.id} href={asString(block.href, "#")} className="sv-header__nav-link">
                {asString(block.label)}
              </a>
            );
          })}
        </nav>

        <div className="sv-header__actions">
          {showSearch && (
            <button type="button" className="sv-header__icon-btn" aria-label="Search">
              <Icon name="search" size={18} />
            </button>
          )}
          {ctaLabel && ctaHref && (
            <a href={ctaHref} className="sv-btn sv-btn--sm">
              {ctaLabel}
              <span className="sv-btn__icon">
                <Icon name="arrow-up-right" size={13} />
              </span>
            </a>
          )}
          <button
            type="button"
            className="sv-header__icon-btn sv-header__icon-btn--mobile"
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((v) => !v)}
          >
            <Icon name={mobileOpen ? "close" : "menu"} size={20} />
          </button>
        </div>
      </Container>

      {mobileOpen && (
        <nav className="sv-header__nav sv-header__nav--mobile" aria-label="Primary mobile">
          <Container width="wide">
            {navBlocks.map((block) => {
              const items = block.type === "nav_menu" ? parseDropdownItems(block.items) : [];
              return (
                <div key={block.id}>
                  <a href={block.type === "nav_menu" ? "#" : asString(block.href, "#")} onClick={() => block.type !== "nav_menu" && setMobileOpen(false)}>
                    {asString(block.label)}
                  </a>
                  {items.length > 0 && (
                    <div className="sv-header__mobile-submenu">
                      {items.map((item) => (
                        <a key={item.href + item.label} href={item.href} onClick={() => setMobileOpen(false)}>
                          {item.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
            {ctaLabel && ctaHref && (
              <a href={ctaHref} className="sv-btn sv-btn--sm sv-header__cta--mobile" onClick={() => setMobileOpen(false)}>
                {ctaLabel}
              </a>
            )}
          </Container>
        </nav>
      )}
    </header>
  );
}
