import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface AboutTemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

export const defaultAboutSections: SectionInstance[] = [
  {
    id: "about-intro",
    type: "page-intro",
    props: {
      heading: "Building better businesses with smart strategy",
      description: "We're a forward-thinking consulting agency helping businesses grow smarter, scale faster, and lead with clarity.",
      imageAspectRatio: "16:9",
    },
  },
  {
    id: "about-stats",
    type: "stats-row",
    props: {
      blocks: [
        block("stat", { eyebrow: "Business transformed", value: "260+", description: "Helping companies grow and perform better.", tone: "surface" }),
        block("cta", { heading: "24/7 support to keep your business moving forward", buttonLabel: "Get in touch", buttonHref: "/contact" }),
        block("stat", { eyebrow: "Years for experience", value: "6+", description: "Years helping businesses thrive.", tone: "surface" }),
      ],
    },
  },
  {
    id: "about-split",
    type: "split-content",
    props: {
      heading: "Built on expertise, driven by results - Get to know us",
      description:
        "We didn't start with a big boardroom — just a big idea: to make business consulting more human, strategic, and impact-driven. From helping early-stage ventures define their roadmap to guiding enterprises through digital transformation, our journey has always been about one thing — unlocking clarity and measurable growth for every client.",
      imagePosition: "right",
      imageAspectRatio: "1:1",
      signatureName: "Carlos Mendes",
      signatureRole: "CEO",
    },
  },
  {
    id: "about-mission-vision",
    type: "mission-vision",
    props: {
      missionTitle: "Our Mission",
      missionDescription:
        "To empower businesses of all sizes to unlock their full potential through strategic insight, tailored consulting, and measurable results.",
      visionTitle: "Our Vision",
      bulletBlocks: [block("bullet", { text: "Global impact" }), block("bullet", { text: "Innovative thinking" }), block("bullet", { text: "Empowering growth" })],
    },
  },
  {
    id: "about-team",
    type: "team-grid",
    props: {
      eyebrow: "Our team",
      heading: "Our team of problem solvers",
      description: "Our diverse team of experienced consultants, analysts, and industry specialists work together to deliver real results.",
      blocks: [
        block("member", { name: "Rachel Kim", role: "Chief Strategy Officer" }),
        block("member", { name: "Hannah Brooks", role: "Chief Strategy Officer" }),
        block("member", { name: "Amira Chen", role: "Operations Consultant" }),
        block("member", { name: "David Hassan", role: "Business Analyst" }),
        block("member", { name: "Elena Novak", role: "Market Research Lead" }),
      ],
    },
  },
  {
    id: "about-cta",
    type: "cta-banner",
    props: {
      heading: "Let's build something that moves your business forward",
      description: "Share a concise story of how the agency was founded, core motivations, and the guiding force in growth.",
      buttonLabel: "Get started now",
      buttonHref: "/contact",
      avatarBlocks: [],
    },
  },
];

export default function AboutTemplate({ sections = defaultAboutSections }: AboutTemplateProps) {
  return <RenderSections sections={sections} />;
}
