import * as React from "react";
import { Container } from "../../components/Container";
import { Avatar } from "../../components/Avatar";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface RealtyTestimonialsProps {
  heading: string;
  headingItalic?: string;
  linkLabel?: string;
  linkHref?: string;
  /** Raw blocks mixing "testimonial" (the 3-up card row) and "logo" (the trust-logo row beneath it). */
  blocks: RawBlock[];
}

/** Heading + "view all" link, a 3-up testimonial card row, and a partner-logo row beneath it. */
export function RealtyTestimonials({ heading, headingItalic, linkLabel, linkHref, blocks }: RealtyTestimonialsProps) {
  const link = optionalLink(linkLabel, linkHref);
  const testimonialBlocks = blocksOfType(blocks, "testimonial");
  const logoBlocks = blocksOfType(blocks, "logo");

  return (
    <section className="sv-section sv-testimonials">
      <Container width="wide">
        <div className="sv-intro__header">
          <h2>
            {heading} {headingItalic && <em>{headingItalic}</em>}
          </h2>
          {link && (
            <a href={link.href} className="sv-text-link">
              {link.label}
              <Icon name="arrow-up-right" size={14} />
            </a>
          )}
        </div>

        <div className="sv-testimonials__grid">
          {testimonialBlocks.map((block) => (
            <div key={block.id} className="sv-testimonials__card">
              <div className="sv-testimonials__stars">
                <Icon name="star" size={14} />
                <Icon name="star" size={14} />
                <Icon name="star" size={14} />
                <Icon name="star" size={14} />
                <Icon name="star" size={14} />
              </div>
              <p>{asString(block.quote)}</p>
              <div className="sv-testimonials__person">
                <Avatar image={asImage(block.avatar)} size={38} />
                <span>
                  <strong>{asString(block.name)}</strong>
                  <em>{asString(block.role)}</em>
                </span>
              </div>
            </div>
          ))}
        </div>

        {logoBlocks.length > 0 && (
          <div className="sv-testimonials__logos">
            {logoBlocks.map((block) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img key={block.id} src={asImage(block.image)?.src} alt={asImage(block.image)?.alt || "Partner logo"} />
            ))}
          </div>
        )}
      </Container>
    </section>
  );
}
