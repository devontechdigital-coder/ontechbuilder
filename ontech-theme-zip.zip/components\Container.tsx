import * as React from "react";
import type { ContainerWidth } from "./types";

interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  width?: ContainerWidth;
  as?: keyof React.JSX.IntrinsicElements;
}

const widthClass: Record<ContainerWidth, string> = {
  narrow: "cop-container--narrow",
  default: "cop-container--default",
  wide: "cop-container--wide",
  full: "cop-container--full",
};

export function Container({ width = "default", as = "div", className = "", children, ...rest }: ContainerProps) {
  const Tag = as as React.ElementType;
  return (
    <Tag className={`cop-container ${widthClass[width]} ${className}`.trim()} {...rest}>
      {children}
    </Tag>
  );
}
