import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "header-dentora",
  name: "Header (Dentora)",
  category: "Header",
  settings: [
    { type: "image", id: "logoImage", label: "Logo image", info: "Leave empty to use the text wordmark below." },
    { type: "text", id: "logoText", label: "Wordmark text", default: "Dentora" },
    { type: "url", id: "activeHref", label: "Active link (highlighted pill)", default: "/" },
    { type: "text", id: "ctaLabel", label: "CTA button label", default: "Book a Call" },
    { type: "url", id: "ctaHref", label: "CTA button link", default: "/contact" },
    { type: "checkbox", id: "sticky", label: "Stick to top on scroll", default: true },
  ],
  blocks: [
    {
      type: "nav_link",
      name: "Nav link",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Menu item" },
        { type: "url", id: "href", label: "Link", default: "#" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "nav_link", settings: { label: "Home", href: "/" } },
    { type: "nav_link", settings: { label: "Services", href: "/services" } },
    { type: "nav_link", settings: { label: "About Us", href: "/about" } },
    { type: "nav_link", settings: { label: "Testimonial", href: "/#testimonial" } },
    { type: "nav_link", settings: { label: "Contact", href: "/contact" } },
  ],
};

export default schema;
