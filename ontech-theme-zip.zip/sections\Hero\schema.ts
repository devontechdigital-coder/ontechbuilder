import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "hero",
  name: "Hero",
  category: "Hero",
  settings: [
    // Content
    { type: "text", id: "eyebrowBadge", label: "Eyebrow badge", default: "Firm of the Year 2025" },
    { type: "text", id: "heading", label: "Heading", default: "Driving business growth through expert strategy" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "Unlock your company's full potential with expert guidance, tailored solutions, and proven results from our seasoned consultants.",
    },
    { type: "text", id: "primaryButtonLabel", label: "Primary button label", default: "See all case studies" },
    { type: "url", id: "primaryButtonHref", label: "Primary button link", default: "/case-studies" },

    // Media
    { type: "image", id: "image", label: "Main image" },
    { type: "image", id: "secondaryImage", label: "Secondary image" },
    { type: "text", id: "secondaryImageBadge", label: "Secondary image badge text", default: "Build a business growth" },

    // Testimonial overlay
    { type: "textarea", id: "testimonialQuote", label: "Testimonial quote", default: "The consultants helped us shape a sustainable strategy that emphasized performance, retention, and employee well-being." },
    { type: "text", id: "testimonialName", label: "Testimonial name", default: "Sofia Grant" },
    { type: "text", id: "testimonialRole", label: "Testimonial role", default: "Director of Strategy" },
    { type: "image", id: "testimonialAvatar", label: "Testimonial avatar" },

    // Trust row
    { type: "text", id: "trustLabel", label: "Trust row label", default: "Based in" },
  ],
  blocks: [
    {
      type: "trust_logo",
      name: "Trust logo",
      settings: [{ type: "image", id: "image", label: "Logo image" }],
    },
  ],
  maxBlocks: 8,
};

export default schema;
