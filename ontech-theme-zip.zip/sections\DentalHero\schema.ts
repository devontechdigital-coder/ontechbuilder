import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "dental-hero",
  name: "Dental hero",
  category: "Hero",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Family-Friendly Dental Care" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "Permanent, natural-looking solutions to replace missing teeth and restore confident, healthy smiles.",
    },
    { type: "text", id: "primaryButtonLabel", label: "Primary button label", default: "Book an Appointment" },
    { type: "url", id: "primaryButtonHref", label: "Primary button link", default: "/contact" },
    { type: "image", id: "image", label: "Banner image" },
    { type: "textarea", id: "ratingText", label: "Rating card text", default: "Restoring natural, healthy, confident dental growth." },
    { type: "text", id: "ratingValue", label: "Rating value", default: "4.9" },
    { type: "text", id: "ratingLabel", label: "Rating label", default: "Rating" },
    { type: "image", id: "ratingAvatar", label: "Rating card avatar" },
  ],
  blocks: [
    {
      type: "tag",
      name: "Treatment tag",
      settings: [{ type: "text", id: "label", label: "Label", default: "Teeth Cleaning" }],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "tag", settings: { label: "Teeth Cleaning" } },
    { type: "tag", settings: { label: "Dental Checkup" } },
    { type: "tag", settings: { label: "Tooth Filling" } },
    { type: "tag", settings: { label: "Gum Treatment" } },
    { type: "tag", settings: { label: "Retainers" } },
  ],
};

export default schema;
