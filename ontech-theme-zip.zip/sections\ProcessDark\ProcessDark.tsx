"use client";

import * as React from "react";
import { Container } from "../../components/Container";
import { Button } from "../../components/Button";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asString, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface ProcessDarkProps {
  eyebrow?: string;
  heading: string;
  description?: string;
  image?: ThemeImage;
  teaserText?: string;
  teaserLinkLabel?: string;
  teaserLinkHref?: string;
  /** Raw step blocks. */
  blocks: RawBlock[];
}

/** Dark "How we work" section: intro + an accessible accordion of process steps. */
export function ProcessDark({ eyebrow, heading, description, image, teaserText, teaserLinkLabel, teaserLinkHref, blocks }: ProcessDarkProps) {
  const [openIndex, setOpenIndex] = React.useState(0);
  const teaserLink = optionalLink(teaserLinkLabel, teaserLinkHref);

  return (
    <section className="cop-section cop-section--dark cop-process">
      <Container width="wide" className="cop-process__intro">
        <ThemeImg image={image} ratio="4:3" placeholderLabel="Process image" className="cop-process__image" />
        <div>
          {eyebrow && <p className="cop-eyebrow cop-eyebrow--light">{eyebrow}</p>}
          <h2>{heading}</h2>
          {description && <p>{description}</p>}
        </div>
      </Container>

      {(teaserText || teaserLink) && (
        <Container width="wide" className="cop-process__teaser">
          {teaserText && <p>{teaserText}</p>}
          {teaserLink && (
            <Button href={teaserLink.href} variant="light" size="sm">
              {teaserLink.label}
            </Button>
          )}
        </Container>
      )}

      <Container width="wide">
        <div className="cop-process__accordion">
          {blocks.map((block, index) => {
            const open = openIndex === index;
            return (
              <div key={block.id} className={`cop-process__item ${open ? "cop-process__item--open" : ""}`}>
                <button
                  type="button"
                  className="cop-process__item-trigger"
                  aria-expanded={open}
                  onClick={() => setOpenIndex(open ? -1 : index)}
                >
                  <span className="cop-process__number">{asString(block.number, String(index + 1).padStart(2, "0"))}</span>
                  <span className="cop-process__title">{asString(block.title)}</span>
                  <Icon name={open ? "minus" : "plus"} size={16} />
                </button>
                {open && <p className="cop-process__description">{asString(block.description)}</p>}
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
