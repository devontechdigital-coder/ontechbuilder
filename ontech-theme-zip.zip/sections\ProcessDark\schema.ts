import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "process-dark",
  name: "Process (dark)",
  category: "Content",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "How we work" },
    { type: "text", id: "heading", label: "Heading", default: "Smart steps to business growth" },
    {
      type: "textarea",
      id: "description",
      label: "Description",
      default: "We follow a strategic four-step approach designed to drive measurable results. From deep discovery to ongoing optimization, every step is focused on moving your business forward with clarity, efficiency, and impact.",
    },
    { type: "image", id: "image", label: "Image" },
    { type: "text", id: "teaserText", label: "Teaser text", default: "Want to know what's possible?" },
    { type: "text", id: "teaserLinkLabel", label: "Teaser link label", default: "Get in touch now" },
    { type: "url", id: "teaserLinkHref", label: "Teaser link URL", default: "/contact" },
  ],
  blocks: [
    {
      type: "step",
      name: "Step",
      settings: [
        { type: "text", id: "number", label: "Number label", default: "01" },
        { type: "text", id: "title", label: "Title", default: "Discovery" },
        { type: "textarea", id: "description", label: "Description", default: "" },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "step", settings: { number: "01", title: "Discovery", description: "We begin by listening closely to your challenges and goals. Through research and deep business analysis, we uncover insights. This foundation shapes every strategy we build moving forward." } },
    { type: "step", settings: { number: "02", title: "Strategy", description: "We translate insight into a clear, actionable roadmap tailored to your business and market." } },
    { type: "step", settings: { number: "03", title: "Execution", description: "Our consultants work alongside your team to implement the plan with precision and pace." } },
    { type: "step", settings: { number: "04", title: "Optimization", description: "We measure outcomes continuously and refine the approach to compound results over time." } },
  ],
};

export default schema;
