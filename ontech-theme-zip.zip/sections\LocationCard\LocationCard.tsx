import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import type { ThemeImage } from "../../components/types";

export interface LocationCardProps {
  image?: ThemeImage;
  title: string;
  address: string;
  email: string;
}

/** A location photo next to a simple address/email card. */
export function LocationCard({ image, title, address, email }: LocationCardProps) {
  return (
    <section className="cop-section cop-location">
      <Container width="wide" className="cop-location__grid">
        <ThemeImg image={image} ratio="4:3" placeholderLabel="Location image" />
        <div className="cop-location__card">
          <h3>{title}</h3>
          <p>{address}</p>
          <a href={`mailto:${email}`}>{email}</a>
        </div>
      </Container>
    </section>
  );
}
