import * as React from "react";
import { Container } from "../../components/Container";
import { Button } from "../../components/Button";
import { ThemeImg } from "../../components/ThemeImg";
import { asImage, asString, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface BlogGridProps {
  eyebrow?: string;
  heading: string;
  seeAllLabel?: string;
  seeAllHref?: string;
  columns: 2 | 3;
  /** Raw post blocks. */
  blocks: RawBlock[];
}

/** "Insights & Ideas" — heading with a "See all blog" action and a post card grid. */
export function BlogGrid({ eyebrow, heading, seeAllLabel, seeAllHref, columns, blocks }: BlogGridProps) {
  const seeAllButton = optionalLink(seeAllLabel, seeAllHref);

  return (
    <section className="cop-section cop-blog">
      <Container width="wide">
        <div className="cop-blog__header">
          <div>
            {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
            <h2>{heading}</h2>
          </div>
          {seeAllButton && (
            <Button href={seeAllButton.href} variant="primary" size="md">
              {seeAllButton.label}
            </Button>
          )}
        </div>

        <div className={`cop-blog__grid cop-grid--cols-${columns}`}>
          {blocks.map((block) => {
            const title = asString(block.title);
            return (
              <a key={block.id} href={asString(block.linkHref, "#")} className="cop-blog__card">
                <ThemeImg image={asImage(block.image)} ratio="4:3" placeholderLabel={title} />
                {Boolean(block.tag || block.date) && (
                  <div className="cop-blog__meta">
                    {typeof block.tag === "string" && block.tag && <span className="cop-blog__tag">{block.tag}</span>}
                    {typeof block.date === "string" && block.date && <span>{block.date}</span>}
                  </div>
                )}
                <p className="cop-blog__title">{title}</p>
              </a>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
