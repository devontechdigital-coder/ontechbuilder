/**
 * config/settings.default.ts
 *
 * Runtime shape + default values for global theme settings. The host
 * platform stores the merchant's actual choices in this shape and
 * passes the resolved object into ThemeLayout as `settings`.
 */

export interface ThemeSettings {
  // Color palette
  colorPrimary: string;
  colorPrimaryContrast: string;
  colorSecondary: string;
  colorLink: string;
  colorBackground: string;
  colorSurface: string;
  colorSurfaceAlt: string;
  colorDark: string;
  colorText: string;
  colorMutedText: string;
  colorBorder: string;

  // Layout
  containerWidth: "narrow" | "default" | "wide" | "full";
  sectionSpacing: number;
  borderRadius: number;

  // Typography
  headingFont: string;
  bodyFont: string;
  headingWeight: string;
  baseFontSize: number;
  headingFontSize: number;
  headingScale: number;
  headingLetterSpacing: number;
  lineHeight: number;

  // Buttons
  buttonStyle: "solid" | "outline";
  buttonRadius: number;
  buttonSize: "sm" | "md" | "lg";
  buttonHoverEffect: "fade" | "lift" | "none";

  // Cards & imagery
  cardShadow: "none" | "soft" | "medium" | "strong";
  cardHoverLift: boolean;

  // Header
  headerVariant: "classic" | "dentora" | "skyvilla";
  stickyHeader: boolean;
  transparentOnHero: boolean;
  headerHeight: number;
  logoWidth: number;
  mobileLogoWidth: number;
  enableMegaMenu: boolean;

  // Footer
  footerVariant: "classic" | "dentora" | "skyvilla";
  footerStyle: "dark" | "light";
  showNewsletter: boolean;
  showRecentWorks: boolean;

  // Motion
  enableScrollReveal: boolean;
  transitionSpeed: number;

  // Floating actions
  showScrollTop: boolean;
}

const settingsDefault: ThemeSettings = {
  colorPrimary: "#3A1B63",
  colorPrimaryContrast: "#FFFFFF",
  colorSecondary: "#C9A24D",
  colorLink: "#3A1B63",
  colorBackground: "#FFFFFF",
  colorSurface: "#F4F3F1",
  colorSurfaceAlt: "#FBF9F5",
  colorDark: "#0B0B0D",
  colorText: "#111113",
  colorMutedText: "#6B6B70",
  colorBorder: "#E7E5E1",

  containerWidth: "default",
  sectionSpacing: 104,
  borderRadius: 14,

  headingFont: "'Sora', 'Inter', sans-serif",
  bodyFont: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
  headingWeight: "700",
  baseFontSize: 16,
  headingFontSize: 42,
  headingScale: 1.3,
  headingLetterSpacing: -1,
  lineHeight: 1.6,

  buttonStyle: "solid",
  buttonRadius: 999,
  buttonSize: "md",
  buttonHoverEffect: "lift",

  cardShadow: "soft",
  cardHoverLift: true,

  headerVariant: "classic",
  stickyHeader: true,
  transparentOnHero: false,
  headerHeight: 80,
  logoWidth: 132,
  mobileLogoWidth: 104,
  enableMegaMenu: true,

  footerVariant: "classic",
  footerStyle: "dark",
  showNewsletter: true,
  showRecentWorks: true,

  enableScrollReveal: true,
  transitionSpeed: 200,

  showScrollTop: true,
};

export default settingsDefault;
