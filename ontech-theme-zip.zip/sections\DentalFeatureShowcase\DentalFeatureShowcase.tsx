import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asString, optionalLink, blocksOfType, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface DentalFeatureShowcaseProps {
  clinicImage?: ThemeImage;
  doctorImage?: ThemeImage;
  doctorImageBadgeLabel?: string;
  doctorImageBadgeHref?: string;
  featureEyebrow?: string;
  featureHeading: string;
  featureDescription?: string;
  doctorName: string;
  doctorRole?: string;
  doctorRatingValue?: string;
  doctorReviewCount?: string;
  doctorDescription?: string;
  /** Raw "stat" blocks — the satisfaction/smiles/rating row inside the feature card. */
  blocks: RawBlock[];
}

/**
 * A 2x2 showcase: a clinic photo and a doctor portrait stacked on the
 * left, paired with a feature/stats card and a doctor-profile card
 * stacked on the right.
 */
export function DentalFeatureShowcase({
  clinicImage,
  doctorImage,
  doctorImageBadgeLabel,
  doctorImageBadgeHref,
  featureEyebrow,
  featureHeading,
  featureDescription,
  doctorName,
  doctorRole,
  doctorRatingValue,
  doctorReviewCount,
  doctorDescription,
  blocks,
}: DentalFeatureShowcaseProps) {
  const statBlocks = blocksOfType(blocks, "stat");
  const badgeLink = optionalLink(doctorImageBadgeLabel, doctorImageBadgeHref);

  return (
    <section className="d1-showcase">
      <Container width="wide" className="d1-showcase__grid">
        <div className="d1-showcase__media-col">
          <ThemeImg image={clinicImage} ratio="auto" placeholderLabel="Clinic image" className="d1-showcase__clinic-image" />
          <div className="d1-showcase__doctor-media">
            <ThemeImg image={doctorImage} ratio="auto" placeholderLabel="Doctor image" className="d1-showcase__doctor-image" />
            {badgeLink && (
              <a href={badgeLink.href} className="d1-showcase__doctor-badge">
                {badgeLink.label}
                <Icon name="arrow-up-right" size={13} />
              </a>
            )}
          </div>
        </div>

        <div className="d1-showcase__card-col">
          <div className="d1-showcase__card">
            {featureEyebrow && <span className="d1-pill">{featureEyebrow}</span>}
            <h2>{featureHeading}</h2>
            {featureDescription && <p className="d1-showcase__card-description">{featureDescription}</p>}
            {statBlocks.length > 0 && (
              <div className="d1-showcase__stats">
                {statBlocks.map((block) => (
                  <div key={block.id} className="d1-showcase__stat">
                    <strong>{asString(block.value)}</strong>
                    <span>{asString(block.label)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="d1-showcase__card d1-showcase__doctor-card">
            <h3>{doctorName}</h3>
            {doctorRole && <p className="d1-showcase__doctor-role">{doctorRole}</p>}
            {doctorRatingValue && (
              <div className="d1-showcase__doctor-rating">
                <Icon name="star" size={13} />
                <strong>{doctorRatingValue}</strong>
                {doctorReviewCount && <span>{doctorReviewCount}</span>}
              </div>
            )}
            {doctorDescription && <p className="d1-showcase__card-description">{doctorDescription}</p>}
          </div>
        </div>
      </Container>
    </section>
  );
}
