import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { asString, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface ContactFormProps {
  heading: string;
  description?: string;
  submitLabel: string;
  /** Native form action URL — the host wires this to its own form-handling endpoint. Submission is a normal browser POST, not a JS network call. */
  actionUrl?: string;
  image?: ThemeImage;
  /** Raw service_option blocks — each block's `label` field is pulled out internally. */
  serviceOptionBlocks: RawBlock[];
}

/** "Have a business challenge? We're ready to help" — a real, accessible contact form. */
export function ContactForm({ heading, description, submitLabel, actionUrl, image, serviceOptionBlocks }: ContactFormProps) {
  const serviceOptions = serviceOptionBlocks.map((block) => asString(block.label)).filter(Boolean);
  return (
    <section className="cop-section cop-contact-form">
      <Container width="wide">
        <h1 className="cop-contact-form__heading">{heading}</h1>
        {description && <p className="cop-contact-form__description">{description}</p>}

        <div className="cop-contact-form__grid">
          <form className="cop-contact-form__form" action={actionUrl || undefined} method="post">
            <div className="cop-contact-form__row">
              <label>
                Your name*
                <input type="text" name="name" required />
              </label>
              <label>
                Email Address*
                <input type="email" name="email" required />
              </label>
            </div>
            <div className="cop-contact-form__row">
              <label>
                Phone number
                <input type="tel" name="phone" />
              </label>
              <label>
                Services
                <select name="service" defaultValue="">
                  <option value="" disabled>
                    Select one…
                  </option>
                  {serviceOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <label className="cop-contact-form__message">
              Message
              <textarea name="message" rows={5} />
            </label>
            <button type="submit" className="cop-btn cop-btn--dark-solid cop-btn--md">
              {submitLabel}
            </button>
          </form>

          <ThemeImg image={image} ratio="3:4" placeholderLabel="Contact image" className="cop-contact-form__image" />
        </div>
      </Container>
    </section>
  );
}
