import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { asImage, asString, type RawBlock } from "../../components/blockHelpers";

export interface ServiceCardsProps {
  eyebrow?: string;
  heading: string;
  description?: string;
  columns: 2 | 3 | 4;
  /** Raw service blocks. */
  blocks: RawBlock[];
}

/** "Our core consulting services" — full-bleed photo cards with a label pill. */
export function ServiceCards({ eyebrow, heading, description, columns, blocks }: ServiceCardsProps) {
  return (
    <section className="cop-section cop-services">
      <Container width="wide">
        <div className="cop-section__heading cop-section__heading--center">
          {eyebrow && <p className="cop-eyebrow">{eyebrow}</p>}
          <h2>{heading}</h2>
          {description && <p className="cop-section__description">{description}</p>}
        </div>

        <div className={`cop-services__grid cop-grid--cols-${columns}`}>
          {blocks.map((block) => {
            const title = asString(block.title);
            return (
              <div key={block.id} className="cop-services__card">
                <ThemeImg image={asImage(block.image)} ratio="3:4" placeholderLabel={title} />
                <span className="cop-services__label">{title}</span>
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
