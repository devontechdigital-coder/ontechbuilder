import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { asString, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface MissionVisionProps {
  missionTitle: string;
  missionDescription: string;
  visionTitle: string;
  visionImage?: ThemeImage;
  /** Raw bullet blocks — each block's `text` field is pulled out internally. */
  bulletBlocks: RawBlock[];
}

/** "Our Mission" plain card next to "Our Vision" image card with a bullet list. */
export function MissionVision({ missionTitle, missionDescription, visionTitle, visionImage, bulletBlocks }: MissionVisionProps) {
  const bullets = bulletBlocks.map((block) => asString(block.text)).filter(Boolean);
  return (
    <section className="cop-section cop-mission-vision">
      <Container width="wide" className="cop-mission-vision__grid">
        <div className="cop-mission-vision__card">
          <h3>{missionTitle}</h3>
          <p>{missionDescription}</p>
        </div>
        <div className="cop-mission-vision__card cop-mission-vision__card--image">
          <ThemeImg image={visionImage} ratio="4:3" placeholderLabel="Vision image" />
          <div className="cop-mission-vision__overlay">
            <h3>{visionTitle}</h3>
            <ul>
              {bullets.map((bullet) => (
                <li key={bullet}>{bullet}</li>
              ))}
            </ul>
          </div>
        </div>
      </Container>
    </section>
  );
}
