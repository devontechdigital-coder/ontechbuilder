import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "realty-contact-split",
  name: "Realty contact split",
  category: "Contact",
  settings: [
    { type: "text", id: "heading", label: "Heading", default: "Quick support when you" },
    { type: "text", id: "headingItalic", label: "Heading emphasis (italic)", default: "need it most" },
    { type: "text", id: "phone", label: "Phone", default: "+1 (234) 567-890" },
    { type: "text", id: "email", label: "Email", default: "hello@skyvilla.com" },
    { type: "text", id: "formHeading", label: "Form heading", default: "Send us a" },
    { type: "text", id: "formHeadingItalic", label: "Form heading emphasis (italic)", default: "message" },
    { type: "text", id: "submitLabel", label: "Submit button label", default: "Send Message" },
    { type: "url", id: "actionUrl", label: "Form action URL", info: "Where the host wants this form submitted — the theme itself makes no network call." },
  ],
};

export default schema;
