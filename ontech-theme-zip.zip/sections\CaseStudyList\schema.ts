import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "case-study-list",
  name: "Case study list",
  category: "Case studies",
  settings: [
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Recent case studies" },
    { type: "text", id: "footerLinkLabel", label: "Footer link label", default: "Let's work together" },
    { type: "url", id: "footerLinkHref", label: "Footer link URL", default: "/contact" },
  ],
  blocks: [
    {
      type: "case_study",
      name: "Case study row",
      settings: [
        { type: "text", id: "tag", label: "Tag", default: "Retail" },
        { type: "text", id: "title", label: "Title", default: "International expansion strategy for a retail brand" },
        { type: "textarea", id: "excerpt", label: "Excerpt (shown when expanded)", default: "" },
        { type: "checkbox", id: "highlighted", label: "Highlight this row", default: false },
      ],
    },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "case_study", settings: { tag: "Healthcare", title: "Digital transformation for a healthcare provider", excerpt: "A phased rollout of digital patient services across a multi-site provider network.", highlighted: true } },
    { type: "case_study", settings: { tag: "Retail", title: "International expansion strategy for a retail brand", excerpt: "Market-entry research and go-to-market planning across three new regions." } },
    { type: "case_study", settings: { tag: "Website Design", title: "Corporate website for a green energy company", excerpt: "A full brand and website relaunch aligned to a new sustainability positioning." } },
    { type: "case_study", settings: { tag: "SaaS Product", title: "Product redesign for a SaaS analytics platform", excerpt: "An end-to-end UX overhaul that lifted activation and reduced churn.", highlighted: true } },
  ],
};

export default schema;
