import * as React from "react";
import { Container } from "../../components/Container";
import { Icon, type IconName } from "../../components/Icon";
import { asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface FooterSkyvillaProps {
  logoText: string;
  heading?: string;
  headingItalic?: string;
  description?: string;
  ratingValue?: string;
  ratingLabel?: string;
  primaryButtonLabel?: string;
  primaryButtonHref?: string;
  socialHeading?: string;
  phone?: string;
  email?: string;
  address?: string;
  creditLine?: string;
  termsLabel?: string;
  termsHref?: string;
  privacyLabel?: string;
  privacyHref?: string;
  /** Raw blocks mixing "link_column" and "social_link". */
  blocks: RawBlock[];
}

interface FooterLink {
  label: string;
  href: string;
}

function parseLinks(value: unknown): FooterLink[] {
  if (typeof value !== "string" || !value.trim()) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((item) => (item && typeof item === "object" ? { label: asString((item as Record<string, unknown>).label).trim(), href: asString((item as Record<string, unknown>).href).trim() } : null))
      .filter((item): item is FooterLink => Boolean(item && item.label && item.href));
  } catch {
    return [];
  }
}

/**
 * Dark navy footer for the Skyvilla home2 template: a closing CTA
 * heading/rating/social row, three link columns plus a contact
 * address block, and a bottom credit bar.
 */
export function FooterSkyvilla({
  logoText,
  heading,
  headingItalic,
  description,
  ratingValue,
  ratingLabel,
  primaryButtonLabel,
  primaryButtonHref,
  socialHeading,
  phone,
  email,
  address,
  creditLine,
  termsLabel,
  termsHref,
  privacyLabel,
  privacyHref,
  blocks,
}: FooterSkyvillaProps) {
  const linkColumnBlocks = blocksOfType(blocks, "link_column");
  const socialBlocks = blocksOfType(blocks, "social_link");
  const primaryButton = optionalLink(primaryButtonLabel, primaryButtonHref);

  return (
    <footer className="sv-footer">
      <Container width="wide" className="sv-footer__top">
        <div className="sv-footer__heading">
          {heading && (
            <h2>
              {heading} {headingItalic && <em>{headingItalic}</em>}
            </h2>
          )}
          {description && <p>{description}</p>}
        </div>
        <div className="sv-footer__top-actions">
          {primaryButton && (
            <a href={primaryButton.href} className="sv-btn">
              {primaryButton.label}
              <span className="sv-btn__icon">
                <Icon name="arrow-up-right" size={14} />
              </span>
            </a>
          )}
          {ratingValue && (
            <div className="sv-footer__rating">
              <span className="sv-footer__rating-stars">
                <Icon name="star" size={13} />
                {ratingValue}
              </span>
              {ratingLabel && <span>{ratingLabel}</span>}
            </div>
          )}
        </div>
      </Container>

      {socialBlocks.length > 0 && (
        <Container width="wide" className="sv-footer__social-row">
          {socialHeading && <span>{socialHeading}</span>}
          <div className="sv-footer__social">
            {socialBlocks.map((block) => (
              <a key={block.id} href={asString(block.href, "#")} aria-label={asString(block.label, "Social link")} target="_blank" rel="noopener noreferrer">
                <Icon name={(asString(block.icon, "facebook") as IconName) || "facebook"} size={15} />
              </a>
            ))}
          </div>
        </Container>
      )}

      <Container width="wide">
        <div className="sv-footer__divider" />
      </Container>

      <Container width="wide" className="sv-footer__grid">
        {linkColumnBlocks.map((block) => (
          <div key={block.id} className="sv-footer__column">
            <h3>{asString(block.heading, "Links")}</h3>
            <ul>
              {parseLinks(block.linksJson).map((link) => (
                <li key={link.href + link.label}>
                  <a href={link.href}>{link.label}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div className="sv-footer__column">
          <h3>Contact</h3>
          <ul className="sv-footer__contact-list">
            {address && <li>{address}</li>}
            {phone && (
              <li>
                <a href={`tel:${phone}`}>{phone}</a>
              </li>
            )}
            {email && (
              <li>
                <a href={`mailto:${email}`}>{email}</a>
              </li>
            )}
          </ul>
        </div>
      </Container>

      <div className="sv-footer__bottom">
        <Container width="wide" className="sv-footer__bottom-inner">
          <span>{logoText}</span>
          <span>{creditLine}</span>
          <span className="sv-footer__bottom-links">
            {termsLabel && termsHref && <a href={termsHref}>{termsLabel}</a>}
            {privacyLabel && privacyHref && <a href={privacyHref}>{privacyLabel}</a>}
          </span>
        </Container>
      </div>
    </footer>
  );
}
