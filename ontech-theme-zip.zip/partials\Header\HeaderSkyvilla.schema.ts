import type { SectionSchema } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "header-skyvilla",
  name: "Header (Skyvilla)",
  category: "Header",
  settings: [
    { type: "image", id: "logoImage", label: "Logo image", info: "Leave empty to use the text wordmark below." },
    { type: "text", id: "logoText", label: "Wordmark text", default: "Skyvilla" },
    { type: "text", id: "ctaLabel", label: "CTA button label", default: "Get Free Quote" },
    { type: "url", id: "ctaHref", label: "CTA button link", default: "/contact" },
    { type: "checkbox", id: "showSearch", label: "Show search icon", default: true },
    { type: "checkbox", id: "sticky", label: "Stick to top on scroll", default: true },
  ],
  blocks: [
    {
      type: "nav_link",
      name: "Nav link",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Menu item" },
        { type: "url", id: "href", label: "Link", default: "#" },
      ],
    },
    {
      type: "nav_menu",
      name: "Nav item with dropdown",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Pages" },
        {
          type: "textarea",
          id: "itemsJson",
          label: "Dropdown links",
          info: "JSON array of flat {label, href} links (no nesting in this header).",
          default: '[{"label":"Overview","href":"/"}]',
        },
      ],
    },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "nav_link", settings: { label: "Home", href: "/" } },
    { type: "nav_link", settings: { label: "About Us", href: "/about" } },
    { type: "nav_link", settings: { label: "Services", href: "/services" } },
    { type: "nav_link", settings: { label: "Blog", href: "/blog" } },
    { type: "nav_menu", settings: { label: "Pages", itemsJson: '[{"label":"Projects","href":"/projects"},{"label":"FAQs","href":"/faq"},{"label":"Contact","href":"/contact"}]' } },
  ],
};

export default schema;
