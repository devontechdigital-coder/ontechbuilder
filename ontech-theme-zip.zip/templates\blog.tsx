import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface BlogTemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

export const defaultBlogSections: SectionInstance[] = [
  {
    id: "blog-intro",
    type: "page-intro",
    props: { heading: "Insights & Ideas", description: "Fresh perspectives on business growth, innovation, leadership and operational efficiency." },
  },
  {
    id: "blog-grid-listing",
    type: "blog-grid",
    props: {
      columns: 3,
      blocks: [
        block("post", { tag: "Growth", date: "June 20, 2025", title: "5 growth strategies every modern business should know", linkHref: "/blog/growth-strategies-2025" }),
        block("post", { tag: "Strategy", date: "June 20, 2025", title: "From goals to KPIs: turning vision into measurable success", linkHref: "/blog/goals-to-kpis" }),
        block("post", { tag: "Marketing", date: "June 20, 2025", title: "Digital transformation for service-based businesses", linkHref: "/blog/digital-transformation-services" }),
      ],
    },
  },
];

export default function BlogTemplate({ sections = defaultBlogSections }: BlogTemplateProps) {
  return <RenderSections sections={sections} />;
}
