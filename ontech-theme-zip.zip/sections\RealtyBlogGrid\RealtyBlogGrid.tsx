import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, type RawBlock } from "../../components/blockHelpers";

export interface RealtyBlogGridProps {
  heading: string;
  headingItalic?: string;
  /** Raw "post" blocks. */
  blocks: RawBlock[];
}

/** Heading + a 3-up blog/insights card grid, each with an image, title, and "Read More" link. */
export function RealtyBlogGrid({ heading, headingItalic, blocks }: RealtyBlogGridProps) {
  return (
    <section className="sv-section sv-blog-grid">
      <Container width="wide">
        <h2 className="sv-section__heading sv-section__heading--center">
          {heading} {headingItalic && <em>{headingItalic}</em>}
        </h2>

        <div className="sv-blog-grid__grid">
          {blocks.map((block) => (
            <a key={block.id} href={asString(block.linkHref, "#")} className="sv-blog-grid__card">
              <ThemeImg image={asImage(block.image)} ratio="auto" placeholderLabel="Post image" className="sv-blog-grid__image" />
              <h3>{asString(block.title)}</h3>
              <span className="sv-blog-grid__link">
                {asString(block.linkLabel, "Read More")}
                <Icon name="arrow-up-right" size={13} />
              </span>
            </a>
          ))}
        </div>
      </Container>
    </section>
  );
}
