import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { asImage, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface DentalInsightsIntroProps {
  eyebrowBadge?: string;
  heading: string;
  /** Raw "thumb" blocks — each block's `image` field is pulled out internally. */
  blocks: RawBlock[];
}

/** Centered intro heading with an "Our Insights" pill and a row of procedure thumbnail images beneath it. */
export function DentalInsightsIntro({ eyebrowBadge, heading, blocks }: DentalInsightsIntroProps) {
  const thumbs = blocks.map((block) => asImage(block.image)).filter((image): image is ThemeImage => Boolean(image));

  return (
    <section className="d1-insights-intro">
      <Container width="wide">
        <div className="d1-insights-intro__header">
          <h2>{heading}</h2>
          {eyebrowBadge && <span className="d1-pill">{eyebrowBadge}</span>}
        </div>
        {thumbs.length > 0 && (
          <div className="d1-insights-intro__grid">
            {thumbs.map((image, index) => (
              <ThemeImg key={image.src + index} image={image} ratio="auto" placeholderLabel="Procedure image" className="d1-insights-intro__thumb" />
            ))}
          </div>
        )}
      </Container>
    </section>
  );
}
