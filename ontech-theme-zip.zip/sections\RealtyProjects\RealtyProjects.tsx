import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, optionalLink, type RawBlock } from "../../components/blockHelpers";

export interface RealtyProjectsProps {
  heading: string;
  headingItalic?: string;
  footerLinkLabel?: string;
  footerLinkHref?: string;
  /** Raw "project" blocks. */
  blocks: RawBlock[];
}

/** Dark full-bleed section: centered heading over a 3-up project gallery, with a closing "get a quote" link row. */
export function RealtyProjects({ heading, headingItalic, footerLinkLabel, footerLinkHref, blocks }: RealtyProjectsProps) {
  const footerLink = optionalLink(footerLinkLabel, footerLinkHref);

  return (
    <section className="sv-section sv-section--dark sv-projects">
      <Container width="wide">
        <h2 className="sv-section__heading sv-section__heading--center">
          {heading} {headingItalic && <em>{headingItalic}</em>}
        </h2>

        <div className="sv-projects__grid">
          {blocks.map((block) => (
            <a key={block.id} href={asString(block.linkHref, "#")} className="sv-projects__card">
              <ThemeImg image={asImage(block.image)} ratio="auto" placeholderLabel="Project image" className="sv-projects__image" />
              <span className="sv-projects__title">{asString(block.title)}</span>
            </a>
          ))}
        </div>

        {footerLink && (
          <div className="sv-projects__footer">
            <a href={footerLink.href} className="sv-text-link sv-text-link--light">
              {footerLink.label}
              <Icon name="arrow-up-right" size={14} />
            </a>
          </div>
        )}
      </Container>
    </section>
  );
}
