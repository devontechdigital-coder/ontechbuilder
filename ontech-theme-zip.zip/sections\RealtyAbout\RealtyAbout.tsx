import * as React from "react";
import { Container } from "../../components/Container";
import { ThemeImg } from "../../components/ThemeImg";
import { Icon } from "../../components/Icon";
import { asImage, asString, blocksOfType, optionalLink, type RawBlock } from "../../components/blockHelpers";
import type { ThemeImage } from "../../components/types";

export interface RealtyAboutProps {
  heading: string;
  headingItalic?: string;
  ctaLabel?: string;
  ctaHref?: string;
  phone?: string;
  image?: ThemeImage;
  badgeValue?: string;
  badgeLabel?: string;
  /** Raw blocks mixing "feature" (left list) and "thumb" (small collage images). */
  blocks: RawBlock[];
}

/** Split section: a feature list + CTA/phone on the left, a big image with two small collage thumbnails and a stat badge on the right. */
export function RealtyAbout({ heading, headingItalic, ctaLabel, ctaHref, phone, image, badgeValue, badgeLabel, blocks }: RealtyAboutProps) {
  const ctaButton = optionalLink(ctaLabel, ctaHref);
  const featureBlocks = blocksOfType(blocks, "feature");
  const thumbs = blocksOfType(blocks, "thumb")
    .map((block) => asImage(block.image))
    .filter((img): img is ThemeImage => Boolean(img));

  return (
    <section className="sv-section sv-about">
      <Container width="wide" className="sv-about__grid">
        <div className="sv-about__content">
          <h2>
            {heading} {headingItalic && <em>{headingItalic}</em>}
          </h2>

          {featureBlocks.length > 0 && (
            <ul className="sv-about__features">
              {featureBlocks.map((block) => (
                <li key={block.id}>
                  <span className="sv-about__feature-icon">
                    <Icon name="check" size={14} />
                  </span>
                  <span>
                    <strong>{asString(block.title)}</strong>
                    {typeof block.description === "string" && block.description && <p>{block.description}</p>}
                  </span>
                </li>
              ))}
            </ul>
          )}

          <div className="sv-about__actions">
            {ctaButton && (
              <a href={ctaButton.href} className="sv-btn">
                {ctaButton.label}
                <span className="sv-btn__icon">
                  <Icon name="arrow-up-right" size={14} />
                </span>
              </a>
            )}
            {phone && (
              <a href={`tel:${phone}`} className="sv-about__phone">
                <Icon name="phone" size={14} />
                {phone}
              </a>
            )}
          </div>
        </div>

        <div className="sv-about__media">
          <ThemeImg image={image} ratio="auto" placeholderLabel="About image" className="sv-about__media-main" />
          {thumbs.map((thumb, index) => (
            <ThemeImg key={thumb.src + index} image={thumb} ratio="auto" placeholderLabel="Thumbnail" className={`sv-about__thumb sv-about__thumb--${index + 1}`} />
          ))}
          {badgeValue && (
            <div className="sv-about__badge">
              <strong>{badgeValue}</strong>
              {badgeLabel && <span>{badgeLabel}</span>}
            </div>
          )}
        </div>
      </Container>
    </section>
  );
}
