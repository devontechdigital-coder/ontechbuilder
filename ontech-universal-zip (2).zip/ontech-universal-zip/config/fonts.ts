/**
 * config/fonts.ts
 *
 * The theme's curated type library: 21 families offered for both the
 * heading and body roles.
 *
 * Performance note — this is why the list lives in code rather than as
 * a big `@import` in theme.css: a stylesheet that imports 21 families
 * makes every visitor download 21 families. Instead each option records
 * the Google Fonts family name and the exact weights the theme uses,
 * and layout/ThemeLayout.tsx builds ONE stylesheet link for only the
 * two families actually selected. Picking "System UI" downloads nothing
 * at all.
 */

export interface FontOption {
  /** The CSS font-family stack stored in settings and written to --otu-font-*. */
  value: string;
  /** Human label shown in the editor's font picker. */
  label: string;
  /** Google Fonts family name. Omitted for the system stack (no download). */
  family?: string;
  /** Weights requested for this family. Kept tight — display faces don't need 9 weights. */
  weights?: number[];
  /** Rough personality tag, surfaced as the option's grouping in the editor. */
  group: "Sans" | "Display" | "Serif" | "System";
}

const SANS_WEIGHTS = [400, 500, 600, 700, 800];
const DISPLAY_WEIGHTS = [500, 600, 700, 800];
const SERIF_WEIGHTS = [400, 500, 600, 700];

export const FONT_OPTIONS: FontOption[] = [
  // — Neutral & UI sans ————————————————————————————————
  { value: "'Inter', system-ui, sans-serif", label: "Inter — neutral UI sans", family: "Inter", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Manrope', system-ui, sans-serif", label: "Manrope — rounded grotesk", family: "Manrope", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Plus Jakarta Sans', system-ui, sans-serif", label: "Plus Jakarta Sans — friendly grotesk", family: "Plus Jakarta Sans", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'DM Sans', system-ui, sans-serif", label: "DM Sans — low-contrast geometric", family: "DM Sans", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Figtree', system-ui, sans-serif", label: "Figtree — warm humanist", family: "Figtree", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Work Sans', system-ui, sans-serif", label: "Work Sans — steady workhorse", family: "Work Sans", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Lexend', system-ui, sans-serif", label: "Lexend — high legibility", family: "Lexend", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Urbanist', system-ui, sans-serif", label: "Urbanist — open geometric", family: "Urbanist", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'IBM Plex Sans', system-ui, sans-serif", label: "IBM Plex Sans — technical", family: "IBM Plex Sans", weights: [400, 500, 600, 700], group: "Sans" },
  { value: "'Barlow', system-ui, sans-serif", label: "Barlow — slightly condensed", family: "Barlow", weights: SANS_WEIGHTS, group: "Sans" },
  { value: "'Karla', system-ui, sans-serif", label: "Karla — quirky grotesk", family: "Karla", weights: [400, 500, 600, 700, 800], group: "Sans" },

  // — Display & geometric ————————————————————————————
  { value: "'Outfit', system-ui, sans-serif", label: "Outfit — modern geometric display", family: "Outfit", weights: DISPLAY_WEIGHTS, group: "Display" },
  { value: "'Sora', system-ui, sans-serif", label: "Sora — engineered display", family: "Sora", weights: DISPLAY_WEIGHTS, group: "Display" },
  { value: "'Space Grotesk', system-ui, sans-serif", label: "Space Grotesk — technical display", family: "Space Grotesk", weights: [400, 500, 600, 700], group: "Display" },
  { value: "'Archivo', system-ui, sans-serif", label: "Archivo — sturdy editorial sans", family: "Archivo", weights: DISPLAY_WEIGHTS, group: "Display" },
  { value: "'Epilogue', system-ui, sans-serif", label: "Epilogue — sharp contemporary", family: "Epilogue", weights: DISPLAY_WEIGHTS, group: "Display" },
  { value: "'Syne', system-ui, sans-serif", label: "Syne — bold art-direction display", family: "Syne", weights: [500, 600, 700, 800], group: "Display" },
  { value: "'Poppins', system-ui, sans-serif", label: "Poppins — geometric sans", family: "Poppins", weights: [400, 500, 600, 700], group: "Display" },
  { value: "'Montserrat', system-ui, sans-serif", label: "Montserrat — wide urban sans", family: "Montserrat", weights: DISPLAY_WEIGHTS, group: "Display" },

  // — Serif ——————————————————————————————————————————
  { value: "'Playfair Display', Georgia, serif", label: "Playfair Display — high-contrast serif", family: "Playfair Display", weights: [500, 600, 700, 800], group: "Serif" },
  { value: "'Fraunces', Georgia, serif", label: "Fraunces — characterful soft serif", family: "Fraunces", weights: SERIF_WEIGHTS, group: "Serif" },
  { value: "'Source Serif 4', Georgia, serif", label: "Source Serif 4 — readable text serif", family: "Source Serif 4", weights: SERIF_WEIGHTS, group: "Serif" },

  // — No download ————————————————————————————————————
  {
    value: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
    label: "System UI — fastest, no webfont",
    group: "System",
  },
];

/** Editor-ready `select` options. Shared by the heading and body font settings. */
export const fontSelectOptions = FONT_OPTIONS.map(({ value, label }) => ({ value, label }));

export const DEFAULT_HEADING_FONT = "'Outfit', system-ui, sans-serif";
export const DEFAULT_BODY_FONT = "'Inter', system-ui, sans-serif";

function findOption(stack: string | undefined): FontOption | undefined {
  if (!stack) return undefined;
  return FONT_OPTIONS.find((option) => option.value === stack);
}

/**
 * Builds a single Google Fonts stylesheet URL covering only the
 * families in use. Returns undefined when both roles are system fonts
 * (or unrecognised), so the theme renders with zero font requests.
 */
export function buildFontHref(headingStack?: string, bodyStack?: string): string | undefined {
  const wanted = [findOption(headingStack), findOption(bodyStack)].filter(
    (option): option is FontOption => Boolean(option?.family),
  );
  if (wanted.length === 0) return undefined;

  const families = new Map<string, Set<number>>();
  for (const option of wanted) {
    const family = option.family as string;
    const set = families.get(family) ?? new Set<number>();
    for (const weight of option.weights ?? [400, 700]) set.add(weight);
    families.set(family, set);
  }

  const params = Array.from(families.entries()).map(([family, weights]) => {
    const list = Array.from(weights).sort((a, b) => a - b).join(";");
    return `family=${family.replace(/ /g, "+")}:wght@${list}`;
  });

  return `https://fonts.googleapis.com/css2?${params.join("&")}&display=swap`;
}
