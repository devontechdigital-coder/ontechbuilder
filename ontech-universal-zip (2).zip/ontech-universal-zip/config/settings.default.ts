/**
 * config/settings.default.ts
 *
 * Runtime shape + default values for the global theme settings. The
 * host stores the merchant's actual choices in this shape and passes
 * the resolved object into ThemeLayout as `settings`.
 */

import { DEFAULT_BODY_FONT, DEFAULT_HEADING_FONT } from "./fonts";

export interface ThemeSettings {
  // Color palette
  colorPrimary: string;
  colorPrimaryContrast: string;
  colorSecondary: string;
  colorAccent: string;
  colorBackground: string;
  colorSurface: string;
  colorSurfaceAlt: string;
  colorDark: string;
  colorText: string;
  colorMutedText: string;
  colorBorder: string;
  colorLink: string;

  // Typography
  headingFont: string;
  bodyFont: string;
  headingWeight: string;
  bodyWeight: string;
  baseFontSize: number;
  headingFontSize: number;
  headingScale: number;
  headingLetterSpacing: number;
  headingLineHeight: number;
  lineHeight: number;
  eyebrowStyle: "bracket" | "line" | "dot" | "plain";

  // Layout
  containerWidth: "narrow" | "default" | "wide" | "full";
  containerMaxWidth: number;
  narrowMaxWidth: number;
  sectionSpacing: number;
  mobileSectionSpacing: number;
  gridGap: number;
  gutter: number;

  // Corners & surfaces
  radiusSm: number;
  radiusMd: number;
  radiusLg: number;
  radiusXl: number;
  cardStyle: "elevated" | "outlined" | "filled" | "flat" | "glass";
  cardShadow: "none" | "soft" | "medium" | "strong";
  cardHoverLift: boolean;
  showCornerBracket: boolean;

  // Buttons
  buttonStyle: "solid" | "outline" | "soft";
  secondaryButtonStyle: "outline" | "ghost" | "solid";
  buttonRadius: number;
  buttonSize: "sm" | "md" | "lg";
  buttonHoverEffect: "fade" | "lift" | "slide" | "none";
  buttonUppercase: boolean;

  // Header
  stickyHeader: boolean;
  transparentOnHero: boolean;
  headerHeight: number;
  logoWidth: number;
  mobileLogoWidth: number;
  enableMegaMenu: boolean;

  // Footer
  footerStyle: "dark" | "light" | "primary";

  // Motion & effects
  enableScrollReveal: boolean;
  transitionSpeed: number;
  enableImageZoom: boolean;

  // Floating actions
  showScrollTop: boolean;
}

const settingsDefault: ThemeSettings = {
  colorPrimary: "#14509B",
  colorPrimaryContrast: "#FFFFFF",
  colorSecondary: "#0FB5A0",
  colorAccent: "#F5A524",
  colorBackground: "#FFFFFF",
  colorSurface: "#F2F5F9",
  colorSurfaceAlt: "#EAF0F7",
  colorDark: "#081226",
  colorText: "#0D1626",
  colorMutedText: "#5A6779",
  colorBorder: "#DCE3EC",
  colorLink: "#14509B",

  headingFont: DEFAULT_HEADING_FONT,
  bodyFont: DEFAULT_BODY_FONT,
  headingWeight: "700",
  bodyWeight: "400",
  baseFontSize: 16,
  headingFontSize: 40,
  headingScale: 1.25,
  headingLetterSpacing: -0.75,
  headingLineHeight: 1.08,
  lineHeight: 1.65,
  eyebrowStyle: "bracket",

  containerWidth: "default",
  containerMaxWidth: 1240,
  narrowMaxWidth: 820,
  sectionSpacing: 104,
  mobileSectionSpacing: 64,
  gridGap: 24,
  gutter: 24,

  radiusSm: 6,
  radiusMd: 12,
  radiusLg: 20,
  radiusXl: 32,
  cardStyle: "outlined",
  cardShadow: "soft",
  cardHoverLift: true,
  showCornerBracket: true,

  buttonStyle: "solid",
  secondaryButtonStyle: "outline",
  buttonRadius: 10,
  buttonSize: "md",
  buttonHoverEffect: "slide",
  buttonUppercase: false,

  stickyHeader: true,
  transparentOnHero: false,
  headerHeight: 80,
  logoWidth: 138,
  mobileLogoWidth: 108,
  enableMegaMenu: true,

  footerStyle: "dark",

  enableScrollReveal: true,
  transitionSpeed: 220,
  enableImageZoom: true,

  showScrollTop: true,
};

export default settingsDefault;
