/**
 * config/settings.schema.ts
 *
 * Declarative description of every GLOBAL setting the visual editor
 * should render, plus the shared schema types each section's own
 * `schema.ts` is written against. No UI code here — the host reads this
 * and generates its own controls.
 */

import { fontSelectOptions } from "./fonts";

export type SettingType =
  | "text"
  | "textarea"
  | "richtext"
  | "url"
  | "image"
  | "video"
  | "color"
  | "select"
  | "checkbox"
  | "range"
  | "number"
  | "font"
  | "icon"
  | "code";

export interface SelectOption {
  value: string;
  label: string;
}

export interface SettingField {
  type: SettingType;
  id: string;
  label: string;
  default?: string | number | boolean;
  info?: string;
  placeholder?: string;
  options?: SelectOption[];
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  /** Optional grouping hint for editors that render collapsible setting groups. */
  group?: string;
}

export interface SettingGroup {
  header: string;
  settings: SettingField[];
}

export interface BlockSchema {
  type: string;
  name: string;
  settings: SettingField[];
}

export interface SectionSchema {
  id: string;
  name: string;
  /** Library category shown in the editor's "add section" panel. */
  category: string;
  /** Short description of what the section is for. */
  description?: string;
  settings: SettingField[];
  blocks?: BlockSchema[];
  maxBlocks?: number;
  defaultBlocks?: { type: string; settings: Record<string, string | number | boolean> }[];
  /** Where this section may be placed. Defaults to anywhere in the body. */
  placement?: "body" | "header" | "footer" | "overlay";
}

export interface ThemeSettingsSchema {
  groups: SettingGroup[];
}

/* ————————————————————————————————————————————————————————————————
   Shared option sets. Sections import these so the same control means
   the same thing everywhere in the library — a merchant learns "Tone"
   once and it behaves identically in all 35 sections.
   ———————————————————————————————————————————————————————————————— */

export const toneOptions: SelectOption[] = [
  { value: "default", label: "Page background" },
  { value: "surface", label: "Surface (subtle tint)" },
  { value: "alt", label: "Alternate tint" },
  { value: "dark", label: "Dark" },
  { value: "primary", label: "Primary color" },
];

export const containerOptions: SelectOption[] = [
  { value: "narrow", label: "Narrow" },
  { value: "default", label: "Default" },
  { value: "wide", label: "Wide" },
  { value: "full", label: "Full width" },
];

export const alignOptions: SelectOption[] = [
  { value: "left", label: "Left" },
  { value: "center", label: "Center" },
  { value: "right", label: "Right" },
];

export const columnOptions: SelectOption[] = [
  { value: "2", label: "2 columns" },
  { value: "3", label: "3 columns" },
  { value: "4", label: "4 columns" },
];

export const columnOptionsWide: SelectOption[] = [
  { value: "2", label: "2 columns" },
  { value: "3", label: "3 columns" },
  { value: "4", label: "4 columns" },
  { value: "5", label: "5 columns" },
  { value: "6", label: "6 columns" },
];

export const gapOptions: SelectOption[] = [
  { value: "none", label: "None" },
  { value: "xs", label: "Extra small" },
  { value: "sm", label: "Small" },
  { value: "md", label: "Medium" },
  { value: "lg", label: "Large" },
  { value: "xl", label: "Extra large" },
];

export const radiusOptions: SelectOption[] = [
  { value: "none", label: "Square" },
  { value: "sm", label: "Small" },
  { value: "md", label: "Medium" },
  { value: "lg", label: "Large" },
  { value: "xl", label: "Extra large" },
  { value: "pill", label: "Fully rounded" },
];

export const cardStyleOptions: SelectOption[] = [
  { value: "elevated", label: "Elevated (shadow)" },
  { value: "outlined", label: "Outlined (hairline)" },
  { value: "filled", label: "Filled (tinted)" },
  { value: "flat", label: "Flat (no chrome)" },
  { value: "glass", label: "Glass (translucent)" },
];

export const aspectOptions: SelectOption[] = [
  { value: "auto", label: "Original" },
  { value: "1:1", label: "Square (1:1)" },
  { value: "4:3", label: "Landscape (4:3)" },
  { value: "3:2", label: "Landscape (3:2)" },
  { value: "16:9", label: "Widescreen (16:9)" },
  { value: "21:9", label: "Cinematic (21:9)" },
  { value: "3:4", label: "Portrait (3:4)" },
  { value: "2:3", label: "Portrait (2:3)" },
  { value: "9:16", label: "Tall (9:16)" },
];

/**
 * Every section's five designs are exposed through this one control.
 * Section schemas import `variantOptions(...)` and pass their own five
 * labels, so the ids stay uniform ("v1"…"v5") across the whole library
 * while the labels stay descriptive.
 */
export function variantOptions(labels: [string, string, string, string, string]): SelectOption[] {
  return labels.map((label, index) => ({ value: `v${index + 1}`, label: `${index + 1} — ${label}` }));
}

/**
 * The Layout/Style/Spacing controls shared by every section, matching
 * the props handled centrally in components/SectionShell.tsx. Section
 * schemas spread this in rather than restating ~10 fields 35 times.
 */
export function baseSectionSettings(options?: { defaultTone?: string; defaultContainer?: string }): SettingField[] {
  return [
    {
      type: "select",
      id: "tone",
      label: "Section tone",
      options: toneOptions,
      default: options?.defaultTone ?? "default",
      group: "Style",
      info: "Background treatment. Use tones to build rhythm down the page.",
    },
    {
      type: "select",
      id: "containerWidth",
      label: "Container width",
      options: containerOptions,
      default: options?.defaultContainer ?? "default",
      group: "Layout",
    },
    { type: "color", id: "backgroundColor", label: "Background override", group: "Style", info: "Leave empty to use the tone above." },
    { type: "color", id: "textColor", label: "Text override", group: "Style" },
    { type: "color", id: "accentColor", label: "Accent override", group: "Style" },
    { type: "range", id: "paddingTop", label: "Padding top", min: 0, max: 220, step: 4, unit: "px", group: "Spacing" },
    { type: "range", id: "paddingBottom", label: "Padding bottom", min: 0, max: 220, step: 4, unit: "px", group: "Spacing" },
    { type: "range", id: "mobilePaddingTop", label: "Mobile padding top", min: 0, max: 160, step: 4, unit: "px", group: "Spacing" },
    { type: "range", id: "mobilePaddingBottom", label: "Mobile padding bottom", min: 0, max: 160, step: 4, unit: "px", group: "Spacing" },
    { type: "text", id: "anchorId", label: "Anchor ID", group: "Advanced", info: "Link to this section with #your-id." },
    { type: "text", id: "customClass", label: "Custom CSS class", group: "Advanced" },
  ];
}

/* ————————————————————————————————————————————————————————————————
   Global theme settings
   ———————————————————————————————————————————————————————————————— */

const settingsSchema: ThemeSettingsSchema = {
  groups: [
    {
      header: "Color palette",
      settings: [
        { type: "color", id: "colorPrimary", label: "Primary", default: "#14509B", info: "Buttons, links, active states and the accent bracket." },
        { type: "color", id: "colorPrimaryContrast", label: "Text on primary", default: "#FFFFFF" },
        { type: "color", id: "colorSecondary", label: "Secondary", default: "#0FB5A0", info: "Used sparingly — highlighted words, chart accents, badges." },
        { type: "color", id: "colorAccent", label: "Accent", default: "#F5A524", info: "Third color for markers, ratings and emphasis." },
        { type: "color", id: "colorBackground", label: "Page background", default: "#FFFFFF" },
        { type: "color", id: "colorSurface", label: "Surface / card background", default: "#F2F5F9" },
        { type: "color", id: "colorSurfaceAlt", label: "Alternate section background", default: "#EAF0F7" },
        { type: "color", id: "colorDark", label: "Dark section background", default: "#081226" },
        { type: "color", id: "colorText", label: "Body text", default: "#0D1626" },
        { type: "color", id: "colorMutedText", label: "Muted text", default: "#5A6779" },
        { type: "color", id: "colorBorder", label: "Border / hairline", default: "#DCE3EC" },
        { type: "color", id: "colorLink", label: "Text link", default: "#14509B" },
      ],
    },
    {
      header: "Typography",
      settings: [
        {
          type: "select",
          id: "headingFont",
          label: "Heading font",
          options: fontSelectOptions,
          default: "'Outfit', system-ui, sans-serif",
          info: "21 curated families. Only the heading and body families you pick are downloaded.",
        },
        { type: "select", id: "bodyFont", label: "Body font", options: fontSelectOptions, default: "'Inter', system-ui, sans-serif" },
        {
          type: "select",
          id: "headingWeight",
          label: "Heading weight",
          options: [
            { value: "500", label: "Medium" },
            { value: "600", label: "Semibold" },
            { value: "700", label: "Bold" },
            { value: "800", label: "Extrabold" },
          ],
          default: "700",
        },
        {
          type: "select",
          id: "bodyWeight",
          label: "Body weight",
          options: [
            { value: "400", label: "Regular" },
            { value: "500", label: "Medium" },
          ],
          default: "400",
        },
        { type: "range", id: "baseFontSize", label: "Body size", min: 14, max: 20, step: 1, unit: "px", default: 16 },
        { type: "range", id: "headingFontSize", label: "Heading size (H2 baseline)", min: 24, max: 64, step: 1, unit: "px", default: 40 },
        { type: "range", id: "headingScale", label: "Heading scale ratio", min: 1.05, max: 1.6, step: 0.05, default: 1.25, info: "Spread between H1, H2 and H3." },
        { type: "range", id: "headingLetterSpacing", label: "Heading letter spacing", min: -3, max: 2, step: 0.25, unit: "px", default: -0.75 },
        { type: "range", id: "headingLineHeight", label: "Heading line height", min: 0.9, max: 1.4, step: 0.02, default: 1.08 },
        { type: "range", id: "lineHeight", label: "Body line height", min: 1.2, max: 2, step: 0.05, default: 1.65 },
        {
          type: "select",
          id: "eyebrowStyle",
          label: "Eyebrow style",
          options: [
            { value: "bracket", label: "Precision bracket (theme signature)" },
            { value: "line", label: "Leading rule" },
            { value: "dot", label: "Leading dot" },
            { value: "plain", label: "Plain text" },
          ],
          default: "bracket",
        },
      ],
    },
    {
      header: "Layout",
      settings: [
        { type: "select", id: "containerWidth", label: "Container width", options: containerOptions, default: "default" },
        { type: "range", id: "containerMaxWidth", label: "Default container max width", min: 1040, max: 1600, step: 20, unit: "px", default: 1240 },
        { type: "range", id: "narrowMaxWidth", label: "Narrow container max width", min: 600, max: 1000, step: 20, unit: "px", default: 820 },
        { type: "range", id: "sectionSpacing", label: "Section vertical spacing", min: 32, max: 200, step: 4, unit: "px", default: 104 },
        { type: "range", id: "mobileSectionSpacing", label: "Mobile section spacing", min: 24, max: 140, step: 4, unit: "px", default: 64 },
        { type: "range", id: "gridGap", label: "Grid gap", min: 8, max: 64, step: 2, unit: "px", default: 24 },
        { type: "range", id: "gutter", label: "Page side gutter", min: 12, max: 64, step: 2, unit: "px", default: 24 },
      ],
    },
    {
      header: "Corners & surfaces",
      settings: [
        { type: "range", id: "radiusSm", label: "Small radius", min: 0, max: 20, step: 1, unit: "px", default: 6 },
        { type: "range", id: "radiusMd", label: "Medium radius", min: 0, max: 32, step: 1, unit: "px", default: 12 },
        { type: "range", id: "radiusLg", label: "Large radius", min: 0, max: 48, step: 1, unit: "px", default: 20 },
        { type: "range", id: "radiusXl", label: "Extra large radius", min: 0, max: 64, step: 2, unit: "px", default: 32 },
        { type: "select", id: "cardStyle", label: "Default card style", options: cardStyleOptions, default: "outlined" },
        {
          type: "select",
          id: "cardShadow",
          label: "Shadow intensity",
          options: [
            { value: "none", label: "None" },
            { value: "soft", label: "Soft" },
            { value: "medium", label: "Medium" },
            { value: "strong", label: "Strong" },
          ],
          default: "soft",
        },
        { type: "checkbox", id: "cardHoverLift", label: "Lift cards on hover", default: true },
        { type: "checkbox", id: "showCornerBracket", label: "Show the accent corner bracket on cards", default: true, info: "The theme's signature detail. Turn off for a plainer look." },
      ],
    },
    {
      header: "Buttons",
      settings: [
        {
          type: "select",
          id: "buttonStyle",
          label: "Primary button style",
          options: [
            { value: "solid", label: "Solid" },
            { value: "outline", label: "Outline" },
            { value: "soft", label: "Soft tint" },
          ],
          default: "solid",
        },
        {
          type: "select",
          id: "secondaryButtonStyle",
          label: "Secondary button style",
          options: [
            { value: "outline", label: "Outline" },
            { value: "ghost", label: "Ghost" },
            { value: "solid", label: "Solid" },
          ],
          default: "outline",
        },
        { type: "range", id: "buttonRadius", label: "Button radius", min: 0, max: 999, step: 1, unit: "px", default: 10 },
        {
          type: "select",
          id: "buttonSize",
          label: "Default size",
          options: [
            { value: "sm", label: "Small" },
            { value: "md", label: "Medium" },
            { value: "lg", label: "Large" },
          ],
          default: "md",
        },
        {
          type: "select",
          id: "buttonHoverEffect",
          label: "Hover effect",
          options: [
            { value: "fade", label: "Fade" },
            { value: "lift", label: "Lift" },
            { value: "slide", label: "Arrow slide" },
            { value: "none", label: "None" },
          ],
          default: "slide",
        },
        { type: "checkbox", id: "buttonUppercase", label: "Uppercase button labels", default: false },
      ],
    },
    {
      header: "Header",
      settings: [
        { type: "checkbox", id: "stickyHeader", label: "Sticky header on scroll", default: true, info: "The Header section's own setting wins if the two disagree." },
        { type: "checkbox", id: "transparentOnHero", label: "Transparent over the hero", default: false },
        { type: "range", id: "headerHeight", label: "Header height", min: 56, max: 132, step: 2, unit: "px", default: 80 },
        { type: "range", id: "logoWidth", label: "Desktop logo width", min: 80, max: 260, step: 4, unit: "px", default: 138 },
        { type: "range", id: "mobileLogoWidth", label: "Mobile logo width", min: 60, max: 200, step: 4, unit: "px", default: 108 },
        { type: "checkbox", id: "enableMegaMenu", label: "Allow dropdown and mega menus", default: true },
      ],
    },
    {
      header: "Footer",
      settings: [
        {
          type: "select",
          id: "footerStyle",
          label: "Footer color",
          options: [
            { value: "dark", label: "Dark" },
            { value: "light", label: "Light" },
            { value: "primary", label: "Primary" },
          ],
          default: "dark",
        },
      ],
    },
    {
      header: "Motion & effects",
      settings: [
        { type: "checkbox", id: "enableScrollReveal", label: "Reveal sections on scroll", default: true, info: "Always disabled automatically for visitors who prefer reduced motion." },
        { type: "range", id: "transitionSpeed", label: "Transition speed", min: 100, max: 600, step: 25, unit: "ms", default: 220 },
        { type: "checkbox", id: "enableImageZoom", label: "Zoom images on hover", default: true },
      ],
    },
    {
      header: "Floating actions",
      settings: [
        { type: "checkbox", id: "showScrollTop", label: "Show back-to-top button", default: true, info: "Add the Floating actions section for WhatsApp, call and custom actions." },
      ],
    },
  ],
};

export default settingsSchema;
