/**
 * theme.config.ts
 *
 * Portable manifest describing this theme package to the host platform.
 * Plain, serializable data only — no side effects, no React imports —
 * so the host can parse and validate it without executing app code.
 */

export interface ThemeConfig {
  id: string;
  name: string;
  version: string;
  engineVersion: string;
  description: string;
  author: string;
  templates: Record<string, string>;
  sections: Record<string, string>;
  capabilities: {
    settingsSchema: boolean;
    sectionSchemas: boolean;
    blocks: boolean;
    localization: boolean;
    imageFields: boolean;
    videoFields: boolean;
    responsivePreview: boolean;
    megaMenu: boolean;
    sectionVariants: boolean;
    customCode: boolean;
  };
}

const themeConfig: ThemeConfig = {
  id: "ontech-universal",
  name: "Ontech Universal",
  version: "1.0.0",
  engineVersion: "^1.0.0",
  description:
    "A universal multi-purpose theme for corporate, agency, SaaS, healthcare, education, construction, real estate, and lead-generation websites. 34 section categories, each with 5 genuinely distinct designs — over 170 section variants in total, plus a curated 21-family type system and full block/schema support for the visual builder.",
  author: "Ontech Theme Studio",
  templates: {
    index: "templates/index.tsx",
    page: "templates/page.tsx",
    about: "templates/about.tsx",
    services: "templates/services.tsx",
    service: "templates/service.tsx",
    portfolio: "templates/portfolio.tsx",
    project: "templates/project.tsx",
    blog: "templates/blog.tsx",
    article: "templates/article.tsx",
    contact: "templates/contact.tsx",
    search: "templates/search.tsx",
    "404": "templates/404.tsx",
  },
  sections: {
    header: "sections/Header/Header.tsx",
    "announcement-bar": "sections/AnnouncementBar/AnnouncementBarSection.tsx",
    hero: "sections/Hero/Hero.tsx",
    "text-block": "sections/TextBlock/TextBlock.tsx",
    cards: "sections/Cards/Cards.tsx",
    gallery: "sections/Gallery/Gallery.tsx",
    slider: "sections/Slider/SliderSection.tsx",
    video: "sections/VideoSection/VideoSection.tsx",
    "video-slider": "sections/VideoSlider/VideoSlider.tsx",
    form: "sections/Forms/Forms.tsx",
    testimonials: "sections/Testimonials/Testimonials.tsx",
    faq: "sections/FAQ/FAQ.tsx",
    timeline: "sections/Timeline/Timeline.tsx",
    services: "sections/Services/Services.tsx",
    "about-us": "sections/AboutUs/AboutUs.tsx",
    features: "sections/Features/Features.tsx",
    team: "sections/Team/Team.tsx",
    pricing: "sections/Pricing/Pricing.tsx",
    stats: "sections/Stats/Stats.tsx",
    "logo-cloud": "sections/LogoCloud/LogoCloud.tsx",
    cta: "sections/CTA/CTA.tsx",
    portfolio: "sections/Portfolio/Portfolio.tsx",
    process: "sections/Process/Process.tsx",
    tabs: "sections/TabsSection/TabsSection.tsx",
    accordion: "sections/AccordionSection/AccordionSection.tsx",
    tables: "sections/Tables/Tables.tsx",
    "image-text": "sections/ImageText/ImageText.tsx",
    "bento-grid": "sections/BentoGrid/BentoGrid.tsx",
    marquee: "sections/Marquee/Marquee.tsx",
    map: "sections/Maps/Maps.tsx",
    "contact-info": "sections/Contact/Contact.tsx",
    footer: "sections/Footer/Footer.tsx",
    popup: "sections/Popup/Popup.tsx",
    "floating-actions": "sections/FloatingActions/FloatingActionsSection.tsx",
    "custom-code": "sections/CustomCode/CustomCode.tsx",
  },
  capabilities: {
    settingsSchema: true,
    sectionSchemas: true,
    blocks: true,
    localization: true,
    imageFields: true,
    videoFields: true,
    responsivePreview: true,
    megaMenu: true,
    sectionVariants: true,
    customCode: true,
  },
};

export default themeConfig;
