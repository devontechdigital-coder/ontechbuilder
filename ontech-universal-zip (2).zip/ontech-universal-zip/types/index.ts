/**
 * types/index.ts
 *
 * Small, portable, frontend-only data contracts shared by every
 * section, variant and template in Ontech Universal.
 *
 * These deliberately describe *presentation* shapes only. There are no
 * backend/domain models here: the host platform maps whatever it stores
 * into these objects before handing them to a section as props.
 */

/** An image chosen in the visual editor. `src` is whatever URL the host resolves (e.g. a Cloud Storage object). */
export interface ThemeImage {
  src?: string;
  alt?: string;
  width?: number;
  height?: number;
  /** Optional focal point, e.g. "50% 30%", forwarded to CSS object-position. */
  focalPoint?: string;
}

/** A video chosen in the visual editor, or an embeddable external URL. */
export interface ThemeVideo {
  /** Direct file URL (mp4/webm) resolved by the host. */
  src?: string;
  /** External embed URL (YouTube/Vimeo). Rendered in an iframe, never executed as script. */
  embedUrl?: string;
  poster?: ThemeImage;
}

export interface LinkValue {
  label: string;
  href: string;
  external?: boolean;
}

export type ContainerWidth = "narrow" | "default" | "wide" | "full";
export type ContentAlignment = "left" | "center" | "right";
export type ImagePosition = "left" | "right" | "top" | "bottom";
export type AspectRatio = "auto" | "1:1" | "4:3" | "3:4" | "3:2" | "2:3" | "16:9" | "9:16" | "21:9";
export type ColumnCount = 1 | 2 | 3 | 4 | 5 | 6;
export type GapSize = "none" | "xs" | "sm" | "md" | "lg" | "xl";
export type RadiusSize = "none" | "sm" | "md" | "lg" | "xl" | "pill";
export type ShadowSize = "none" | "soft" | "medium" | "strong";

/**
 * Surface tone for a whole section. Every variant honours this, which is
 * what lets a merchant build vertical rhythm (light / tinted / dark)
 * without touching per-section colors.
 */
export type SectionTone = "default" | "surface" | "alt" | "dark" | "primary";

/** Card treatment shared by every card-bearing section. */
export type CardStyle = "elevated" | "outlined" | "filled" | "flat" | "glass";

/**
 * Props that EVERY section in this theme accepts, on top of its own
 * content props. Handled centrally by components/SectionShell.tsx so no
 * variant re-implements padding, tone or container logic.
 */
export interface SectionBaseProps {
  /** Which of the five designs to render: "v1" … "v5". */
  variant?: string;
  tone?: SectionTone;
  containerWidth?: ContainerWidth;
  /** Vertical padding overrides in px. Undefined = the global section spacing. */
  paddingTop?: number | string;
  paddingBottom?: number | string;
  /** Padding overrides applied below the mobile breakpoint. */
  mobilePaddingTop?: number | string;
  mobilePaddingBottom?: number | string;
  /** Optional id so a nav link or CTA can deep-link to this section. */
  anchorId?: string;
  /** Extra class names, e.g. from the Custom Code section's class field. */
  customClass?: string;
  /** Per-section color overrides. Blank means "inherit the global palette". */
  backgroundColor?: string;
  textColor?: string;
  accentColor?: string;
}

/** Shared shape for the heading cluster most sections open with. */
export interface SectionHeadingContent {
  eyebrow?: string;
  heading?: string;
  subheading?: string;
  description?: string;
  align?: ContentAlignment;
}
