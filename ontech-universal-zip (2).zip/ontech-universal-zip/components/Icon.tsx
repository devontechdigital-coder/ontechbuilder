import * as React from "react";

/**
 * components/Icon.tsx
 *
 * A dependency-free line-icon set drawn on a 24px grid. Deliberately
 * hand-maintained instead of pulling in an icon package: the theme ships
 * ~45 glyphs rather than a few thousand, and every section's icon
 * picker resolves to a name in this union.
 */
export type IconName =
  | "arrow-right"
  | "arrow-left"
  | "arrow-up-right"
  | "arrow-down"
  | "chevron-down"
  | "chevron-up"
  | "chevron-left"
  | "chevron-right"
  | "plus"
  | "minus"
  | "check"
  | "check-circle"
  | "close"
  | "menu"
  | "search"
  | "star"
  | "heart"
  | "quote"
  | "play"
  | "pause"
  | "mail"
  | "phone"
  | "whatsapp"
  | "map-pin"
  | "clock"
  | "calendar"
  | "globe"
  | "shield"
  | "lock"
  | "zap"
  | "spark"
  | "target"
  | "trending-up"
  | "bar-chart"
  | "layers"
  | "grid"
  | "settings"
  | "users"
  | "user"
  | "briefcase"
  | "building"
  | "home"
  | "wrench"
  | "lightbulb"
  | "rocket"
  | "award"
  | "book"
  | "file-text"
  | "download"
  | "external-link"
  | "message-circle"
  | "send"
  | "facebook"
  | "instagram"
  | "linkedin"
  | "x-social"
  | "youtube";

interface IconProps extends React.SVGAttributes<SVGSVGElement> {
  name: IconName | string;
  size?: number;
}

const paths: Record<IconName, React.ReactNode> = {
  "arrow-right": <path d="M5 12h14M13 5l7 7-7 7" />,
  "arrow-left": <path d="M19 12H5M11 5l-7 7 7 7" />,
  "arrow-up-right": <path d="M7 17 17 7M9 7h8v8" />,
  "arrow-down": <path d="M12 5v14M5 13l7 7 7-7" />,
  "chevron-down": <path d="m6 9 6 6 6-6" />,
  "chevron-up": <path d="m6 15 6-6 6 6" />,
  "chevron-left": <path d="m15 6-6 6 6 6" />,
  "chevron-right": <path d="m9 6 6 6-6 6" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  check: <path d="m5 13 4 4L19 7" />,
  "check-circle": (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="m8 12 3 3 5-6" />
    </>
  ),
  close: <path d="M6 6l12 12M18 6 6 18" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-3.6-3.6" />
    </>
  ),
  star: <path d="m12 2 2.9 6.3 6.9.7-5.2 4.6 1.6 6.8L12 17l-6.2 3.4 1.6-6.8L2.2 9l6.9-.7L12 2Z" />,
  heart: <path d="M12 20s-7-4.4-7-9a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 4.6-7 9-7 9Z" />,
  quote: <path d="M9 7c-2.8 1-4 3-4 6v4h6v-6H7c0-1.8.7-3 2-3.6Zm10 0c-2.8 1-4 3-4 6v4h6v-6h-4c0-1.8.7-3 2-3.6Z" />,
  play: <path d="M8 5.5v13l11-6.5-11-6.5Z" />,
  pause: <path d="M9 5v14M15 5v14" />,
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m4 7 8 6 8-6" />
    </>
  ),
  phone: <path d="M6.6 10.8a15.9 15.9 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.24 11 11 0 0 0 3.4.55 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11 11 0 0 0 .55 3.4 1 1 0 0 1-.24 1L6.6 10.8Z" />,
  whatsapp: <path d="M20 11.8A7.9 7.9 0 0 1 8.6 19L4 20l1.1-4.4A7.9 7.9 0 1 1 20 11.8Zm-5.2 4c.6-.2 1-.8 1.1-1.3 0-.2 0-.4-.1-.5l-1.6-.8c-.2 0-.4 0-.5.2l-.5.7a5.6 5.6 0 0 1-2.4-2.4l.7-.5c.2-.1.2-.3.2-.5l-.8-1.6c-.1-.2-.3-.2-.5-.1-.5 0-1.1.5-1.3 1.1-.3 1 .2 2.4 1.7 4 1.5 1.5 3 2 4 1.7Z" />,
  "map-pin": (
    <>
      <path d="M12 21s7-6.1 7-11.5A7 7 0 0 0 5 9.5C5 14.9 12 21 12 21Z" />
      <circle cx="12" cy="9.5" r="2.4" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5.2l3.2 2" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M3 10h18M8 3v4M16 3v4" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.4 2.6 3.6 5.6 3.6 9S14.4 18.4 12 21c-2.4-2.6-3.6-5.6-3.6-9S9.6 5.6 12 3Z" />
    </>
  ),
  shield: <path d="M12 3l7 3v5.5c0 4.3-2.9 7.6-7 9.5-4.1-1.9-7-5.2-7-9.5V6l7-3Z" />,
  lock: (
    <>
      <rect x="4" y="10" width="16" height="11" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </>
  ),
  zap: <path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z" />,
  spark: <path d="M12 2.5 13.7 8 19 9.7 13.7 11.4 12 17l-1.7-5.6L5 9.7l5.3-1.7L12 2.5Z" />,
  target: (
    <>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1.4" />
    </>
  ),
  "trending-up": <path d="m3 17 6-6 4 4 8-8M15 7h6v6" />,
  "bar-chart": <path d="M5 20V11M12 20V4M19 20v-6" />,
  layers: <path d="m12 3 9 5-9 5-9-5 9-5Zm9 9-9 5-9-5m18 4-9 5-9-5" />,
  grid: (
    <>
      <rect x="3" y="3" width="7.5" height="7.5" rx="1.5" />
      <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5" />
      <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5" />
      <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1v.3a2 2 0 1 1-4 0v-.2a1.6 1.6 0 0 0-2.8-1.1l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3.5 15H3a2 2 0 1 1 0-4h.2a1.6 1.6 0 0 0 1.1-2.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 2.7-1.1V4a2 2 0 1 1 4 0v.2a1.6 1.6 0 0 0 2.8 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.8h.3a2 2 0 1 1 0 4h-.2a1.6 1.6 0 0 0-1.2.9Z" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.4" />
      <path d="M2.5 20a6.5 6.5 0 0 1 13 0M17 5.2a3.4 3.4 0 0 1 0 6.6M18 20a6.6 6.6 0 0 0-2-4.7" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="3.6" />
      <path d="M4.5 20a7.5 7.5 0 0 1 15 0" />
    </>
  ),
  briefcase: (
    <>
      <rect x="3" y="7" width="18" height="13" rx="2" />
      <path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 12h18" />
    </>
  ),
  building: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="2" />
      <path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2" />
    </>
  ),
  home: <path d="m4 10 8-6 8 6v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-9Z" />,
  wrench: <path d="M15 3a5 5 0 0 0-4.6 7L3 17.4V21h3.6l7.4-7.4A5 5 0 1 0 15 3Z" />,
  lightbulb: <path d="M9.5 18h5M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.5.4.8 1 .8 1.6v.5h5.4v-.5c0-.6.3-1.2.8-1.6A6 6 0 0 0 12 3Z" />,
  rocket: <path d="M13.5 3C17 4 21 8 20 11.5l-3.2 3.2-4.5-4.5L15.5 7M9.5 14.5 5 20m2-8L3.5 13 5 15m4 4 1 1.5L12 17" />,
  award: (
    <>
      <circle cx="12" cy="9" r="5.5" />
      <path d="m8.5 13.5-1.5 7L12 18l5 2.5-1.5-7" />
    </>
  ),
  book: <path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2V5Zm4-2v18" />,
  "file-text": (
    <>
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" />
      <path d="M14 3v5h5M9 13h6M9 17h4" />
    </>
  ),
  download: <path d="M12 4v10m0 0 4-4m-4 4-4-4M4 18h16" />,
  "external-link": <path d="M14 4h6v6M20 4l-8 8M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4" />,
  "message-circle": <path d="M20 11.5A7.5 7.5 0 0 1 9 18.2L4 19.5l1.3-4.6A7.5 7.5 0 1 1 20 11.5Z" />,
  send: <path d="M21 3 10.5 13.5M21 3l-6.8 18-3.7-7.5L3 9.8 21 3Z" />,
  facebook: <path d="M14 9h3V6h-3a4 4 0 0 0-4 4v2H7v3h3v6h3v-6h3l1-3h-4v-2a1 1 0 0 1 1-1Z" />,
  instagram: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" />
    </>
  ),
  linkedin: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M7 10v7M7 7v.01M11 17v-4.5a2.5 2.5 0 0 1 5 0V17M11 10v7" />
    </>
  ),
  "x-social": <path d="m4 4 16 16M20 4 4 20" />,
  youtube: (
    <>
      <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
      <path d="m10.5 9.5 5 2.5-5 2.5v-5Z" />
    </>
  ),
};

/** Unknown names render nothing rather than throwing, so a stale icon setting can't break a page. */
export function Icon({ name, size = 20, className, ...rest }: IconProps) {
  const glyph = paths[name as IconName];
  if (!glyph) return null;
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {glyph}
    </svg>
  );
}

export const ICON_NAMES: IconName[] = Object.keys(paths) as IconName[];

/** Editor-ready options for any schema field of type `icon`/`select` that picks a glyph. */
export const iconSelectOptions = ICON_NAMES.map((name) => ({
  value: name,
  label: name.replace(/-/g, " ").replace(/\b\w/g, (character) => character.toUpperCase()),
}));
