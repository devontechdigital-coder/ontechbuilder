import * as React from "react";
import { cn, lines } from "./utils";

interface RichTextProps {
  /** Plain text from a textarea, or sanitized HTML from the host's rich-text field. */
  value?: string;
  /** True when the host guarantees the value is already-sanitized editor HTML. */
  html?: boolean;
  className?: string;
}

/**
 * Renders body copy.
 *
 * Plain textarea values become real paragraphs (blank line = new
 * paragraph) rather than one blob with lost line breaks. Values marked
 * `html` come from the host's rich-text field, which sanitizes on save —
 * the theme only renders, it never sanitizes-and-trusts arbitrary input
 * of its own, and it never executes anything.
 */
export function RichText({ value, html = false, className }: RichTextProps) {
  if (!value?.trim()) return null;

  if (html) {
    return <div className={cn("otu-prose", className)} dangerouslySetInnerHTML={{ __html: value }} />;
  }

  const paragraphs = value.split(/\n{2,}/).map((block) => block.trim()).filter(Boolean);
  return (
    <div className={cn("otu-prose", className)}>
      {paragraphs.map((paragraph, index) => (
        <p key={index}>
          {lines(paragraph).map((line, lineIndex, all) => (
            <React.Fragment key={lineIndex}>
              {line}
              {lineIndex < all.length - 1 ? <br /> : null}
            </React.Fragment>
          ))}
        </p>
      ))}
    </div>
  );
}
