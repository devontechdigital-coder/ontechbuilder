/**
 * components/utils.ts
 *
 * Tiny, dependency-free helpers. Deliberately not a utility library —
 * only what more than one section actually needs.
 */

/** Joins class names, dropping falsy entries. Replaces a `clsx` dependency. */
export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

/** Normalises a px-ish setting value to a CSS length, or undefined to fall back to the token. */
export function px(value: number | string | undefined | null): string | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  if (typeof value === "number") return Number.isFinite(value) ? `${value}px` : undefined;
  const trimmed = String(value).trim();
  if (!trimmed) return undefined;
  return /^-?\d+(\.\d+)?$/.test(trimmed) ? `${trimmed}px` : trimmed;
}

/**
 * Splits a newline- or comma-separated textarea value into clean items.
 * Used wherever a schema exposes a "one per line" list (feature bullets,
 * marquee messages, table cells) instead of a heavier block type.
 */
export function lines(value: unknown): string[] {
  if (typeof value !== "string") return [];
  return value
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

/** Splits a single "a | b | c" row into cells. Used by the Table section. */
export function cells(value: unknown, separator = "|"): string[] {
  if (typeof value !== "string") return [];
  return value.split(separator).map((cell) => cell.trim());
}

/**
 * Only allows in-theme, non-executable link targets through. Blocks
 * `javascript:` and `data:` URLs so a mis-configured or pasted link can
 * never become a script execution vector.
 */
export function safeHref(href: unknown): string | undefined {
  if (typeof href !== "string") return undefined;
  const value = href.trim();
  if (!value) return undefined;
  if (/^(javascript|data|vbscript):/i.test(value.replace(/\s/g, ""))) return undefined;
  return value;
}

/** Stable, SSR-safe id derived from a string — avoids useId for markup that must match on the server. */
export function slugify(value: string, fallback = "item"): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
  return slug || fallback;
}
