"use client";

import * as React from "react";

/**
 * components/ScrollReveal.tsx
 *
 * Renders nothing. One IntersectionObserver marks each top-level
 * section with `.otu-in-view` the first time it enters the viewport,
 * which theme.css uses to fade and rise it into place, then unobserves
 * it so scrolling back never re-triggers.
 *
 * A single controller mounted once in ThemeLayout is deliberately
 * simpler than teaching 35 sections their own animation logic, and it
 * bails out entirely under prefers-reduced-motion.
 */
export function ScrollReveal({ enabled }: { enabled: boolean }) {
  React.useEffect(() => {
    if (!enabled) return;
    if (typeof window === "undefined" || !("IntersectionObserver" in window)) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;

    const main = document.querySelector(".otu-main");
    if (!main) return;
    const targets = Array.from(main.children);
    if (targets.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("otu-in-view");
            observer.unobserve(entry.target);
          }
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -6% 0px" },
    );

    targets.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [enabled]);

  return null;
}
