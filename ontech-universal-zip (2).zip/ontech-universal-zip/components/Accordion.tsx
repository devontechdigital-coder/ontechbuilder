import * as React from "react";
import { Icon, type IconName } from "./Icon";
import { cn } from "./utils";

export interface AccordionItem {
  id: string;
  question: string;
  answer?: string;
  icon?: string;
  meta?: string;
}

interface AccordionProps {
  items: AccordionItem[];
  /** Passing the same name to every item makes them mutually exclusive — one open at a time. */
  exclusiveName?: string;
  /** Index that starts open. -1 opens none. */
  defaultOpen?: number;
  markerStyle?: "plus" | "chevron" | "arrow" | "none";
  className?: string;
  itemClassName?: string;
  renderAnswer?: (item: AccordionItem) => React.ReactNode;
}

const markerIcon: Record<string, IconName> = {
  plus: "plus",
  chevron: "chevron-down",
  arrow: "arrow-down",
};

/**
 * Built on native <details>/<summary>.
 *
 * That gives correct expand/collapse semantics, keyboard operation and
 * in-page find-on-page behaviour with no JavaScript at all — the whole
 * FAQ and Accordion categories render on the server. `name` makes the
 * group exclusive natively in modern browsers, and degrades to
 * independently-openable items elsewhere, which is a harmless fallback.
 */
export function Accordion({
  items,
  exclusiveName,
  defaultOpen = 0,
  markerStyle = "plus",
  className,
  itemClassName,
  renderAnswer,
}: AccordionProps) {
  if (items.length === 0) return null;
  return (
    <div className={cn("otu-accordion", `otu-accordion--${markerStyle}`, className)}>
      {items.map((item, index) => (
        <details
          key={item.id}
          className={cn("otu-accordion__item", itemClassName)}
          name={exclusiveName}
          open={index === defaultOpen}
        >
          <summary className="otu-accordion__summary">
            <span className="otu-accordion__question">
              {item.icon ? <Icon name={item.icon} size={18} className="otu-accordion__icon" /> : null}
              {item.question}
            </span>
            {item.meta ? <span className="otu-accordion__meta">{item.meta}</span> : null}
            {markerStyle !== "none" ? (
              <span className="otu-accordion__marker" aria-hidden="true">
                <Icon name={markerIcon[markerStyle] ?? "plus"} size={18} />
              </span>
            ) : null}
          </summary>
          <div className="otu-accordion__panel">
            {renderAnswer ? renderAnswer(item) : item.answer ? <p>{item.answer}</p> : null}
          </div>
        </details>
      ))}
    </div>
  );
}
