"use client";

import * as React from "react";
import { Icon } from "./Icon";

/**
 * The always-available back-to-top control mounted by ThemeLayout.
 *
 * It stays hidden until the visitor is a viewport or so down the page,
 * so it never covers content on a short page, and it scrolls with
 * `behavior: "auto"` when reduced motion is requested.
 */
export function BackToTop({ show }: { show: boolean }) {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    if (!show || typeof window === "undefined") return;
    const onScroll = () => setVisible(window.scrollY > window.innerHeight * 0.8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [show]);

  if (!show) return null;

  const toTop = () => {
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
  };

  return (
    <button
      type="button"
      className={`otu-to-top${visible ? " is-visible" : ""}`}
      onClick={toTop}
      aria-label="Back to top"
      tabIndex={visible ? 0 : -1}
      aria-hidden={visible ? undefined : "true"}
    >
      <Icon name="chevron-up" size={20} />
    </button>
  );
}
