"use client";

import * as React from "react";
import { Icon } from "./Icon";
import { cn, slugify } from "./utils";

export interface TabItem {
  id: string;
  label: string;
  icon?: string;
  meta?: string;
  content: React.ReactNode;
}

interface TabsProps {
  items: TabItem[];
  /** Horizontal pills/underline, or a vertical rail with the panel beside it. */
  orientation?: "horizontal" | "vertical";
  listStyle?: "pill" | "underline" | "boxed" | "rail";
  align?: "left" | "center";
  className?: string;
  idPrefix?: string;
}

/**
 * A WAI-ARIA tabs implementation: roving tabindex, arrow-key/Home/End
 * navigation, and `aria-controls`/`aria-labelledby` wiring between each
 * tab and its panel. Inactive panels are unmounted rather than hidden,
 * which keeps long tabbed content out of the accessibility tree.
 */
export function Tabs({ items, orientation = "horizontal", listStyle = "pill", align = "left", className, idPrefix = "tabs" }: TabsProps) {
  const [active, setActive] = React.useState(0);
  const tabRefs = React.useRef<Array<HTMLButtonElement | null>>([]);

  if (items.length === 0) return null;

  const focusTab = (index: number) => {
    const next = (index + items.length) % items.length;
    setActive(next);
    tabRefs.current[next]?.focus();
  };

  const onKeyDown = (event: React.KeyboardEvent) => {
    const nextKey = orientation === "vertical" ? "ArrowDown" : "ArrowRight";
    const prevKey = orientation === "vertical" ? "ArrowUp" : "ArrowLeft";
    if (event.key === nextKey) {
      event.preventDefault();
      focusTab(active + 1);
    } else if (event.key === prevKey) {
      event.preventDefault();
      focusTab(active - 1);
    } else if (event.key === "Home") {
      event.preventDefault();
      focusTab(0);
    } else if (event.key === "End") {
      event.preventDefault();
      focusTab(items.length - 1);
    }
  };

  const base = slugify(idPrefix, "tabs");

  return (
    <div className={cn("otu-tabs", `otu-tabs--${orientation}`, `otu-tabs--${listStyle}`, `otu-tabs--${align}`, className)}>
      <div className="otu-tabs__list" role="tablist" aria-orientation={orientation} onKeyDown={onKeyDown}>
        {items.map((item, index) => (
          <button
            key={item.id}
            ref={(element) => {
              tabRefs.current[index] = element;
            }}
            type="button"
            role="tab"
            id={`${base}-tab-${index}`}
            aria-controls={`${base}-panel-${index}`}
            aria-selected={index === active}
            tabIndex={index === active ? 0 : -1}
            className={cn("otu-tabs__tab", index === active && "is-active")}
            onClick={() => setActive(index)}
          >
            {item.icon ? <Icon name={item.icon} size={18} /> : null}
            <span className="otu-tabs__tab-label">{item.label}</span>
            {item.meta ? <span className="otu-tabs__tab-meta">{item.meta}</span> : null}
          </button>
        ))}
      </div>

      <div
        className="otu-tabs__panel"
        role="tabpanel"
        id={`${base}-panel-${active}`}
        aria-labelledby={`${base}-tab-${active}`}
        tabIndex={0}
      >
        {items[active]?.content}
      </div>
    </div>
  );
}
