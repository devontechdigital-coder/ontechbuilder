import * as React from "react";
import type { AspectRatio, ThemeImage as ThemeImageValue } from "../types";
import { cn } from "./utils";

interface ThemeImageProps extends React.HTMLAttributes<HTMLDivElement> {
  image?: ThemeImageValue;
  /** Optional narrow-viewport art direction. Falls back to `image` when unset. */
  mobileImage?: ThemeImageValue;
  ratio?: AspectRatio;
  /** Shown before an image is chosen — never an external URL. */
  placeholderLabel?: string;
  fit?: "cover" | "contain";
  /** First-screen media should opt out of lazy loading. */
  priority?: boolean;
  rounded?: boolean;
}

const ratioClass: Record<AspectRatio, string> = {
  auto: "",
  "1:1": "otu-ratio--1-1",
  "4:3": "otu-ratio--4-3",
  "3:4": "otu-ratio--3-4",
  "3:2": "otu-ratio--3-2",
  "2:3": "otu-ratio--2-3",
  "16:9": "otu-ratio--16-9",
  "9:16": "otu-ratio--9-16",
  "21:9": "otu-ratio--21-9",
};

/**
 * The theme's only <img> renderer.
 *
 * Uses a plain <img> rather than next/image so the package stays
 * portable — the host resolves `src` from its own storage. When a
 * mobile image is supplied it renders a <picture> with a single
 * source, which is real art direction rather than a CSS crop.
 */
export function ThemeImage({
  image,
  mobileImage,
  ratio = "auto",
  placeholderLabel = "Image",
  fit = "cover",
  priority = false,
  rounded = true,
  className,
  ...rest
}: ThemeImageProps) {
  const hasImage = Boolean(image?.src);
  return (
    <div
      className={cn("otu-media", ratioClass[ratio], rounded && "otu-media--rounded", `otu-media--${fit}`, className)}
      {...rest}
    >
      {hasImage ? (
        <picture>
          {mobileImage?.src ? <source media="(max-width: 767px)" srcSet={mobileImage.src} /> : null}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={image?.src}
            alt={image?.alt ?? ""}
            width={image?.width}
            height={image?.height}
            loading={priority ? "eager" : "lazy"}
            decoding={priority ? "sync" : "async"}
            style={image?.focalPoint ? { objectPosition: image.focalPoint } : undefined}
          />
        </picture>
      ) : (
        <div className="otu-media__placeholder" role="img" aria-label={placeholderLabel}>
          <span>{placeholderLabel}</span>
        </div>
      )}
    </div>
  );
}
