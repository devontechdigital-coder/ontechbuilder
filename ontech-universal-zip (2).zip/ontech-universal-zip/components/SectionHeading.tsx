import * as React from "react";
import type { ContentAlignment } from "../types";
import { cn } from "./utils";

interface SectionHeadingProps {
  eyebrow?: string;
  heading?: string;
  /** Words inside {curly braces} in `heading` render in the accent color. */
  description?: string;
  align?: ContentAlignment;
  /** h2 by default; a hero or a page-title section passes "h1". */
  as?: "h1" | "h2" | "h3";
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  /** Slot for a CTA or filter row that sits beside the heading on wide screens. */
  aside?: React.ReactNode;
  children?: React.ReactNode;
}

/**
 * Splits a heading on {braces} so a merchant can accent part of a
 * headline from a plain text field — no rich-text editor, no HTML.
 * "Built for {every industry}" renders the braced words in the accent.
 */
export function HighlightedText({ text }: { text: string }) {
  if (!text.includes("{")) return <>{text}</>;
  const parts = text.split(/(\{[^}]*\})/g).filter(Boolean);
  return (
    <>
      {parts.map((part, index) =>
        part.startsWith("{") && part.endsWith("}") ? (
          <em key={index} className="otu-highlight">
            {part.slice(1, -1)}
          </em>
        ) : (
          <React.Fragment key={index}>{part}</React.Fragment>
        ),
      )}
    </>
  );
}

/**
 * The shared heading cluster: eyebrow, title, description. The eyebrow
 * carries the theme's signature precision bracket (see theme.css), which
 * is what visually ties otherwise very different section designs
 * together.
 */
export function SectionHeading({
  eyebrow,
  heading,
  description,
  align = "left",
  as = "h2",
  size = "md",
  className,
  aside,
  children,
}: SectionHeadingProps) {
  const Tag = as as React.ElementType;
  if (!eyebrow && !heading && !description && !aside && !children) return null;

  return (
    <div className={cn("otu-heading", `otu-heading--${align}`, `otu-heading--${size}`, aside && "otu-heading--split", className)}>
      <div className="otu-heading__main">
        {eyebrow ? <p className="otu-eyebrow">{eyebrow}</p> : null}
        {heading ? (
          <Tag className="otu-heading__title">
            <HighlightedText text={heading} />
          </Tag>
        ) : null}
        {description ? <p className="otu-heading__description">{description}</p> : null}
        {children}
      </div>
      {aside ? <div className="otu-heading__aside">{aside}</div> : null}
    </div>
  );
}
