import * as React from "react";
import { Icon, type IconName } from "./Icon";
import { cn, safeHref } from "./utils";

export type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "light" | "dark" | "link";
export type ButtonSize = "sm" | "md" | "lg";

interface ThemeButtonProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "type"> {
  href?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  iconName?: IconName | string;
  iconPosition?: "left" | "right";
  fullWidth?: boolean;
  /** Renders a real <button type="submit"> instead of an anchor — used by the Form sections. */
  type?: "submit" | "button";
}

/**
 * Renders an anchor by default (no router dependency), or a real
 * <button> when `type` is given, so form submits stay native and
 * keyboard-operable. Anchors with an unsafe href degrade to a
 * non-interactive span rather than rendering a live bad link.
 */
export function ThemeButton({
  href,
  variant = "primary",
  size = "md",
  iconName,
  iconPosition = "right",
  fullWidth,
  type,
  className,
  children,
  ...rest
}: ThemeButtonProps) {
  const classes = cn(
    "otu-btn",
    `otu-btn--${variant}`,
    `otu-btn--${size}`,
    fullWidth && "otu-btn--full",
    iconName && `otu-btn--icon-${iconPosition}`,
    className,
  );

  const content = (
    <>
      {iconName && iconPosition === "left" ? <Icon name={iconName} size={size === "lg" ? 20 : 17} className="otu-btn__icon" /> : null}
      <span className="otu-btn__label">{children}</span>
      {iconName && iconPosition === "right" ? <Icon name={iconName} size={size === "lg" ? 20 : 17} className="otu-btn__icon" /> : null}
    </>
  );

  if (type) {
    const buttonProps = rest as unknown as React.ButtonHTMLAttributes<HTMLButtonElement>;
    return (
      <button type={type} className={classes} {...buttonProps}>
        {content}
      </button>
    );
  }

  const safe = safeHref(href);
  if (!safe) {
    return <span className={cn(classes, "otu-btn--static")}>{content}</span>;
  }

  return (
    <a className={classes} href={safe} {...rest}>
      {content}
    </a>
  );
}

/** Renders a button only when both a label and link exist — keeps every variant free of `{label && href && …}` noise. */
export function MaybeButton({
  label,
  href,
  ...rest
}: { label?: string; href?: string } & Omit<ThemeButtonProps, "children" | "href">) {
  if (!label?.trim()) return null;
  return (
    <ThemeButton href={href} {...rest}>
      {label}
    </ThemeButton>
  );
}
