import * as React from "react";
import type { SectionBaseProps, SectionTone } from "../types";
import { cn, px } from "./utils";

interface SectionShellProps extends SectionBaseProps {
  /** Kebab-case section name, e.g. "hero" — produces `otu-hero` and `otu-hero--v2`. */
  name: string;
  children: React.ReactNode;
  className?: string;
  /** Set false for chrome (header/footer/announcement) that shouldn't get section padding. */
  padded?: boolean;
  as?: "section" | "div" | "aside" | "header" | "footer";
  ariaLabel?: string;
}

const tones: readonly SectionTone[] = ["default", "surface", "alt", "dark", "primary"];

/**
 * components/SectionShell.tsx
 *
 * Every section in this theme renders through here. It is the single
 * implementation of the "Layout / Style / Spacing" schema groups that
 * appear on all 35 sections: tone, container width, per-section color
 * overrides, anchor id, custom classes and desktop/mobile padding.
 *
 * Centralising it is what keeps 170 variant components short enough to
 * stay readable — a variant only ever describes its own composition.
 * Mobile padding is passed down as custom properties rather than
 * inline padding so a CSS media query can pick it up (inline styles
 * can't be overridden by a stylesheet).
 */
export function SectionShell({
  name,
  variant = "v1",
  tone = "default",
  paddingTop,
  paddingBottom,
  mobilePaddingTop,
  mobilePaddingBottom,
  anchorId,
  customClass,
  backgroundColor,
  textColor,
  accentColor,
  padded = true,
  as = "section",
  ariaLabel,
  className,
  children,
}: SectionShellProps) {
  const Tag = as as React.ElementType;
  const resolvedTone = tones.includes(tone) ? tone : "default";

  const style: React.CSSProperties = {};
  const top = px(paddingTop);
  const bottom = px(paddingBottom);
  const mobileTop = px(mobilePaddingTop);
  const mobileBottom = px(mobilePaddingBottom);
  if (top) (style as Record<string, string>)["--otu-section-pt"] = top;
  if (bottom) (style as Record<string, string>)["--otu-section-pb"] = bottom;
  if (mobileTop) (style as Record<string, string>)["--otu-section-pt-mobile"] = mobileTop;
  if (mobileBottom) (style as Record<string, string>)["--otu-section-pb-mobile"] = mobileBottom;
  if (backgroundColor) (style as Record<string, string>)["--otu-section-bg"] = backgroundColor;
  if (textColor) (style as Record<string, string>)["--otu-section-fg"] = textColor;
  if (accentColor) (style as Record<string, string>)["--otu-color-accent"] = accentColor;

  return (
    <Tag
      id={anchorId || undefined}
      aria-label={ariaLabel}
      className={cn(
        padded && "otu-section",
        `otu-${name}`,
        `otu-${name}--${variant}`,
        `otu-variant-${variant}`,
        backgroundColor && "otu-section--custom-bg",
        textColor && "otu-section--custom-fg",
        className,
        customClass,
      )}
      data-tone={resolvedTone}
      data-variant={variant}
      style={Object.keys(style).length ? style : undefined}
    >
      {children}
    </Tag>
  );
}
