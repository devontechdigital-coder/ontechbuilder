"use client";

import * as React from "react";
import { Icon } from "./Icon";
import { cn } from "./utils";

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  /** Where the panel sits within the viewport. */
  position?: "center" | "bottom" | "top" | "left" | "right";
  size?: "sm" | "md" | "lg" | "full";
  showOverlay?: boolean;
  closeOnOverlay?: boolean;
  ariaLabel: string;
  className?: string;
  children: React.ReactNode;
}

/**
 * components/Modal.tsx
 *
 * A ~90-line dialog rather than a modal package. It covers what an
 * accessible dialog actually needs: role="dialog" + aria-modal, Escape
 * to close, focus moved into the panel on open and restored to the
 * trigger on close, a focus trap on Tab/Shift+Tab, and background
 * scroll lock. Nothing renders until `open`, so a closed popup costs a
 * single boolean.
 */
export function Modal({
  open,
  onClose,
  position = "center",
  size = "md",
  showOverlay = true,
  closeOnOverlay = true,
  ariaLabel,
  className,
  children,
}: ModalProps) {
  const panelRef = React.useRef<HTMLDivElement | null>(null);
  const restoreRef = React.useRef<HTMLElement | null>(null);

  React.useEffect(() => {
    if (!open) return;
    restoreRef.current = (document.activeElement as HTMLElement) ?? null;

    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";

    const panel = panelRef.current;
    const focusables = () =>
      Array.from(
        panel?.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ) ?? [],
      ).filter((element) => element.offsetParent !== null);

    (focusables()[0] ?? panel)?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== "Tab") return;
      const items = focusables();
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = overflow;
      restoreRef.current?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className={cn("otu-modal", `otu-modal--${position}`, `otu-modal--${size}`, className)}>
      {showOverlay ? (
        <div className="otu-modal__overlay" onClick={closeOnOverlay ? onClose : undefined} aria-hidden="true" />
      ) : null}
      <div className="otu-modal__panel" role="dialog" aria-modal="true" aria-label={ariaLabel} ref={panelRef} tabIndex={-1}>
        <button type="button" className="otu-modal__close" onClick={onClose} aria-label="Close">
          <Icon name="close" size={18} />
        </button>
        {children}
      </div>
    </div>
  );
}

interface PopupTriggerOptions {
  /** Seconds to wait after load before opening. 0 opens immediately. */
  delay?: number;
  /** Open when the pointer leaves the top of the viewport (desktop only). */
  exitIntent?: boolean;
  /** Open after this percentage of the page has been scrolled. */
  scrollPercent?: number;
  /** Remember a dismissal for this many days. 0 means "show every visit". */
  rememberDays?: number;
  /** Key used for the dismissal record. */
  storageKey: string;
}

/**
 * Shared open/dismiss logic for all five Popup designs.
 *
 * Dismissal is remembered in sessionStorage/localStorage guarded by
 * try/catch, because a popup that reappears on every scroll is worse
 * than no popup — and because storage throws outright in some embedded
 * and private-browsing contexts.
 */
export function usePopupTrigger({ delay = 0, exitIntent = false, scrollPercent = 0, rememberDays = 0, storageKey }: PopupTriggerOptions) {
  const [open, setOpen] = React.useState(false);
  const dismissedRef = React.useRef(false);

  const readDismissed = React.useCallback((): boolean => {
    if (rememberDays <= 0) return false;
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (!raw) return false;
      return Number(raw) + rememberDays * 86400000 > Date.now();
    } catch {
      return false;
    }
  }, [rememberDays, storageKey]);

  const close = React.useCallback(() => {
    dismissedRef.current = true;
    setOpen(false);
    if (rememberDays > 0) {
      try {
        window.localStorage.setItem(storageKey, String(Date.now()));
      } catch {
        /* storage unavailable — the popup simply shows again next visit */
      }
    }
  }, [rememberDays, storageKey]);

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (readDismissed()) return;

    const show = () => {
      if (!dismissedRef.current) setOpen(true);
    };

    const timers: number[] = [];
    if (delay >= 0 && !exitIntent && !scrollPercent) {
      timers.push(window.setTimeout(show, Math.max(0, delay) * 1000));
    } else if (delay > 0) {
      timers.push(window.setTimeout(show, delay * 1000));
    }

    let onMouseOut: ((event: MouseEvent) => void) | undefined;
    if (exitIntent && window.matchMedia?.("(pointer: fine)").matches) {
      onMouseOut = (event: MouseEvent) => {
        if (event.clientY <= 0) show();
      };
      document.addEventListener("mouseout", onMouseOut);
    }

    let onScroll: (() => void) | undefined;
    if (scrollPercent > 0) {
      onScroll = () => {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        if (max > 0 && (window.scrollY / max) * 100 >= scrollPercent) show();
      };
      window.addEventListener("scroll", onScroll, { passive: true });
    }

    return () => {
      timers.forEach((timer) => window.clearTimeout(timer));
      if (onMouseOut) document.removeEventListener("mouseout", onMouseOut);
      if (onScroll) window.removeEventListener("scroll", onScroll);
    };
  }, [delay, exitIntent, scrollPercent, readDismissed]);

  return { open, close };
}
