"use client";

import * as React from "react";
import { Icon } from "./Icon";
import { cn } from "./utils";

export interface SliderProps {
  children: React.ReactNode[];
  /** Items visible per view at each breakpoint. Drives a CSS custom property, not JS measurement. */
  desktopItems?: number;
  tabletItems?: number;
  mobileItems?: number;
  gap?: "none" | "sm" | "md" | "lg";
  showArrows?: boolean;
  showDots?: boolean;
  /** Milliseconds between auto-advances. 0 disables autoplay. */
  autoplay?: number;
  loop?: boolean;
  arrowStyle?: "circle" | "square" | "minimal";
  arrowPosition?: "top-right" | "sides" | "bottom";
  ariaLabel?: string;
  className?: string;
  trackClassName?: string;
}

/**
 * components/Slider.tsx
 *
 * A carousel built on CSS scroll-snap instead of a carousel library.
 * The track is a real horizontally scrollable list, so touch and
 * trackpad swiping, keyboard scrolling and screen-reader traversal all
 * work natively; JS only adds prev/next, dots and optional autoplay on
 * top of `scrollTo`.
 *
 * Autoplay pauses on hover, on focus within the track, when the tab is
 * hidden, and is never started at all under prefers-reduced-motion.
 */
export function Slider({
  children,
  desktopItems = 3,
  tabletItems = 2,
  mobileItems = 1,
  gap = "md",
  showArrows = true,
  showDots = true,
  autoplay = 0,
  loop = true,
  arrowStyle = "circle",
  arrowPosition = "top-right",
  ariaLabel = "Carousel",
  className,
  trackClassName,
}: SliderProps) {
  const trackRef = React.useRef<HTMLUListElement | null>(null);
  const [active, setActive] = React.useState(0);
  const [paused, setPaused] = React.useState(false);
  const count = React.Children.count(children);

  const scrollToIndex = React.useCallback((index: number) => {
    const track = trackRef.current;
    if (!track) return;
    const item = track.children[index] as HTMLElement | undefined;
    if (!item) return;
    track.scrollTo({ left: item.offsetLeft - track.offsetLeft, behavior: "smooth" });
  }, []);

  // Derive the active index from real scroll position so dots stay
  // correct after a manual swipe, not just after a button press.
  React.useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    let frame = 0;
    const onScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const items = Array.from(track.children) as HTMLElement[];
        const left = track.scrollLeft + track.offsetLeft;
        let nearest = 0;
        let distance = Infinity;
        items.forEach((item, index) => {
          const delta = Math.abs(item.offsetLeft - left);
          if (delta < distance) {
            distance = delta;
            nearest = index;
          }
        });
        setActive(nearest);
      });
    };
    track.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      track.removeEventListener("scroll", onScroll);
    };
  }, []);

  const go = React.useCallback(
    (direction: 1 | -1) => {
      const next = active + direction;
      if (next < 0) {
        scrollToIndex(loop ? count - 1 : 0);
      } else if (next >= count) {
        scrollToIndex(loop ? 0 : count - 1);
      } else {
        scrollToIndex(next);
      }
    },
    [active, count, loop, scrollToIndex],
  );

  React.useEffect(() => {
    if (!autoplay || count < 2 || paused) return;
    if (typeof window === "undefined") return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => {
      if (document.hidden) return;
      go(1);
    }, Math.max(1500, autoplay));
    return () => window.clearInterval(timer);
  }, [autoplay, count, paused, go]);

  const style = {
    "--otu-slider-desktop": desktopItems,
    "--otu-slider-tablet": tabletItems,
    "--otu-slider-mobile": mobileItems,
  } as React.CSSProperties;

  const arrows =
    showArrows && count > 1 ? (
      <div className={cn("otu-slider__arrows", `otu-slider__arrows--${arrowStyle}`)}>
        <button type="button" className="otu-slider__arrow" onClick={() => go(-1)} aria-label="Previous slide">
          <Icon name="arrow-left" size={18} />
        </button>
        <button type="button" className="otu-slider__arrow" onClick={() => go(1)} aria-label="Next slide">
          <Icon name="arrow-right" size={18} />
        </button>
      </div>
    ) : null;

  return (
    <div
      className={cn("otu-slider", `otu-slider--gap-${gap}`, `otu-slider--arrows-${arrowPosition}`, className)}
      style={style}
      role="group"
      aria-roledescription="carousel"
      aria-label={ariaLabel}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
    >
      {arrowPosition === "top-right" ? arrows : null}

      <ul className={cn("otu-slider__track", trackClassName)} ref={trackRef} tabIndex={0}>
        {React.Children.map(children, (child, index) => (
          <li
            className="otu-slider__item"
            aria-roledescription="slide"
            aria-label={`${index + 1} of ${count}`}
            aria-hidden={index === active ? undefined : "false"}
          >
            {child}
          </li>
        ))}
      </ul>

      {arrowPosition === "sides" ? arrows : null}

      {(showDots && count > 1) || arrowPosition === "bottom" ? (
        <div className="otu-slider__footer">
          {showDots && count > 1 ? (
            <div className="otu-slider__dots" role="tablist" aria-label="Choose slide">
              {Array.from({ length: count }).map((_, index) => (
                <button
                  key={index}
                  type="button"
                  role="tab"
                  aria-selected={index === active}
                  aria-label={`Go to slide ${index + 1}`}
                  className={cn("otu-slider__dot", index === active && "is-active")}
                  onClick={() => scrollToIndex(index)}
                />
              ))}
            </div>
          ) : (
            <span />
          )}
          {arrowPosition === "bottom" ? arrows : null}
        </div>
      ) : null}
    </div>
  );
}
