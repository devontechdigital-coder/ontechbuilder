import * as React from "react";
import { asBoolean, asString, type RawBlock } from "./blockHelpers";
import { cn, lines, slugify } from "./utils";

export type FieldType = "text" | "email" | "tel" | "textarea" | "select" | "checkbox" | "radio" | "date" | "number" | "hidden";

export interface FormFieldConfig {
  id: string;
  type: FieldType;
  label: string;
  name: string;
  placeholder?: string;
  required: boolean;
  width: "full" | "half" | "third";
  options: string[];
  helpText?: string;
  rows?: number;
  value?: string;
}

/**
 * Turns raw `field` blocks into render-ready field configs.
 *
 * `name` falls back to a slug of the label so a merchant who adds a
 * field without touching the advanced "field name" setting still gets a
 * usable, correctly-named form control.
 */
export function parseFields(blocks: RawBlock[]): FormFieldConfig[] {
  return blocks.map((block, index) => {
    const label = asString(block.label, "Field");
    const type = asString(block.fieldType, "text") as FieldType;
    return {
      id: asString(block.id, `field-${index}`),
      type,
      label,
      name: asString(block.name).trim() || slugify(label, `field-${index}`),
      placeholder: asString(block.placeholder) || undefined,
      required: asBoolean(block.required, false),
      width: (asString(block.width, "full") as FormFieldConfig["width"]) || "full",
      options: lines(block.options),
      helpText: asString(block.helpText) || undefined,
      rows: Number(block.rows) || undefined,
      value: asString(block.value) || undefined,
    };
  });
}

/**
 * Renders one field with a real, permanently-visible <label> tied to
 * its control by id. Placeholders are supplementary here, never a
 * substitute for a label — a placeholder-only form loses its labels the
 * moment someone starts typing.
 */
export function FormField({ field, idPrefix = "f" }: { field: FormFieldConfig; idPrefix?: string }) {
  const controlId = `${idPrefix}-${field.id}`;
  const describedBy = field.helpText ? `${controlId}-help` : undefined;

  if (field.type === "hidden") {
    return <input type="hidden" name={field.name} value={field.value ?? ""} />;
  }

  const help = field.helpText ? (
    <span className="otu-field__help" id={describedBy}>
      {field.helpText}
    </span>
  ) : null;

  if (field.type === "checkbox") {
    return (
      <div className={cn("otu-field", "otu-field--checkbox", `otu-field--${field.width}`)}>
        <label className="otu-field__check" htmlFor={controlId}>
          <input
            id={controlId}
            type="checkbox"
            name={field.name}
            required={field.required}
            aria-describedby={describedBy}
            value="yes"
          />
          <span>
            {field.label}
            {field.required ? <span aria-hidden="true"> *</span> : null}
          </span>
        </label>
        {help}
      </div>
    );
  }

  if (field.type === "radio") {
    return (
      <fieldset className={cn("otu-field", "otu-field--radio", `otu-field--${field.width}`)}>
        <legend className="otu-field__label">
          {field.label}
          {field.required ? <span aria-hidden="true"> *</span> : null}
        </legend>
        <div className="otu-field__radios">
          {field.options.map((option, index) => (
            <label key={option} className="otu-field__check" htmlFor={`${controlId}-${index}`}>
              <input id={`${controlId}-${index}`} type="radio" name={field.name} value={option} required={field.required && index === 0} />
              <span>{option}</span>
            </label>
          ))}
        </div>
        {help}
      </fieldset>
    );
  }

  return (
    <div className={cn("otu-field", `otu-field--${field.width}`, `otu-field--${field.type}`)}>
      <label className="otu-field__label" htmlFor={controlId}>
        {field.label}
        {field.required ? <span aria-hidden="true"> *</span> : null}
      </label>

      {field.type === "textarea" ? (
        <textarea
          id={controlId}
          name={field.name}
          rows={field.rows ?? 5}
          placeholder={field.placeholder}
          required={field.required}
          aria-describedby={describedBy}
        />
      ) : field.type === "select" ? (
        <select id={controlId} name={field.name} required={field.required} defaultValue="" aria-describedby={describedBy}>
          <option value="" disabled>
            {field.placeholder || "Choose one"}
          </option>
          {field.options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      ) : (
        <input
          id={controlId}
          type={field.type}
          name={field.name}
          placeholder={field.placeholder}
          required={field.required}
          aria-describedby={describedBy}
          autoComplete={autoCompleteFor(field)}
        />
      )}

      {help}
    </div>
  );
}

/** Maps common field names to autocomplete tokens so browsers can fill forms properly. */
function autoCompleteFor(field: FormFieldConfig): string | undefined {
  const key = `${field.name} ${field.label}`.toLowerCase();
  if (field.type === "email" || key.includes("email")) return "email";
  if (field.type === "tel" || key.includes("phone") || key.includes("mobile")) return "tel";
  if (key.includes("company") || key.includes("organisation") || key.includes("organization")) return "organization";
  if (key.includes("name")) return "name";
  if (key.includes("city")) return "address-level2";
  if (key.includes("zip") || key.includes("postal")) return "postal-code";
  return undefined;
}

export interface ThemeFormProps {
  fields: FormFieldConfig[];
  /** Native form action. The host points this at its own handler — the theme never posts via JS. */
  actionUrl?: string;
  method?: "post" | "get";
  consentText?: string;
  successNote?: string;
  className?: string;
  idPrefix?: string;
  children?: React.ReactNode;
}

/**
 * A plain, native <form>. Submission is an ordinary browser POST to
 * whatever endpoint the host configures — the theme deliberately ships
 * no submission logic, no fetch, and no third-party form service.
 */
export function ThemeForm({
  fields,
  actionUrl,
  method = "post",
  consentText,
  className,
  idPrefix = "form",
  children,
}: ThemeFormProps) {
  return (
    <form className={cn("otu-form", className)} action={actionUrl || undefined} method={method}>
      <div className="otu-form__grid">
        {fields.map((field) => (
          <FormField key={field.id} field={field} idPrefix={idPrefix} />
        ))}
      </div>
      {consentText ? <p className="otu-form__consent">{consentText}</p> : null}
      {children}
    </form>
  );
}
