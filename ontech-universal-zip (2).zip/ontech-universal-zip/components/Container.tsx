import * as React from "react";
import type { ContainerWidth } from "../types";
import { cn } from "./utils";

interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  width?: ContainerWidth;
  as?: keyof React.JSX.IntrinsicElements;
  /** Removes the horizontal gutter — for full-bleed media inside a normal section. */
  flush?: boolean;
}

const widthClass: Record<ContainerWidth, string> = {
  narrow: "otu-container--narrow",
  default: "otu-container--default",
  wide: "otu-container--wide",
  full: "otu-container--full",
};

/** The single horizontal-rhythm primitive. Width tokens come from global settings. */
export function Container({ width = "default", as = "div", flush = false, className, children, ...rest }: ContainerProps) {
  const Tag = as as React.ElementType;
  return (
    <Tag className={cn("otu-container", widthClass[width] ?? widthClass.default, flush && "otu-container--flush", className)} {...rest}>
      {children}
    </Tag>
  );
}
