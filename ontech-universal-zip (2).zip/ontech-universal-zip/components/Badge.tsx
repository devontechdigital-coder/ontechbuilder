import * as React from "react";
import { Icon, type IconName } from "./Icon";
import { cn } from "./utils";

interface BadgeProps {
  children: React.ReactNode;
  tone?: "accent" | "neutral" | "success" | "inverse" | "outline";
  size?: "sm" | "md";
  iconName?: IconName | string;
  className?: string;
}

/** Small pill used for eyebrow badges, tags, categories and "most popular" markers. */
export function Badge({ children, tone = "accent", size = "sm", iconName, className }: BadgeProps) {
  return (
    <span className={cn("otu-badge", `otu-badge--${tone}`, `otu-badge--${size}`, className)}>
      {iconName ? <Icon name={iconName} size={14} /> : null}
      {children}
    </span>
  );
}

interface RatingProps {
  /** 0–5. Rendered as filled stars plus an accessible text label. */
  value?: number;
  count?: string;
  showValue?: boolean;
  className?: string;
}

export function Rating({ value = 5, count, showValue = false, className }: RatingProps) {
  const clamped = Math.max(0, Math.min(5, Number(value) || 0));
  const filled = Math.round(clamped);
  return (
    <span className={cn("otu-rating", className)}>
      <span className="otu-rating__stars" aria-hidden="true">
        {[0, 1, 2, 3, 4].map((index) => (
          <Icon key={index} name="star" size={16} className={index < filled ? "is-filled" : undefined} />
        ))}
      </span>
      <span className="otu-visually-hidden">{`Rated ${clamped} out of 5`}</span>
      {showValue ? <strong className="otu-rating__value">{clamped.toFixed(1)}</strong> : null}
      {count ? <span className="otu-rating__count">{count}</span> : null}
    </span>
  );
}
