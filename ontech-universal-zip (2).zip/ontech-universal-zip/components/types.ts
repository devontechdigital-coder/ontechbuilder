/**
 * components/types.ts
 *
 * Re-export of the theme's portable types so section files can import
 * from a single neighbouring path (`../../components/types`) exactly
 * like the reference theme does, while the canonical definitions live
 * in `types/index.ts`.
 */
export * from "../types";
