import * as React from "react";

import { Header } from "../sections/Header/Header";
import { AnnouncementBarSection } from "../sections/AnnouncementBar/AnnouncementBarSection";
import { Hero } from "../sections/Hero/Hero";
import { TextBlock } from "../sections/TextBlock/TextBlock";
import { Cards } from "../sections/Cards/Cards";
import { Gallery } from "../sections/Gallery/Gallery";
import { SliderSection } from "../sections/Slider/SliderSection";
import { VideoSection } from "../sections/VideoSection/VideoSection";
import { VideoSlider } from "../sections/VideoSlider/VideoSlider";
import { Forms } from "../sections/Forms/Forms";
import { Testimonials } from "../sections/Testimonials/Testimonials";
import { FAQ } from "../sections/FAQ/FAQ";
import { Timeline } from "../sections/Timeline/Timeline";
import { Services } from "../sections/Services/Services";
import { AboutUs } from "../sections/AboutUs/AboutUs";
import { Features } from "../sections/Features/Features";
import { Team } from "../sections/Team/Team";
import { Pricing } from "../sections/Pricing/Pricing";
import { Stats } from "../sections/Stats/Stats";
import { LogoCloud } from "../sections/LogoCloud/LogoCloud";
import { CTA } from "../sections/CTA/CTA";
import { Portfolio } from "../sections/Portfolio/Portfolio";
import { Process } from "../sections/Process/Process";
import { TabsSection } from "../sections/TabsSection/TabsSection";
import { AccordionSection } from "../sections/AccordionSection/AccordionSection";
import { Tables } from "../sections/Tables/Tables";
import { ImageText } from "../sections/ImageText/ImageText";
import { BentoGrid } from "../sections/BentoGrid/BentoGrid";
import { Marquee } from "../sections/Marquee/Marquee";
import { Maps } from "../sections/Maps/Maps";
import { Contact } from "../sections/Contact/Contact";
import { Footer } from "../sections/Footer/Footer";
import { Popup } from "../sections/Popup/Popup";
import { FloatingActionsSection } from "../sections/FloatingActions/FloatingActionsSection";
import { CustomCode } from "../sections/CustomCode/CustomCode";

/**
 * components/sectionRegistry.tsx
 *
 * Maps every section schema's `id` to the component that renders it.
 * `header`, `announcement-bar`, `footer`, `popup` and `floating-actions`
 * ARE included here even though a host commonly composes them as page
 * chrome/overlays rather than reorderable body sections (see
 * layout/defaultChrome.ts) — including them costs nothing for hosts
 * that treat them separately, and makes the theme work correctly for
 * hosts that render every section generically through one registry.
 */
export const sectionRegistry: Record<string, React.ComponentType<any>> = {
  header: Header,
  "announcement-bar": AnnouncementBarSection,
  hero: Hero,
  "text-block": TextBlock,
  cards: Cards,
  gallery: Gallery,
  slider: SliderSection,
  video: VideoSection,
  "video-slider": VideoSlider,
  form: Forms,
  testimonials: Testimonials,
  faq: FAQ,
  timeline: Timeline,
  services: Services,
  "about-us": AboutUs,
  features: Features,
  team: Team,
  pricing: Pricing,
  stats: Stats,
  "logo-cloud": LogoCloud,
  cta: CTA,
  portfolio: Portfolio,
  process: Process,
  tabs: TabsSection,
  accordion: AccordionSection,
  tables: Tables,
  "image-text": ImageText,
  "bento-grid": BentoGrid,
  marquee: Marquee,
  map: Maps,
  "contact-info": Contact,
  footer: Footer,
  popup: Popup,
  "floating-actions": FloatingActionsSection,
  "custom-code": CustomCode,
};

export interface SectionInstance {
  type: keyof typeof sectionRegistry | string;
  props: Record<string, unknown>;
  id: string;
}

interface RenderSectionsProps {
  sections: SectionInstance[];
}

/** Renders an ordered list of section instances supplied by the host platform. Unknown types are skipped safely rather than throwing. */
export function RenderSections({ sections }: RenderSectionsProps) {
  return (
    <>
      {sections.map((section) => {
        const Component = sectionRegistry[section.type];
        if (!Component) return null;
        return <Component key={section.id} {...section.props} />;
      })}
    </>
  );
}
