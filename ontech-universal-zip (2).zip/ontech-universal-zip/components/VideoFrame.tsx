"use client";

import * as React from "react";
import { Icon } from "./Icon";
import { ThemeImage } from "./ThemeImage";
import type { AspectRatio, ThemeImage as ThemeImageValue, ThemeVideo } from "../types";
import { cn } from "./utils";

interface VideoFrameProps {
  video?: ThemeVideo;
  poster?: ThemeImageValue;
  ratio?: AspectRatio;
  autoplay?: boolean;
  muted?: boolean;
  loop?: boolean;
  controls?: boolean;
  /** Show the poster with a play button and only load the video on click. */
  lazyPoster?: boolean;
  playLabel?: string;
  className?: string;
  rounded?: boolean;
}

/**
 * components/VideoFrame.tsx
 *
 * Native <video> for uploaded files, a sandboxed <iframe> for external
 * embeds — no video player package.
 *
 * `lazyPoster` is the default for a reason: an embed loaded on mount
 * pulls in a multi-hundred-kilobyte third-party player on every page
 * view. Here the poster image is the only cost until someone actually
 * presses play, which matters a lot on the 512MB/0.5CPU target.
 *
 * Autoplay is forced muted+playsInline, because browsers block
 * unmuted autoplay anyway and a video that silently fails to start
 * looks like a broken section.
 */
export function VideoFrame({
  video,
  poster,
  ratio = "16:9",
  autoplay = false,
  muted = true,
  loop = false,
  controls = true,
  lazyPoster = true,
  playLabel = "Play video",
  className,
  rounded = true,
}: VideoFrameProps) {
  const [activated, setActivated] = React.useState(false);
  const posterImage = poster ?? video?.poster;
  const hasSource = Boolean(video?.src || video?.embedUrl);

  const showPoster = hasSource && lazyPoster && !activated && !autoplay;

  if (!hasSource) {
    return (
      <ThemeImage
        image={posterImage}
        ratio={ratio}
        rounded={rounded}
        placeholderLabel="Video"
        className={cn("otu-video", className)}
      />
    );
  }

  return (
    <div className={cn("otu-video", `otu-ratio--${ratio.replace(":", "-")}`, rounded && "otu-video--rounded", className)}>
      {showPoster ? (
        <>
          <ThemeImage image={posterImage} ratio="auto" rounded={false} placeholderLabel="Video poster" className="otu-video__poster" />
          <button type="button" className="otu-video__play" onClick={() => setActivated(true)} aria-label={playLabel}>
            <Icon name="play" size={26} />
          </button>
        </>
      ) : video?.embedUrl ? (
        <iframe
          className="otu-video__embed"
          src={buildEmbedSrc(video.embedUrl, activated || autoplay, muted, loop)}
          title={playLabel}
          loading="lazy"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          referrerPolicy="strict-origin-when-cross-origin"
          allowFullScreen
        />
      ) : (
        // eslint-disable-next-line jsx-a11y/media-has-caption
        <video
          className="otu-video__player"
          src={video?.src}
          poster={posterImage?.src}
          autoPlay={autoplay || activated}
          muted={autoplay ? true : muted}
          loop={loop}
          controls={controls}
          playsInline
          preload={autoplay ? "auto" : "metadata"}
        />
      )}
    </div>
  );
}

/**
 * Appends autoplay/mute/loop params to a YouTube or Vimeo URL. Anything
 * else is passed through untouched — the theme doesn't try to be a
 * universal URL parser, it just avoids breaking valid embed links.
 */
function buildEmbedSrc(url: string, autoplay: boolean, muted: boolean, loop: boolean): string {
  try {
    const parsed = new URL(url);
    if (autoplay) parsed.searchParams.set("autoplay", "1");
    if (muted) parsed.searchParams.set("muted", "1");
    if (muted && parsed.hostname.includes("youtube")) parsed.searchParams.set("mute", "1");
    if (loop) parsed.searchParams.set("loop", "1");
    return parsed.toString();
  } catch {
    return url;
  }
}
