import type { LinkValue, ThemeImage, ThemeVideo } from "../types";
import { lines as linesUtil, safeHref } from "./utils";

/** Re-exported so section files can pull all block-parsing helpers from one module. */
export const lines = linesUtil;

/**
 * components/blockHelpers.ts
 *
 * A visual editor stores block settings flat (`buttonLabel` +
 * `buttonHref`, one `blocks` array mixing several block `type`s).
 * Section components want composed shapes. These helpers do that
 * composition INSIDE the theme package, so a host that forwards a
 * section's `settings` and `blocks` verbatim is enough for every
 * section here — no bespoke per-section adapter code anywhere.
 */

/** A block in its raw stored shape: an id, a type, and its settings spread flat. */
export interface RawBlock {
  id: string;
  type: string;
  [field: string]: unknown;
}

export function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

export function asNumber(value: unknown, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function asBoolean(value: unknown, fallback: boolean): boolean {
  if (typeof value === "boolean") return value;
  if (value === "true") return true;
  if (value === "false") return false;
  return fallback;
}

/**
 * Editors commonly persist `select` values as strings even when the
 * schema's options look numeric ("3" for a column count). This coerces
 * back to the union the component expects, clamped to the allowed set.
 */
export function asOneOf<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  const candidate = typeof value === "string" ? value : String(value ?? "");
  return (allowed as readonly string[]).includes(candidate) ? (candidate as T) : fallback;
}

export function asImage(value: unknown): ThemeImage | undefined {
  if (value && typeof value === "object") {
    const image = value as ThemeImage;
    if (typeof image.src === "string" && image.src.trim()) return image;
  }
  if (typeof value === "string" && value.trim()) return { src: value };
  return undefined;
}

export function asVideo(value: unknown): ThemeVideo | undefined {
  if (value && typeof value === "object") {
    const video = value as ThemeVideo;
    if ((video.src && video.src.trim()) || (video.embedUrl && video.embedUrl.trim())) return video;
  }
  if (typeof value === "string" && value.trim()) return { src: value };
  return undefined;
}

/** Builds a LinkValue only when both label and href are present — nothing renders a half-formed button. */
export function optionalLink(label: unknown, href: unknown, external?: unknown): LinkValue | undefined {
  const l = asString(label).trim();
  const h = safeHref(href);
  if (!l || !h) return undefined;
  return { label: l, href: h, external: asBoolean(external, false) };
}

/** A link that is valid with just an href, because its label comes from elsewhere (e.g. a card title). */
export function hrefOnly(href: unknown): string | undefined {
  return safeHref(href);
}

/** Filters a mixed blocks array down to a single type. */
export function blocksOfType(blocks: RawBlock[] | undefined, type: string): RawBlock[] {
  if (!Array.isArray(blocks)) return [];
  return blocks.filter((block) => block && block.type === type);
}

/** Normalises whatever the host passed as `blocks` into a safe array. */
export function asBlocks(blocks: unknown): RawBlock[] {
  return Array.isArray(blocks) ? (blocks.filter(Boolean) as RawBlock[]) : [];
}

export interface NestedLink extends LinkValue {
  children?: LinkValue[];
}

/**
 * Parses the "Label|/url" link-list textarea format used by header and
 * footer link columns. A line indented by 2+ spaces becomes a child of
 * the line above it, which gives real nested menus from plain text with
 * no extra field type. Malformed lines are skipped, never thrown on.
 */
export function parseNestedLinks(text: unknown): NestedLink[] {
  if (typeof text !== "string" || !text.trim()) return [];
  const links: NestedLink[] = [];
  let lastTopLevel: NestedLink | null = null;

  for (const rawLine of text.split("\n")) {
    if (!rawLine.trim()) continue;
    const indented = /^\s{2,}/.test(rawLine);
    const [labelRaw, hrefRaw] = rawLine.trim().split("|");
    const label = labelRaw?.trim();
    const href = safeHref(hrefRaw);
    if (!label || !href) continue;

    if (indented && lastTopLevel) {
      lastTopLevel.children = [...(lastTopLevel.children ?? []), { label, href }];
    } else {
      const link: NestedLink = { label, href };
      links.push(link);
      lastTopLevel = link;
    }
  }
  return links;
}

export interface ParsedColumn {
  heading: string;
  links: LinkValue[];
}

/**
 * Parses the mega-menu / footer "Columns" textarea format:
 *   ## Column heading
 *   Label|/url
 *
 *   ## Next column
 *   Label|/url
 *
 * Content before the first `##` collects into one unheaded column,
 * which is what a "simple" dropdown looks like.
 */
export function parseColumns(text: unknown): ParsedColumn[] {
  if (typeof text !== "string" || !text.trim()) return [];
  const columns: ParsedColumn[] = [];
  let current: ParsedColumn | null = null;

  for (const rawLine of text.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith("##")) {
      current = { heading: line.replace(/^##\s*/, ""), links: [] };
      columns.push(current);
      continue;
    }
    if (!line.includes("|")) continue;
    const [label, hrefRaw] = line.split("|").map((part) => part.trim());
    const href = safeHref(hrefRaw);
    if (!label || !href) continue;
    if (!current) {
      current = { heading: "", links: [] };
      columns.push(current);
    }
    current.links.push({ label, href });
  }
  return columns;
}
