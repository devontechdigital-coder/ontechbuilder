import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface ContactTemplateProps {
  sections?: SectionInstance[];
}

const defaultContactSections: SectionInstance[] = [
  { id: "contact-form", type: "form", props: { variant: "v5" } },
  { id: "contact-map", type: "map", props: { variant: "v1" } },
  { id: "contact-faq", type: "faq", props: { variant: "v3" } },
];

export default function ContactTemplate({ sections = defaultContactSections }: ContactTemplateProps) {
  return <RenderSections sections={sections} />;
}
