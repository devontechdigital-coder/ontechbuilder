import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface AboutTemplateProps {
  sections?: SectionInstance[];
}

let counter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  counter += 1;
  return { id: `${type}-${counter}`, type, ...settings };
}

const defaultAboutSections: SectionInstance[] = [
  { id: "about-intro", type: "text-block", props: { variant: "v4", heading: "We built the firm we wished we could hire." } },
  { id: "about-story", type: "about-us", props: { variant: "v3", eyebrow: "Our story", heading: "A decade of measured growth", blocks: [
    block("stat", { value: "260+", label: "Companies transformed" }),
    block("stat", { value: "95%", label: "Client satisfaction" }),
    block("stat", { value: "12", label: "Years in business" }),
  ] } },
  { id: "about-values", type: "features", props: { variant: "v1", eyebrow: "How we work", heading: "The principles behind every engagement" } },
  { id: "about-timeline", type: "timeline", props: { variant: "v2", eyebrow: "Milestones", heading: "Where we've been" } },
  { id: "about-team", type: "team", props: { variant: "v1", eyebrow: "Our team", heading: "Meet the people behind the work" } },
  { id: "about-cta", type: "cta", props: { variant: "v3", heading: "Want to work together?", primaryLabel: "Get in touch", primaryHref: "/contact" } },
];

export default function AboutTemplate({ sections = defaultAboutSections }: AboutTemplateProps) {
  return <RenderSections sections={sections} />;
}
