import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface ServiceTemplateProps {
  sections?: SectionInstance[];
}

/** templates/service.tsx — single service detail page. */
const defaultServiceSections: SectionInstance[] = [
  { id: "service-hero", type: "hero", props: { variant: "v3", eyebrow: "Service", heading: "Business Strategy" } },
  { id: "service-detail", type: "image-text", props: { variant: "v1", heading: "What's included" } },
  { id: "service-accordion", type: "accordion", props: { variant: "v1", eyebrow: "Details", heading: "What's included" } },
  { id: "service-testimonial", type: "testimonials", props: { variant: "v3" } },
  { id: "service-cta", type: "cta", props: { variant: "v2", heading: "Ready to get started?", primaryLabel: "Book a consultation", primaryHref: "/contact" } },
];

export default function ServiceTemplate({ sections = defaultServiceSections }: ServiceTemplateProps) {
  return <RenderSections sections={sections} />;
}
