import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface BlogTemplateProps {
  sections?: SectionInstance[];
}

/** templates/blog.tsx — blog index. Uses the Cards section (horizontal media variant) as a lightweight post grid — no separate blog-post section type was needed. */
const defaultBlogSections: SectionInstance[] = [
  { id: "blog-intro", type: "text-block", props: { variant: "v1", eyebrow: "Blog", heading: "Insights & ideas" } },
  { id: "blog-grid", type: "cards", props: { variant: "v2", columns: 2 } },
  { id: "blog-newsletter", type: "cta", props: { variant: "v3", heading: "Get new posts in your inbox" } },
];

export default function BlogTemplate({ sections = defaultBlogSections }: BlogTemplateProps) {
  return <RenderSections sections={sections} />;
}
