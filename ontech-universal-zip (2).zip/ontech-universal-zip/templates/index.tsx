import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface IndexTemplateProps {
  sections?: SectionInstance[];
}

let blockCounter = 0;
function block(type: string, settings: Record<string, unknown> = {}) {
  blockCounter += 1;
  return { id: `${type}-${blockCounter}`, type, ...settings };
}

/**
 * templates/index.tsx
 *
 * Sample homepage content so the theme looks polished immediately after
 * installation — every value is editable through each section's own
 * schema.ts. Deliberately shows a balanced selection (per the theme
 * brief) rather than all 170 section designs at once; the rest of the
 * library remains available to add from the section list.
 */
export const defaultIndexSections: SectionInstance[] = [
  {
    id: "hero-1",
    type: "hero",
    props: {
      variant: "v1",
      eyebrow: "Business Consulting",
      badgeLabel: "Rated 4.9/5 by 400+ clients",
      heading: "Driving business growth through {expert strategy}",
      description:
        "Unlock your company's full potential with tailored guidance, proven frameworks, and measurable results from senior consultants.",
      primaryCtaLabel: "Book a consultation",
      primaryCtaHref: "/contact",
      secondaryCtaLabel: "See our work",
      secondaryCtaHref: "/portfolio",
      trustLabel: "Trusted by teams at",
      noteTitle: "Sofia Grant, Director of Strategy",
      noteText: "The team helped us shape a strategy that actually stuck.",
      blocks: [
        block("bullet", { icon: "check-circle", label: "No long-term lock-in" }),
        block("bullet", { icon: "check-circle", label: "Dedicated senior consultant" }),
        block("bullet", { icon: "check-circle", label: "Results within 90 days" }),
      ],
    },
  },
  {
    id: "logo-cloud-1",
    type: "logo-cloud",
    props: {
      variant: "v2",
      heading: "Companies who rely on our expertise",
      blocks: [
        block("logo", { name: "Meridian" }),
        block("logo", { name: "Larkspur" }),
        block("logo", { name: "Northloop" }),
        block("logo", { name: "Calderon Group" }),
        block("logo", { name: "Fieldstone" }),
        block("logo", { name: "Amber & Co" }),
      ],
    },
  },
  {
    id: "services-1",
    type: "services",
    props: {
      variant: "v1",
      eyebrow: "What we offer",
      heading: "Our core consulting services",
      description: "Tailored solutions to help businesses overcome challenges and achieve sustainable growth.",
      columns: 4,
      blocks: [
        block("service", { icon: "target", title: "Business strategy", text: "Long-range planning connected to real execution." }),
        block("service", { icon: "settings", title: "Process optimization", text: "Cutting the friction between decision and delivery." }),
        block("service", { icon: "trending-up", title: "Financial advisory", text: "Clear-eyed modelling for growth and resilience." }),
        block("service", { icon: "users", title: "Change management", text: "Bringing the whole organisation along with the plan." }),
      ],
    },
  },
  {
    id: "about-1",
    type: "about-us",
    props: {
      variant: "v1",
      eyebrow: "About Ontech",
      heading: "Driven by insight, focused on results",
      description:
        "We provide tailored consulting solutions to help businesses overcome challenges, seize opportunities, and achieve sustainable growth.",
      ctaLabel: "Meet the team",
      ctaHref: "/about",
      imageRatio: "4:3",
    },
  },
  {
    id: "features-1",
    type: "features",
    props: {
      variant: "v1",
      eyebrow: "Why choose us",
      heading: "What makes us different",
      columns: 4,
      blocks: [
        block("feature", { icon: "users", title: "Senior consultants only", text: "No handoffs to junior staff." }),
        block("feature", { icon: "zap", title: "Fast to start", text: "Engagements begin within two weeks." }),
        block("feature", { icon: "shield", title: "No lock-in", text: "Month-to-month, cancel any time." }),
        block("feature", { icon: "trending-up", title: "Tied to outcomes", text: "Every project has a measurable target." }),
      ],
    },
  },
  {
    id: "stats-1",
    type: "stats",
    props: {
      variant: "v2",
      blocks: [
        block("stat", { value: "260", suffix: "+", label: "Companies transformed" }),
        block("stat", { value: "95", suffix: "%", label: "Client satisfaction rate" }),
        block("stat", { value: "150", suffix: "M", label: "In measured revenue growth" }),
        block("stat", { value: "12", suffix: "", label: "Years in business" }),
      ],
    },
  },
  {
    id: "portfolio-1",
    type: "portfolio",
    props: {
      variant: "v1",
      eyebrow: "Our work",
      heading: "Selected projects",
      columns: 3,
      blocks: [
        block("project", { category: "Healthcare", title: "Digital transformation for a healthcare provider", href: "/portfolio" }),
        block("project", { category: "Retail", title: "International expansion strategy", href: "/portfolio" }),
        block("project", { category: "SaaS", title: "Product redesign for an analytics platform", href: "/portfolio" }),
      ],
    },
  },
  {
    id: "process-1",
    type: "process",
    props: {
      variant: "v2",
      eyebrow: "How we work",
      heading: "Smart steps to business growth",
      description: "A strategic four-step approach designed to drive measurable results.",
      blocks: [
        block("step", { title: "Discovery", description: "We begin by listening closely to your challenges and goals." }),
        block("step", { title: "Strategy", description: "We translate insight into a clear, actionable roadmap." }),
        block("step", { title: "Execution", description: "Our consultants implement the plan with precision and pace." }),
        block("step", { title: "Optimization", description: "We measure outcomes continuously and refine the approach." }),
      ],
    },
  },
  {
    id: "testimonials-1",
    type: "testimonials",
    props: {
      variant: "v1",
      eyebrow: "Testimonials",
      heading: "Proven impact, shared experiences",
      ratingValue: 4.9,
      ratingCount: "from 420 reviews",
      blocks: [
        block("testimonial", { name: "Amanda Lewis", role: "Director of Strategy, Meridian Health", quote: "Our company was growing fast, but our culture couldn't keep pace. The team helped us rebuild it deliberately.", rating: 5 }),
        block("testimonial", { name: "Owen Ricci", role: "COO, Larkspur Manufacturing", quote: "They didn't just hand us a deck — they stayed until the new process was actually running.", rating: 5 }),
        block("testimonial", { name: "Priya Nair", role: "Founder, Northloop Retail", quote: "The clearest, most honest advisory relationship we've had.", rating: 5 }),
      ],
    },
  },
  {
    id: "cta-1",
    type: "cta",
    props: {
      variant: "v1",
      eyebrow: "Ready when you are",
      heading: "Let's build something that moves your business forward",
      primaryLabel: "Get started now",
      primaryHref: "/contact",
    },
  },
  {
    id: "faq-1",
    type: "faq",
    props: {
      variant: "v1",
      eyebrow: "FAQ",
      heading: "Frequently asked questions",
      blocks: [
        block("faq", { question: "How long does a typical engagement take?", answer: "Most engagements run 8–12 weeks from discovery to handover." }),
        block("faq", { question: "Do you work with early-stage companies?", answer: "Yes — we tailor scope and pricing for teams under 50 people." }),
        block("faq", { question: "What does pricing look like?", answer: "We quote fixed-fee by project scope rather than open-ended hourly billing." }),
      ],
    },
  },
  {
    id: "contact-info-1",
    type: "contact-info",
    props: {
      variant: "v1",
      eyebrow: "Get in touch",
      heading: "We'd love to hear from you",
      phone: "+1 (555) 010-2030",
      email: "hello@example.com",
      address: "400 Michigan Ave, Chicago, IL 60611",
    },
  },
];

export default function IndexTemplate({ sections = defaultIndexSections }: IndexTemplateProps) {
  return <RenderSections sections={sections} />;
}
