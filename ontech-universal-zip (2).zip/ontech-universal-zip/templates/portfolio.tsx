import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface PortfolioTemplateProps {
  sections?: SectionInstance[];
}

const defaultPortfolioSections: SectionInstance[] = [
  { id: "portfolio-intro", type: "text-block", props: { variant: "v1", eyebrow: "Our work", heading: "Selected projects across industries" } },
  { id: "portfolio-grid", type: "portfolio", props: { variant: "v2", heading: "All projects" } },
  { id: "portfolio-logos", type: "logo-cloud", props: { variant: "v1", heading: "Trusted by teams across industries" } },
  { id: "portfolio-cta", type: "cta", props: { variant: "v1", heading: "Have a project in mind?", primaryLabel: "Start a conversation", primaryHref: "/contact" } },
];

export default function PortfolioTemplate({ sections = defaultPortfolioSections }: PortfolioTemplateProps) {
  return <RenderSections sections={sections} />;
}
