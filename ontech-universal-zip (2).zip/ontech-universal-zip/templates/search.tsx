import * as React from "react";
import { Container } from "../components/Container";
import { Icon } from "../components/Icon";
import { safeHref } from "../components/utils";

export interface SearchResultItem {
  title: string;
  url: string;
  excerpt?: string;
  type?: string;
}

export interface SearchTemplateProps {
  query?: string;
  results?: SearchResultItem[];
}

/**
 * templates/search.tsx
 *
 * Renders host-supplied search results. The theme performs no search
 * logic of its own — `results` is whatever the host's search backend
 * returns.
 */
export default function SearchTemplate({ query = "", results = [] }: SearchTemplateProps) {
  return (
    <section className="otu-section otu-search">
      <Container width="default">
        <div className="otu-search__head">
          <Icon name="search" size={22} />
          <h1>
            {results.length > 0 ? `${results.length} results` : "No results"}
            {query ? <> for &ldquo;{query}&rdquo;</> : null}
          </h1>
        </div>

        {results.length > 0 ? (
          <ul className="otu-search__results">
            {results.map((result) => {
              const href = safeHref(result.url) ?? "#";
              return (
                <li key={href + result.title}>
                  <a href={href}>
                    {result.type ? <span className="otu-search__type">{result.type}</span> : null}
                    <h2>{result.title}</h2>
                    {result.excerpt ? <p>{result.excerpt}</p> : null}
                  </a>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="otu-search__empty">No results matched your search. Try a different term.</p>
        )}
      </Container>
    </section>
  );
}
