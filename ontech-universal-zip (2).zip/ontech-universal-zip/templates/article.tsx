import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface ArticleTemplateProps {
  sections?: SectionInstance[];
}

/** templates/article.tsx — single blog post / article page. */
const defaultArticleSections: SectionInstance[] = [
  { id: "article-header", type: "text-block", props: { variant: "v1", eyebrow: "Article", heading: "5 growth strategies every modern business should know" } },
  { id: "article-body", type: "text-block", props: { variant: "v5" } },
  { id: "article-related", type: "cards", props: { variant: "v2", eyebrow: "Related reading", columns: 2 } },
];

export default function ArticleTemplate({ sections = defaultArticleSections }: ArticleTemplateProps) {
  return <RenderSections sections={sections} />;
}
