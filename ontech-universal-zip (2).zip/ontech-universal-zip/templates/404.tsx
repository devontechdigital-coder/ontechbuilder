import * as React from "react";
import { Container } from "../components/Container";
import { ThemeButton } from "../components/ThemeButton";
import { Icon } from "../components/Icon";

export interface NotFoundTemplateProps {
  heading?: string;
  description?: string;
  homeHref?: string;
}

/** templates/404.tsx — a plain, on-brand not-found page. */
export default function NotFoundTemplate({
  heading = "Page not found",
  description = "The page you're looking for may have been moved or no longer exists.",
  homeHref = "/",
}: NotFoundTemplateProps) {
  return (
    <section className="otu-section otu-not-found">
      <Container width="narrow">
        <Icon name="map-pin" size={32} />
        <p className="otu-not-found__code">404</p>
        <h1>{heading}</h1>
        <p>{description}</p>
        <ThemeButton href={homeHref} variant="primary" iconName="arrow-right">
          Back to homepage
        </ThemeButton>
      </Container>
    </section>
  );
}
