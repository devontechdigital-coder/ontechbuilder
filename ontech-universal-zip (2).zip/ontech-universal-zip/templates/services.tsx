import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface ServicesTemplateProps {
  sections?: SectionInstance[];
}

const defaultServicesSections: SectionInstance[] = [
  { id: "services-intro", type: "text-block", props: { variant: "v1", eyebrow: "Services", heading: "Every capability, one accountable team" } },
  { id: "services-grid", type: "services", props: { variant: "v3", eyebrow: "What we offer", heading: "Explore our services" } },
  { id: "services-process", type: "process", props: { variant: "v1", eyebrow: "How it works", heading: "From first call to measurable results" } },
  { id: "services-pricing", type: "pricing", props: { variant: "v1", eyebrow: "Pricing", heading: "Simple, transparent pricing" } },
  { id: "services-faq", type: "faq", props: { variant: "v1", eyebrow: "FAQ", heading: "Common questions about our services" } },
  { id: "services-cta", type: "cta", props: { variant: "v1", heading: "Ready to talk about your project?", primaryLabel: "Book a consultation", primaryHref: "/contact" } },
];

export default function ServicesTemplate({ sections = defaultServicesSections }: ServicesTemplateProps) {
  return <RenderSections sections={sections} />;
}
