import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface ProjectTemplateProps {
  sections?: SectionInstance[];
}

/** templates/project.tsx — single case-study / project detail page. */
const defaultProjectSections: SectionInstance[] = [
  { id: "project-hero", type: "hero", props: { variant: "v2", eyebrow: "Case study", heading: "Digital transformation for a healthcare provider" } },
  { id: "project-overview", type: "image-text", props: { variant: "v1", eyebrow: "Overview", heading: "The challenge" } },
  { id: "project-stats", type: "stats", props: { variant: "v1" } },
  { id: "project-gallery", type: "gallery", props: { variant: "v1", eyebrow: "Gallery", heading: "The work" } },
  { id: "project-testimonial", type: "testimonials", props: { variant: "v3" } },
  { id: "project-cta", type: "cta", props: { variant: "v1", heading: "Want results like these?", primaryLabel: "Get in touch", primaryHref: "/contact" } },
];

export default function ProjectTemplate({ sections = defaultProjectSections }: ProjectTemplateProps) {
  return <RenderSections sections={sections} />;
}
