import * as React from "react";
import { RenderSections, type SectionInstance } from "../components/sectionRegistry";

export interface PageTemplateProps {
  sections?: SectionInstance[];
}

/**
 * templates/page.tsx
 *
 * Generic content-page template: an arbitrary, host-supplied list of
 * body sections with no hardcoded structure. Used for any page that
 * doesn't need one of the specialised templates.
 */
const defaultPageSections: SectionInstance[] = [
  {
    id: "page-intro",
    type: "text-block",
    props: {
      variant: "v1",
      eyebrow: "Page",
      heading: "Page title",
      body: "Replace this page with your own sections from the theme's library.",
    },
  },
];

export default function PageTemplate({ sections = defaultPageSections }: PageTemplateProps) {
  return <RenderSections sections={sections} />;
}
