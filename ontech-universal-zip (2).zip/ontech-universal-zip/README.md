# Ontech Universal

A universal, multi-purpose theme for corporate, agency, SaaS, healthcare,
education, construction, real estate, professional-services, and
lead-generation websites — built as a reusable component library for a
visual website builder, not a single website.

- **Theme ID:** `ontech-universal`
- **Version:** 1.0.0
- **Required theme engine:** `^1.0.0`

This package is a **portable frontend theme only** — no backend, database,
authentication, storage, or infrastructure code. The host platform handles
installation, versioning, publishing, preview, and content storage.

---

## What's in the library

**34 section categories, 5 genuinely different designs each — 170 section
variants in total**, plus a Custom Code section. Every category was built
so the five designs differ through real layout, composition, and
interaction changes, not just recoloring:

Header · Hero Banner · Text/Content · Cards · Image Gallery ·
Slider/Carousel · Video · Video Slider · Forms · Testimonials · FAQ ·
Timeline · Services · About Us · Features/Why Choose Us · Team · Pricing ·
Statistics/Counters · Logo/Client/Partner · CTA · Portfolio/Projects ·
Process/How It Works · Tabs · Accordion · Tables · Image + Text ·
Bento Grid · Marquee/Moving Content · Maps/Location · Contact ·
Footer · Popups/Modal · Floating Elements · Announcement Bars · Custom Code

## Structure

```
ontech-universal/
├── theme.config.ts             Manifest read by the host platform
├── config/
│   ├── settings.schema.ts      Global settings shown in the visual editor
│   ├── settings.default.ts     Default values + the ThemeSettings type
│   └── fonts.ts                21-family curated font system
├── layout/
│   ├── ThemeLayout.tsx         Injects design tokens, mounts chrome + overlays
│   └── defaultChrome.ts        Ready-to-use default header/footer/announcement/floating instances
├── templates/                  index, page, about, services, service, portfolio,
│                                project, blog, article, contact, search, 404
├── sections/                   One folder per category, each with N variant
│                                components in variants/ + one schema.ts
├── components/                 Shared, presentation-only building blocks
│                                (Container, SectionShell, Icon, ThemeImage,
│                                ThemeButton, Slider, Accordion, Tabs, Modal,
│                                FormFields, VideoFrame, ScrollReveal, …)
├── types/                      Portable, frontend-only data contracts
├── assets/styles/theme.css     The full token-driven stylesheet
├── locales/en.json             Interface label localization
└── README.md
```

## The variant system

Every section schema exposes a `variant` setting with values `v1`–`v5`.
Each section's top-level component (e.g. `sections/Hero/Hero.tsx`) is a
thin dispatcher that maps `variant` to the matching component in that
section's `variants/` folder. A host that only forwards a section's
`settings` and `blocks` verbatim gets every design in the library working
correctly — no per-section adapter code is needed.

## Global settings

`config/settings.schema.ts` groups global controls into Color palette,
Typography, Layout, Corners & surfaces, Buttons, Header, Footer, Motion &
effects, and Floating actions. `layout/ThemeLayout.tsx` is the single
place these become CSS custom properties (`--otu-color-primary`,
`--otu-radius-lg`, `--otu-section-spacing`, etc.) — every section reads
through these tokens rather than hardcoding values, so editing global
settings restyles the whole site, including all 170 section designs, at
once.

### Typography — 21 curated font families

`config/fonts.ts` offers 21 families across four groups (neutral sans,
display/geometric, serif, and a zero-download system stack) for both the
heading and body roles independently. Only the two families actually
selected are ever downloaded: `ThemeLayout` builds one Google Fonts
`<link>` covering just those two, with only the weights each design
actually uses. Choosing "System UI" for both roles downloads no webfont
at all — useful for the lightest possible page weight.

### Colors

Default palette: primary `#14509B` (deep azure), secondary `#0FB5A0`
(mint), accent `#F5A524`, with cool-toned surfaces (`#F2F5F9` /
`#EAF0F7`) and a dark tone of `#081226`. Every color is a global setting;
individual sections also accept a background/text/accent override.

### Section tone

Every section accepts a `tone` (`default` / `surface` / `alt` / `dark` /
`primary`), plus per-section padding, container width, and a custom CSS
class — handled centrally by `components/SectionShell.tsx` so no variant
re-implements this.

## Responsive behavior

Built mobile-first and checked at desktop/tablet/mobile for navigation,
hero stacking, grids, cards, forms, tables, galleries, sliders, bento
layouts, footer columns, floating buttons, and popups. Tables scroll
horizontally by default; the "Stacked on mobile" Tables design restacks
into label/value pairs instead. Bento grids collapse to two, then one,
column. The mobile header uses a dedicated full-height drawer, not a
hidden copy of the desktop nav.

## Accessibility

Semantic HTML throughout; a skip-to-content link; visible focus rings on
every interactive element; FAQ/Accordion sections built on native
`<details>`; Tabs built as a full WAI-ARIA implementation with roving
tabindex and arrow-key navigation; the Header's mega-menu and mobile
drawer are keyboard-operable; the Modal primitive traps focus, closes on
Escape, and restores focus to its trigger; all animation respects
`prefers-reduced-motion`, including the scroll-reveal controller,
marquees, and animated stat counters.

## Blocks and repeatable content

Every section that has repeating content (cards, testimonials, team
members, FAQ items, pricing plans, timeline steps, logos, …) exposes a
`blocks` array in its schema with `type`, `name`, and `settings`, plus
`defaultBlocks` for sensible out-of-the-box content. The host's builder
is expected to handle add/remove/duplicate/reorder/edit against this
array; the theme only renders whatever it's given.

`components/blockHelpers.ts` centralizes the flat-storage → composed-prop
adaptation (`asImage`, `optionalLink`, `parseColumns`, `parseNestedLinks`,
etc.) so a host that forwards `settings`/`blocks` verbatim needs no
per-section glue code.

## Images and video

`components/ThemeImage.tsx` is the only image renderer in the theme — it
never hardcodes an external URL, always supports alt text, and falls
back to a labeled placeholder before an image is chosen. `components/
VideoFrame.tsx` renders uploaded files with a native `<video>` and
external URLs with a sandboxed `<iframe>`; by default it shows only the
poster image until the visitor presses play, so an unwatched video never
costs more than a single image request. No image or video SDK is
bundled.

## Forms

Every Forms design and every popup that includes a form renders a real,
native `<form>` (`components/FormFields.tsx` + `components/ThemeForm`).
Submission is a plain browser POST to whatever `actionUrl` the host
configures — **the theme contains no fetch/AJAX submission logic of its
own**. Field configuration (type, label, required, width, options) comes
entirely from the section's `field` blocks.

## Maps

The Maps/Location category never bundles a Maps SDK or API key.
`embedUrl` accepts a plain `https://` iframe URL a merchant already has
(for example, from Google Maps' own "Share → Embed" feature) and renders
it as-is in a sandboxed iframe; without one, a labeled placeholder shows
instead. There is no code in this theme that requests, stores, or
transmits a Maps API key.

## Floating Elements

WhatsApp, call, back-to-top, and a custom CTA are all supported, and
**no phone number or WhatsApp number is ever hardcoded** — every number
comes from the section's own settings (`whatsappNumber`, `phone`,
`customHref`). Leaving a field blank hides that action.

## Popups

Built on a single dependency-free `Modal` primitive
(`components/Modal.tsx`) with a real focus trap, Escape-to-close, and
scroll lock, plus a `usePopupTrigger` hook that supports a delay, exit
intent, scroll-depth trigger, and remembering a dismissal in
`localStorage` for a configurable number of days (guarded by try/catch,
since storage can throw in private-browsing or embedded contexts). No
modal package is bundled.

## Custom Code — what it supports and what it deliberately doesn't

The Custom Code section (`sections/CustomCode/CustomCode.tsx`) is a
controlled escape hatch, scoped to what is actually safe for a theme
package to ship:

**Supported:** static, host-sanitized HTML markup, and styling via the
`customClass` field available on *every* section in the theme (not just
this one) — target that class from your own stylesheet.

**Not supported, on purpose:** arbitrary JavaScript execution. The theme
contains no `eval()`, no `new Function()`, no dynamic `<script>`
injection, and no other mechanism for a merchant-supplied string to run
as code in a visitor's browser. This isn't an oversight — a theme
package that lets any editable text field execute as JavaScript is a
stored-XSS vector for every site built on it. If a host platform wants to
offer safe custom-JS support, that requires its own server-side
sanitization and a CSP-scoped execution mechanism, which is host
infrastructure, not something a portable frontend package can respectably
provide.

## Performance

No animation library, no large icon package (the theme ships ~55
hand-drawn glyphs, not a few thousand), no additional UI framework or
state-management package. Carousels are CSS scroll-snap, not a slider
library. Accordions and FAQs are native `<details>` — zero JS on the
server-rendered page. Marquees are pure CSS `@keyframes`. The one
IntersectionObserver-driven controller (`ScrollReveal`) handles
scroll-reveal for every section from a single mount point rather than
each section running its own observer. Built with the stated 512MB /
0.5 CPU platform constraint in mind throughout.

## What this package does NOT contain

No Next.js application, NestJS module, Prisma model, database migration,
Redis, BullMQ, Meilisearch, authentication, API route, Docker or
deployment file, CMS, visual builder, or Cloud Storage integration. This
is only the portable frontend theme; the host platform supplies
everything else.
