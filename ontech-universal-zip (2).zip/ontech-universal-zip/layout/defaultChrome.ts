import type { SectionInstance } from "../components/sectionRegistry";

/**
 * layout/defaultChrome.ts
 *
 * Header, footer, and overlay sections are usually composed once per
 * page by the host and passed into ThemeLayout's `header`/`footer`/
 * `overlays` slots (see README) rather than living in a page's
 * reorderable body-section list. This file provides ready-to-use
 * default instances for a host to seed a new site with, matching each
 * schema's own `defaultBlocks`.
 */

export const defaultAnnouncementSection: SectionInstance = {
  id: "announcement-1",
  type: "announcement-bar",
  props: {
    variant: "v1",
    message: "Free strategy consultations available this month — limited slots.",
    dismissible: true,
  },
};

export const defaultHeaderSection: SectionInstance = {
  id: "header-1",
  type: "header",
  props: {
    variant: "v4",
    logoText: "Ontech",
    phone: "+1 (555) 010-2030",
    email: "hello@example.com",
    ctaLabel: "Book a consultation",
    ctaHref: "/contact",
    sticky: true,
    topBarMessage: "Trusted by 400+ teams worldwide",
    navBlocks: [
      { id: "nav-home", type: "nav_link", label: "Home", href: "/" },
      {
        id: "nav-services",
        type: "nav_menu",
        label: "Services",
        style: "mega",
        columnsText:
          "## By capability\nStrategy & advisory|/services/strategy\nImplementation|/services/implementation\nManaged support|/services/support\n\n## By industry\nHealthcare|/industries/healthcare\nConstruction|/industries/construction\nFinance|/industries/finance",
        featuredTitle: "Book a free consultation",
        featuredDescription: "Talk to our consultants about your growth strategy.",
        featuredLinkLabel: "Get in touch",
        featuredLinkHref: "/contact",
      },
      {
        id: "nav-work",
        type: "nav_menu",
        label: "Work",
        style: "simple",
        columnsText: "All projects|/portfolio\nCase studies|/portfolio#case-studies",
      },
      { id: "nav-about", type: "nav_link", label: "About", href: "/about" },
      { id: "nav-contact", type: "nav_link", label: "Contact", href: "/contact" },
    ],
    socialBlocks: [
      { id: "social-linkedin", type: "social", icon: "linkedin", label: "LinkedIn", href: "https://linkedin.com" },
    ],
  },
};

export const defaultFooterSection: SectionInstance = {
  id: "footer-1",
  type: "footer",
  props: {
    variant: "v1",
    logoText: "Ontech",
    tagline: "Expert strategy, delivered by people who stay until it's actually working.",
    phone: "+1 (555) 010-2030",
    email: "hello@example.com",
    address: "400 Michigan Ave, Chicago, IL 60611",
    linksText:
      "## Company\nAbout|/about\nCareers|/careers\nContact|/contact\n\n## Services\nStrategy|/services/strategy\nImplementation|/services/implementation\nSupport|/services/support\n\n## Resources\nBlog|/blog\nCase studies|/portfolio\nFAQ|/faq",
    credit: "Built on Ontech Universal",
    socialBlocks: [
      { id: "social-linkedin", type: "social", icon: "linkedin", label: "LinkedIn", href: "https://linkedin.com" },
      { id: "social-instagram", type: "social", icon: "instagram", label: "Instagram", href: "https://instagram.com" },
    ],
  },
};

export const defaultFloatingActionsSection: SectionInstance = {
  id: "floating-1",
  type: "floating-actions",
  props: {
    variant: "v1",
    whatsappNumber: "",
    phone: "",
  },
};
