import * as React from "react";
import settingsDefault, { type ThemeSettings } from "../config/settings.default";
import { buildFontHref } from "../config/fonts";
import { ScrollReveal } from "../components/ScrollReveal";
import { BackToTop } from "../components/BackToTop";

export interface ThemeLayoutProps {
  /** Partial settings are merged over the defaults, so a host that stores only changed keys still renders correctly. */
  settings?: Partial<ThemeSettings>;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  /** Announcement bars render above the header. */
  announcement?: React.ReactNode;
  /** Popups and floating action sections — rendered last so they stack above page content. */
  overlays?: React.ReactNode;
  children: React.ReactNode;
}

/**
 * layout/ThemeLayout.tsx
 *
 * The single place global settings become CSS custom properties. Every
 * section reads color, spacing, radius and typography through these
 * variables (see assets/styles/theme.css) instead of hardcoding values,
 * so editing global settings restyles all 170 designs at once.
 *
 * The font <link> is built from just the two selected families — see
 * config/fonts.ts for why the theme doesn't @import all 21.
 */
export function ThemeLayout({ settings, header, footer, announcement, overlays, children }: ThemeLayoutProps) {
  const resolved: ThemeSettings = { ...settingsDefault, ...(settings ?? {}) };
  const fontHref = buildFontHref(resolved.headingFont, resolved.bodyFont);

  const containerWidth =
    resolved.containerWidth === "narrow"
      ? `${resolved.narrowMaxWidth}px`
      : resolved.containerWidth === "wide"
      ? `${Math.round(resolved.containerMaxWidth * 1.13)}px`
      : resolved.containerWidth === "full"
      ? "100%"
      : `${resolved.containerMaxWidth}px`;

  const styleVars = {
    "--otu-color-primary": resolved.colorPrimary,
    "--otu-color-primary-contrast": resolved.colorPrimaryContrast,
    "--otu-color-secondary": resolved.colorSecondary,
    "--otu-color-accent": resolved.colorAccent,
    "--otu-color-background": resolved.colorBackground,
    "--otu-color-surface": resolved.colorSurface,
    "--otu-color-surface-alt": resolved.colorSurfaceAlt,
    "--otu-color-dark": resolved.colorDark,
    "--otu-color-text": resolved.colorText,
    "--otu-color-muted": resolved.colorMutedText,
    "--otu-color-border": resolved.colorBorder,
    "--otu-color-link": resolved.colorLink,

    "--otu-font-heading": resolved.headingFont,
    "--otu-font-body": resolved.bodyFont,
    "--otu-heading-weight": resolved.headingWeight,
    "--otu-body-weight": resolved.bodyWeight,
    "--otu-base-font-size": `${resolved.baseFontSize}px`,
    "--otu-heading-size": `${resolved.headingFontSize}px`,
    "--otu-heading-scale": `${resolved.headingScale}`,
    "--otu-heading-tracking": `${resolved.headingLetterSpacing}px`,
    "--otu-heading-leading": `${resolved.headingLineHeight}`,
    "--otu-line-height": `${resolved.lineHeight}`,

    "--otu-container": containerWidth,
    "--otu-container-default": `${resolved.containerMaxWidth}px`,
    "--otu-container-narrow": `${resolved.narrowMaxWidth}px`,
    "--otu-container-wide": `${Math.round(resolved.containerMaxWidth * 1.13)}px`,
    "--otu-section-spacing": `${resolved.sectionSpacing}px`,
    "--otu-section-spacing-mobile": `${resolved.mobileSectionSpacing}px`,
    "--otu-grid-gap": `${resolved.gridGap}px`,
    "--otu-gutter": `${resolved.gutter}px`,

    "--otu-radius-sm": `${resolved.radiusSm}px`,
    "--otu-radius-md": `${resolved.radiusMd}px`,
    "--otu-radius-lg": `${resolved.radiusLg}px`,
    "--otu-radius-xl": `${resolved.radiusXl}px`,
    "--otu-button-radius": `${resolved.buttonRadius}px`,

    "--otu-header-height": `${resolved.headerHeight}px`,
    "--otu-logo-width": `${resolved.logoWidth}px`,
    "--otu-mobile-logo-width": `${resolved.mobileLogoWidth}px`,
    "--otu-transition": `${resolved.transitionSpeed}ms`,
  } as React.CSSProperties;

  return (
    <div
      id="otu-top"
      className="otu-theme"
      style={styleVars}
      data-button-style={resolved.buttonStyle}
      data-button-secondary={resolved.secondaryButtonStyle}
      data-button-hover={resolved.buttonHoverEffect}
      data-button-uppercase={resolved.buttonUppercase ? "true" : "false"}
      data-button-size={resolved.buttonSize}
      data-card-style={resolved.cardStyle}
      data-card-shadow={resolved.cardShadow}
      data-card-hover-lift={resolved.cardHoverLift ? "true" : "false"}
      data-corner-bracket={resolved.showCornerBracket ? "true" : "false"}
      data-eyebrow={resolved.eyebrowStyle}
      data-image-zoom={resolved.enableImageZoom ? "true" : "false"}
      data-scroll-reveal={resolved.enableScrollReveal ? "true" : "false"}
      data-footer-style={resolved.footerStyle}
      data-sticky-header={resolved.stickyHeader ? "true" : "false"}
    >
      {fontHref ? <link rel="stylesheet" href={fontHref} /> : null}

      <a className="otu-skip-link" href="#otu-main">
        Skip to content
      </a>

      {announcement}
      {header}
      <main className="otu-main" id="otu-main">
        {children}
      </main>
      {footer}
      {overlays}

      <BackToTop show={resolved.showScrollTop} />
      <ScrollReveal enabled={resolved.enableScrollReveal} />
    </div>
  );
}

export default ThemeLayout;
