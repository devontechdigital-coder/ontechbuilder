import * as React from "react";
import type { ColumnCount, SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { PortfolioGrid } from "./variants/PortfolioGrid";
import { PortfolioMasonryFilter } from "./variants/PortfolioMasonryFilter";
import { PortfolioListRows } from "./variants/PortfolioListRows";
import { PortfolioFeaturedCase } from "./variants/PortfolioFeaturedCase";
import { PortfolioCarousel } from "./variants/PortfolioCarousel";

export interface PortfolioProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  columns?: ColumnCount;
  seeAllLabel?: string;
  seeAllHref?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<PortfolioProps>> = {
  v1: PortfolioGrid,
  v2: PortfolioMasonryFilter,
  v3: PortfolioListRows,
  v4: PortfolioFeaturedCase,
  v5: PortfolioCarousel,
};

/**
 * Portfolio / Projects — five presentation styles.
 * v1 Even grid with hover reveal · v2 Masonry with category filter
 * pills · v3 Numbered horizontal rows · v4 One large featured case +
 * supporting list · v5 Carousel.
 */
export function Portfolio(props: PortfolioProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Portfolio;
