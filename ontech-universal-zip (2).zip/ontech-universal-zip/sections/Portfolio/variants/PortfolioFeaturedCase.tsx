import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { PortfolioProps } from "../Portfolio";

/** Portfolio 04 — Featured case + list. The first project gets a large split feature treatment; the remainder run as a compact supporting list. */
export function PortfolioFeaturedCase(props: PortfolioProps) {
  const [featured, ...rest] = props.blocks ?? [];
  if (!featured) return null;

  return (
    <SectionShell name="portfolio" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
        {props.heading ? <h2>{props.heading}</h2> : null}

        <a href={safeHref(featured.href as string) ?? "#"} className="otu-portfolio__featured">
          <ThemeImage image={featured.image as never} ratio="16:9" placeholderLabel={asString(featured.title)} />
          <div>
            <span className="otu-portfolio-card__tag">{asString(featured.category)}</span>
            <h3>{asString(featured.title)}</h3>
            <p>{asString(featured.description)}</p>
            <MaybeButton label="View case study" href={safeHref(featured.href as string)} variant="link" iconName="arrow-right" />
          </div>
        </a>

        {rest.length > 0 ? (
          <div className="otu-portfolio__supporting">
            {rest.map((project) => (
              <a key={project.id} href={safeHref(project.href as string) ?? "#"} className="otu-portfolio__supporting-item">
                <ThemeImage image={project.image as never} ratio="4:3" placeholderLabel={asString(project.title)} />
                <span>{asString(project.title)}</span>
              </a>
            ))}
          </div>
        ) : null}
      </Container>
    </SectionShell>
  );
}
