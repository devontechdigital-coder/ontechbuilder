"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { PortfolioProps } from "../Portfolio";

/** Portfolio 02 — Masonry + filter. Category pills filter a varied-height masonry grid client-side — for a large, browsable project archive. */
export function PortfolioMasonryFilter(props: PortfolioProps) {
  const items = props.blocks ?? [];
  const categories = Array.from(new Set(items.map((item) => asString(item.category, "General"))));
  const [active, setActive] = React.useState<string | null>(null);
  const visible = active ? items.filter((item) => asString(item.category, "General") === active) : items;

  return (
    <SectionShell name="portfolio" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        {categories.length > 1 ? (
          <div className="otu-portfolio__filters" role="group" aria-label="Filter projects by category">
            <button type="button" className={!active ? "is-active" : undefined} onClick={() => setActive(null)}>
              All
            </button>
            {categories.map((category) => (
              <button key={category} type="button" className={active === category ? "is-active" : undefined} onClick={() => setActive(category)}>
                {category}
              </button>
            ))}
          </div>
        ) : null}
        <div className="otu-portfolio__masonry">
          {visible.map((project) => (
            <a key={project.id} href={safeHref(project.href as string) ?? "#"} className="otu-portfolio-masonry-item">
              <ThemeImage image={project.image as never} ratio="3:4" placeholderLabel={asString(project.title)} />
              <span>{asString(project.title)}</span>
            </a>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
