import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { ThemeImage } from "../../../components/ThemeImage";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { PortfolioProps } from "../Portfolio";

/** Portfolio 05 — Carousel. 2.2/1.4/1.05 items per view with a "see all" link in the heading — good when the archive lives on its own page. */
export function PortfolioCarousel(props: PortfolioProps) {
  return (
    <SectionShell name="portfolio" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading
          eyebrow={props.eyebrow}
          heading={props.heading}
          description={props.description}
          aside={<MaybeButton label={props.seeAllLabel || "See all projects"} href={props.seeAllHref} variant="link" iconName="arrow-right" />}
        />
        <Slider desktopItems={2.2} tabletItems={1.4} mobileItems={1.05} ariaLabel="Projects">
          {(props.blocks ?? []).map((project) => (
            <a key={project.id} href={safeHref(project.href as string) ?? "#"} className="otu-portfolio-card otu-portfolio-card--static">
              <ThemeImage image={project.image as never} ratio="4:3" placeholderLabel={asString(project.title)} />
              <span className="otu-portfolio-card__tag">{asString(project.category)}</span>
              <h3>{asString(project.title)}</h3>
            </a>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
