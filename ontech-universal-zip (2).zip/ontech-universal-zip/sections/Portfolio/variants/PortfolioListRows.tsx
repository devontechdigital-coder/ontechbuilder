import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { PortfolioProps } from "../Portfolio";

/** Portfolio 03 — List rows. Numbered hairline rows that reveal a thumbnail preview on hover — text-forward, image as accent. */
export function PortfolioListRows(props: PortfolioProps) {
  return (
    <SectionShell name="portfolio" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-portfolio__rows">
          {(props.blocks ?? []).map((project, index) => (
            <a key={project.id} href={safeHref(project.href as string) ?? "#"} className="otu-portfolio-row">
              <span className="otu-portfolio-row__index">{String(index + 1).padStart(2, "0")}</span>
              <span className="otu-portfolio-row__title">{asString(project.title)}</span>
              <span className="otu-portfolio-row__category">{asString(project.category)}</span>
              <ThemeImage image={project.image as never} ratio="4:3" placeholderLabel={asString(project.title)} className="otu-portfolio-row__preview" />
              <Icon name="arrow-up-right" size={18} />
            </a>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
