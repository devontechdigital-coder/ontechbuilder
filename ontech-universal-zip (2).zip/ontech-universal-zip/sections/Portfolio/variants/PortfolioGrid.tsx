import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { PortfolioProps } from "../Portfolio";

/** Portfolio 01 — Even grid. Category tag and title reveal over the image on hover/focus. The default project grid. */
export function PortfolioGrid(props: PortfolioProps) {
  return (
    <SectionShell name="portfolio" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-portfolio__grid otu-grid-cols-${props.columns ?? 3}`}>
          {(props.blocks ?? []).map((project) => (
            <a key={project.id} href={safeHref(project.href as string) ?? "#"} className="otu-portfolio-card">
              <ThemeImage image={project.image as never} ratio="4:3" placeholderLabel={asString(project.title)} rounded={false} />
              <div className="otu-portfolio-card__overlay">
                <span className="otu-portfolio-card__tag">{asString(project.category)}</span>
                <h3>{asString(project.title)}</h3>
                <Icon name="arrow-up-right" size={18} />
              </div>
            </a>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
