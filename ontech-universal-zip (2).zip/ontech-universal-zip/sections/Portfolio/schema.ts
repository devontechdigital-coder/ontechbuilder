import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, columnOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "portfolio",
  name: "Portfolio / Projects",
  category: "Portfolio",
  description: "Five presentation styles: even grid, masonry with filter, list rows, featured case + list, carousel.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Even grid", "Masonry + filter", "List rows", "Featured case + list", "Carousel"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our work", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Selected projects", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "select", id: "columns", label: "Columns", options: columnOptions, default: "3", group: "Layout" },
    { type: "text", id: "seeAllLabel", label: "\"See all\" label", default: "See all projects", group: "Content" },
    { type: "url", id: "seeAllHref", label: "\"See all\" link", default: "/portfolio", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "project", name: "Project", settings: [
      { type: "image", id: "image", label: "Image" },
      { type: "text", id: "category", label: "Category", default: "Healthcare" },
      { type: "text", id: "title", label: "Title", default: "Digital transformation for a healthcare provider" },
      { type: "textarea", id: "description", label: "Description", default: "A phased rollout of digital patient services across a multi-site provider network." },
      { type: "url", id: "href", label: "Link" },
    ] },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "project", settings: { category: "Healthcare", title: "Digital transformation for a healthcare provider", description: "A phased rollout of digital patient services." } },
    { type: "project", settings: { category: "Retail", title: "International expansion strategy", description: "Market-entry research across three new regions." } },
    { type: "project", settings: { category: "SaaS", title: "Product redesign for an analytics platform", description: "An end-to-end UX overhaul that lifted activation." } },
  ],
};

export default schema;
