import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Tabs } from "../../../components/Tabs";
import { asString } from "../../../components/blockHelpers";
import type { TabsSectionProps } from "../TabsSection";

/** Tabs 04 — Boxed panel. A bordered container box wraps the whole tab list + panel as one unit, on a tinted section — heavier, more app-like chrome. */
export function TabsBoxedPanel(props: TabsSectionProps) {
  const items = (props.blocks ?? []).map((tab) => ({ id: tab.id, label: asString(tab.label), content: <p className="otu-tabs__prose">{asString(tab.content)}</p> }));
  return (
    <SectionShell name="tabs" {...props} tone={props.tone ?? "surface"}>
      <Container width="default">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-tabs__boxed">
          <Tabs items={items} listStyle="boxed" align="center" idPrefix="boxed" />
        </div>
      </Container>
    </SectionShell>
  );
}
