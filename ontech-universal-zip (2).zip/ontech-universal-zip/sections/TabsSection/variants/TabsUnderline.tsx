import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Tabs } from "../../../components/Tabs";
import { asString } from "../../../components/blockHelpers";
import type { TabsSectionProps } from "../TabsSection";

/** Tabs 02 — Underline. A quieter text-tab row with an animated underline beneath the active tab, left-aligned. */
export function TabsUnderline(props: TabsSectionProps) {
  const items = (props.blocks ?? []).map((tab) => ({ id: tab.id, label: asString(tab.label), content: <p className="otu-tabs__prose">{asString(tab.content)}</p> }));
  return (
    <SectionShell name="tabs" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Tabs items={items} listStyle="underline" align="left" idPrefix="underline" />
      </Container>
    </SectionShell>
  );
}
