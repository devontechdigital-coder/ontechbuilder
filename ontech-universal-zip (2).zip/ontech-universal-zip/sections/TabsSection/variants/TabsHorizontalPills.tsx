import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Tabs } from "../../../components/Tabs";
import { asString } from "../../../components/blockHelpers";
import type { TabsSectionProps } from "../TabsSection";

/** Tabs 01 — Horizontal pills. Rounded pill tab buttons, centered. The default tabbed content block. */
export function TabsHorizontalPills(props: TabsSectionProps) {
  const items = (props.blocks ?? []).map((tab) => ({ id: tab.id, label: asString(tab.label), content: <p className="otu-tabs__prose">{asString(tab.content)}</p> }));
  return (
    <SectionShell name="tabs" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Tabs items={items} listStyle="pill" align="center" idPrefix="pills" />
      </Container>
    </SectionShell>
  );
}
