import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Tabs } from "../../../components/Tabs";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { TabsSectionProps } from "../TabsSection";

/** Tabs 03 — Vertical rail. A left-hand icon rail with the content panel beside it — reads more like an app settings panel than a page section. */
export function TabsVerticalRail(props: TabsSectionProps) {
  const items = (props.blocks ?? []).map((tab) => ({
    id: tab.id,
    label: asString(tab.label),
    icon: asString(tab.icon, "spark"),
    content: (
      <div className="otu-tabs__rail-panel">
        <Icon name={asString(tab.icon, "spark")} size={28} />
        <p>{asString(tab.content)}</p>
      </div>
    ),
  }));
  return (
    <SectionShell name="tabs" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Tabs items={items} orientation="vertical" listStyle="rail" idPrefix="rail" />
      </Container>
    </SectionShell>
  );
}
