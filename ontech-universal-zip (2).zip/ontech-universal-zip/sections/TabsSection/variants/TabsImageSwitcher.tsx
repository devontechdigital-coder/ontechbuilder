"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TabsSectionProps } from "../TabsSection";

/** Tabs 05 — Image switcher. Selecting a tab swaps a large adjacent image as well as the text — for walking through product modes or steps visually. */
export function TabsImageSwitcher(props: TabsSectionProps) {
  const items = props.blocks ?? [];
  const [active, setActive] = React.useState(0);
  const current = items[active] ?? items[0];

  return (
    <SectionShell name="tabs" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-tabs__image-switch">
          <div className="otu-tabs__image-switch-list" role="tablist" aria-label={props.heading || "Options"}>
            {items.map((tab, index) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={index === active}
                className={index === active ? "is-active" : undefined}
                onClick={() => setActive(index)}
              >
                <span>{asString(tab.label)}</span>
                {index === active ? <p>{asString(tab.content)}</p> : null}
              </button>
            ))}
          </div>
          <ThemeImage image={current?.image as never} ratio="4:3" placeholderLabel={asString(current?.label)} />
        </div>
      </Container>
    </SectionShell>
  );
}
