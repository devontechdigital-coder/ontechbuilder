import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { TabsHorizontalPills } from "./variants/TabsHorizontalPills";
import { TabsUnderline } from "./variants/TabsUnderline";
import { TabsVerticalRail } from "./variants/TabsVerticalRail";
import { TabsBoxedPanel } from "./variants/TabsBoxedPanel";
import { TabsImageSwitcher } from "./variants/TabsImageSwitcher";

export interface TabsSectionProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<TabsSectionProps>> = {
  v1: TabsHorizontalPills,
  v2: TabsUnderline,
  v3: TabsVerticalRail,
  v4: TabsBoxedPanel,
  v5: TabsImageSwitcher,
};

/**
 * Tabs — five layouts, all on the shared WAI-ARIA Tabs primitive.
 * v1 Horizontal pills · v2 Underline tabs · v3 Vertical rail · v4 Boxed
 * panel with heavier chrome · v5 Tab list that swaps a large image.
 */
export function TabsSection(props: TabsSectionProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default TabsSection;
