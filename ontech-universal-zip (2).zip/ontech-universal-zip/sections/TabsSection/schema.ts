import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "tabs",
  name: "Tabs",
  category: "Tabs",
  description: "Five layouts on a shared WAI-ARIA tabs primitive: pills, underline, vertical rail, boxed panel, image switcher.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Horizontal pills", "Underline", "Vertical rail", "Boxed panel", "Image switcher"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Capabilities", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "One team, every capability", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "tab", name: "Tab", settings: [
      { type: "text", id: "label", label: "Tab label", default: "Strategy" },
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "target" },
      { type: "textarea", id: "content", label: "Content", default: "Long-range planning connected to real, measured execution." },
      { type: "image", id: "image", label: "Image", info: "Image switcher design only." },
    ] },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "tab", settings: { label: "Strategy", icon: "target", content: "Long-range planning connected to real, measured execution." } },
    { type: "tab", settings: { label: "Delivery", icon: "settings", content: "Embedded implementation, not just recommendations on a slide." } },
    { type: "tab", settings: { label: "Analytics", icon: "bar-chart", content: "Dashboards that make the impact of the work visible." } },
  ],
};

export default schema;
