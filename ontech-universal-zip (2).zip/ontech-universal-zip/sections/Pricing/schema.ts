import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "pricing",
  name: "Pricing",
  category: "Pricing",
  description: "Five layouts: even cards, monthly/yearly toggle, highlighted tier, single callout, comparison table.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Even cards", "Monthly/yearly toggle", "Highlighted tier", "Single callout", "Comparison table"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Pricing", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Simple, transparent pricing", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "text", id: "monthlyLabel", label: "Monthly toggle label", default: "Monthly", group: "Content" },
    { type: "text", id: "yearlyLabel", label: "Yearly toggle label", default: "Yearly", group: "Content" },
    { type: "text", id: "yearlyDiscountNote", label: "Yearly billing note", default: "billed annually — save 15%", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "plan", name: "Plan", settings: [
      { type: "text", id: "name", label: "Plan name", default: "Growth" },
      { type: "text", id: "description", label: "Short description", default: "For teams ready to move fast." },
      { type: "text", id: "price", label: "Price", default: "$2,400/mo" },
      { type: "text", id: "yearlyPrice", label: "Yearly price (advanced)", default: "$24,000/yr" },
      { type: "text", id: "billingText", label: "Billing note", default: "billed monthly" },
      { type: "textarea", id: "features", label: "Features (one per line)", default: "Dedicated consultant\nBi-weekly strategy sessions\nQuarterly business review" },
      { type: "checkbox", id: "highlighted", label: "Highlight this plan", default: false },
      { type: "text", id: "badgeLabel", label: "Highlight badge text", default: "Most popular" },
      { type: "text", id: "ctaLabel", label: "Button label", default: "Get started" },
      { type: "url", id: "ctaHref", label: "Button link", default: "/contact" },
    ] },
  ],
  maxBlocks: 5,
  defaultBlocks: [
    { type: "plan", settings: { name: "Starter", price: "$900/mo", description: "For small teams testing the waters.", features: "Monthly strategy call\nEmail support\nQuarterly report", ctaLabel: "Get started" } },
    { type: "plan", settings: { name: "Growth", price: "$2,400/mo", description: "For teams ready to move fast.", features: "Dedicated consultant\nBi-weekly sessions\nQuarterly business review", highlighted: true, ctaLabel: "Get started" } },
    { type: "plan", settings: { name: "Enterprise", price: "Custom", description: "For complex, multi-market organisations.", features: "Embedded team\nWeekly working sessions\nCustom reporting", ctaLabel: "Talk to sales" } },
  ],
};

export default schema;
