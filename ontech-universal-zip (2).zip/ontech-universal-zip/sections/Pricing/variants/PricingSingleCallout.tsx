import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString, lines } from "../../../components/blockHelpers";
import type { PricingProps } from "../Pricing";

/** Pricing 05 — Single callout. One plan only, presented as a wide feature card — for a custom-quote / "talk to sales" model instead of self-serve tiers. */
export function PricingSingleCallout(props: PricingProps) {
  const plan = (props.blocks ?? [])[0];
  if (!plan) return null;
  const features = lines(plan.features);

  return (
    <SectionShell name="pricing" {...props} tone={props.tone ?? "dark"}>
      <Container width="default">
        <div className="otu-pricing__callout">
          <div>
            {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
            <ul>
              {features.map((feature) => (
                <li key={feature}>
                  <Icon name="check" size={16} /> {feature}
                </li>
              ))}
            </ul>
          </div>
          <div className="otu-pricing__callout-card">
            <span className="otu-pricing-card__price">
              <span>{asString(plan.price, "Custom")}</span>
              {plan.billingText ? <small>{asString(plan.billingText)}</small> : null}
            </span>
            <MaybeButton label={asString(plan.ctaLabel, "Talk to sales")} href={asString(plan.ctaHref) || undefined} variant="primary" size="lg" fullWidth />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
