"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import { PricingCard } from "./PricingCard";
import type { PricingProps } from "../Pricing";

/** Pricing 02 — Monthly/yearly toggle. A switch changes which price is shown per plan, reading from a "yearlyPrice" field alongside the default price. */
export function PricingToggleTiers(props: PricingProps) {
  const [yearly, setYearly] = React.useState(false);
  const plans = (props.blocks ?? []).map((plan) => (yearly && plan.yearlyPrice ? { ...plan, price: plan.yearlyPrice, billingText: props.yearlyDiscountNote ?? plan.billingText } : plan));

  return (
    <SectionShell name="pricing" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-pricing__toggle" role="group" aria-label="Billing period">
          <button type="button" className={!yearly ? "is-active" : undefined} onClick={() => setYearly(false)}>
            {props.monthlyLabel || "Monthly"}
          </button>
          <button type="button" className={yearly ? "is-active" : undefined} onClick={() => setYearly(true)}>
            {props.yearlyLabel || "Yearly"}
          </button>
        </div>
        <div className="otu-pricing__grid">
          {plans.map((plan) => (
            <PricingCard key={asString(plan.id)} plan={plan} />
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
