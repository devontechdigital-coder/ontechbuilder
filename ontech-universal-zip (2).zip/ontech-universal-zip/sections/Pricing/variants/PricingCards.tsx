import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { PricingCard } from "./PricingCard";
import type { PricingProps } from "../Pricing";

/** Pricing 01 — Even cards. Three (or more) equal-weight plan cards side by side. The standard pricing layout. */
export function PricingCards(props: PricingProps) {
  return (
    <SectionShell name="pricing" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-pricing__grid">
          {(props.blocks ?? []).map((plan) => (
            <PricingCard key={plan.id} plan={plan} />
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
