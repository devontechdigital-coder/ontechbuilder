import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { PricingCard } from "./PricingCard";
import { asBoolean } from "../../../components/blockHelpers";
import type { PricingProps } from "../Pricing";

/** Pricing 03 — Highlighted tier. The plan marked "highlighted" renders visually raised and larger than its neighbours, drawing the eye to the recommended option. */
export function PricingHighlightedTable(props: PricingProps) {
  return (
    <SectionShell name="pricing" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-pricing__raised-grid">
          {(props.blocks ?? []).map((plan) => (
            <PricingCard key={plan.id} plan={plan} className={asBoolean(plan.highlighted, false) ? "otu-pricing-card--raised" : undefined} />
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
