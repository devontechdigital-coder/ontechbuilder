import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString, lines } from "../../../components/blockHelpers";
import type { PricingProps } from "../Pricing";

/** Pricing 04 — Comparison table. Plans as columns, every feature as its own row with a check/cross per plan — for detailed feature-by-feature comparison. */
export function PricingComparisonTable(props: PricingProps) {
  const plans = props.blocks ?? [];
  const featureRows = Array.from(new Set(plans.flatMap((plan) => lines(plan.features))));

  return (
    <SectionShell name="pricing" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-pricing-table__scroll">
          <table className="otu-pricing-table">
            <thead>
              <tr>
                <th scope="col" />
                {plans.map((plan) => (
                  <th scope="col" key={plan.id}>
                    <span className="otu-pricing-table__plan">{asString(plan.name)}</span>
                    <span className="otu-pricing-table__price">{asString(plan.price)}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {featureRows.map((feature) => (
                <tr key={feature}>
                  <th scope="row">{feature}</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>{lines(plan.features).includes(feature) ? <Icon name="check" size={18} /> : <span aria-hidden="true">—</span>}</td>
                  ))}
                </tr>
              ))}
              <tr>
                <th scope="row" />
                {plans.map((plan) => (
                  <td key={plan.id}>
                    <MaybeButton label={asString(plan.ctaLabel, "Choose")} href={asString(plan.ctaHref) || undefined} variant="outline" size="sm" />
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </Container>
    </SectionShell>
  );
}
