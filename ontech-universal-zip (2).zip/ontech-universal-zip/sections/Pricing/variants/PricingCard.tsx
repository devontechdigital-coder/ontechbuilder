import * as React from "react";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { asBoolean, asString, lines } from "../../../components/blockHelpers";
import { cn } from "../../../components/utils";
import type { RawBlock } from "../../../components/blockHelpers";

/** Shared plan-card body used by every pricing design that shows cards. */
export function PricingCard({ plan, className }: { plan: RawBlock; className?: string }) {
  const highlighted = asBoolean(plan.highlighted, false);
  const features = lines(plan.features);
  return (
    <div className={cn("otu-pricing-card", highlighted && "otu-pricing-card--highlighted", className)}>
      {highlighted ? <span className="otu-pricing-card__badge">{asString(plan.badgeLabel, "Most popular")}</span> : null}
      <h3>{asString(plan.name)}</h3>
      <p className="otu-pricing-card__desc">{asString(plan.description)}</p>
      <div className="otu-pricing-card__price">
        <span>{asString(plan.price)}</span>
        {plan.billingText ? <small>{asString(plan.billingText)}</small> : null}
      </div>
      <ul className="otu-pricing-card__features">
        {features.map((feature) => (
          <li key={feature}>
            <Icon name="check" size={16} />
            {feature}
          </li>
        ))}
      </ul>
      <MaybeButton
        label={asString(plan.ctaLabel, "Get started")}
        href={asString(plan.ctaHref) || undefined}
        variant={highlighted ? "primary" : "outline"}
        fullWidth
      />
    </div>
  );
}
