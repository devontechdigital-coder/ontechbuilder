import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { PricingCards } from "./variants/PricingCards";
import { PricingToggleTiers } from "./variants/PricingToggleTiers";
import { PricingHighlightedTable } from "./variants/PricingHighlightedTable";
import { PricingSingleCallout } from "./variants/PricingSingleCallout";
import { PricingComparisonTable } from "./variants/PricingComparisonTable";

export interface PricingProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  monthlyLabel?: string;
  yearlyLabel?: string;
  yearlyDiscountNote?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<PricingProps>> = {
  v1: PricingCards,
  v2: PricingToggleTiers,
  v3: PricingHighlightedTable,
  v4: PricingSingleCallout,
  v5: PricingComparisonTable,
};

/**
 * Pricing — five layouts.
 * v1 Three even cards · v2 Monthly/yearly toggle · v3 Cards with one
 * highlighted plan raised above the rest · v4 Single custom-quote
 * callout · v5 Full feature-comparison table.
 */
export function Pricing(props: PricingProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Pricing;
