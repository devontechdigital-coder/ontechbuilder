import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import type { CardsProps } from "../Cards";

/** Cards 01 — Icon grid. Bordered cards with an icon, title and short blurb. The general-purpose default. */
export function CardsGrid(props: CardsProps) {
  return (
    <SectionShell name="cards" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-cards__grid otu-grid-cols-${props.columns ?? 3}`}>
          {(props.blocks ?? []).map((card) => (
            <div key={card.id} className={`otu-card otu-card--${props.cardStyle ?? "outlined"}`}>
              <span className="otu-card__icon">
                <Icon name={asString(card.icon, "spark")} size={22} />
              </span>
              <h3 className="otu-card__title">{asString(card.title)}</h3>
              <p className="otu-card__text">{asString(card.text)}</p>
              <MaybeButton label={asString(card.linkLabel) || undefined} href={asString(card.linkHref) || undefined} variant="link" size="sm" iconName="arrow-right" />
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
