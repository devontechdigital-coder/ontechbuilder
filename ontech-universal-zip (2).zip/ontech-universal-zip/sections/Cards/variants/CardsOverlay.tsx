import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { CardsProps } from "../Cards";

/** Cards 03 — Full-bleed photo overlay. Image fills the card; title and text sit on a bottom gradient scrim. */
export function CardsOverlay(props: CardsProps) {
  return (
    <SectionShell name="cards" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-cards__grid otu-grid-cols-${props.columns ?? 3}`}>
          {(props.blocks ?? []).map((card) => (
            <div key={card.id} className="otu-card otu-card--overlay">
              <ThemeImage image={card.image as never} ratio="3:4" placeholderLabel={asString(card.title)} rounded={false} />
              <div className="otu-card__overlay-content">
                <h3 className="otu-card__title">{asString(card.title)}</h3>
                <p className="otu-card__text">{asString(card.text)}</p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
