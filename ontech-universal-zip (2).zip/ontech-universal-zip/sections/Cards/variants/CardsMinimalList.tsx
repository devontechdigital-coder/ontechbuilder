import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { CardsProps } from "../Cards";

/** Cards 05 — Minimal numbered list. No borders, no icons — just a number, title and text separated by hairlines. */
export function CardsMinimalList(props: CardsProps) {
  return (
    <SectionShell name="cards" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <ol className="otu-cards__minimal">
          {(props.blocks ?? []).map((card, index) => (
            <li key={card.id} className="otu-cards__minimal-item">
              <span className="otu-cards__minimal-index">{String(index + 1).padStart(2, "0")}</span>
              <div>
                <h3 className="otu-card__title">{asString(card.title)}</h3>
                <p className="otu-card__text">{asString(card.text)}</p>
              </div>
            </li>
          ))}
        </ol>
      </Container>
    </SectionShell>
  );
}
