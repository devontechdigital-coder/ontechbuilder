import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { CardsProps } from "../Cards";

/** Cards 04 — Offset stacked cards. Alternating vertical offset per card creates a hand-arranged rhythm instead of a rigid grid. */
export function CardsStacked(props: CardsProps) {
  return (
    <SectionShell name="cards" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-cards__stacked">
          {(props.blocks ?? []).map((card, index) => (
            <div key={card.id} className={`otu-card otu-card--${props.cardStyle ?? "elevated"} otu-cards__stacked-item`} style={{ "--otu-stack-offset": index % 2 === 0 ? "0px" : "36px" } as React.CSSProperties}>
              <Icon name={asString(card.icon, "layers")} size={24} />
              <h3 className="otu-card__title">{asString(card.title)}</h3>
              <p className="otu-card__text">{asString(card.text)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
