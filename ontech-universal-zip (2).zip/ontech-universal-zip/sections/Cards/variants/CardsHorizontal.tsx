import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { CardsProps } from "../Cards";

/** Cards 02 — Horizontal media cards. Small square image beside title/text, stacked in a single column list. */
export function CardsHorizontal(props: CardsProps) {
  return (
    <SectionShell name="cards" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-cards__list">
          {(props.blocks ?? []).map((card) => (
            <div key={card.id} className={`otu-card otu-card--row otu-card--${props.cardStyle ?? "flat"}`}>
              <ThemeImage image={card.image as never} ratio="1:1" placeholderLabel={asString(card.title)} className="otu-card__thumb" />
              <div>
                <h3 className="otu-card__title">{asString(card.title)}</h3>
                <p className="otu-card__text">{asString(card.text)}</p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
