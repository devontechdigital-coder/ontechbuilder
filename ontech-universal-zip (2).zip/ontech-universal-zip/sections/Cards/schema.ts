import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, cardStyleOptions, columnOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "cards",
  name: "Cards",
  category: "Content",
  description: "Five card treatments: icon grid, horizontal media, photo overlay, offset stacked, minimal numbered list.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Icon grid", "Horizontal media", "Photo overlay", "Offset stacked", "Minimal numbered list"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "What we offer", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Built around what your team actually needs", group: "Content" },
    { type: "textarea", id: "description", label: "Description", default: "Every engagement starts from your operating reality, not a generic framework.", group: "Content" },
    { type: "select", id: "columns", label: "Columns", options: columnOptions, default: "3", group: "Layout" },
    { type: "select", id: "cardStyle", label: "Card style", options: cardStyleOptions, default: "outlined", group: "Style" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "card", name: "Card", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "spark" },
      { type: "image", id: "image", label: "Image" },
      { type: "text", id: "title", label: "Title", default: "Strategic clarity" },
      { type: "textarea", id: "text", label: "Text", default: "We help leadership teams cut through competing priorities to a plan everyone can execute." },
      { type: "text", id: "linkLabel", label: "Link label" },
      { type: "url", id: "linkHref", label: "Link URL" },
    ] },
  ],
  maxBlocks: 9,
  defaultBlocks: [
    { type: "card", settings: { icon: "target", title: "Strategic clarity", text: "A plan the whole team can execute, not just admire." } },
    { type: "card", settings: { icon: "trending-up", title: "Measurable growth", text: "Every initiative is tied to a metric we track together." } },
    { type: "card", settings: { icon: "users", title: "Embedded delivery", text: "We work inside your team, not at arm's length." } },
  ],
};

export default schema;
