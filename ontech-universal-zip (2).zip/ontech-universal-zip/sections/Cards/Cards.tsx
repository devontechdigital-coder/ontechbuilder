import * as React from "react";
import type { CardStyle, ColumnCount, SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { CardsGrid } from "./variants/CardsGrid";
import { CardsHorizontal } from "./variants/CardsHorizontal";
import { CardsOverlay } from "./variants/CardsOverlay";
import { CardsStacked } from "./variants/CardsStacked";
import { CardsMinimalList } from "./variants/CardsMinimalList";

export interface CardsProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  columns?: ColumnCount;
  cardStyle?: CardStyle;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<CardsProps>> = {
  v1: CardsGrid,
  v2: CardsHorizontal,
  v3: CardsOverlay,
  v4: CardsStacked,
  v5: CardsMinimalList,
};

/**
 * Cards — five card treatments.
 * v1 Icon grid · v2 Horizontal media cards · v3 Full-bleed photo overlay ·
 * v4 Offset stacked cards · v5 Minimal numbered list.
 */
export function Cards(props: CardsProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Cards;
