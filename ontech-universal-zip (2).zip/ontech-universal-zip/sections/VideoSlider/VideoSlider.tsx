import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { VideoSliderStandard } from "./variants/VideoSliderStandard";
import { VideoSliderFullscreen } from "./variants/VideoSliderFullscreen";
import { VideoSliderThumbRail } from "./variants/VideoSliderThumbRail";
import { VideoSliderVertical } from "./variants/VideoSliderVertical";
import { VideoSliderTestimonial } from "./variants/VideoSliderTestimonial";

export interface VideoSliderProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<VideoSliderProps>> = {
  v1: VideoSliderStandard,
  v2: VideoSliderFullscreen,
  v3: VideoSliderThumbRail,
  v4: VideoSliderVertical,
  v5: VideoSliderTestimonial,
};

/**
 * Video Slider — five ways to browse multiple videos.
 * v1 Standard horizontal · v2 Fullscreen one-at-a-time · v3 Big player +
 * thumbnail rail · v4 Vertical/reel-style scroller · v5 Video testimonial
 * carousel.
 */
export function VideoSlider(props: VideoSliderProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default VideoSlider;
