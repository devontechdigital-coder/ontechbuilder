import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { VideoFrame } from "../../../components/VideoFrame";
import { asString } from "../../../components/blockHelpers";
import type { VideoSliderProps } from "../VideoSlider";

/** Video Slider 05 — Video testimonials. Portrait clips paired with the speaker's name and role, one and a half per view. */
export function VideoSliderTestimonial(props: VideoSliderProps) {
  return (
    <SectionShell name="video-slider" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Slider desktopItems={2.5} tabletItems={1.5} mobileItems={1.05} gap="sm" ariaLabel={props.heading || "Video testimonials"}>
          {(props.blocks ?? []).map((item) => (
            <div className="otu-video-testimonial" key={item.id}>
              <VideoFrame video={item.video as never} poster={item.poster as never} ratio="3:4" />
              <p className="otu-video-testimonial__name">{asString(item.title)}</p>
              <p className="otu-video-testimonial__role">{asString(item.text)}</p>
            </div>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
