"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { VideoFrame } from "../../../components/VideoFrame";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { VideoSliderProps } from "../VideoSlider";

/** Video Slider 03 — Thumbnail rail. Large active player with a scrollable playlist beside it — a mini video library. */
export function VideoSliderThumbRail(props: VideoSliderProps) {
  const items = props.blocks ?? [];
  const [active, setActive] = React.useState(0);
  const current = items[active] ?? items[0];

  return (
    <SectionShell name="video-slider" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-video-playlist">
          <div className="otu-video-playlist__main">
            <VideoFrame video={current?.video as never} poster={current?.poster as never} ratio="16:9" />
            <h3>{asString(current?.title)}</h3>
          </div>
          <ul className="otu-video-playlist__rail">
            {items.map((item, index) => (
              <li key={item.id}>
                <button type="button" className={index === active ? "is-active" : undefined} onClick={() => setActive(index)}>
                  <span className="otu-video-playlist__thumb">
                    <ThemeImage image={item.poster as never} ratio="16:9" placeholderLabel={asString(item.title)} rounded={false} />
                    <Icon name="play" size={16} />
                  </span>
                  <span>{asString(item.title)}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </SectionShell>
  );
}
