import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { VideoFrame } from "../../../components/VideoFrame";
import { asString } from "../../../components/blockHelpers";
import type { VideoSliderProps } from "../VideoSlider";

/** Video Slider 04 — Vertical reel. Tall 9:16 clips in a horizontally scrolling row — short-form / social-style content. */
export function VideoSliderVertical(props: VideoSliderProps) {
  return (
    <SectionShell name="video-slider" {...props}>
      <Container width={props.containerWidth ?? "wide"} flush>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} className="otu-container otu-container--flush" align="center" />
        <div className="otu-video-reel">
          {(props.blocks ?? []).map((item) => (
            <div className="otu-video-reel__item" key={item.id}>
              <VideoFrame video={item.video as never} poster={item.poster as never} ratio="9:16" controls={false} />
              <span>{asString(item.title)}</span>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
