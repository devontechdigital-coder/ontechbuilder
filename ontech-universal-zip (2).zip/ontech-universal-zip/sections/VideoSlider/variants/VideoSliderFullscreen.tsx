import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { Slider } from "../../../components/Slider";
import { VideoFrame } from "../../../components/VideoFrame";
import { asString } from "../../../components/blockHelpers";
import type { VideoSliderProps } from "../VideoSlider";

/** Video Slider 02 — Fullscreen. One large full-bleed video per slide with its caption overlaid at the bottom. */
export function VideoSliderFullscreen(props: VideoSliderProps) {
  return (
    <SectionShell name="video-slider" {...props} padded={false}>
      <Slider desktopItems={1} tabletItems={1} mobileItems={1} gap="none" arrowStyle="minimal" ariaLabel={props.heading || "Video slider"}>
        {(props.blocks ?? []).map((item) => (
          <div className="otu-video-slide-full" key={item.id}>
            <VideoFrame video={item.video as never} poster={item.poster as never} ratio="auto" rounded={false} />
            <div className="otu-video-slide-full__caption">
              <h3>{asString(item.title)}</h3>
              <p>{asString(item.text)}</p>
            </div>
          </div>
        ))}
      </Slider>
    </SectionShell>
  );
}
