import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { VideoFrame } from "../../../components/VideoFrame";
import { asString } from "../../../components/blockHelpers";
import type { VideoSliderProps } from "../VideoSlider";

/** Video Slider 01 — Standard. 2/1.5/1 videos per view, each with its own title beneath. */
export function VideoSliderStandard(props: VideoSliderProps) {
  return (
    <SectionShell name="video-slider" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Slider desktopItems={2} tabletItems={1.5} mobileItems={1} ariaLabel={props.heading || "Video slider"}>
          {(props.blocks ?? []).map((item) => (
            <div className="otu-video-slide" key={item.id}>
              <VideoFrame video={item.video as never} poster={item.poster as never} ratio="16:9" />
              <h3>{asString(item.title)}</h3>
            </div>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
