import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "video-slider",
  name: "Video Slider",
  category: "Video",
  description: "Five ways to browse multiple videos: standard row, fullscreen, thumbnail rail, vertical reel, video testimonials.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Standard horizontal", "Fullscreen", "Thumbnail rail", "Vertical reel", "Video testimonials"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "In their words", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Client stories on video", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "clip", name: "Video clip", settings: [
      { type: "video", id: "video", label: "Video" },
      { type: "image", id: "poster", label: "Poster image" },
      { type: "text", id: "title", label: "Title", default: "Amanda Lewis" },
      { type: "text", id: "text", label: "Subtitle / role", default: "Director of Strategy, Meridian Health" },
    ] },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "clip", settings: { title: "Amanda Lewis", text: "Director of Strategy, Meridian Health" } },
    { type: "clip", settings: { title: "Owen Ricci", text: "COO, Larkspur Manufacturing" } },
    { type: "clip", settings: { title: "Priya Nair", text: "Founder, Northloop Retail" } },
  ],
};

export default schema;
