import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "tables",
  name: "Tables",
  category: "Tables",
  description: "Five layouts for tabular content — all horizontally scrollable on narrow screens; one restacks into cards instead.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Comparison", "Feature matrix", "Plan cards + table", "Plain data rows", "Stacked on mobile"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Compare", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Compare our service tiers", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "text", id: "headerRow", label: "Header row", default: "Feature | Starter | Growth | Enterprise", group: "Content", info: "Pipe-separated columns." },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "row", name: "Row", settings: [
      { type: "text", id: "cells", label: "Row cells", default: "Dedicated consultant | No | Yes | Yes", info: "Pipe-separated, first cell is the row label. Use Yes/No for the feature-matrix design." },
    ] },
  ],
  maxBlocks: 14,
  defaultBlocks: [
    { type: "row", settings: { cells: "Dedicated consultant | No | Yes | Yes" } },
    { type: "row", settings: { cells: "Quarterly review | No | Yes | Yes" } },
    { type: "row", settings: { cells: "Custom reporting | No | No | Yes" } },
    { type: "row", settings: { cells: "Response time | 3 days | 1 day | Same day" } },
  ],
};

export default schema;
