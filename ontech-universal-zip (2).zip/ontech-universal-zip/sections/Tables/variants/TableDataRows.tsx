import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { parseHeader, parseRow } from "./tableUtils";
import type { TablesProps } from "../Tables";

/** Table 04 — Plain data rows. Zebra-striped rows with no card chrome — for general reference data (specs, rates, timelines) rather than a plan comparison. */
export function TableDataRows(props: TablesProps) {
  const header = parseHeader(props.headerRow);
  return (
    <SectionShell name="tables" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-table__scroll">
          <table className="otu-table otu-table--striped">
            <thead>
              <tr>
                {header.map((cell, index) => (
                  <th key={index} scope="col">{cell}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(props.blocks ?? []).map((block) => (
                <tr key={block.id}>
                  {parseRow(block).map((cell, index) => (
                    <td key={index}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Container>
    </SectionShell>
  );
}
