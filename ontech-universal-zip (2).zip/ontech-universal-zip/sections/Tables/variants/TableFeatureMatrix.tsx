import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { parseHeader, parseRow } from "./tableUtils";
import type { TablesProps } from "../Tables";

/** Table 02 — Feature matrix. Cells containing "yes"/"true"/"✓" render as a check icon; everything else renders as plain text — for a plan-vs-feature grid. */
export function TableFeatureMatrix(props: TablesProps) {
  const header = parseHeader(props.headerRow);
  const isPositive = (value: string) => ["yes", "true", "✓", "check"].includes(value.trim().toLowerCase());

  return (
    <SectionShell name="tables" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-table__scroll">
          <table className="otu-table otu-table--matrix">
            <thead>
              <tr>
                {header.map((cell, index) => (
                  <th key={index} scope="col">{cell}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(props.blocks ?? []).map((block) => {
                const row = parseRow(block);
                return (
                  <tr key={block.id}>
                    {row.map((cell, index) =>
                      index === 0 ? (
                        <th key={index} scope="row">{cell}</th>
                      ) : (
                        <td key={index}>{isPositive(cell) ? <Icon name="check" size={18} /> : cell.trim() ? cell : <span aria-hidden="true">—</span>}</td>
                      ),
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Container>
    </SectionShell>
  );
}
