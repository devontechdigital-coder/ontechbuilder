import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { parseHeader, parseRow } from "./tableUtils";
import type { TablesProps } from "../Tables";

/**
 * Table 05 — Stacked on mobile.
 * A real <table> on desktop; below the mobile breakpoint each row
 * becomes its own labelled card instead of scrolling horizontally —
 * the only design of the five that restacks rather than scrolls, for
 * data where horizontal scanning matters (specs, technical detail).
 */
export function TableStackedMobile(props: TablesProps) {
  const header = parseHeader(props.headerRow);
  return (
    <SectionShell name="tables" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />

        <table className="otu-table otu-table--stack-mobile">
          <thead>
            <tr>
              {header.map((cell, index) => (
                <th key={index} scope="col">{cell}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(props.blocks ?? []).map((block) => {
              const row = parseRow(block);
              return (
                <tr key={block.id}>
                  {row.map((cell, index) => (
                    <td key={index} data-label={header[index] ?? ""}>
                      {cell}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </Container>
    </SectionShell>
  );
}
