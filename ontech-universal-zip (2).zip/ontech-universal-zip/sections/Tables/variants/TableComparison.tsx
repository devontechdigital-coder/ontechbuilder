import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { parseHeader, parseRow } from "./tableUtils";
import type { TablesProps } from "../Tables";

/** Table 01 — Comparison. A standard header row + data rows table, horizontally scrollable on narrow screens. The default service-comparison table. */
export function TableComparison(props: TablesProps) {
  const header = parseHeader(props.headerRow);
  return (
    <SectionShell name="tables" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-table__scroll">
          <table className="otu-table">
            {header.length > 0 ? (
              <thead>
                <tr>
                  {header.map((cell, index) => (
                    <th key={index} scope="col">{cell}</th>
                  ))}
                </tr>
              </thead>
            ) : null}
            <tbody>
              {(props.blocks ?? []).map((block) => {
                const row = parseRow(block);
                return (
                  <tr key={block.id}>
                    {row.map((cell, index) => (index === 0 ? <th key={index} scope="row">{cell}</th> : <td key={index}>{cell}</td>))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Container>
    </SectionShell>
  );
}
