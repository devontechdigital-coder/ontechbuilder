import { asString, type RawBlock } from "../../../components/blockHelpers";
import { cells } from "../../../components/utils";

/** Shared parsing for the pipe-separated row format used by every Tables design. */
export function parseHeader(headerRow: string | undefined): string[] {
  return cells(headerRow);
}

export function parseRow(block: RawBlock): string[] {
  return cells(asString(block.cells));
}
