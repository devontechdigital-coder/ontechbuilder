import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { parseHeader, parseRow } from "./tableUtils";
import type { TablesProps } from "../Tables";

/** Table 03 — Plan header cards above the data. The header row renders as a strip of elevated plan-name cards, with the comparison rows beneath — bridges the Pricing and Tables categories. */
export function TablePlansCards(props: TablesProps) {
  const header = parseHeader(props.headerRow);
  const [label, ...plans] = header;

  return (
    <SectionShell name="tables" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-table__plan-cards" style={{ "--otu-table-cols": plans.length } as React.CSSProperties}>
          <span />
          {plans.map((plan) => (
            <div key={plan} className="otu-table__plan-card">
              {plan}
            </div>
          ))}
        </div>
        <div className="otu-table__scroll">
          <table className="otu-table">
            <tbody>
              {(props.blocks ?? []).map((block) => {
                const row = parseRow(block);
                return (
                  <tr key={block.id}>
                    {row.map((cell, index) => (index === 0 ? <th key={index} scope="row">{cell}</th> : <td key={index}>{cell}</td>))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <span className="otu-visually-hidden">{label}</span>
      </Container>
    </SectionShell>
  );
}
