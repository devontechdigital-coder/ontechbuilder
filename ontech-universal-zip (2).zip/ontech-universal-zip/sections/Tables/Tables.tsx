import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { TableComparison } from "./variants/TableComparison";
import { TableFeatureMatrix } from "./variants/TableFeatureMatrix";
import { TablePlansCards } from "./variants/TablePlansCards";
import { TableDataRows } from "./variants/TableDataRows";
import { TableStackedMobile } from "./variants/TableStackedMobile";

export interface TablesProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  /** "header" row textarea + "row" blocks — see schema for the pipe-separated format. */
  headerRow?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<TablesProps>> = {
  v1: TableComparison,
  v2: TableFeatureMatrix,
  v3: TablePlansCards,
  v4: TableDataRows,
  v5: TableStackedMobile,
};

/**
 * Tables — five layouts for tabular content (plans, comparisons, specs).
 * Every design scrolls horizontally on narrow screens rather than
 * crushing columns unreadably, and v5 restacks into label/value pairs
 * instead of scrolling at all.
 * v1 Service comparison · v2 Feature matrix with check/cross ·
 * v3 Plan cards with a data table beneath · v4 Plain data rows ·
 * v5 Mobile-first stacked cards.
 */
export function Tables(props: TablesProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Tables;
