import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import type { ContactProps } from "../Contact";

/** Contact 01 — Cards row. Phone, email and address each get their own bordered card with an icon — the default "reach us" block. */
export function ContactCardsRow(props: ContactProps) {
  return (
    <SectionShell name="contact-info" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-contact__cards">
          {props.phone ? (
            <a className="otu-contact__card" href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
              <Icon name="phone" size={22} />
              <h3>Call us</h3>
              <p>{props.phone}</p>
            </a>
          ) : null}
          {props.email ? (
            <a className="otu-contact__card" href={`mailto:${props.email}`}>
              <Icon name="mail" size={22} />
              <h3>Email us</h3>
              <p>{props.email}</p>
            </a>
          ) : null}
          {props.address ? (
            <div className="otu-contact__card">
              <Icon name="map-pin" size={22} />
              <h3>Visit us</h3>
              <p>{props.address}</p>
            </div>
          ) : null}
        </div>
      </Container>
    </SectionShell>
  );
}
