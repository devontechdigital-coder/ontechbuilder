import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import type { ContactProps } from "../Contact";

/** Contact 05 — Full-bleed banner. Background image with a scrim, contact details centered on top — the most visual of the five, good as a contact-page header. */
export function ContactFullBleedBanner(props: ContactProps) {
  return (
    <SectionShell name="contact-info" {...props} padded={false} className="otu-contact--banner">
      <ThemeImage image={props.image} ratio="auto" rounded={false} placeholderLabel="Contact" />
      <div className="otu-contact__banner-scrim" />
      <Container width="default" className="otu-contact__banner-content">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
        {props.heading ? <h1>{props.heading}</h1> : null}
        <div className="otu-contact__inline otu-contact__inline--light">
          {props.phone ? (
            <a href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
              <Icon name="phone" size={16} /> {props.phone}
            </a>
          ) : null}
          {props.email ? (
            <a href={`mailto:${props.email}`}>
              <Icon name="mail" size={16} /> {props.email}
            </a>
          ) : null}
        </div>
      </Container>
    </SectionShell>
  );
}
