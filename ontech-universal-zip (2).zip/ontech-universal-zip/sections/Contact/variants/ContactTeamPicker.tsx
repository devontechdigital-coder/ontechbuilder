import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { ContactProps } from "../Contact";

/** Contact 04 — Team picker. "Who should you talk to?" cards — a person, their focus area, and direct contact details, so the visitor reaches the right person. */
export function ContactTeamPicker(props: ContactProps) {
  return (
    <SectionShell name="contact-info" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-contact__team">
          {(props.blocks ?? []).map((person) => (
            <div className="otu-contact__team-card" key={person.id}>
              <ThemeImage image={person.image as never} ratio="1:1" placeholderLabel={asString(person.name, "Contact")} rounded className="otu-avatar otu-avatar--lg" />
              <h3>{asString(person.name)}</h3>
              <p>{asString(person.focus)}</p>
              {person.email ? (
                <a href={`mailto:${asString(person.email)}`}>
                  <Icon name="mail" size={16} /> {asString(person.email)}
                </a>
              ) : null}
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
