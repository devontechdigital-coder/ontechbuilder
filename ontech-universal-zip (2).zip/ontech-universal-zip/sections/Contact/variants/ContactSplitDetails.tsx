import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import type { ContactProps } from "../Contact";

/** Contact 02 — Split with image. A supporting photo on one side, a full detail list (address, phone, email, hours) on the other. */
export function ContactSplitDetails(props: ContactProps) {
  return (
    <SectionShell name="contact-info" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-contact__split">
          <ThemeImage image={props.image} ratio="4:3" placeholderLabel="Contact" />
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
            <dl className="otu-contact__detail-list">
              {props.address ? (
                <div>
                  <dt><Icon name="map-pin" size={16} /></dt>
                  <dd>{props.address}</dd>
                </div>
              ) : null}
              {props.phone ? (
                <div>
                  <dt><Icon name="phone" size={16} /></dt>
                  <dd>{props.phone}</dd>
                </div>
              ) : null}
              {props.email ? (
                <div>
                  <dt><Icon name="mail" size={16} /></dt>
                  <dd>{props.email}</dd>
                </div>
              ) : null}
              {props.hours ? (
                <div>
                  <dt><Icon name="clock" size={16} /></dt>
                  <dd>{props.hours}</dd>
                </div>
              ) : null}
            </dl>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
