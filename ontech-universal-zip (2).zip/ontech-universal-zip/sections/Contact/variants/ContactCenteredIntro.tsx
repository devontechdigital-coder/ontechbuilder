import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import type { ContactProps } from "../Contact";

/** Contact 03 — Centered intro. A short centered statement above one inline row of contact methods separated by dividers — minimal, calm. */
export function ContactCenteredIntro(props: ContactProps) {
  return (
    <SectionShell name="contact-info" {...props}>
      <Container width="narrow">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        {props.heading ? <h2 className="otu-heading--center">{props.heading}</h2> : null}
        {props.description ? <p className="otu-prose--center">{props.description}</p> : null}
        <div className="otu-contact__inline">
          {props.phone ? (
            <a href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
              <Icon name="phone" size={16} /> {props.phone}
            </a>
          ) : null}
          {props.email ? (
            <a href={`mailto:${props.email}`}>
              <Icon name="mail" size={16} /> {props.email}
            </a>
          ) : null}
          {props.address ? (
            <span>
              <Icon name="map-pin" size={16} /> {props.address}
            </span>
          ) : null}
        </div>
      </Container>
    </SectionShell>
  );
}
