import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "contact-info",
  name: "Contact",
  category: "Contact",
  description: "Five ways to display contact information (no form) — distinct from the Forms category.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Cards row", "Split with image", "Centered intro", "Team picker", "Full-bleed banner"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Get in touch", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "We'd love to hear from you", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media" },
    { type: "text", id: "phone", label: "Phone", default: "+1 (555) 010-2030", group: "Content" },
    { type: "text", id: "email", label: "Email", default: "hello@example.com", group: "Content" },
    { type: "text", id: "address", label: "Address", default: "400 Michigan Ave, Chicago, IL 60611", group: "Content" },
    { type: "text", id: "hours", label: "Hours", default: "Mon–Fri, 9am–6pm", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "person", name: "Contact person (team picker design)", settings: [
      { type: "image", id: "image", label: "Photo" },
      { type: "text", id: "name", label: "Name", default: "Sofia Grant" },
      { type: "text", id: "focus", label: "Focus area", default: "New business & partnerships" },
      { type: "text", id: "email", label: "Email" },
    ] },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "person", settings: { name: "Sofia Grant", focus: "New business & partnerships", email: "sofia@example.com" } },
    { type: "person", settings: { name: "Marcus Webb", focus: "Existing client support", email: "marcus@example.com" } },
  ],
};

export default schema;
