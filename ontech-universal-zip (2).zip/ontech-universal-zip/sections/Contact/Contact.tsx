import * as React from "react";
import type { SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { ContactCardsRow } from "./variants/ContactCardsRow";
import { ContactSplitDetails } from "./variants/ContactSplitDetails";
import { ContactCenteredIntro } from "./variants/ContactCenteredIntro";
import { ContactTeamPicker } from "./variants/ContactTeamPicker";
import { ContactFullBleedBanner } from "./variants/ContactFullBleedBanner";

export interface ContactProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  image?: ThemeImage;
  phone?: string;
  email?: string;
  address?: string;
  hours?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<ContactProps>> = {
  v1: ContactCardsRow,
  v2: ContactSplitDetails,
  v3: ContactCenteredIntro,
  v4: ContactTeamPicker,
  v5: ContactFullBleedBanner,
};

/**
 * Contact — five ways to present contact information as its own
 * section (distinct from the Forms category — no <form> here, just
 * ways to display how to reach the business).
 * v1 Three contact-method cards · v2 Split details + image · v3
 * Centered intro with inline details · v4 "Pick who to contact" team
 * cards · v5 Full-bleed contact banner.
 */
export function Contact(props: ContactProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Contact;
