import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { FAQProps } from "../FAQ";

/** FAQ 02 — Two column. Questions split into two independent accordions side by side — fits more Q&A above the fold on wide screens. */
export function FaqTwoColumn(props: FAQProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.question), answer: asString(block.answer) }));
  const half = Math.ceil(items.length / 2);

  return (
    <SectionShell name="faq" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-faq__two-col">
          <Accordion items={items.slice(0, half)} exclusiveName="faq-col-a" />
          <Accordion items={items.slice(half)} exclusiveName="faq-col-b" />
        </div>
      </Container>
    </SectionShell>
  );
}
