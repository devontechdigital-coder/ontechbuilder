import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { RawBlock } from "../../../components/blockHelpers";
import type { FAQProps } from "../FAQ";

/** FAQ 04 — Categorized. Groups questions under their "category" field into labelled clusters — for FAQ pages with real breadth (pricing, support, security…). */
export function FaqCategorized(props: FAQProps) {
  const blocks = props.blocks ?? [];
  const groups = new Map<string, RawBlock[]>();
  blocks.forEach((block) => {
    const category = asString(block.category, "General");
    groups.set(category, [...(groups.get(category) ?? []), block]);
  });

  return (
    <SectionShell name="faq" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-faq__categorized">
          {Array.from(groups.entries()).map(([category, items]) => (
            <div key={category} className="otu-faq__category">
              <h3>{category}</h3>
              <Accordion
                items={items.map((block) => ({ id: block.id, question: asString(block.question), answer: asString(block.answer) }))}
                exclusiveName={`faq-cat-${category}`}
                markerStyle="chevron"
              />
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
