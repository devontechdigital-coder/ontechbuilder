import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { FAQProps } from "../FAQ";

/** FAQ 01 — Simple. One narrow centered accordion column. The default FAQ block. */
export function FaqSimple(props: FAQProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.question), answer: asString(block.answer) }));
  return (
    <SectionShell name="faq" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Accordion items={items} exclusiveName="faq-simple" />
      </Container>
    </SectionShell>
  );
}
