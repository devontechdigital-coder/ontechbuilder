import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Accordion } from "../../../components/Accordion";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import type { FAQProps } from "../FAQ";

/** FAQ 03 — Split with contact card. Accordion on the left, a "still have questions" card with a CTA pinned on the right. */
export function FaqSplitContact(props: FAQProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.question), answer: asString(block.answer) }));
  return (
    <SectionShell name="faq" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-faq__split">
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p className="otu-faq__split-desc">{props.description}</p> : null}
            <Accordion items={items} exclusiveName="faq-split" />
          </div>
          <div className="otu-faq__contact-card">
            <h3>{props.contactTitle || "Still have questions?"}</h3>
            <p>{props.contactText || "Our team is happy to walk through anything that's still unclear."}</p>
            <MaybeButton label={props.contactLabel || "Contact us"} href={props.contactHref || "/contact"} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
