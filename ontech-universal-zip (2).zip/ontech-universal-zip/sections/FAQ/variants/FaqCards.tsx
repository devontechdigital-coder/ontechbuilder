import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { FAQProps } from "../FAQ";

/** FAQ 05 — Cards. Each question is its own bordered, individually-elevated card rather than a joined list — reads less dense, more scannable. */
export function FaqCards(props: FAQProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.question), answer: asString(block.answer) }));
  return (
    <SectionShell name="faq" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Accordion items={items} markerStyle="arrow" className="otu-faq__cards" itemClassName="otu-faq__card" defaultOpen={-1} />
      </Container>
    </SectionShell>
  );
}
