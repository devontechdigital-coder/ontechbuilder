import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "faq",
  name: "FAQ",
  category: "FAQ",
  description: "Five accordion layouts, all on native <details> — no JS required for open/close.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Simple", "Two column", "Split + contact card", "Categorized", "Individual cards"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "FAQ", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Frequently asked questions", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "text", id: "contactTitle", label: "Contact card title", default: "Still have questions?", group: "Content", info: "Split + contact design only." },
    { type: "textarea", id: "contactText", label: "Contact card text", default: "Our team is happy to walk through anything that's still unclear.", group: "Content" },
    { type: "text", id: "contactLabel", label: "Contact button label", default: "Contact us", group: "Content" },
    { type: "url", id: "contactHref", label: "Contact button link", default: "/contact", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "faq", name: "Question", settings: [
      { type: "text", id: "question", label: "Question", default: "How long does a typical engagement take?" },
      { type: "textarea", id: "answer", label: "Answer", default: "Most engagements run 8–12 weeks from discovery to handover, though scope varies by project." },
      { type: "text", id: "category", label: "Category (advanced)", default: "General", info: "Categorized design only." },
    ] },
  ],
  maxBlocks: 16,
  defaultBlocks: [
    { type: "faq", settings: { question: "How long does a typical engagement take?", answer: "Most engagements run 8–12 weeks from discovery to handover, though scope varies by project.", category: "General" } },
    { type: "faq", settings: { question: "Do you work with early-stage companies?", answer: "Yes — we tailor scope and pricing for teams under 50 people.", category: "General" } },
    { type: "faq", settings: { question: "What does pricing look like?", answer: "We quote fixed-fee by project scope rather than open-ended hourly billing.", category: "Pricing" } },
    { type: "faq", settings: { question: "Can we cancel mid-engagement?", answer: "Yes, with 14 days' notice — there's no long-term lock-in.", category: "Pricing" } },
  ],
};

export default schema;
