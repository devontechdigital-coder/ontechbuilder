import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { FaqSimple } from "./variants/FaqSimple";
import { FaqTwoColumn } from "./variants/FaqTwoColumn";
import { FaqSplitContact } from "./variants/FaqSplitContact";
import { FaqCategorized } from "./variants/FaqCategorized";
import { FaqCards } from "./variants/FaqCards";

export interface FAQProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  contactTitle?: string;
  contactText?: string;
  contactLabel?: string;
  contactHref?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<FAQProps>> = {
  v1: FaqSimple,
  v2: FaqTwoColumn,
  v3: FaqSplitContact,
  v4: FaqCategorized,
  v5: FaqCards,
};

/**
 * FAQ — five layouts, all on the native <details> Accordion primitive.
 * v1 Simple single column · v2 Two-column split list · v3 Split with a
 * "still have questions" contact card · v4 Grouped by category ·
 * v5 Individual bordered cards instead of a joined list.
 */
export function FAQ(props: FAQProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default FAQ;
