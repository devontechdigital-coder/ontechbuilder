import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { MarqueeText } from "./variants/MarqueeText";
import { MarqueeLogos } from "./variants/MarqueeLogos";
import { MarqueeServices } from "./variants/MarqueeServices";
import { MarqueeBadges } from "./variants/MarqueeBadges";
import { MarqueeDualDirection } from "./variants/MarqueeDualDirection";

export interface MarqueeProps extends SectionBaseProps {
  heading?: string;
  text?: string;
  speed?: number;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<MarqueeProps>> = {
  v1: MarqueeText,
  v2: MarqueeLogos,
  v3: MarqueeServices,
  v4: MarqueeBadges,
  v5: MarqueeDualDirection,
};

/**
 * Marquee / Moving Content — five continuous-scroll treatments, all
 * pure CSS animation (transform + keyframes), pausing under
 * prefers-reduced-motion.
 * v1 Repeating text statement · v2 Logo marquee · v3 Service name
 * marquee with dividers · v4 Badge/tag pill marquee · v5 Two rows
 * scrolling in opposite directions.
 */
export function Marquee(props: MarqueeProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Marquee;
