import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "marquee",
  name: "Marquee / Moving Content",
  category: "Marquee",
  description: "Five continuous-scroll treatments, pure CSS animation, always paused under prefers-reduced-motion.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Text statement", "Logo strip", "Service names", "Badge/tag pills", "Dual direction"]), default: "v1", group: "Layout" },
    { type: "text", id: "heading", label: "Heading / label", default: "Trusted by growing teams", group: "Content" },
    { type: "text", id: "text", label: "Repeating text", default: "Strategy · Delivery · Results", group: "Content", info: "Text statement design only." },
    { type: "range", id: "speed", label: "Scroll duration", min: 10, max: 90, step: 5, unit: "s", default: 30, group: "Behaviour", info: "Higher = slower." },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "item", name: "Item", settings: [
      { type: "text", id: "label", label: "Label", default: "Strategy" },
      { type: "image", id: "image", label: "Logo image", info: "Logo strip design only." },
    ] },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "item", settings: { label: "Strategy" } },
    { type: "item", settings: { label: "Delivery" } },
    { type: "item", settings: { label: "Analytics" } },
    { type: "item", settings: { label: "Change management" } },
    { type: "item", settings: { label: "M&A" } },
  ],
};

export default schema;
