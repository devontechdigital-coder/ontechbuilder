import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { asString, type RawBlock } from "../../../components/blockHelpers";
import type { MarqueeProps } from "../Marquee";

function Row({ items, reverse, speed }: { items: RawBlock[]; reverse?: boolean; speed?: number }) {
  const doubled = [...items, ...items];
  return (
    <div className={`otu-marquee${reverse ? " otu-marquee--reverse" : ""}`} style={speed ? ({ "--otu-marquee-duration": `${speed}s` } as React.CSSProperties) : undefined}>
      <div className="otu-marquee__track">
        {doubled.map((item, index) => (
          <span className="otu-marquee__pill" key={`${item.id}-${index}`} aria-hidden={index >= items.length}>
            {asString(item.label)}
          </span>
        ))}
      </div>
    </div>
  );
}

/** Marquee 05 — Dual direction. Two rows scroll opposite directions at slightly different speeds — the busiest, most visually dynamic of the five. */
export function MarqueeDualDirection(props: MarqueeProps) {
  const items = props.blocks ?? [];
  const half = Math.ceil(items.length / 2);
  return (
    <SectionShell name="marquee" {...props} padded className="otu-marquee-section otu-marquee-section--dual">
      <Row items={items.slice(0, half)} speed={props.speed} />
      <Row items={items.slice(half)} reverse speed={props.speed ? props.speed * 1.3 : undefined} />
    </SectionShell>
  );
}
