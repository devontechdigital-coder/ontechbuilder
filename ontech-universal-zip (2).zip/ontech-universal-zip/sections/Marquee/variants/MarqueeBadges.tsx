import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { MarqueeProps } from "../Marquee";

/** Marquee 04 — Badge/tag pills. Small rounded pill tags scroll continuously — for certifications, tech stack, or keyword tags. */
export function MarqueeBadges(props: MarqueeProps) {
  const items = props.blocks ?? [];
  const doubled = [...items, ...items];
  return (
    <SectionShell name="marquee" {...props} padded className="otu-marquee-section">
      <div className="otu-marquee" style={props.speed ? ({ "--otu-marquee-duration": `${props.speed}s` } as React.CSSProperties) : undefined}>
        <div className="otu-marquee__track">
          {doubled.map((item, index) => (
            <span className="otu-marquee__pill" key={`${item.id}-${index}`} aria-hidden={index >= items.length}>
              {asString(item.label)}
            </span>
          ))}
        </div>
      </div>
    </SectionShell>
  );
}
