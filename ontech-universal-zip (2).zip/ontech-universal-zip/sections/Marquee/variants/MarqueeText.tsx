import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import type { MarqueeProps } from "../Marquee";

/** Marquee 01 — Text statement. One short phrase repeats edge-to-edge with a small icon divider — a large, atmospheric banner line. */
export function MarqueeText(props: MarqueeProps) {
  const items = Array(8).fill(props.text || props.heading || "");
  return (
    <SectionShell name="marquee" {...props} padded className="otu-marquee-section">
      <div className="otu-marquee otu-marquee--text" style={props.speed ? ({ "--otu-marquee-duration": `${props.speed}s` } as React.CSSProperties) : undefined}>
        <div className="otu-marquee__track">
          {[...items, ...items].map((text, index) => (
            <span className="otu-marquee__item otu-marquee__item--text" key={index} aria-hidden={index >= items.length}>
              {text}
              <Icon name="spark" size={20} />
            </span>
          ))}
        </div>
      </div>
    </SectionShell>
  );
}
