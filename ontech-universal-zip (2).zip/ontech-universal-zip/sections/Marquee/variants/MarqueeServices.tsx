import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { MarqueeProps } from "../Marquee";

/** Marquee 03 — Service names. Service or capability names scroll with a bullet divider between each — a fast, textural way to list breadth of offering. */
export function MarqueeServices(props: MarqueeProps) {
  const items = props.blocks ?? [];
  const doubled = [...items, ...items];
  return (
    <SectionShell name="marquee" {...props} padded tone={props.tone ?? "dark"} className="otu-marquee-section">
      <div className="otu-marquee otu-marquee--reverse" style={props.speed ? ({ "--otu-marquee-duration": `${props.speed}s` } as React.CSSProperties) : undefined}>
        <div className="otu-marquee__track">
          {doubled.map((item, index) => (
            <span className="otu-marquee__item otu-marquee__item--service" key={`${item.id}-${index}`} aria-hidden={index >= items.length}>
              {asString(item.label)}
              <span aria-hidden="true">•</span>
            </span>
          ))}
        </div>
      </div>
    </SectionShell>
  );
}
