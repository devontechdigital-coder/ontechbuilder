import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { MarqueeProps } from "../Marquee";

/** Marquee 02 — Logo strip. Client/partner logos scroll continuously. (Overlaps in purpose with the Logo Cloud category's own marquee — offered here too as a standalone moving-content block.) */
export function MarqueeLogos(props: MarqueeProps) {
  const items = props.blocks ?? [];
  const doubled = [...items, ...items];
  return (
    <SectionShell name="marquee" {...props} padded className="otu-marquee-section">
      {props.heading ? <p className="otu-logos__heading otu-container otu-container--wide">{props.heading}</p> : null}
      <div className="otu-marquee" style={props.speed ? ({ "--otu-marquee-duration": `${props.speed}s` } as React.CSSProperties) : undefined}>
        <div className="otu-marquee__track">
          {doubled.map((item, index) => {
            const image = item.image as { src?: string; alt?: string } | undefined;
            return (
              <span className="otu-marquee__item" key={`${item.id}-${index}`} aria-hidden={index >= items.length}>
                {image?.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={image.src} alt={image.alt || asString(item.label, "Logo")} loading="lazy" />
                ) : (
                  asString(item.label, "Client")
                )}
              </span>
            );
          })}
        </div>
      </div>
    </SectionShell>
  );
}
