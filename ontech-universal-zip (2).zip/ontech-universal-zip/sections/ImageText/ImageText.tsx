import * as React from "react";
import type { AspectRatio, SectionBaseProps, ThemeImage } from "../../types";
import { ImageTextSplit } from "./variants/ImageTextSplit";
import { ImageTextOverlap } from "./variants/ImageTextOverlap";
import { ImageTextStackedCentered } from "./variants/ImageTextStackedCentered";
import { ImageTextFramed } from "./variants/ImageTextFramed";
import { ImageTextZigzag } from "./variants/ImageTextZigzag";

export interface ImageTextProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  body?: string;
  image?: ThemeImage;
  secondaryImage?: ThemeImage;
  imageRatio?: AspectRatio;
  imagePosition?: "left" | "right";
  ctaLabel?: string;
  ctaHref?: string;
}

const variants: Record<string, React.ComponentType<ImageTextProps>> = {
  v1: ImageTextSplit,
  v2: ImageTextOverlap,
  v3: ImageTextStackedCentered,
  v4: ImageTextFramed,
  v5: ImageTextZigzag,
};

/**
 * Image + Text — five compositions of one media block with one copy
 * block (the general two-up building block used across About, Services
 * detail, and marketing pages).
 * v1 Even split · v2 Overlapping images with copy behind · v3 Stacked,
 * centered, image below text · v4 Framed image with a border accent ·
 * v5 Two images in a zigzag with copy threaded between.
 */
export function ImageText(props: ImageTextProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} />;
}

export default ImageText;
