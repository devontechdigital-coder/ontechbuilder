import type { SectionSchema } from "../../config/settings.schema";
import { aspectOptions, baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "image-text",
  name: "Image + Text",
  category: "Image + Text",
  description: "Five compositions of one media block with one copy block: split, overlap, stacked, framed, zigzag.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Even split", "Overlapping images", "Stacked, centered", "Framed", "Zigzag pair"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our approach", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Strategy that survives contact with reality", group: "Content" },
    { type: "textarea", id: "description", label: "Short description", group: "Content" },
    { type: "richtext", id: "body", label: "Full copy (rich text)", group: "Content" },
    { type: "image", id: "image", label: "Main image", group: "Media" },
    { type: "image", id: "secondaryImage", label: "Secondary image", group: "Media", info: "Overlap and zigzag designs only." },
    { type: "select", id: "imageRatio", label: "Image ratio", options: aspectOptions, default: "4:3", group: "Media" },
    {
      type: "select",
      id: "imagePosition",
      label: "Image position",
      options: [
        { value: "left", label: "Left" },
        { value: "right", label: "Right" },
      ],
      default: "left",
      group: "Layout",
    },
    { type: "text", id: "ctaLabel", label: "Button label", group: "Content" },
    { type: "url", id: "ctaHref", label: "Button link", group: "Content" },
    ...baseSectionSettings(),
  ],
};

export default schema;
