import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import { MaybeButton } from "../../../components/ThemeButton";
import type { ImageTextProps } from "../ImageText";

/** Image + Text 02 — Overlap. Two images overlap diagonally on one side; the copy column sits behind/beside them for depth. */
export function ImageTextOverlap(props: ImageTextProps) {
  return (
    <SectionShell name="image-text" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-image-text__overlap">
          <div className="otu-image-text__overlap-media">
            <ThemeImage image={props.image} ratio="3:4" placeholderLabel="Image" className="otu-image-text__overlap-back" />
            <ThemeImage image={props.secondaryImage} ratio="1:1" placeholderLabel="Detail" className="otu-image-text__overlap-front" />
          </div>
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body ?? props.description} />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
