import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import { MaybeButton } from "../../../components/ThemeButton";
import type { ImageTextProps } from "../ImageText";

/** Image + Text 05 — Zigzag pair. Two images of different sizes stagger vertically on one side while copy runs the full height on the other. */
export function ImageTextZigzag(props: ImageTextProps) {
  return (
    <SectionShell name="image-text" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-image-text__zigzag">
          <div className="otu-image-text__zigzag-media">
            <ThemeImage image={props.image} ratio="3:4" placeholderLabel="Image" className="otu-image-text__zigzag-tall" />
            <ThemeImage image={props.secondaryImage} ratio="4:3" placeholderLabel="Image" className="otu-image-text__zigzag-wide" />
          </div>
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body ?? props.description} />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
