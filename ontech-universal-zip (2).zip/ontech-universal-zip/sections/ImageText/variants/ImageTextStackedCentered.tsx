import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import { MaybeButton } from "../../../components/ThemeButton";
import type { ImageTextProps } from "../ImageText";

/** Image + Text 03 — Stacked, centered. Narrow centered copy above a wide image beneath it — vertical rhythm instead of a side-by-side split. */
export function ImageTextStackedCentered(props: ImageTextProps) {
  return (
    <SectionShell name="image-text" {...props}>
      <Container width="narrow">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        {props.heading ? <h2 className="otu-heading--center">{props.heading}</h2> : null}
        <RichText value={props.body ?? props.description} className="otu-prose--center" />
        <div className="otu-image-text__stacked-actions">
          <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
        </div>
      </Container>
      <Container width="wide">
        <ThemeImage image={props.image} ratio={props.imageRatio ?? "21:9"} placeholderLabel="Image" />
      </Container>
    </SectionShell>
  );
}
