import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import { MaybeButton } from "../../../components/ThemeButton";
import { cn } from "../../../components/utils";
import type { ImageTextProps } from "../ImageText";

/** Image + Text 04 — Framed. The image sits inside a thick accent-colored border/frame offset from the copy — a more crafted, deliberate feel than a plain split. */
export function ImageTextFramed(props: ImageTextProps) {
  return (
    <SectionShell name="image-text" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className={cn("otu-image-text__framed", props.imagePosition === "right" && "otu-image-text__framed--reverse")}>
          <div className="otu-image-text__frame">
            <ThemeImage image={props.image} ratio={props.imageRatio ?? "1:1"} placeholderLabel="Image" />
          </div>
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body ?? props.description} />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
