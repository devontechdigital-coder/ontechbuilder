import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import { MaybeButton } from "../../../components/ThemeButton";
import { cn } from "../../../components/utils";
import type { ImageTextProps } from "../ImageText";

/** Image + Text 01 — Even split. Fifty-fifty columns, image position configurable. The default two-up block. */
export function ImageTextSplit(props: ImageTextProps) {
  return (
    <SectionShell name="image-text" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className={cn("otu-image-text__split", props.imagePosition === "right" && "otu-image-text__split--reverse")}>
          <ThemeImage image={props.image} ratio={props.imageRatio ?? "4:3"} placeholderLabel="Image" />
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body ?? props.description} />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
