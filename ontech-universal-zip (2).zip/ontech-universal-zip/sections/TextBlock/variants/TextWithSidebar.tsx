import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { RichText } from "../../../components/RichText";
import type { TextBlockProps } from "../TextBlock";

/** Text 03 — Sticky sidebar label beside a wider prose column. Suited to policy/legal/about pages. */
export function TextWithSidebar(props: TextBlockProps) {
  return (
    <SectionShell name="text" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <div className="otu-text__sidebar">
          <aside className="otu-text__sidebar-rail">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.sidebarLabel ? <h3>{props.sidebarLabel}</h3> : null}
            {props.sidebarText ? <p className="otu-text__sidebar-note">{props.sidebarText}</p> : null}
          </aside>
          <div className="otu-text__sidebar-main">
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body} html={props.bodyHtml} />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
