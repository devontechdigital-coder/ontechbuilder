import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { RichText } from "../../../components/RichText";
import type { TextBlockProps } from "../TextBlock";

/** Text 05 — Editorial article opening with a CSS drop cap on the first paragraph. */
export function TextDropcapArticle(props: TextBlockProps) {
  const paragraphs = (props.body ?? "").split(/\n{2,}/).filter((p) => p.trim());
  const [first, ...rest] = paragraphs;
  return (
    <SectionShell name="text" {...props}>
      <Container width="narrow">
        {props.heading ? <h2 className="otu-text__article-title">{props.heading}</h2> : null}
        {first ? <p className="otu-text__dropcap">{first}</p> : null}
        <RichText value={rest.join("\n\n")} html={props.bodyHtml} />
      </Container>
    </SectionShell>
  );
}
