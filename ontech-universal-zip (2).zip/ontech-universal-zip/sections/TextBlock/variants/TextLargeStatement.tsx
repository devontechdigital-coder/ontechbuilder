import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { HighlightedText } from "../../../components/SectionHeading";
import type { TextBlockProps } from "../TextBlock";

/** Text 04 — One oversized statement, no supporting body copy. For a mission line or a bold claim. */
export function TextLargeStatement(props: TextBlockProps) {
  return (
    <SectionShell name="text" {...props}>
      <Container width="wide">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        <p className="otu-text__statement">
          <HighlightedText text={props.heading ?? ""} />
        </p>
      </Container>
    </SectionShell>
  );
}
