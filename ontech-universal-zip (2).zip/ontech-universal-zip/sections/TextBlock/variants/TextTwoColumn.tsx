import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { RichText } from "../../../components/RichText";
import type { TextBlockProps } from "../TextBlock";

/** Text 02 — Heading in a fixed left column, running text in a wider right column. Magazine layout. */
export function TextTwoColumn(props: TextBlockProps) {
  return (
    <SectionShell name="text" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <div className="otu-text__two-col">
          <div className="otu-text__two-col-head">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
          </div>
          <RichText value={props.body} html={props.bodyHtml} className="otu-text__two-col-body" />
        </div>
      </Container>
    </SectionShell>
  );
}
