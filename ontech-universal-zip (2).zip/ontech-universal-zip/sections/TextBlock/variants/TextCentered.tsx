import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { RichText } from "../../../components/RichText";
import type { TextBlockProps } from "../TextBlock";

/** Text 01 — Centered, narrow measure. Classic readable prose block. */
export function TextCentered(props: TextBlockProps) {
  return (
    <SectionShell name="text" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} align="center" />
        <RichText value={props.body} html={props.bodyHtml} className="otu-prose--center" />
      </Container>
    </SectionShell>
  );
}
