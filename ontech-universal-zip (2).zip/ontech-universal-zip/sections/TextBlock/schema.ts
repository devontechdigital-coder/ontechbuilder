import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "text-block",
  name: "Text / Content",
  category: "Content",
  description: "Five prose compositions: centered, two-column, sidebar, large statement, drop-cap article.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Centered narrow", "Two-column magazine", "Sidebar + body", "Large statement", "Drop-cap article"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our approach", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Clarity before complexity", group: "Content" },
    { type: "textarea", id: "body", label: "Body copy", group: "Content", default: "We start every engagement by mapping how the business actually works today, not how the org chart says it should. That single discipline is why our recommendations get implemented instead of filed away.\n\nEvery deliverable is built to be used by the people who inherit it, not just the people who commissioned it." },
    { type: "text", id: "sidebarLabel", label: "Sidebar label", default: "Why it matters", group: "Content", info: "Sidebar design only." },
    { type: "text", id: "sidebarText", label: "Sidebar note", default: "Most transformation programs fail at handover, not at design.", group: "Content", info: "Sidebar design only." },
    ...baseSectionSettings(),
  ],
};

export default schema;
