import * as React from "react";
import type { ContentAlignment, SectionBaseProps } from "../../types";
import { TextCentered } from "./variants/TextCentered";
import { TextTwoColumn } from "./variants/TextTwoColumn";
import { TextWithSidebar } from "./variants/TextWithSidebar";
import { TextLargeStatement } from "./variants/TextLargeStatement";
import { TextDropcapArticle } from "./variants/TextDropcapArticle";

export interface TextBlockProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  body?: string;
  bodyHtml?: boolean;
  sidebarLabel?: string;
  sidebarText?: string;
  align?: ContentAlignment;
  columns?: 1 | 2;
}

const variants: Record<string, React.ComponentType<TextBlockProps>> = {
  v1: TextCentered,
  v2: TextTwoColumn,
  v3: TextWithSidebar,
  v4: TextLargeStatement,
  v5: TextDropcapArticle,
};

/**
 * Text / Content — five prose compositions.
 * v1 Centered narrow · v2 Two-column magazine · v3 Sidebar label + body ·
 * v4 Oversized single statement · v5 Drop-cap article opening.
 */
export function TextBlock(props: TextBlockProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} />;
}

export default TextBlock;
