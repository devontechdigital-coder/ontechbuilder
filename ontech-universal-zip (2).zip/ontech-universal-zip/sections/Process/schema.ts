import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "process",
  name: "Process / How It Works",
  category: "Process",
  description: "Five layouts for a genuinely ordered process: numbered rows, connected steps, dark panels, vertical track, card carousel.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Numbered rows", "Connected steps", "Dark panels", "Vertical track", "Card carousel"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "How we work", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Smart steps to business growth", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "text", id: "teaserText", label: "Closing teaser text", default: "Want to know what's possible?", group: "Content", info: "Dark panels design only." },
    { type: "text", id: "teaserLinkLabel", label: "Closing teaser link label", default: "Get in touch now", group: "Content" },
    { type: "url", id: "teaserLinkHref", label: "Closing teaser link", default: "/contact", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "step", name: "Step", settings: [
      { type: "text", id: "number", label: "Step number (advanced)", info: "Leave blank to auto-number." },
      { type: "text", id: "title", label: "Title", default: "Discovery" },
      { type: "textarea", id: "description", label: "Description", default: "We begin by listening closely to your challenges and goals through research and analysis." },
    ] },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "step", settings: { title: "Discovery", description: "We begin by listening closely to your challenges and goals." } },
    { type: "step", settings: { title: "Strategy", description: "We translate insight into a clear, actionable roadmap." } },
    { type: "step", settings: { title: "Execution", description: "Our consultants implement the plan with precision and pace." } },
    { type: "step", settings: { title: "Optimization", description: "We measure outcomes continuously and refine the approach." } },
  ],
};

export default schema;
