import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { asString } from "../../../components/blockHelpers";
import type { ProcessProps } from "../Process";

/** Process 05 — Card carousel. Each step is its own swipeable card, numbered — for a long or highly detailed process that would overwhelm a static grid. */
export function ProcessCardsCarousel(props: ProcessProps) {
  return (
    <SectionShell name="process" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Slider desktopItems={3} tabletItems={2} mobileItems={1.1} ariaLabel="Process steps">
          {(props.blocks ?? []).map((step, index) => (
            <div className="otu-process__card" key={step.id}>
              <span>{asString(step.number, String(index + 1).padStart(2, "0"))}</span>
              <h3>{asString(step.title)}</h3>
              <p>{asString(step.description)}</p>
            </div>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
