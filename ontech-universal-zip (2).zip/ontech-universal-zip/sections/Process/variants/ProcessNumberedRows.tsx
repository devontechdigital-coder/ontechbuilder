import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { ProcessProps } from "../Process";

/** Process 01 — Numbered rows. Large step numbers beside title and description, separated by hairlines. The default "how it works" layout. */
export function ProcessNumberedRows(props: ProcessProps) {
  return (
    <SectionShell name="process" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-process__rows">
          {(props.blocks ?? []).map((step, index) => (
            <div className="otu-process__row" key={step.id}>
              <span className="otu-process__number">{asString(step.number, String(index + 1).padStart(2, "0"))}</span>
              <h3>{asString(step.title)}</h3>
              <p>{asString(step.description)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
