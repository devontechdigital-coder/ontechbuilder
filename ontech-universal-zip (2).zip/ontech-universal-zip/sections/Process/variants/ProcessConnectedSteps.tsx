import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { ProcessProps } from "../Process";

/** Process 02 — Connected steps. Circular number badges linked by a horizontal (desktop) or vertical (mobile) connecting line — visualises the sequence directly. */
export function ProcessConnectedSteps(props: ProcessProps) {
  const items = props.blocks ?? [];
  return (
    <SectionShell name="process" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-process__connected">
          {items.map((step, index) => (
            <div className="otu-process__connected-step" key={step.id}>
              <div className="otu-process__connected-badge">
                <span>{index + 1}</span>
                {index < items.length - 1 ? <Icon name="arrow-right" size={16} className="otu-process__connected-arrow" /> : null}
              </div>
              <h3>{asString(step.title)}</h3>
              <p>{asString(step.description)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
