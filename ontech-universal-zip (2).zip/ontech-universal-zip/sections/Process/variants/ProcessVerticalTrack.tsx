import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { ProcessProps } from "../Process";

/** Process 04 — Vertical track. A left-hand progress line with filled dots marking each stage — reads like a project status tracker. */
export function ProcessVerticalTrack(props: ProcessProps) {
  return (
    <SectionShell name="process" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <ol className="otu-process__track">
          {(props.blocks ?? []).map((step, index) => (
            <li key={step.id}>
              <span className="otu-process__track-dot">{index + 1}</span>
              <h3>{asString(step.title)}</h3>
              <p>{asString(step.description)}</p>
            </li>
          ))}
        </ol>
      </Container>
    </SectionShell>
  );
}
