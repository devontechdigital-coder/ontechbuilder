import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import type { ProcessProps } from "../Process";

/** Process 03 — Dark panels. Steps as bordered panels on a dark section, closing with a teaser line and CTA — for a confident, high-contrast close. */
export function ProcessDarkPanels(props: ProcessProps) {
  return (
    <SectionShell name="process" {...props} tone={props.tone ?? "dark"}>
      <Container width={props.containerWidth ?? "wide"}>
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
        {props.heading ? <h2>{props.heading}</h2> : null}
        {props.description ? <p className="otu-process__intro">{props.description}</p> : null}

        <div className="otu-process__panels">
          {(props.blocks ?? []).map((step, index) => (
            <div className="otu-process__panel" key={step.id}>
              <span>{asString(step.number, String(index + 1).padStart(2, "0"))}</span>
              <h3>{asString(step.title)}</h3>
              <p>{asString(step.description)}</p>
            </div>
          ))}
        </div>

        {(props.teaserText || props.teaserLinkLabel) ? (
          <div className="otu-process__teaser">
            {props.teaserText ? <span>{props.teaserText}</span> : null}
            <MaybeButton label={props.teaserLinkLabel} href={props.teaserLinkHref} variant="light" iconName="arrow-right" />
          </div>
        ) : null}
      </Container>
    </SectionShell>
  );
}
