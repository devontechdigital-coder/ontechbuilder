import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { ProcessNumberedRows } from "./variants/ProcessNumberedRows";
import { ProcessConnectedSteps } from "./variants/ProcessConnectedSteps";
import { ProcessDarkPanels } from "./variants/ProcessDarkPanels";
import { ProcessVerticalTrack } from "./variants/ProcessVerticalTrack";
import { ProcessCardsCarousel } from "./variants/ProcessCardsCarousel";

export interface ProcessProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  teaserText?: string;
  teaserLinkLabel?: string;
  teaserLinkHref?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<ProcessProps>> = {
  v1: ProcessNumberedRows,
  v2: ProcessConnectedSteps,
  v3: ProcessDarkPanels,
  v4: ProcessVerticalTrack,
  v5: ProcessCardsCarousel,
};

/**
 * Process / How It Works — five ways to present a genuinely ordered
 * sequence. Numbering is appropriate here because the content is a real
 * process with a fixed order.
 * v1 Numbered rows · v2 Connected steps with a linking line · v3 Dark
 * panel steps with a closing teaser · v4 Vertical progress track ·
 * v5 Step-card carousel.
 */
export function Process(props: ProcessProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Process;
