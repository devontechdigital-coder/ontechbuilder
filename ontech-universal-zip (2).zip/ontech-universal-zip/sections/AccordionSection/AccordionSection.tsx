import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { AccordionSimpleList } from "./variants/AccordionSimpleList";
import { AccordionWithImage } from "./variants/AccordionWithImage";
import { AccordionNumbered } from "./variants/AccordionNumbered";
import { AccordionBordered } from "./variants/AccordionBordered";
import { AccordionCompactMeta } from "./variants/AccordionCompactMeta";

export interface AccordionSectionProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  image?: unknown;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<AccordionSectionProps>> = {
  v1: AccordionSimpleList,
  v2: AccordionWithImage,
  v3: AccordionNumbered,
  v4: AccordionBordered,
  v5: AccordionCompactMeta,
};

/**
 * Accordion — five general-purpose expandable-list layouts (distinct
 * from the FAQ category, which is question/answer specific). Suited to
 * policy details, product specs, service inclusions.
 * v1 Simple list · v2 Static image beside the accordion · v3 Numbered
 * items · v4 Individually bordered items · v5 Compact rows with a meta
 * label.
 */
export function AccordionSection(props: AccordionSectionProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default AccordionSection;
