import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { AccordionSectionProps } from "../AccordionSection";

/** Accordion 01 — Simple list. A plain joined accordion in a narrow column. */
export function AccordionSimpleList(props: AccordionSectionProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.title), answer: asString(block.text) }));
  return (
    <SectionShell name="accordion" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Accordion items={items} exclusiveName="accordion-simple" />
      </Container>
    </SectionShell>
  );
}
