import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { AccordionSectionProps } from "../AccordionSection";

/** Accordion 04 — Bordered. Each item is its own bordered card with independent spacing rather than a joined list. */
export function AccordionBordered(props: AccordionSectionProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.title), answer: asString(block.text) }));
  return (
    <SectionShell name="accordion" {...props}>
      <Container width="default">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Accordion items={items} markerStyle="plus" className="otu-accordion--bordered" itemClassName="otu-accordion__item--bordered" defaultOpen={-1} />
      </Container>
    </SectionShell>
  );
}
