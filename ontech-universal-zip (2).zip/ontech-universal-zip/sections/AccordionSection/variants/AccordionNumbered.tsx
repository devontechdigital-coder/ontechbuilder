import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { AccordionSectionProps } from "../AccordionSection";

/** Accordion 03 — Numbered. Each item is prefixed with its index — for a genuinely ordered checklist rather than free-standing Q&A. */
export function AccordionNumbered(props: AccordionSectionProps) {
  const items = (props.blocks ?? []).map((block, index) => ({
    id: block.id,
    question: `${String(index + 1).padStart(2, "0")} — ${asString(block.title)}`,
    answer: asString(block.text),
  }));
  return (
    <SectionShell name="accordion" {...props}>
      <Container width="default">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Accordion items={items} exclusiveName="accordion-numbered" markerStyle="chevron" />
      </Container>
    </SectionShell>
  );
}
