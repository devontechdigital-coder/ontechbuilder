"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { AccordionSectionProps } from "../AccordionSection";

/** Accordion 02 — With image. A static supporting image sits beside the accordion — for explaining product specs alongside a photo. */
export function AccordionWithImage(props: AccordionSectionProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.title), answer: asString(block.text) }));
  return (
    <SectionShell name="accordion" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-accordion-section__split">
          <ThemeImage image={props.image as never} ratio="4:3" placeholderLabel="Details" />
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <Accordion items={items} exclusiveName="accordion-image" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
