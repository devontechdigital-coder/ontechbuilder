import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Accordion } from "../../../components/Accordion";
import { asString } from "../../../components/blockHelpers";
import type { AccordionSectionProps } from "../AccordionSection";

/** Accordion 05 — Compact with meta. Each row shows a small meta label (e.g. a duration or category) inline before the marker — dense, spec-sheet style. */
export function AccordionCompactMeta(props: AccordionSectionProps) {
  const items = (props.blocks ?? []).map((block) => ({ id: block.id, question: asString(block.title), answer: asString(block.text), meta: asString(block.meta) }));
  return (
    <SectionShell name="accordion" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Accordion items={items} markerStyle="chevron" className="otu-accordion--compact" defaultOpen={-1} />
      </Container>
    </SectionShell>
  );
}
