import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "accordion",
  name: "Accordion",
  category: "Accordion",
  description: "Five general-purpose expandable-list layouts (specs, inclusions, policies) — distinct from the FAQ category.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Simple list", "With image", "Numbered", "Bordered cards", "Compact with meta"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Details", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "What's included", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media", info: "With-image design only." },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "item", name: "Item", settings: [
      { type: "text", id: "title", label: "Title", default: "Onboarding & discovery" },
      { type: "textarea", id: "text", label: "Text", default: "A structured two-week discovery phase covering stakeholder interviews and current-state mapping." },
      { type: "text", id: "meta", label: "Meta label (advanced)", default: "2 weeks", info: "Compact design only." },
    ] },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "item", settings: { title: "Onboarding & discovery", text: "A structured two-week discovery phase.", meta: "2 weeks" } },
    { type: "item", settings: { title: "Strategy sprint", text: "Workshops that produce a written 12-month plan.", meta: "3 weeks" } },
    { type: "item", settings: { title: "Implementation support", text: "Hands-on delivery alongside your team.", meta: "8 weeks" } },
  ],
};

export default schema;
