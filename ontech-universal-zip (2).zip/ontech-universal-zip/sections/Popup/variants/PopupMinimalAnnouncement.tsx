"use client";

import * as React from "react";
import { Modal, usePopupTrigger } from "../../../components/Modal";
import { MaybeButton } from "../../../components/ThemeButton";
import type { PopupProps } from "../Popup";

/** Popup 05 — Minimal announcement. A small, low-chrome bottom-corner card with just a line of text and one link — the lightest-weight of the five, closest to a toast. */
export function PopupMinimalAnnouncement(props: PopupProps) {
  const { open, close } = usePopupTrigger({
    delay: props.delay ?? 3,
    rememberDays: props.rememberDays ?? 1,
    storageKey: "otu-popup-minimal",
  });

  return (
    <Modal open={open} onClose={close} position={props.position ?? "bottom"} size={props.width ?? "sm"} showOverlay={false} ariaLabel={props.heading || "Announcement"}>
      <div className="otu-popup otu-popup--minimal">
        <p>{props.heading}</p>
        <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="link" size="sm" iconName="arrow-right" />
      </div>
    </Modal>
  );
}
