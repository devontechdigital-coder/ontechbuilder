"use client";

import * as React from "react";
import { Modal, usePopupTrigger } from "../../../components/Modal";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import type { PopupProps } from "../Popup";

/** Popup 02 — Consultation booking. Exit-intent triggered by default — a last-chance offer to book a call before the visitor leaves. */
export function PopupConsultation(props: PopupProps) {
  const { open, close } = usePopupTrigger({
    exitIntent: props.exitIntent ?? true,
    delay: props.delay ?? 0,
    rememberDays: props.rememberDays ?? 3,
    storageKey: "otu-popup-consultation",
  });

  return (
    <Modal open={open} onClose={close} position={props.position ?? "center"} size={props.width ?? "md"} ariaLabel={props.heading || "Book a consultation"}>
      <div className="otu-popup otu-popup--consult">
        <Icon name="calendar" size={28} />
        {props.heading ? <h3>{props.heading}</h3> : null}
        {props.description ? <p>{props.description}</p> : null}
        <MaybeButton label={props.ctaLabel || "Book a free consultation"} href={props.ctaHref} variant="primary" fullWidth iconName="arrow-right" />
      </div>
    </Modal>
  );
}
