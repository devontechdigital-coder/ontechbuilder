"use client";

import * as React from "react";
import { Modal, usePopupTrigger } from "../../../components/Modal";
import { ThemeForm, parseFields } from "../../../components/FormFields";
import { MaybeButton } from "../../../components/ThemeButton";
import type { PopupProps } from "../Popup";

/** Popup 01 — Lead capture. A centered card with a short form — the standard "get our guide" / newsletter popup. */
export function PopupLeadCapture(props: PopupProps) {
  const { open, close } = usePopupTrigger({
    delay: props.delay ?? 8,
    rememberDays: props.rememberDays ?? 7,
    storageKey: "otu-popup-lead-capture",
  });
  const fields = parseFields(props.blocks ?? []);

  return (
    <Modal open={open} onClose={close} position={props.position ?? "center"} size={props.width ?? "sm"} ariaLabel={props.heading || "Sign up"}>
      <div className="otu-popup otu-popup--lead">
        {props.heading ? <h3>{props.heading}</h3> : null}
        {props.description ? <p>{props.description}</p> : null}
        <ThemeForm fields={fields} actionUrl={props.actionUrl} idPrefix="popup-lead">
          <MaybeButton type="submit" label={props.ctaLabel || "Subscribe"} variant="primary" fullWidth />
        </ThemeForm>
      </div>
    </Modal>
  );
}
