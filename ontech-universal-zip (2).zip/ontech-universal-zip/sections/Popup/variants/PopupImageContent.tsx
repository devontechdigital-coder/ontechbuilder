"use client";

import * as React from "react";
import { Modal, usePopupTrigger } from "../../../components/Modal";
import { ThemeImage } from "../../../components/ThemeImage";
import { MaybeButton } from "../../../components/ThemeButton";
import type { PopupProps } from "../Popup";

/** Popup 04 — Image + content. A photo fills the left half of the card, copy and CTA on the right — for a richer, more editorial announcement. */
export function PopupImageContent(props: PopupProps) {
  const { open, close } = usePopupTrigger({
    delay: props.delay ?? 6,
    rememberDays: props.rememberDays ?? 7,
    storageKey: "otu-popup-image",
  });

  return (
    <Modal open={open} onClose={close} position={props.position ?? "center"} size={props.width ?? "lg"} ariaLabel={props.heading || "Announcement"}>
      <div className="otu-popup otu-popup--image">
        <ThemeImage image={props.image} ratio="auto" rounded={false} placeholderLabel="Announcement" />
        <div className="otu-popup--image-content">
          {props.heading ? <h3>{props.heading}</h3> : null}
          {props.description ? <p>{props.description}</p> : null}
          <MaybeButton label={props.ctaLabel || "Learn more"} href={props.ctaHref} variant="primary" />
        </div>
      </div>
    </Modal>
  );
}
