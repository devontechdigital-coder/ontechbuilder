"use client";

import * as React from "react";
import { Modal, usePopupTrigger } from "../../../components/Modal";
import { MaybeButton } from "../../../components/ThemeButton";
import type { PopupProps } from "../Popup";

/** Popup 03 — Promotional. A bold, tinted card for an offer or announcement, triggered by scroll depth rather than time or exit — appears once the visitor is engaged. */
export function PopupPromotional(props: PopupProps) {
  const { open, close } = usePopupTrigger({
    scrollPercent: props.scrollPercent ?? 50,
    rememberDays: props.rememberDays ?? 1,
    storageKey: "otu-popup-promo",
  });

  return (
    <Modal open={open} onClose={close} position={props.position ?? "bottom"} size={props.width ?? "sm"} ariaLabel={props.heading || "Offer"}>
      <div className="otu-popup otu-popup--promo">
        {props.heading ? <h3>{props.heading}</h3> : null}
        {props.description ? <p>{props.description}</p> : null}
        <MaybeButton label={props.ctaLabel || "Claim offer"} href={props.ctaHref} variant="primary" fullWidth />
      </div>
    </Modal>
  );
}
