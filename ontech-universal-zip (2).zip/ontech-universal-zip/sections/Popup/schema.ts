import type { SectionSchema } from "../../config/settings.schema";
import { variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "popup",
  name: "Popup / Modal",
  category: "Popups",
  placement: "overlay",
  description: "Five modal designs on a dependency-free, accessible dialog: lead capture, consultation, promotional, image + content, minimal announcement.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Lead capture form", "Consultation booking", "Promotional offer", "Image + content", "Minimal announcement"]), default: "v1", group: "Layout" },
    { type: "text", id: "heading", label: "Heading", default: "Get our free strategy guide", group: "Content" },
    { type: "textarea", id: "description", label: "Description", default: "A practical framework for planning your next 12 months, used with over 200 clients.", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media", info: "Image + content design only." },
    { type: "text", id: "ctaLabel", label: "Button label", default: "Get the guide", group: "Content" },
    { type: "url", id: "ctaHref", label: "Button link", group: "Content" },
    { type: "url", id: "actionUrl", label: "Form action URL", group: "Content", info: "Lead capture design only. Native POST." },
    {
      type: "select",
      id: "position",
      label: "Position",
      options: [
        { value: "center", label: "Center" },
        { value: "bottom", label: "Bottom" },
        { value: "top", label: "Top" },
        { value: "left", label: "Left" },
        { value: "right", label: "Right" },
      ],
      default: "center",
      group: "Layout",
    },
    {
      type: "select",
      id: "width",
      label: "Width",
      options: [
        { value: "sm", label: "Small" },
        { value: "md", label: "Medium" },
        { value: "lg", label: "Large" },
        { value: "full", label: "Full" },
      ],
      default: "sm",
      group: "Layout",
    },
    { type: "range", id: "delay", label: "Open after delay", min: 0, max: 60, step: 1, unit: "s", default: 6, group: "Trigger" },
    { type: "checkbox", id: "exitIntent", label: "Also open on exit intent", default: false, group: "Trigger", info: "Desktop pointer devices only." },
    { type: "range", id: "scrollPercent", label: "Also open after scrolling this far", min: 0, max: 100, step: 5, unit: "%", default: 0, group: "Trigger", info: "0 disables the scroll trigger." },
    { type: "range", id: "rememberDays", label: "Remember dismissal for", min: 0, max: 90, step: 1, unit: "days", default: 7, group: "Trigger", info: "0 shows the popup on every visit." },
  ],
  blocks: [
    { type: "field", name: "Form field (lead capture design)", settings: [
      { type: "text", id: "label", label: "Label", default: "Email address" },
      { type: "select", id: "fieldType", label: "Field type", options: [
        { value: "text", label: "Text" },
        { value: "email", label: "Email" },
      ], default: "email" },
      { type: "checkbox", id: "required", label: "Required", default: true },
    ] },
  ],
  maxBlocks: 4,
  defaultBlocks: [{ type: "field", settings: { label: "Email address", fieldType: "email", required: true } }],
};

export default schema;
