"use client";

import * as React from "react";
import type { SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { PopupLeadCapture } from "./variants/PopupLeadCapture";
import { PopupConsultation } from "./variants/PopupConsultation";
import { PopupPromotional } from "./variants/PopupPromotional";
import { PopupImageContent } from "./variants/PopupImageContent";
import { PopupMinimalAnnouncement } from "./variants/PopupMinimalAnnouncement";

export interface PopupProps extends SectionBaseProps {
  heading?: string;
  description?: string;
  image?: ThemeImage;
  ctaLabel?: string;
  ctaHref?: string;
  /** Native form action for popups that include a form. No JS submission. */
  actionUrl?: string;
  /** Seconds before the popup opens automatically. */
  delay?: number;
  /** Open when the pointer leaves the top of the viewport (desktop only). */
  exitIntent?: boolean;
  /** Open after this percentage of the page has been scrolled. */
  scrollPercent?: number;
  /** Days to remember a dismissal before showing again. 0 = every visit. */
  rememberDays?: number;
  position?: "center" | "bottom" | "top" | "left" | "right";
  width?: "sm" | "md" | "lg" | "full";
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<PopupProps>> = {
  v1: PopupLeadCapture,
  v2: PopupConsultation,
  v3: PopupPromotional,
  v4: PopupImageContent,
  v5: PopupMinimalAnnouncement,
};

/**
 * Popups — five modal designs, all built on the shared, dependency-free
 * Modal + usePopupTrigger primitives (focus trap, Escape to close,
 * scroll lock, and configurable delay/exit-intent/scroll triggers with
 * dismissal remembered locally).
 * v1 Lead-capture form · v2 Consultation booking · v3 Promotional offer
 * · v4 Image + content · v5 Minimal announcement/CTA.
 */
export function Popup(props: PopupProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Popup;
