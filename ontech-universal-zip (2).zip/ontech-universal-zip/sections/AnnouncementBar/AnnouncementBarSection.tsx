"use client";

import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { AnnouncementSimple } from "./variants/AnnouncementSimple";
import { AnnouncementPromoCta } from "./variants/AnnouncementPromoCta";
import { AnnouncementTicker } from "./variants/AnnouncementTicker";
import { AnnouncementCountdown } from "./variants/AnnouncementCountdown";
import { AnnouncementSplitSocial } from "./variants/AnnouncementSplitSocial";

export interface AnnouncementBarSectionProps extends SectionBaseProps {
  message?: string;
  ctaLabel?: string;
  ctaHref?: string;
  dismissible?: boolean;
  /** ISO date string. Countdown design only — no countdown library, just a plain interval. */
  countdownTarget?: string;
  countdownLabel?: string;
  phone?: string;
  email?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<AnnouncementBarSectionProps>> = {
  v1: AnnouncementSimple,
  v2: AnnouncementPromoCta,
  v3: AnnouncementTicker,
  v4: AnnouncementCountdown,
  v5: AnnouncementSplitSocial,
};

/**
 * Announcement Bars — five slim top-of-page banners.
 * v1 Simple centered notice · v2 Promo message + CTA · v3 Multi-message
 * ticker · v4 Countdown-ready structure (plain interval, no library) ·
 * v5 Split contact/social announcement.
 */
export function AnnouncementBarSection(props: AnnouncementBarSectionProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default AnnouncementBarSection;
