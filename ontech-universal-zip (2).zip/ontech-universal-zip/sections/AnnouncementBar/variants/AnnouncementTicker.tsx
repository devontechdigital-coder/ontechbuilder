import * as React from "react";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import { useDismiss } from "./useDismiss";
import type { AnnouncementBarSectionProps } from "../AnnouncementBarSection";

/** Announcement 03 — Multi-message ticker. Several messages ("message" blocks) scroll continuously in a CSS marquee — for rotating multiple short notices. */
export function AnnouncementTicker(props: AnnouncementBarSectionProps) {
  const { dismissed, dismiss } = useDismiss("otu-announce-ticker", props.dismissible ?? true);
  const messages = props.blocks ?? [];
  if (dismissed || messages.length === 0) return null;
  const doubled = [...messages, ...messages];

  return (
    <div className="otu-announce otu-announce--ticker" role="region" aria-label="Announcements">
      <div className="otu-marquee otu-marquee--bar">
        <div className="otu-marquee__track">
          {doubled.map((item, index) => (
            <span key={`${item.id}-${index}`} aria-hidden={index >= messages.length}>
              {asString(item.text)}
            </span>
          ))}
        </div>
      </div>
      {props.dismissible !== false ? (
        <button type="button" onClick={dismiss} aria-label="Dismiss announcement">
          <Icon name="close" size={14} />
        </button>
      ) : null}
    </div>
  );
}
