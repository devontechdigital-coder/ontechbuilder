import * as React from "react";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import { useDismiss } from "./useDismiss";
import type { AnnouncementBarSectionProps } from "../AnnouncementBarSection";

/** Announcement 05 — Split contact/social. Message on the left, phone/email and social icons on the right — a utility bar rather than a marketing message. */
export function AnnouncementSplitSocial(props: AnnouncementBarSectionProps) {
  const { dismissed, dismiss } = useDismiss("otu-announce-split", props.dismissible ?? false);
  if (dismissed) return null;

  return (
    <div className="otu-announce otu-announce--split" role="region" aria-label="Announcement">
      <p>{props.message}</p>
      <div className="otu-announce__split-right">
        {props.phone ? (
          <a href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
            <Icon name="phone" size={13} /> {props.phone}
          </a>
        ) : null}
        {props.email ? (
          <a href={`mailto:${props.email}`}>
            <Icon name="mail" size={13} /> {props.email}
          </a>
        ) : null}
        {(props.blocks ?? []).map((social) => {
          const href = safeHref(social.href as string);
          return href ? (
            <a key={social.id} href={href} aria-label={asString(social.label, "Social profile")}>
              <Icon name={asString(social.icon, "linkedin")} size={13} />
            </a>
          ) : null;
        })}
      </div>
      {props.dismissible ? (
        <button type="button" onClick={dismiss} aria-label="Dismiss announcement">
          <Icon name="close" size={14} />
        </button>
      ) : null}
    </div>
  );
}
