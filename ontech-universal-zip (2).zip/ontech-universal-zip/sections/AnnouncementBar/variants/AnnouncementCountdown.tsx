"use client";

import * as React from "react";
import { Icon } from "../../../components/Icon";
import { useDismiss } from "./useDismiss";
import type { AnnouncementBarSectionProps } from "../AnnouncementBarSection";

/**
 * Announcement 04 — Countdown-ready structure.
 * A plain `setInterval` ticks down to `countdownTarget` — no countdown
 * library. Renders nothing once the target has passed.
 */
function useCountdown(target?: string) {
  const [remaining, setRemaining] = React.useState<number | null>(null);
  React.useEffect(() => {
    if (!target) return;
    const targetTime = new Date(target).getTime();
    if (Number.isNaN(targetTime)) return;
    const tick = () => setRemaining(Math.max(0, targetTime - Date.now()));
    tick();
    const interval = window.setInterval(tick, 1000);
    return () => window.clearInterval(interval);
  }, [target]);
  return remaining;
}

function formatDuration(ms: number) {
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return { days, hours, minutes, seconds };
}

export function AnnouncementCountdown(props: AnnouncementBarSectionProps) {
  const { dismissed, dismiss } = useDismiss("otu-announce-countdown", props.dismissible ?? true);
  const remaining = useCountdown(props.countdownTarget);
  if (dismissed || remaining === null || remaining <= 0) return null;
  const { days, hours, minutes, seconds } = formatDuration(remaining);

  return (
    <div className="otu-announce otu-announce--countdown" role="region" aria-label="Announcement">
      <p>{props.countdownLabel || props.message}</p>
      <span className="otu-announce__countdown" aria-hidden="true">
        {days > 0 ? `${days}d ` : ""}
        {String(hours).padStart(2, "0")}:{String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
      </span>
      {props.dismissible !== false ? (
        <button type="button" onClick={dismiss} aria-label="Dismiss announcement">
          <Icon name="close" size={14} />
        </button>
      ) : null}
    </div>
  );
}
