import * as React from "react";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { useDismiss } from "./useDismiss";
import type { AnnouncementBarSectionProps } from "../AnnouncementBarSection";

/** Announcement 02 — Promo + CTA. Message and a small inline text-link CTA on one line — for a limited-time offer or new feature. */
export function AnnouncementPromoCta(props: AnnouncementBarSectionProps) {
  const { dismissed, dismiss } = useDismiss("otu-announce-promo", props.dismissible ?? true);
  if (dismissed || !props.message) return null;

  return (
    <div className="otu-announce otu-announce--promo" role="region" aria-label="Announcement">
      <p>
        {props.message} <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="link" size="sm" iconName="arrow-right" />
      </p>
      {props.dismissible !== false ? (
        <button type="button" onClick={dismiss} aria-label="Dismiss announcement">
          <Icon name="close" size={14} />
        </button>
      ) : null}
    </div>
  );
}
