import * as React from "react";
import { Icon } from "../../../components/Icon";
import { useDismiss } from "./useDismiss";
import type { AnnouncementBarSectionProps } from "../AnnouncementBarSection";

/** Announcement 01 — Simple. One centered line of text, optionally dismissible. The lightest-weight top bar. */
export function AnnouncementSimple(props: AnnouncementBarSectionProps) {
  const { dismissed, dismiss } = useDismiss("otu-announce-simple", props.dismissible ?? true);
  if (dismissed || !props.message) return null;

  return (
    <div className="otu-announce otu-announce--simple" role="region" aria-label="Announcement">
      <p>{props.message}</p>
      {props.dismissible !== false ? (
        <button type="button" onClick={dismiss} aria-label="Dismiss announcement">
          <Icon name="close" size={14} />
        </button>
      ) : null}
    </div>
  );
}
