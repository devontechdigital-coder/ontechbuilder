"use client";

import * as React from "react";

/** Shared "dismiss and remember for this session" behaviour for every announcement design. */
export function useDismiss(storageKey: string, dismissible: boolean) {
  const [dismissed, setDismissed] = React.useState(false);

  React.useEffect(() => {
    if (!dismissible) return;
    try {
      if (window.sessionStorage.getItem(storageKey) === "1") setDismissed(true);
    } catch {
      /* storage unavailable — bar just doesn't remember dismissal this session */
    }
  }, [dismissible, storageKey]);

  const dismiss = React.useCallback(() => {
    setDismissed(true);
    try {
      window.sessionStorage.setItem(storageKey, "1");
    } catch {
      /* ignore */
    }
  }, [storageKey]);

  return { dismissed, dismiss };
}
