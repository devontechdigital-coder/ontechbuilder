import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "announcement-bar",
  name: "Announcement Bar",
  category: "Announcement Bars",
  placement: "header",
  description: "Five slim top-of-page banners: simple, promo + CTA, ticker, countdown, split contact/social.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Simple centered notice", "Promo + CTA", "Multi-message ticker", "Countdown", "Split contact/social"]), default: "v1", group: "Layout" },
    { type: "text", id: "message", label: "Message", default: "Free strategy consultations available this month — limited slots.", group: "Content" },
    { type: "text", id: "ctaLabel", label: "CTA label", default: "Book now", group: "Content", info: "Promo + CTA design only." },
    { type: "url", id: "ctaHref", label: "CTA link", default: "/contact", group: "Content" },
    { type: "checkbox", id: "dismissible", label: "Allow dismissing", default: true, group: "Behaviour", info: "Remembered for the browser session." },
    { type: "text", id: "countdownTarget", label: "Countdown target (ISO date)", default: "2026-12-31T23:59:59", group: "Countdown", info: "Countdown design only, e.g. 2026-12-31T23:59:59." },
    { type: "text", id: "countdownLabel", label: "Countdown label", default: "Offer ends in", group: "Countdown" },
    { type: "text", id: "phone", label: "Phone", group: "Split design" },
    { type: "text", id: "email", label: "Email", group: "Split design" },
  ],
  blocks: [
    { type: "message", name: "Ticker message", settings: [{ type: "text", id: "text", label: "Text", default: "Now accepting new clients for Q1" }] },
    { type: "social", name: "Social link (split design)", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "linkedin" },
      { type: "text", id: "label", label: "Accessible label", default: "LinkedIn" },
      { type: "url", id: "href", label: "Profile URL" },
    ] },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "message", settings: { text: "Free strategy consultations available this month" } },
    { type: "message", settings: { text: "Now accepting new clients for Q1" } },
  ],
};

export default schema;
