import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString, blocksOfType } from "../../../components/blockHelpers";
import { Icon } from "../../../components/Icon";
import type { HeroProps } from "../Hero";
import { HeroActions, HeroBadge, HeroCopy } from "../heroParts";

/**
 * Hero 05 — Bento composition.
 * Headline and actions sit in the largest tile of a bento grid; the
 * remaining tiles hold the main image, a secondary image and a set of
 * small stat/feature cards from the "card" blocks. The most visually
 * dense of the five — reads as a product/company overview at a glance.
 */
export function HeroBento(props: HeroProps) {
  const cards = blocksOfType(props.blocks ?? [], "card").slice(0, 2);

  return (
    <SectionShell name="hero" {...props} padded>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-hero__bento">
          <div className="otu-hero__bento-main otu-bento-tile">
            <HeroBadge props={props} />
            <HeroCopy props={props} />
            <HeroActions props={props} />
          </div>

          <div className="otu-hero__bento-image otu-bento-tile otu-bento-tile--media">
            <ThemeImage image={props.image} ratio="auto" priority />
          </div>

          {props.secondaryImage?.src ? (
            <div className="otu-hero__bento-secondary otu-bento-tile otu-bento-tile--media">
              <ThemeImage image={props.secondaryImage} ratio="auto" />
            </div>
          ) : null}

          {cards.map((card) => (
            <div key={card.id} className="otu-hero__bento-card otu-bento-tile">
              <Icon name={asString(card.icon, "spark")} size={22} />
              <p className="otu-hero__bento-card-value">{asString(card.value)}</p>
              <p className="otu-hero__bento-card-label">{asString(card.label)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
