import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { VideoFrame } from "../../../components/VideoFrame";
import { ThemeImage } from "../../../components/ThemeImage";
import type { HeroProps } from "../Hero";
import { HeroActions, HeroBadge, HeroCopy, HeroStats, HeroTrust } from "../heroParts";

/**
 * Hero 02 — Full-bleed visual.
 * Background image or video fills the section; content sits on a
 * gradient scrim. Tallest and most visual of the five — built to pair
 * with Header 03 (transparent overlay).
 */
export function HeroFullBleed(props: HeroProps) {
  const hasVideo = Boolean(props.video?.src || props.video?.embedUrl);
  return (
    <SectionShell name="hero" {...props} padded={false} className={`otu-hero--height-${props.height ?? "tall"}`}>
      <div className="otu-hero__backdrop">
        {hasVideo ? (
          <VideoFrame video={props.video} poster={props.backgroundImage ?? props.image} ratio="auto" autoplay muted loop controls={false} rounded={false} />
        ) : (
          <ThemeImage image={props.backgroundImage ?? props.image} ratio="auto" rounded={false} priority />
        )}
        <div className="otu-hero__scrim" style={props.overlayOpacity !== undefined ? ({ "--otu-scrim-opacity": props.overlayOpacity } as React.CSSProperties) : undefined} />
      </div>

      <Container width={props.containerWidth ?? "wide"} className="otu-hero__overlay-content">
        <div className={`otu-hero__stack otu-hero__stack--${props.align ?? "left"}`}>
          <HeroBadge props={props} />
          <HeroCopy props={props} />
          <HeroActions props={props} secondaryVariant="light" />
          <HeroStats blocks={props.blocks ?? []} className="otu-hero__stats--inline" />
          <HeroTrust props={props} />
        </div>
      </Container>
    </SectionShell>
  );
}
