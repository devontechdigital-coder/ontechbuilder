import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import type { HeroProps } from "../Hero";
import { HeroActions, HeroCopy, HeroNote } from "../heroParts";

/**
 * Hero 04 — Editorial.
 * Oversized asymmetric headline running behind an offset image, with
 * copy displaced to a narrow column below. Magazine-like composition
 * for agencies and brand-forward sites that want less "template" feel.
 */
export function HeroEditorial(props: HeroProps) {
  return (
    <SectionShell name="hero" {...props} padded>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-hero__editorial">
          <div className="otu-hero__editorial-head">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            <h1 className="otu-hero__editorial-title">{props.heading}</h1>
          </div>

          <div className="otu-hero__editorial-media">
            <ThemeImage image={props.image} mobileImage={props.mobileImage} ratio={props.imageRatio ?? "3:4"} priority />
            <HeroNote props={props} />
          </div>

          <div className="otu-hero__editorial-foot">
            <HeroCopy props={{ ...props, heading: undefined, eyebrow: undefined }} />
            <HeroActions props={props} />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
