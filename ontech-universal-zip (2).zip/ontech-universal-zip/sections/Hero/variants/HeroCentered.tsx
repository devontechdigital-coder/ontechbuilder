import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import type { HeroProps } from "../Hero";
import { HeroActions, HeroBadge, HeroCopy, HeroLogos, HeroTrust } from "../heroParts";

/**
 * Hero 03 — Centered SaaS hero.
 * Everything on one vertical axis: badge, headline, actions, trust row,
 * then a wide product visual beneath. The default "announcement,
 * headline, screenshot" shape SaaS and startup sites expect.
 */
export function HeroCentered(props: HeroProps) {
  return (
    <SectionShell name="hero" {...props} padded>
      <Container width={props.containerWidth === "full" ? "wide" : props.containerWidth ?? "default"}>
        <div className="otu-hero__centered">
          <HeroBadge props={props} />
          <HeroCopy props={props} />
          <HeroActions props={props} />
          <HeroTrust props={props} />
        </div>
      </Container>

      {props.image?.src || props.video ? (
        <Container width={props.containerWidth === "narrow" ? "default" : props.containerWidth ?? "wide"}>
          <div className="otu-hero__showcase">
            <ThemeImage image={props.image} mobileImage={props.mobileImage} ratio={props.imageRatio ?? "16:9"} priority />
          </div>
        </Container>
      ) : null}

      <Container width="wide">
        <HeroLogos blocks={props.blocks ?? []} label={props.trustLabel} />
      </Container>
    </SectionShell>
  );
}
