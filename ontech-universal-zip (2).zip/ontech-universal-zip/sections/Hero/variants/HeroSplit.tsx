import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { cn } from "../../../components/utils";
import type { HeroProps } from "../Hero";
import { HeroActions, HeroBadge, HeroBullets, HeroCopy, HeroLogos, HeroNote, HeroTrust } from "../heroParts";

/**
 * Hero 01 — Split.
 * Content left, media right (or reversed), with a floating note card
 * overlapping the image corner. The dependable two-column workhorse —
 * suits consulting, SaaS, professional services.
 */
export function HeroSplit(props: HeroProps) {
  const reversed = props.align === "right";
  return (
    <SectionShell name="hero" {...props} padded>
      <Container width={props.containerWidth ?? "wide"}>
        <div className={cn("otu-hero__split", reversed && "otu-hero__split--reverse")}>
          <div className="otu-hero__content">
            <HeroBadge props={props} />
            <HeroCopy props={props} />
            <HeroActions props={props} />
            <HeroBullets blocks={props.blocks ?? []} />
            <HeroTrust props={props} />
          </div>

          <div className="otu-hero__media">
            <ThemeImage image={props.image} mobileImage={props.mobileImage} ratio={props.imageRatio ?? "4:3"} priority />
            <HeroNote props={props} />
          </div>
        </div>

        <HeroLogos blocks={props.blocks ?? []} label={props.trustLabel && !props.ratingCount ? undefined : "Trusted by"} />
      </Container>
    </SectionShell>
  );
}
