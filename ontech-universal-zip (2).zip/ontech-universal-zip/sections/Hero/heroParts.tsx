import * as React from "react";
import { Badge, Rating } from "../../components/Badge";
import { MaybeButton } from "../../components/ThemeButton";
import { HighlightedText } from "../../components/SectionHeading";
import { asString, blocksOfType, type RawBlock } from "../../components/blockHelpers";
import { Icon } from "../../components/Icon";
import type { HeroProps } from "./Hero";

/** Small pieces every hero design reuses, so the five variants stay purely about composition. */

export function HeroBadge({ props }: { props: HeroProps }) {
  if (!props.badgeLabel) return null;
  return (
    <Badge tone="accent" size="md" iconName={props.badgeIcon || "spark"} className="otu-hero__badge">
      {props.badgeLabel}
    </Badge>
  );
}

export function HeroCopy({ props, headingTag = "h1" }: { props: HeroProps; headingTag?: "h1" | "h2" }) {
  const Tag = headingTag as React.ElementType;
  return (
    <>
      {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
      {props.heading ? (
        <Tag className="otu-hero__heading">
          <HighlightedText text={props.heading} />
        </Tag>
      ) : null}
      {props.description ? <p className="otu-hero__description">{props.description}</p> : null}
    </>
  );
}

export function HeroActions({ props, secondaryVariant = "outline" }: { props: HeroProps; secondaryVariant?: "outline" | "ghost" | "light" }) {
  if (!props.primaryCtaLabel && !props.secondaryCtaLabel) return null;
  return (
    <div className="otu-hero__actions">
      <MaybeButton label={props.primaryCtaLabel} href={props.primaryCtaHref} variant="primary" size="lg" iconName="arrow-right" />
      <MaybeButton label={props.secondaryCtaLabel} href={props.secondaryCtaHref} variant={secondaryVariant} size="lg" />
    </div>
  );
}

/** Rating + short trust label. Renders nothing unless there's something to say. */
export function HeroTrust({ props }: { props: HeroProps }) {
  if (!props.trustLabel && !props.ratingCount) return null;
  return (
    <div className="otu-hero__trust">
      {props.ratingValue ? <Rating value={props.ratingValue} count={props.ratingCount} showValue /> : null}
      {props.trustLabel ? <span className="otu-hero__trust-label">{props.trustLabel}</span> : null}
    </div>
  );
}

export function HeroStats({ blocks, className }: { blocks: RawBlock[]; className?: string }) {
  const stats = blocksOfType(blocks, "stat");
  if (stats.length === 0) return null;
  return (
    <dl className={`otu-hero__stats ${className ?? ""}`.trim()}>
      {stats.map((stat) => (
        <div key={stat.id} className="otu-hero__stat">
          <dt>{asString(stat.value)}</dt>
          <dd>{asString(stat.label)}</dd>
        </div>
      ))}
    </dl>
  );
}

export function HeroBullets({ blocks }: { blocks: RawBlock[] }) {
  const bullets = blocksOfType(blocks, "bullet");
  if (bullets.length === 0) return null;
  return (
    <ul className="otu-hero__bullets">
      {bullets.map((bullet) => (
        <li key={bullet.id}>
          <Icon name={asString(bullet.icon, "check-circle")} size={18} />
          {asString(bullet.label)}
        </li>
      ))}
    </ul>
  );
}

/** Client-logo strip used by the centered and split heroes. */
export function HeroLogos({ blocks, label }: { blocks: RawBlock[]; label?: string }) {
  const logos = blocksOfType(blocks, "logo");
  if (logos.length === 0) return null;
  return (
    <div className="otu-hero__logos">
      {label ? <p className="otu-hero__logos-label">{label}</p> : null}
      <ul>
        {logos.map((logo) => {
          const image = logo.image as { src?: string; alt?: string } | undefined;
          return (
            <li key={logo.id}>
              {image?.src ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={image.src} alt={image.alt || asString(logo.name, "Client logo")} loading="lazy" />
              ) : (
                <span>{asString(logo.name, "Client")}</span>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/** The small floating note card that overlaps hero media in designs 1 and 4. */
export function HeroNote({ props }: { props: HeroProps }) {
  if (!props.noteTitle && !props.noteText) return null;
  return (
    <figure className="otu-hero__note">
      <Icon name="quote" size={22} className="otu-hero__note-icon" />
      {props.noteText ? <blockquote>{props.noteText}</blockquote> : null}
      {props.noteTitle ? <figcaption>{props.noteTitle}</figcaption> : null}
    </figure>
  );
}
