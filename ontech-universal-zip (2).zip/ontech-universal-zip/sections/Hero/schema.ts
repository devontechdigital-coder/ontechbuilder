import type { SectionSchema } from "../../config/settings.schema";
import { aspectOptions, alignOptions, containerOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "hero",
  name: "Hero banner",
  category: "Hero",
  description: "Five opening compositions: split, full-bleed, centered SaaS, editorial, and bento.",
  settings: [
    {
      type: "select",
      id: "variant",
      label: "Design",
      options: variantOptions(["Split content/media", "Full-bleed visual", "Centered SaaS hero", "Editorial", "Bento composition"]),
      default: "v1",
      group: "Layout",
    },

    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Business Consulting", group: "Content" },
    { type: "text", id: "badgeLabel", label: "Badge label", default: "Rated 4.9/5 by 400+ clients", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Driving business growth through {expert strategy}", group: "Content", info: "Wrap words in {braces} to accent them." },
    { type: "textarea", id: "description", label: "Description", default: "Unlock your company's full potential with tailored guidance, proven frameworks, and measurable results from senior consultants.", group: "Content" },
    { type: "text", id: "primaryCtaLabel", label: "Primary button label", default: "Book a consultation", group: "Content" },
    { type: "url", id: "primaryCtaHref", label: "Primary button link", default: "/contact", group: "Content" },
    { type: "text", id: "secondaryCtaLabel", label: "Secondary button label", default: "See our work", group: "Content" },
    { type: "url", id: "secondaryCtaHref", label: "Secondary button link", default: "/portfolio", group: "Content" },

    { type: "image", id: "image", label: "Main image", group: "Media" },
    { type: "image", id: "mobileImage", label: "Mobile image", group: "Media" },
    { type: "image", id: "secondaryImage", label: "Secondary image", group: "Media", info: "Bento design only." },
    { type: "image", id: "backgroundImage", label: "Background image", group: "Media", info: "Full-bleed design only." },
    { type: "video", id: "video", label: "Background or showcase video", group: "Media" },
    { type: "select", id: "imageRatio", label: "Image aspect ratio", options: aspectOptions, default: "4:3", group: "Media" },
    { type: "range", id: "overlayOpacity", label: "Overlay darkness", min: 0, max: 0.85, step: 0.05, default: 0.45, group: "Media", info: "Full-bleed design only." },

    { type: "text", id: "noteTitle", label: "Floating note attribution", default: "Sofia Grant, Director of Strategy", group: "Content" },
    { type: "textarea", id: "noteText", label: "Floating note quote", default: "The team helped us shape a strategy that actually stuck.", group: "Content" },

    { type: "text", id: "trustLabel", label: "Trust label", default: "Trusted by teams at", group: "Trust" },
    { type: "range", id: "ratingValue", label: "Rating value", min: 0, max: 5, step: 0.1, default: 4.9, group: "Trust" },
    { type: "text", id: "ratingCount", label: "Rating count text", default: "from 420 reviews", group: "Trust" },

    { type: "select", id: "align", label: "Content alignment", options: alignOptions, default: "left", group: "Layout" },
    {
      type: "select",
      id: "height",
      label: "Section height",
      options: [
        { value: "auto", label: "Auto (content height)" },
        { value: "medium", label: "Medium" },
        { value: "tall", label: "Tall" },
        { value: "screen", label: "Full screen" },
      ],
      default: "auto",
      group: "Layout",
      info: "Full-bleed design only.",
    },
    { type: "select", id: "containerWidth", label: "Container width", options: containerOptions, default: "wide", group: "Layout" },
  ],
  blocks: [
    { type: "stat", name: "Stat", settings: [
      { type: "text", id: "value", label: "Value", default: "260+" },
      { type: "text", id: "label", label: "Label", default: "Companies transformed" },
    ] },
    { type: "bullet", name: "Bullet point", settings: [
      { type: "icon", id: "icon", label: "Icon", default: "check-circle" },
      { type: "text", id: "label", label: "Label", default: "No long-term contracts" },
    ] },
    { type: "logo", name: "Trust logo", settings: [
      { type: "text", id: "name", label: "Company name", default: "Client" },
      { type: "image", id: "image", label: "Logo image" },
    ] },
    { type: "card", name: "Bento stat card", settings: [
      { type: "icon", id: "icon", label: "Icon", default: "trending-up" },
      { type: "text", id: "value", label: "Value", default: "95%" },
      { type: "text", id: "label", label: "Label", default: "Client satisfaction" },
    ] },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "bullet", settings: { icon: "check-circle", label: "No long-term lock-in" } },
    { type: "bullet", settings: { icon: "check-circle", label: "Dedicated senior consultant" } },
    { type: "bullet", settings: { icon: "check-circle", label: "Results within 90 days" } },
  ],
};

export default schema;
