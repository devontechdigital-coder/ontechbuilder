import * as React from "react";
import type { AspectRatio, ContentAlignment, SectionBaseProps, ThemeImage, ThemeVideo } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { HeroSplit } from "./variants/HeroSplit";
import { HeroFullBleed } from "./variants/HeroFullBleed";
import { HeroCentered } from "./variants/HeroCentered";
import { HeroEditorial } from "./variants/HeroEditorial";
import { HeroBento } from "./variants/HeroBento";

export interface HeroProps extends SectionBaseProps {
  eyebrow?: string;
  badgeLabel?: string;
  badgeIcon?: string;
  /** Wrap words in {braces} to accent them. */
  heading?: string;
  description?: string;
  primaryCtaLabel?: string;
  primaryCtaHref?: string;
  secondaryCtaLabel?: string;
  secondaryCtaHref?: string;

  image?: ThemeImage;
  mobileImage?: ThemeImage;
  secondaryImage?: ThemeImage;
  tertiaryImage?: ThemeImage;
  backgroundImage?: ThemeImage;
  video?: ThemeVideo;
  imageRatio?: AspectRatio;

  overlayOpacity?: number;
  height?: "auto" | "medium" | "tall" | "screen";
  align?: ContentAlignment;
  mobileAlign?: ContentAlignment;
  contentWidth?: "narrow" | "default" | "wide";

  trustLabel?: string;
  ratingValue?: number;
  ratingCount?: string;
  noteTitle?: string;
  noteText?: string;

  /** Mixed blocks: "stat", "bullet", "logo", "card". */
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<HeroProps>> = {
  v1: HeroSplit,
  v2: HeroFullBleed,
  v3: HeroCentered,
  v4: HeroEditorial,
  v5: HeroBento,
};

/**
 * Hero — five distinct opening compositions.
 *
 * v1 Split content/media · v2 Full-bleed media with overlay ·
 * v3 Centered product hero with trust row · v4 Asymmetric editorial ·
 * v5 Bento composition.
 */
export function Hero(props: HeroProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Hero;
