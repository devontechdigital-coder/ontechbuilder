import type { SectionSchema } from "../../config/settings.schema";
import { aspectOptions, baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "video",
  name: "Video",
  category: "Video",
  description: "Five video presentations on native <video>/<iframe> — no player dependency.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Centered", "Split with copy", "Full-bleed background", "Floating card", "Minimal inline"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Watch", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "See how we work", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "video", id: "video", label: "Video", group: "Media" },
    { type: "image", id: "poster", label: "Poster image", group: "Media" },
    { type: "select", id: "ratio", label: "Aspect ratio", options: aspectOptions, default: "16:9", group: "Media" },
    { type: "checkbox", id: "autoplay", label: "Autoplay (muted)", default: false, group: "Media" },
    { type: "checkbox", id: "muted", label: "Muted", default: true, group: "Media" },
    { type: "checkbox", id: "loop", label: "Loop", default: false, group: "Media" },
    { type: "text", id: "captionTitle", label: "Caption title", group: "Content", info: "Floating card design only." },
    { type: "text", id: "captionText", label: "Caption text", group: "Content" },
    { type: "text", id: "ctaLabel", label: "Button label", group: "Content", info: "Split design only." },
    { type: "url", id: "ctaHref", label: "Button link", group: "Content" },
    ...baseSectionSettings(),
  ],
};

export default schema;
