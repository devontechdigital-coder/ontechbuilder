import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { VideoFrame } from "../../../components/VideoFrame";
import type { VideoSectionProps } from "../VideoSection";

/** Video 03 — Full-bleed background loop. Muted looping video behind centered text — atmosphere over information. */
export function VideoFullBleed(props: VideoSectionProps) {
  return (
    <SectionShell name="video" {...props} padded={false} className="otu-video--full-bleed">
      <VideoFrame video={props.video} poster={props.poster} ratio="auto" autoplay muted loop controls={false} lazyPoster={false} rounded={false} />
      <div className="otu-video__scrim" />
      <Container width={props.containerWidth ?? "default"} className="otu-video__full-content">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
        {props.heading ? <h2>{props.heading}</h2> : null}
        {props.description ? <p>{props.description}</p> : null}
      </Container>
    </SectionShell>
  );
}
