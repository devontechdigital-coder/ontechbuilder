import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { VideoFrame } from "../../../components/VideoFrame";
import type { VideoSectionProps } from "../VideoSection";

/** Video 01 — Centered. Heading above a wide centered player. The default "watch our story" layout. */
export function VideoCentered(props: VideoSectionProps) {
  return (
    <SectionShell name="video" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <VideoFrame video={props.video} poster={props.poster} ratio={props.ratio ?? "16:9"} autoplay={props.autoplay} muted={props.muted} loop={props.loop} />
      </Container>
    </SectionShell>
  );
}
