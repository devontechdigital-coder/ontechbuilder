import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { VideoFrame } from "../../../components/VideoFrame";
import { MaybeButton } from "../../../components/ThemeButton";
import type { VideoSectionProps } from "../VideoSection";

/** Video 02 — Split. Player on one side, headline/copy/CTA on the other. For explaining a product or service. */
export function VideoSplit(props: VideoSectionProps) {
  return (
    <SectionShell name="video" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-video-split">
          <VideoFrame video={props.video} poster={props.poster} ratio={props.ratio ?? "4:3"} autoplay={props.autoplay} muted={props.muted} loop={props.loop} />
          <div className="otu-video-split__content">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
