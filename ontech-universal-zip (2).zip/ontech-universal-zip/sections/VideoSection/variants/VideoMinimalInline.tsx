import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { VideoFrame } from "../../../components/VideoFrame";
import type { VideoSectionProps } from "../VideoSection";

/** Video 05 — Minimal inline. Narrow container, small heading, no scrim or card chrome — for embedding a demo mid-page without visual weight. */
export function VideoMinimalInline(props: VideoSectionProps) {
  return (
    <SectionShell name="video" {...props}>
      <Container width="narrow">
        {props.heading ? <h3 className="otu-video__minimal-title">{props.heading}</h3> : null}
        <VideoFrame video={props.video} poster={props.poster} ratio={props.ratio ?? "16:9"} autoplay={props.autoplay} muted={props.muted} loop={props.loop} rounded />
        {props.description ? <p className="otu-video__minimal-caption">{props.description}</p> : null}
      </Container>
    </SectionShell>
  );
}
