import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { VideoFrame } from "../../../components/VideoFrame";
import type { VideoSectionProps } from "../VideoSection";

/** Video 04 — Floating card. The player sits as an elevated card over a tinted section, with the caption below like a photo credit. */
export function VideoFloatingCard(props: VideoSectionProps) {
  return (
    <SectionShell name="video" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "default"}>
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        {props.heading ? <h2 className="otu-heading__title otu-heading--center">{props.heading}</h2> : null}
        <div className="otu-video__card">
          <VideoFrame video={props.video} poster={props.poster} ratio={props.ratio ?? "16:9"} autoplay={props.autoplay} muted={props.muted} loop={props.loop} />
        </div>
        {(props.captionTitle || props.captionText) ? (
          <div className="otu-video__caption">
            {props.captionTitle ? <strong>{props.captionTitle}</strong> : null}
            {props.captionText ? <span>{props.captionText}</span> : null}
          </div>
        ) : null}
      </Container>
    </SectionShell>
  );
}
