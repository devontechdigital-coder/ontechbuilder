import * as React from "react";
import type { AspectRatio, SectionBaseProps, ThemeImage, ThemeVideo } from "../../types";
import { VideoCentered } from "./variants/VideoCentered";
import { VideoSplit } from "./variants/VideoSplit";
import { VideoFullBleed } from "./variants/VideoFullBleed";
import { VideoFloatingCard } from "./variants/VideoFloatingCard";
import { VideoMinimalInline } from "./variants/VideoMinimalInline";

export interface VideoSectionProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  video?: ThemeVideo;
  poster?: ThemeImage;
  ratio?: AspectRatio;
  autoplay?: boolean;
  muted?: boolean;
  loop?: boolean;
  captionTitle?: string;
  captionText?: string;
  ctaLabel?: string;
  ctaHref?: string;
}

const variants: Record<string, React.ComponentType<VideoSectionProps>> = {
  v1: VideoCentered,
  v2: VideoSplit,
  v3: VideoFullBleed,
  v4: VideoFloatingCard,
  v5: VideoMinimalInline,
};

/**
 * Video — five presentation styles, all on the native <video>/<iframe>
 * VideoFrame primitive — no video-player dependency.
 * v1 Centered with caption · v2 Split with copy beside it · v3 Full-bleed
 * background loop · v4 Floating card over a tinted backdrop · v5 Minimal
 * inline player.
 */
export function VideoSection(props: VideoSectionProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} />;
}

export default VideoSection;
