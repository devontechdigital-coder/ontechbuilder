import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, columnOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "features",
  name: "Features / Why Choose Us",
  category: "Features",
  description: "Five layouts: icon grid, checklist, alternating rows, comparison strip, floating icon callouts.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Icon grid", "Checklist + image", "Alternating rows", "Comparison strip", "Floating icon callouts"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Why choose us", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "What makes us different", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media", info: "Checklist and floating-icon designs only." },
    { type: "select", id: "columns", label: "Columns", options: columnOptions, default: "4", group: "Layout" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "feature", name: "Feature", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "check-circle" },
      { type: "image", id: "image", label: "Image", info: "Alternating design only." },
      { type: "text", id: "title", label: "Title", default: "Senior consultants only" },
      { type: "textarea", id: "text", label: "Text", default: "No handoffs to junior staff — the person who scopes the work delivers it." },
      { type: "text", id: "oldValue", label: "\"Typical approach\" text", default: "Junior staff, slow ramp-up", info: "Comparison strip design only." },
    ] },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "feature", settings: { icon: "users", title: "Senior consultants only", text: "No handoffs to junior staff.", oldValue: "Junior staff, slow ramp-up" } },
    { type: "feature", settings: { icon: "zap", title: "Fast to start", text: "Engagements begin within two weeks.", oldValue: "6–8 week onboarding" } },
    { type: "feature", settings: { icon: "shield", title: "No lock-in", text: "Month-to-month, cancel any time.", oldValue: "12-month contracts" } },
    { type: "feature", settings: { icon: "trending-up", title: "Tied to outcomes", text: "Every project has a measurable target.", oldValue: "Hours billed, not results" } },
  ],
};

export default schema;
