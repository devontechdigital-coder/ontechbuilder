import * as React from "react";
import type { ColumnCount, SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { FeaturesGrid } from "./variants/FeaturesGrid";
import { FeaturesChecklist } from "./variants/FeaturesChecklist";
import { FeaturesAlternating } from "./variants/FeaturesAlternating";
import { FeaturesComparisonStrip } from "./variants/FeaturesComparisonStrip";
import { FeaturesFloatingIcons } from "./variants/FeaturesFloatingIcons";

export interface FeaturesProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  image?: ThemeImage;
  columns?: ColumnCount;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<FeaturesProps>> = {
  v1: FeaturesGrid,
  v2: FeaturesChecklist,
  v3: FeaturesAlternating,
  v4: FeaturesComparisonStrip,
  v5: FeaturesFloatingIcons,
};

/**
 * Features / Why Choose Us — five layouts.
 * v1 Icon grid · v2 Checklist beside an image · v3 Alternating feature
 * rows with media · v4 "Us vs typical" comparison strip · v5 Image with
 * floating icon callouts.
 */
export function Features(props: FeaturesProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Features;
