import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { FeaturesProps } from "../Features";

const positions = ["top-left", "top-right", "bottom-left", "bottom-right"] as const;

/** Features 05 — Floating icon callouts. A large image with small labelled icon cards positioned at its corners — a product-shot style layout. */
export function FeaturesFloatingIcons(props: FeaturesProps) {
  const items = (props.blocks ?? []).slice(0, 4);
  return (
    <SectionShell name="features" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        {props.heading ? <h2 className="otu-heading--center">{props.heading}</h2> : null}
        <div className="otu-features__floating">
          <ThemeImage image={props.image} ratio="1:1" placeholderLabel="Product" className="otu-features__floating-image" />
          {items.map((feature, index) => (
            <div key={feature.id} className={`otu-features__floating-card otu-features__floating-card--${positions[index % positions.length]}`}>
              <Icon name={asString(feature.icon, "check-circle")} size={18} />
              <span>{asString(feature.title)}</span>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
