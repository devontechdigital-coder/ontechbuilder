import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import { cn } from "../../../components/utils";
import type { FeaturesProps } from "../Features";

/** Features 03 — Alternating rows. Each feature gets its own full row with a real image, alternating left/right — the most spacious of the five. */
export function FeaturesAlternating(props: FeaturesProps) {
  return (
    <SectionShell name="features" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-features__alternating">
          {(props.blocks ?? []).map((feature, index) => (
            <div key={feature.id} className={cn("otu-features__alt-row", index % 2 === 1 && "otu-features__alt-row--reverse")}>
              <ThemeImage image={feature.image as never} ratio="4:3" placeholderLabel={asString(feature.title)} />
              <div>
                <Icon name={asString(feature.icon, "check-circle")} size={26} />
                <h3>{asString(feature.title)}</h3>
                <p>{asString(feature.text)}</p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
