import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { FeaturesProps } from "../Features";

/** Features 04 — Comparison strip. A two-column "typical approach vs. ours" row per feature — makes the differentiation explicit rather than implied. */
export function FeaturesComparisonStrip(props: FeaturesProps) {
  return (
    <SectionShell name="features" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-features__comparison">
          <div className="otu-features__comparison-head">
            <span />
            <span>Typical approach</span>
            <span>With Ontech</span>
          </div>
          {(props.blocks ?? []).map((feature) => (
            <div className="otu-features__comparison-row" key={feature.id}>
              <span className="otu-features__comparison-label">{asString(feature.title)}</span>
              <span className="otu-features__comparison-old">
                <Icon name="minus" size={16} />
                {asString(feature.oldValue, "Slow, generic")}
              </span>
              <span className="otu-features__comparison-new">
                <Icon name="check" size={16} />
                {asString(feature.text)}
              </span>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
