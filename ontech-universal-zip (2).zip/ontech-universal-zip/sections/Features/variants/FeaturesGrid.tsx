import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { FeaturesProps } from "../Features";

/** Features 01 — Icon grid. The direct, general-purpose "why choose us" block. */
export function FeaturesGrid(props: FeaturesProps) {
  return (
    <SectionShell name="features" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-features__grid otu-grid-cols-${props.columns ?? 4}`}>
          {(props.blocks ?? []).map((feature) => (
            <div className="otu-feature" key={feature.id}>
              <Icon name={asString(feature.icon, "check-circle")} size={24} />
              <h3>{asString(feature.title)}</h3>
              <p>{asString(feature.text)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
