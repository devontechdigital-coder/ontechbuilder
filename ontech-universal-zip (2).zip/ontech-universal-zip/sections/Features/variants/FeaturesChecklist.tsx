import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { FeaturesProps } from "../Features";

/** Features 02 — Checklist. Image on one side, a vertical checklist of benefits on the other — for a benefits-driven pitch. */
export function FeaturesChecklist(props: FeaturesProps) {
  return (
    <SectionShell name="features" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-features__checklist-layout">
          <ThemeImage image={props.image} ratio="4:3" placeholderLabel="Why choose us" />
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
            <ul className="otu-features__checklist">
              {(props.blocks ?? []).map((feature) => (
                <li key={feature.id}>
                  <Icon name="check" size={16} />
                  <div>
                    <strong>{asString(feature.title)}</strong>
                    <span>{asString(feature.text)}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
