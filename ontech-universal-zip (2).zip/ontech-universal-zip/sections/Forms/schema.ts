import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "form",
  name: "Contact form",
  category: "Forms",
  description: "Five layouts around one native, accessible <form>. Presentation only — submission posts to actionUrl.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Simple", "Split image + form", "Floating card", "Multi-column enquiry", "Consultation / quote"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Get in touch", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Have a business challenge? We're ready to help", group: "Content" },
    { type: "textarea", id: "description", label: "Description", default: "Tell us a little about what you're working on and a consultant will follow up within one business day.", group: "Content" },
    { type: "text", id: "submitLabel", label: "Submit button label", default: "Send message", group: "Content" },
    { type: "url", id: "actionUrl", label: "Form action URL", group: "Behaviour", info: "The host's own form-handling endpoint. Native POST — no JS submission." },
    { type: "textarea", id: "consentText", label: "Consent text", default: "By submitting this form you agree to be contacted about your enquiry.", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media", info: "Split image design only." },
    { type: "text", id: "phone", label: "Phone number", default: "+1 (555) 010-2030", group: "Content", info: "Consultation design only." },
    { type: "text", id: "email", label: "Email address", default: "hello@example.com", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    {
      type: "field",
      name: "Form field",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Full name" },
        { type: "text", id: "name", label: "Field name (advanced)", info: "Leave blank to auto-generate from the label." },
        {
          type: "select",
          id: "fieldType",
          label: "Field type",
          options: [
            { value: "text", label: "Text" },
            { value: "email", label: "Email" },
            { value: "tel", label: "Phone" },
            { value: "textarea", label: "Textarea" },
            { value: "select", label: "Dropdown" },
            { value: "checkbox", label: "Checkbox" },
            { value: "radio", label: "Radio group" },
            { value: "date", label: "Date" },
            { value: "number", label: "Number" },
          ],
          default: "text",
        },
        { type: "text", id: "placeholder", label: "Placeholder" },
        { type: "textarea", id: "options", label: "Options (one per line)", info: "Dropdown / radio only." },
        { type: "checkbox", id: "required", label: "Required", default: false },
        {
          type: "select",
          id: "width",
          label: "Field width",
          options: [
            { value: "full", label: "Full width" },
            { value: "half", label: "Half width" },
            { value: "third", label: "Third width" },
          ],
          default: "full",
        },
        { type: "text", id: "helpText", label: "Help text" },
      ],
    },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "field", settings: { label: "Full name", fieldType: "text", required: true, width: "half" } },
    { type: "field", settings: { label: "Email address", fieldType: "email", required: true, width: "half" } },
    { type: "field", settings: { label: "Phone number", fieldType: "tel", width: "half" } },
    { type: "field", settings: { label: "Company", fieldType: "text", width: "half" } },
    { type: "field", settings: { label: "Message", fieldType: "textarea", width: "full" } },
  ],
};

export default schema;
