import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { ThemeForm, parseFields } from "../../../components/FormFields";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FormsProps } from "../Forms";

/** Form 02 — Split image + lead form. Image builds trust/context on one side, the form sits on the other. Good for a dedicated contact page. */
export function FormSplitImage(props: FormsProps) {
  const fields = parseFields(props.blocks ?? []);
  return (
    <SectionShell name="form" {...props}>
      <Container width={props.containerWidth ?? "wide"} flush>
        <div className="otu-form-split">
          <ThemeImage image={props.image} ratio="auto" rounded={false} className="otu-form-split__media" placeholderLabel="Contact" />
          <div className="otu-form-split__content">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
            <ThemeForm fields={fields} actionUrl={props.actionUrl} consentText={props.consentText} idPrefix="split">
              <MaybeButton type="submit" label={props.submitLabel || "Send message"} variant="primary" size="lg" />
            </ThemeForm>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
