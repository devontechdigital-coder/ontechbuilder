import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeForm, parseFields } from "../../../components/FormFields";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FormsProps } from "../Forms";

/** Form 04 — Multi-column enquiry. A wide form using the field-level width setting (half/third) to lay out many fields compactly. */
export function FormMultiColumn(props: FormsProps) {
  const fields = parseFields(props.blocks ?? []);
  return (
    <SectionShell name="form" {...props}>
      <Container width="default">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <ThemeForm fields={fields} actionUrl={props.actionUrl} consentText={props.consentText} idPrefix="multi" className="otu-form--wide">
          <MaybeButton type="submit" label={props.submitLabel || "Submit enquiry"} variant="primary" size="lg" />
        </ThemeForm>
      </Container>
    </SectionShell>
  );
}
