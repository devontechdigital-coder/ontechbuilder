import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeForm, parseFields } from "../../../components/FormFields";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FormsProps } from "../Forms";

/** Form 01 — Simple. One narrow centered column — name, email, message. The lightest-weight contact option. */
export function FormSimple(props: FormsProps) {
  const fields = parseFields(props.blocks ?? []);
  return (
    <SectionShell name="form" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <ThemeForm fields={fields} actionUrl={props.actionUrl} consentText={props.consentText} idPrefix="simple">
          <MaybeButton type="submit" label={props.submitLabel || "Send message"} variant="primary" size="lg" fullWidth />
        </ThemeForm>
      </Container>
    </SectionShell>
  );
}
