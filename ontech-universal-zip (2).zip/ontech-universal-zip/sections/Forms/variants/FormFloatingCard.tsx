import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeForm, parseFields } from "../../../components/FormFields";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FormsProps } from "../Forms";

/** Form 03 — Floating card. A dark or tinted section with an elevated white card holding the form — high-contrast conversion block. */
export function FormFloatingCard(props: FormsProps) {
  const fields = parseFields(props.blocks ?? []);
  return (
    <SectionShell name="form" {...props} tone={props.tone ?? "dark"}>
      <Container width="default">
        <div className="otu-form-floating">
          <div className="otu-form-floating__intro">
            {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
          </div>
          <div className="otu-form-floating__card">
            <ThemeForm fields={fields} actionUrl={props.actionUrl} consentText={props.consentText} idPrefix="float">
              <MaybeButton type="submit" label={props.submitLabel || "Request a callback"} variant="primary" size="lg" fullWidth />
            </ThemeForm>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
