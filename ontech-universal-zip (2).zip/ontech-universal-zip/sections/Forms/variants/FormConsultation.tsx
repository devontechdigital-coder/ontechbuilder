import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import { ThemeForm, parseFields } from "../../../components/FormFields";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FormsProps } from "../Forms";

/** Form 05 — Consultation / quote. Conversion-focused: benefit bullets and direct contact details sit beside the form to reduce hesitation. */
export function FormConsultation(props: FormsProps) {
  const fields = parseFields(props.blocks ?? []);
  return (
    <SectionShell name="form" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-form-consult">
          <div className="otu-form-consult__side">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}

            <ul className="otu-form-consult__perks">
              <li>
                <Icon name="check-circle" size={18} /> Free 30-minute strategy call
              </li>
              <li>
                <Icon name="check-circle" size={18} /> Response within one business day
              </li>
              <li>
                <Icon name="check-circle" size={18} /> No obligation to continue
              </li>
            </ul>

            <div className="otu-form-consult__contact">
              {props.phone ? (
                <a href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
                  <Icon name="phone" size={17} /> {props.phone}
                </a>
              ) : null}
              {props.email ? (
                <a href={`mailto:${props.email}`}>
                  <Icon name="mail" size={17} /> {props.email}
                </a>
              ) : null}
            </div>
          </div>

          <div className="otu-form-consult__card">
            <ThemeForm fields={fields} actionUrl={props.actionUrl} consentText={props.consentText} idPrefix="consult">
              <MaybeButton type="submit" label={props.submitLabel || "Get my free consultation"} variant="primary" size="lg" fullWidth />
            </ThemeForm>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
