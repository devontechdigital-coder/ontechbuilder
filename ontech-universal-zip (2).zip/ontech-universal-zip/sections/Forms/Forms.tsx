import * as React from "react";
import type { SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { FormSimple } from "./variants/FormSimple";
import { FormSplitImage } from "./variants/FormSplitImage";
import { FormFloatingCard } from "./variants/FormFloatingCard";
import { FormMultiColumn } from "./variants/FormMultiColumn";
import { FormConsultation } from "./variants/FormConsultation";

export interface FormsProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  submitLabel?: string;
  /** Native form action URL. The host wires this to its own handler — submission is a normal browser POST. */
  actionUrl?: string;
  consentText?: string;
  image?: ThemeImage;
  phone?: string;
  email?: string;
  address?: string;
  /** Mixed "field" blocks. */
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<FormsProps>> = {
  v1: FormSimple,
  v2: FormSplitImage,
  v3: FormFloatingCard,
  v4: FormMultiColumn,
  v5: FormConsultation,
};

/**
 * Forms — five presentation styles around the shared native <form>
 * primitive (components/FormFields.tsx). Presentation only: submission
 * is a plain browser POST to whatever `actionUrl` the host configures.
 * v1 Simple contact · v2 Split image + form · v3 Floating card over a
 * tinted section · v4 Multi-column enquiry · v5 Conversion-focused
 * consultation request with trust details.
 */
export function Forms(props: FormsProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Forms;
