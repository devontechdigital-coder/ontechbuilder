"use client";

import * as React from "react";
import { Icon } from "../../components/Icon";
import { ThemeImage } from "../../components/ThemeImage";
import { MaybeButton } from "../../components/ThemeButton";
import { asString, parseColumns, type RawBlock } from "../../components/blockHelpers";
import { cn, safeHref } from "../../components/utils";
import type { HeaderProps } from "./Header";

/**
 * sections/Header/parts.tsx
 *
 * The behavioural core shared by all five header designs: sticky
 * state, the mobile drawer, the desktop nav with dropdown/mega panels,
 * and the utility cluster (search, phone, socials, CTAs).
 *
 * Keeping this in one place is what lets the five variants differ in
 * *composition* — where the logo sits, how nav and utilities are
 * arranged, whether it floats — without any of them re-implementing
 * keyboard-accessible menus.
 */

export interface NavItem {
  id: string;
  label: string;
  href?: string;
  style: "link" | "simple" | "mega";
  columns: ReturnType<typeof parseColumns>;
  featuredTitle?: string;
  featuredDescription?: string;
  featuredLinkLabel?: string;
  featuredLinkHref?: string;
  featuredImage?: unknown;
}

export function parseNavBlocks(blocks: RawBlock[], enableMegaMenu: boolean): NavItem[] {
  return blocks.map((block, index) => {
    const columns = parseColumns(block.columnsText);
    const requested = asString(block.style, block.type === "nav_menu" ? "simple" : "link");
    const style: NavItem["style"] =
      !enableMegaMenu || columns.length === 0 ? "link" : requested === "mega" ? "mega" : requested === "link" ? "link" : "simple";
    return {
      id: asString(block.id, `nav-${index}`),
      label: asString(block.label, "Menu"),
      href: safeHref(block.href),
      style,
      columns,
      featuredTitle: asString(block.featuredTitle) || undefined,
      featuredDescription: asString(block.featuredDescription) || undefined,
      featuredLinkLabel: asString(block.featuredLinkLabel) || undefined,
      featuredLinkHref: safeHref(block.featuredLinkHref),
      featuredImage: block.featuredImage,
    };
  });
}

/** Adds `is-stuck` once the page has scrolled, so a header can change elevation/background on scroll. */
export function useScrolled(threshold = 12): boolean {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    const onScroll = () => setScrolled(window.scrollY > threshold);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [threshold]);
  return scrolled;
}

/** Locks background scroll while the mobile drawer is open and closes it on Escape. */
export function useMobileMenu() {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    if (!open) return;
    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return { open, setOpen, toggle: () => setOpen((value) => !value) };
}

export function Logo({ props, mobile = false }: { props: HeaderProps; mobile?: boolean }) {
  const image = mobile ? props.mobileLogoImage ?? props.logoImage : props.logoImage;
  return (
    <a className={cn("otu-header__logo", mobile && "otu-header__logo--mobile")} href={safeHref(props.logoHref) ?? "/"}>
      {image?.src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={image.src} alt={image.alt || props.logoText || "Home"} />
      ) : (
        <span className="otu-header__wordmark">{props.logoText || "Ontech"}</span>
      )}
    </a>
  );
}

/**
 * One desktop nav item. Dropdowns open on hover AND on focus-within via
 * CSS, plus an explicit button toggle for keyboard and touch users —
 * hover alone would strand anyone not using a mouse.
 */
export function NavEntry({ item }: { item: NavItem }) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLLIElement | null>(null);

  React.useEffect(() => {
    if (!open) return;
    const onPointer = (event: MouseEvent) => {
      if (!ref.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (item.style === "link") {
    return (
      <li className="otu-nav__item">
        <a className="otu-nav__link" href={item.href ?? "#"}>
          {item.label}
        </a>
      </li>
    );
  }

  const isMega = item.style === "mega";

  return (
    <li className={cn("otu-nav__item", "otu-nav__item--has-menu", isMega && "otu-nav__item--mega")} ref={ref}>
      <button type="button" className="otu-nav__link" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
        {item.label}
        <Icon name="chevron-down" size={15} className="otu-nav__caret" />
      </button>

      <div className={cn("otu-nav__panel", isMega ? "otu-nav__panel--mega" : "otu-nav__panel--simple", open && "is-open")}>
        <div className="otu-nav__panel-inner">
          <div className="otu-nav__columns">
            {item.columns.map((column, index) => (
              <div className="otu-nav__column" key={`${column.heading}-${index}`}>
                {column.heading ? <p className="otu-nav__column-heading">{column.heading}</p> : null}
                <ul>
                  {column.links.map((link) => (
                    <li key={link.href + link.label}>
                      <a href={link.href}>{link.label}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {isMega && (item.featuredTitle || item.featuredImage) ? (
            <div className="otu-nav__featured">
              <ThemeImage image={item.featuredImage as never} ratio="16:9" placeholderLabel="Featured" />
              {item.featuredTitle ? <p className="otu-nav__featured-title">{item.featuredTitle}</p> : null}
              {item.featuredDescription ? <p className="otu-nav__featured-text">{item.featuredDescription}</p> : null}
              <MaybeButton label={item.featuredLinkLabel} href={item.featuredLinkHref} variant="link" size="sm" iconName="arrow-right" />
            </div>
          ) : null}
        </div>
      </div>
    </li>
  );
}

export function DesktopNav({ items, className }: { items: NavItem[]; className?: string }) {
  if (items.length === 0) return null;
  return (
    <nav className={cn("otu-nav", className)} aria-label="Primary">
      <ul className="otu-nav__list">
        {items.map((item) => (
          <NavEntry key={item.id} item={item} />
        ))}
      </ul>
    </nav>
  );
}

export function UtilityCluster({ props, compact = false }: { props: HeaderProps; compact?: boolean }) {
  const socials = (props.socialBlocks ?? []).map((block) => ({
    id: asString(block.id),
    icon: asString(block.icon, "linkedin"),
    href: safeHref(block.href),
    label: asString(block.label, "Social profile"),
  }));

  return (
    <div className={cn("otu-header__utilities", compact && "otu-header__utilities--compact")}>
      {props.showSearch ? (
        <a className="otu-header__icon-link" href={safeHref(props.searchHref) ?? "/search"} aria-label="Search">
          <Icon name="search" size={19} />
        </a>
      ) : null}

      {props.phone ? (
        <a className="otu-header__phone" href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
          <Icon name="phone" size={17} />
          <span>{props.phone}</span>
        </a>
      ) : null}

      {socials.length > 0 && !compact ? (
        <span className="otu-header__socials">
          {socials.map((social) =>
            social.href ? (
              <a key={social.id} href={social.href} aria-label={social.label} rel="noopener noreferrer">
                <Icon name={social.icon} size={17} />
              </a>
            ) : null,
          )}
        </span>
      ) : null}

      <MaybeButton label={props.secondaryCtaLabel} href={props.secondaryCtaHref} variant="ghost" size="sm" className="otu-header__cta-secondary" />
      <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" size="sm" className="otu-header__cta" />
    </div>
  );
}

export function MobileToggle({ open, onClick }: { open: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      className="otu-header__burger"
      aria-expanded={open}
      aria-controls="otu-mobile-menu"
      aria-label={open ? "Close menu" : "Open menu"}
      onClick={onClick}
    >
      <Icon name={open ? "close" : "menu"} size={22} />
    </button>
  );
}

/**
 * The mobile drawer.
 *
 * Purpose-built rather than a hidden copy of the desktop bar: full-height
 * panel, large touch targets, submenus as native <details> so they
 * expand in place with no extra state, and the CTAs pinned to the
 * bottom where a thumb can reach them.
 */
export function MobileMenu({ items, props, open, onClose }: { items: NavItem[]; props: HeaderProps; open: boolean; onClose: () => void }) {
  return (
    <div className={cn("otu-mobile", open && "is-open")} id="otu-mobile-menu" hidden={!open}>
      <div className="otu-mobile__overlay" onClick={onClose} aria-hidden="true" />
      <div className="otu-mobile__panel" role="dialog" aria-modal="true" aria-label="Menu">
        <div className="otu-mobile__top">
          <Logo props={props} mobile />
          <button type="button" className="otu-mobile__close" onClick={onClose} aria-label="Close menu">
            <Icon name="close" size={22} />
          </button>
        </div>

        <nav className="otu-mobile__nav" aria-label="Mobile">
          <ul>
            {items.map((item) =>
              item.style === "link" || item.columns.length === 0 ? (
                <li key={item.id}>
                  <a className="otu-mobile__link" href={item.href ?? "#"} onClick={onClose}>
                    {item.label}
                    <Icon name="arrow-up-right" size={17} />
                  </a>
                </li>
              ) : (
                <li key={item.id}>
                  <details className="otu-mobile__group">
                    <summary>
                      {item.label}
                      <Icon name="chevron-down" size={18} />
                    </summary>
                    <div className="otu-mobile__sub">
                      {item.columns.map((column, index) => (
                        <div key={`${column.heading}-${index}`}>
                          {column.heading ? <p className="otu-mobile__sub-heading">{column.heading}</p> : null}
                          <ul>
                            {column.links.map((link) => (
                              <li key={link.href + link.label}>
                                <a href={link.href} onClick={onClose}>
                                  {link.label}
                                </a>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </details>
                </li>
              ),
            )}
          </ul>
        </nav>

        <div className="otu-mobile__footer">
          {props.phone ? (
            <a className="otu-mobile__contact" href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
              <Icon name="phone" size={17} />
              {props.phone}
            </a>
          ) : null}
          {props.email ? (
            <a className="otu-mobile__contact" href={`mailto:${props.email}`}>
              <Icon name="mail" size={17} />
              {props.email}
            </a>
          ) : null}
          <div className="otu-mobile__ctas">
            <MaybeButton label={props.secondaryCtaLabel} href={props.secondaryCtaHref} variant="outline" size="md" fullWidth />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" size="md" fullWidth />
          </div>
        </div>
      </div>
    </div>
  );
}

/** Shared outer element for every header design — owns sticky/transparent/scrolled state. */
export function HeaderShell({
  props,
  variant,
  scrolled,
  open,
  className,
  children,
}: {
  props: HeaderProps;
  variant: string;
  scrolled: boolean;
  open: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <header
      id={props.anchorId || undefined}
      className={cn(
        "otu-header",
        `otu-header--${variant}`,
        props.sticky && "otu-header--sticky",
        props.transparentOnHero && "otu-header--transparent",
        scrolled && "is-stuck",
        open && "is-menu-open",
        props.showBorder === false && "otu-header--borderless",
        className,
        props.customClass,
      )}
      data-tone={props.tone ?? "default"}
      style={
        props.backgroundColor || props.textColor
          ? ({
              "--otu-header-bg": props.backgroundColor,
              "--otu-header-fg": props.textColor,
            } as React.CSSProperties)
          : undefined
      }
    >
      {children}
    </header>
  );
}
