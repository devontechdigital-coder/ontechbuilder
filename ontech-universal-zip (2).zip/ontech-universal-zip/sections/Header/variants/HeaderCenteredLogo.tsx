"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import type { HeaderProps } from "../Header";
import { HeaderShell, Logo, MobileMenu, MobileToggle, NavEntry, parseNavBlocks, useMobileMenu, useScrolled } from "../parts";
import { safeHref } from "../../../components/utils";

/**
 * Header 02 — Centered logo, split navigation.
 * The menu is dealt evenly to either side of a centred wordmark, which
 * gives a brand-led, symmetrical masthead. Suits studios, clinics and
 * hospitality more than link-heavy corporate sites.
 */
export function HeaderCenteredLogo(props: HeaderProps) {
  const items = parseNavBlocks(props.navBlocks ?? [], props.enableMegaMenu !== false);
  const scrolled = useScrolled();
  const menu = useMobileMenu();

  const half = Math.ceil(items.length / 2);
  const left = items.slice(0, half);
  const right = items.slice(half);

  return (
    <HeaderShell props={props} variant="v2" scrolled={scrolled} open={menu.open}>
      <Container width={props.containerWidth ?? "wide"} className="otu-header__inner">
        <nav className="otu-nav otu-nav--split otu-nav--left" aria-label="Primary">
          <ul className="otu-nav__list">
            {left.map((item) => (
              <NavEntry key={item.id} item={item} />
            ))}
          </ul>
        </nav>

        <div className="otu-header__center">
          <Logo props={props} />
        </div>

        <nav className="otu-nav otu-nav--split otu-nav--right" aria-label="Secondary">
          <ul className="otu-nav__list">
            {right.map((item) => (
              <NavEntry key={item.id} item={item} />
            ))}
          </ul>
        </nav>

        <div className="otu-header__edge">
          {props.showSearch ? (
            <a className="otu-header__icon-link" href={safeHref(props.searchHref) ?? "/search"} aria-label="Search">
              <Icon name="search" size={19} />
            </a>
          ) : null}
          <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" size="sm" />
        </div>

        <MobileToggle open={menu.open} onClick={menu.toggle} />
      </Container>
      <MobileMenu items={items} props={props} open={menu.open} onClose={() => menu.setOpen(false)} />
    </HeaderShell>
  );
}
