"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { MaybeButton } from "../../../components/ThemeButton";
import type { HeaderProps } from "../Header";
import { DesktopNav, HeaderShell, Logo, MobileMenu, MobileToggle, parseNavBlocks, useMobileMenu, useScrolled } from "../parts";

/**
 * Header 05 — Compact floating pill.
 * The whole bar is an inset, rounded capsule that detaches from the top
 * edge and tightens as you scroll. Deliberately low-density: a short
 * menu and one CTA. Best for landing pages, SaaS and portfolios.
 */
export function HeaderMinimal(props: HeaderProps) {
  const items = parseNavBlocks(props.navBlocks ?? [], props.enableMegaMenu !== false);
  const scrolled = useScrolled(24);
  const menu = useMobileMenu();

  return (
    <HeaderShell props={props} variant="v5" scrolled={scrolled} open={menu.open} className="otu-header--floating">
      <Container width={props.containerWidth ?? "default"}>
        <div className="otu-header__pill">
          <Logo props={props} />
          <DesktopNav items={items} className="otu-nav--pill" />
          <div className="otu-header__edge">
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" size="sm" iconName="arrow-up-right" />
          </div>
          <MobileToggle open={menu.open} onClick={menu.toggle} />
        </div>
      </Container>
      <MobileMenu items={items} props={props} open={menu.open} onClose={() => menu.setOpen(false)} />
    </HeaderShell>
  );
}
