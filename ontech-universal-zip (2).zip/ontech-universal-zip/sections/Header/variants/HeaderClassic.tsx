"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import type { HeaderProps } from "../Header";
import { DesktopNav, HeaderShell, Logo, MobileMenu, MobileToggle, UtilityCluster, parseNavBlocks, useMobileMenu, useScrolled } from "../parts";

/**
 * Header 01 — Classic horizontal.
 * Logo left, nav centre-left, utilities and CTA right. The workhorse
 * layout: predictable, dense with links, and comfortable for sites with
 * a long menu.
 */
export function HeaderClassic(props: HeaderProps) {
  const items = parseNavBlocks(props.navBlocks ?? [], props.enableMegaMenu !== false);
  const scrolled = useScrolled();
  const menu = useMobileMenu();

  return (
    <HeaderShell props={props} variant="v1" scrolled={scrolled} open={menu.open}>
      <Container width={props.containerWidth ?? "wide"} className="otu-header__inner">
        <Logo props={props} />
        <DesktopNav items={items} className="otu-nav--inline" />
        <UtilityCluster props={props} />
        <MobileToggle open={menu.open} onClick={menu.toggle} />
      </Container>
      <MobileMenu items={items} props={props} open={menu.open} onClose={() => menu.setOpen(false)} />
    </HeaderShell>
  );
}
