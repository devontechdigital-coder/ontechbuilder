"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { HeaderProps } from "../Header";
import { DesktopNav, HeaderShell, Logo, MobileMenu, MobileToggle, parseNavBlocks, useMobileMenu, useScrolled } from "../parts";

/**
 * Header 04 — Two-row premium mega menu.
 * A slim utility bar (contact details, socials, short message) sits
 * above the main bar; the utility row scrolls away and the main bar
 * sticks. Built for large B2B, healthcare and education sites where the
 * menu carries real information architecture.
 */
export function HeaderMega(props: HeaderProps) {
  const items = parseNavBlocks(props.navBlocks ?? [], props.enableMegaMenu !== false);
  const scrolled = useScrolled(60);
  const menu = useMobileMenu();

  const utilities = (props.utilityBlocks ?? []).map((block, index) => ({
    id: asString(block.id, `u-${index}`),
    icon: asString(block.icon, "check"),
    label: asString(block.label),
  }));

  const socials = (props.socialBlocks ?? []).map((block, index) => ({
    id: asString(block.id, `s-${index}`),
    icon: asString(block.icon, "linkedin"),
    href: safeHref(block.href),
    label: asString(block.label, "Social profile"),
  }));

  return (
    <HeaderShell props={props} variant="v4" scrolled={scrolled} open={menu.open} className="otu-header--two-row">
      {props.showTopBar !== false ? (
        <div className="otu-header__topbar">
          <Container width={props.containerWidth ?? "wide"}>
            <div className="otu-header__topbar-inner">
              <div className="otu-header__topbar-left">
                {props.topBarMessage ? <span className="otu-header__topbar-message">{props.topBarMessage}</span> : null}
                {utilities.map((utility) => (
                  <span key={utility.id} className="otu-header__topbar-item">
                    <Icon name={utility.icon} size={15} />
                    {utility.label}
                  </span>
                ))}
              </div>
              <div className="otu-header__topbar-right">
                {props.email ? (
                  <a href={`mailto:${props.email}`}>
                    <Icon name="mail" size={15} />
                    {props.email}
                  </a>
                ) : null}
                {props.phone ? (
                  <a href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
                    <Icon name="phone" size={15} />
                    {props.phone}
                  </a>
                ) : null}
                {socials.length > 0 ? (
                  <span className="otu-header__socials">
                    {socials.map((social) =>
                      social.href ? (
                        <a key={social.id} href={social.href} aria-label={social.label} rel="noopener noreferrer">
                          <Icon name={social.icon} size={15} />
                        </a>
                      ) : null,
                    )}
                  </span>
                ) : null}
              </div>
            </div>
          </Container>
        </div>
      ) : null}

      <div className="otu-header__main">
        <Container width={props.containerWidth ?? "wide"} className="otu-header__inner">
          <Logo props={props} />
          <DesktopNav items={items} className="otu-nav--inline otu-nav--roomy" />
          <div className="otu-header__edge">
            {props.showSearch ? (
              <a className="otu-header__icon-link" href={safeHref(props.searchHref) ?? "/search"} aria-label="Search">
                <Icon name="search" size={19} />
              </a>
            ) : null}
            <MaybeButton label={props.secondaryCtaLabel} href={props.secondaryCtaHref} variant="outline" size="sm" />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" size="md" iconName="arrow-right" />
          </div>
          <MobileToggle open={menu.open} onClick={menu.toggle} />
        </Container>
      </div>

      <MobileMenu items={items} props={props} open={menu.open} onClose={() => menu.setOpen(false)} />
    </HeaderShell>
  );
}
