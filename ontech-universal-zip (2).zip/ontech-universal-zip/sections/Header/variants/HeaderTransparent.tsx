"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import type { HeaderProps } from "../Header";
import { DesktopNav, HeaderShell, Logo, MobileMenu, MobileToggle, UtilityCluster, parseNavBlocks, useMobileMenu, useScrolled } from "../parts";

/**
 * Header 03 — Transparent overlay.
 * Sits on top of a full-bleed hero with no background of its own, then
 * fades in a solid bar once the visitor scrolls past it. Pairs with
 * Hero 02 and Hero 04.
 */
export function HeaderTransparent(props: HeaderProps) {
  const items = parseNavBlocks(props.navBlocks ?? [], props.enableMegaMenu !== false);
  const scrolled = useScrolled(40);
  const menu = useMobileMenu();

  return (
    <HeaderShell
      props={{ ...props, transparentOnHero: true }}
      variant="v3"
      scrolled={scrolled}
      open={menu.open}
      className="otu-header--overlay"
    >
      <Container width={props.containerWidth ?? "wide"} className="otu-header__inner">
        <Logo props={props} />
        <DesktopNav items={items} className="otu-nav--inline otu-nav--center" />
        <UtilityCluster props={props} compact />
        <MobileToggle open={menu.open} onClick={menu.toggle} />
      </Container>
      <MobileMenu items={items} props={props} open={menu.open} onClose={() => menu.setOpen(false)} />
    </HeaderShell>
  );
}
