import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { containerOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "header",
  name: "Header",
  category: "Navigation",
  placement: "header",
  description: "Five navigation systems: classic, centered logo, transparent overlay, two-row mega menu, and a floating pill.",
  settings: [
    {
      type: "select",
      id: "variant",
      label: "Design",
      options: variantOptions(["Classic horizontal", "Centered logo", "Transparent overlay", "Mega menu + utility bar", "Compact floating pill"]),
      default: "v1",
      group: "Layout",
    },

    // Brand
    { type: "image", id: "logoImage", label: "Logo", group: "Brand" },
    { type: "image", id: "mobileLogoImage", label: "Mobile logo", group: "Brand", info: "Falls back to the main logo." },
    { type: "text", id: "logoText", label: "Logo text", default: "Ontech", group: "Brand", info: "Shown when no logo image is set." },
    { type: "url", id: "logoHref", label: "Logo link", default: "/", group: "Brand" },

    // Actions
    { type: "text", id: "ctaLabel", label: "Primary button label", default: "Book a consultation", group: "Actions" },
    { type: "url", id: "ctaHref", label: "Primary button link", default: "/contact", group: "Actions" },
    { type: "text", id: "secondaryCtaLabel", label: "Secondary button label", group: "Actions" },
    { type: "url", id: "secondaryCtaHref", label: "Secondary button link", group: "Actions" },
    { type: "checkbox", id: "showSearch", label: "Show search", default: false, group: "Actions" },
    { type: "url", id: "searchHref", label: "Search page link", default: "/search", group: "Actions" },

    // Contact
    { type: "text", id: "phone", label: "Phone number", default: "+1 (555) 010-2030", group: "Contact" },
    { type: "text", id: "email", label: "Email address", default: "hello@example.com", group: "Contact" },

    // Behaviour
    { type: "checkbox", id: "sticky", label: "Stick to the top on scroll", default: true, group: "Behaviour" },
    { type: "checkbox", id: "transparentOnHero", label: "Transparent over the hero", default: false, group: "Behaviour", info: "Design 3 is always transparent." },
    { type: "checkbox", id: "showBorder", label: "Show bottom hairline", default: true, group: "Behaviour" },
    { type: "checkbox", id: "enableMegaMenu", label: "Allow dropdown and mega panels", default: true, group: "Behaviour" },

    // Utility bar (design 4)
    { type: "checkbox", id: "showTopBar", label: "Show utility bar", default: true, group: "Utility bar", info: "Design 4 only." },
    { type: "text", id: "topBarMessage", label: "Utility bar message", default: "Trusted by 400+ teams worldwide", group: "Utility bar" },

    { type: "select", id: "containerWidth", label: "Container width", options: containerOptions, default: "wide", group: "Layout" },
    { type: "color", id: "backgroundColor", label: "Background override", group: "Style" },
    { type: "color", id: "textColor", label: "Text override", group: "Style" },
    { type: "text", id: "customClass", label: "Custom CSS class", group: "Advanced" },
  ],
  blocks: [
    {
      type: "nav_link",
      name: "Nav link",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Home" },
        { type: "url", id: "href", label: "Link", default: "/" },
      ],
    },
    {
      type: "nav_menu",
      name: "Nav menu (dropdown or mega)",
      settings: [
        { type: "text", id: "label", label: "Label", default: "Services" },
        {
          type: "select",
          id: "style",
          label: "Panel style",
          options: [
            { value: "simple", label: "Simple dropdown" },
            { value: "mega", label: "Mega panel" },
            { value: "link", label: "Plain link (ignore columns)" },
          ],
          default: "simple",
        },
        {
          type: "textarea",
          id: "columnsText",
          label: "Menu items",
          info: "One link per line as Label|/url. Start a line with ## to begin a new column heading.",
          default: "Strategy|/services/strategy\nImplementation|/services/implementation\nSupport|/services/support",
        },
        { type: "text", id: "featuredTitle", label: "Featured title (mega only)" },
        { type: "textarea", id: "featuredDescription", label: "Featured description (mega only)" },
        { type: "text", id: "featuredLinkLabel", label: "Featured link label" },
        { type: "url", id: "featuredLinkHref", label: "Featured link URL" },
        { type: "image", id: "featuredImage", label: "Featured image" },
      ],
    },
    {
      type: "social",
      name: "Social link",
      settings: [
        { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "linkedin" },
        { type: "text", id: "label", label: "Accessible label", default: "LinkedIn" },
        { type: "url", id: "href", label: "Profile URL" },
      ],
    },
    {
      type: "utility",
      name: "Utility bar item",
      settings: [
        { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "check" },
        { type: "text", id: "label", label: "Label", default: "ISO 27001 certified" },
      ],
    },
  ],
  maxBlocks: 14,
  defaultBlocks: [
    { type: "nav_link", settings: { label: "Home", href: "/" } },
    { type: "nav_menu", settings: { label: "Services", style: "mega", columnsText: "## By capability\nStrategy & advisory|/services/strategy\nImplementation|/services/implementation\nManaged support|/services/support\n\n## By industry\nHealthcare|/industries/healthcare\nConstruction|/industries/construction\nFinance|/industries/finance" } },
    { type: "nav_menu", settings: { label: "Work", style: "simple", columnsText: "All projects|/portfolio\nCase studies|/portfolio#case-studies" } },
    { type: "nav_link", settings: { label: "About", href: "/about" } },
    { type: "nav_link", settings: { label: "Contact", href: "/contact" } },
  ],
};

export default schema;
