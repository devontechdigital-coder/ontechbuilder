import * as React from "react";
import type { SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { HeaderClassic } from "./variants/HeaderClassic";
import { HeaderCenteredLogo } from "./variants/HeaderCenteredLogo";
import { HeaderTransparent } from "./variants/HeaderTransparent";
import { HeaderMega } from "./variants/HeaderMega";
import { HeaderMinimal } from "./variants/HeaderMinimal";

export interface HeaderProps extends SectionBaseProps {
  logoImage?: ThemeImage;
  mobileLogoImage?: ThemeImage;
  logoText?: string;
  logoHref?: string;
  /** Mixed nav blocks: "nav_link" for plain links, "nav_menu" for dropdown/mega panels. */
  navBlocks?: RawBlock[];
  socialBlocks?: RawBlock[];
  /** Small feature/USP items shown in the top utility bar of some designs. */
  utilityBlocks?: RawBlock[];
  phone?: string;
  email?: string;
  address?: string;
  ctaLabel?: string;
  ctaHref?: string;
  secondaryCtaLabel?: string;
  secondaryCtaHref?: string;
  showSearch?: boolean;
  searchHref?: string;
  sticky?: boolean;
  transparentOnHero?: boolean;
  showBorder?: boolean;
  showTopBar?: boolean;
  topBarMessage?: string;
  enableMegaMenu?: boolean;
}

const variants: Record<string, React.ComponentType<HeaderProps>> = {
  v1: HeaderClassic,
  v2: HeaderCenteredLogo,
  v3: HeaderTransparent,
  v4: HeaderMega,
  v5: HeaderMinimal,
};

/**
 * Header — five genuinely different navigation systems.
 *
 * v1 Classic bar · v2 Centered logo with split nav · v3 Transparent
 * overlay · v4 Two-row mega-menu with a utility bar · v5 Compact
 * floating pill.
 */
export function Header(props: HeaderProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return (
    <Variant
      {...props}
      navBlocks={asBlocks(props.navBlocks)}
      socialBlocks={asBlocks(props.socialBlocks)}
      utilityBlocks={asBlocks(props.utilityBlocks)}
    />
  );
}

export default Header;
