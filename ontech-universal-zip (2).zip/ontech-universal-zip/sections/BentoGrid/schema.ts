import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "bento-grid",
  name: "Bento Grid",
  category: "Bento Grid",
  description: "Five modern grid compositions on CSS Grid, each reflowing cleanly to one column on mobile.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Even tiles", "Asymmetric anchor", "Photo mosaic", "Mixed stats + features", "Portfolio bento"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Overview", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Everything in one view", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "tile", name: "Tile", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "spark" },
      { type: "image", id: "image", label: "Image" },
      { type: "text", id: "title", label: "Title", default: "Strategic clarity" },
      { type: "textarea", id: "text", label: "Text", default: "A plan the whole team can execute." },
      { type: "checkbox", id: "isStat", label: "Show as a big stat instead", default: false, info: "Mixed stats design only." },
      { type: "text", id: "value", label: "Stat value", default: "95%", info: "Used when \"show as a stat\" is on." },
      { type: "text", id: "category", label: "Category", info: "Portfolio bento design only." },
      { type: "url", id: "href", label: "Link" },
    ] },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "tile", settings: { icon: "target", title: "Strategic clarity", text: "A plan the whole team can execute." } },
    { type: "tile", settings: { icon: "trending-up", title: "Measurable growth", text: "Every initiative tied to a metric." } },
    { type: "tile", settings: { icon: "users", title: "Embedded delivery", text: "We work inside your team." } },
    { type: "tile", settings: { icon: "shield", title: "No lock-in", text: "Cancel any time, no penalty." } },
  ],
};

export default schema;
