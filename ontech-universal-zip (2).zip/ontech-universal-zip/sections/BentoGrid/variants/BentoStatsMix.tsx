import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asBoolean, asString } from "../../../components/blockHelpers";
import { cn } from "../../../components/utils";
import type { BentoGridProps } from "../BentoGrid";

/** Bento 04 — Mixed stats + features. Tiles marked "isStat" render as a large number instead of icon/title/text — for combining company facts with feature callouts in one grid. */
export function BentoStatsMix(props: BentoGridProps) {
  return (
    <SectionShell name="bento" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-bento otu-bento--stats-mix">
          {(props.blocks ?? []).map((tile) => {
            const isStat = asBoolean(tile.isStat, false);
            return (
              <div className={cn("otu-bento-tile", isStat && "otu-bento-tile--stat")} key={tile.id}>
                {isStat ? (
                  <>
                    <p className="otu-bento-tile__stat-value">{asString(tile.value)}</p>
                    <p className="otu-bento-tile__stat-label">{asString(tile.title)}</p>
                  </>
                ) : (
                  <>
                    <Icon name={asString(tile.icon, "spark")} size={22} />
                    <h3>{asString(tile.title)}</h3>
                    <p>{asString(tile.text)}</p>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </Container>
    </SectionShell>
  );
}
