import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { BentoGridProps } from "../BentoGrid";

/** Bento 03 — Photo mosaic. Every tile is image-first with a caption overlay, in varied cell sizes — reads as a company overview collage. */
export function BentoMosaic(props: BentoGridProps) {
  return (
    <SectionShell name="bento" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-bento otu-bento--mosaic">
          {(props.blocks ?? []).map((tile, index) => (
            <div className={`otu-bento-tile otu-bento-tile--media otu-bento-tile--mosaic-${(index % 4) + 1}`} key={tile.id}>
              <ThemeImage image={tile.image as never} ratio="auto" placeholderLabel={asString(tile.title)} rounded={false} />
              <span className="otu-bento-tile__caption">{asString(tile.title)}</span>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
