import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { BentoGridProps } from "../BentoGrid";

/** Bento 05 — Portfolio bento. Each tile links out to a project, with category/title overlay and a hover arrow — bridges Bento and Portfolio categories. */
export function BentoPortfolio(props: BentoGridProps) {
  return (
    <SectionShell name="bento" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-bento otu-bento--portfolio">
          {(props.blocks ?? []).map((tile, index) => (
            <a
              key={tile.id}
              href={safeHref(tile.href as string) ?? "#"}
              className={`otu-bento-tile otu-bento-tile--media otu-bento-tile--portfolio-${(index % 3) + 1}`}
            >
              <ThemeImage image={tile.image as never} ratio="auto" placeholderLabel={asString(tile.title)} rounded={false} />
              <div className="otu-bento-tile__overlay">
                <span>{asString(tile.category)}</span>
                <h3>{asString(tile.title)}</h3>
              </div>
              <Icon name="arrow-up-right" size={18} className="otu-bento-tile__arrow" />
            </a>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
