import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { BentoGridProps } from "../BentoGrid";

/** Bento 02 — Asymmetric anchor. The first tile spans two columns and two rows as a large anchor; remaining tiles fill smaller cells around it. */
export function BentoAsymmetric(props: BentoGridProps) {
  const [anchor, ...rest] = props.blocks ?? [];
  return (
    <SectionShell name="bento" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-bento otu-bento--asymmetric">
          {anchor ? (
            <div className="otu-bento-tile otu-bento-tile--anchor">
              {anchor.image ? <ThemeImage image={anchor.image as never} ratio="auto" placeholderLabel={asString(anchor.title)} className="otu-bento-tile__media" /> : null}
              <Icon name={asString(anchor.icon, "spark")} size={28} />
              <h3>{asString(anchor.title)}</h3>
              <p>{asString(anchor.text)}</p>
            </div>
          ) : null}
          {rest.map((tile) => (
            <div className="otu-bento-tile" key={tile.id}>
              <Icon name={asString(tile.icon, "spark")} size={22} />
              <h3>{asString(tile.title)}</h3>
              <p>{asString(tile.text)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
