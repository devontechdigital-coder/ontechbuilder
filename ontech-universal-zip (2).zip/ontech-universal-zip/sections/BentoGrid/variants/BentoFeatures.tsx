import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { BentoGridProps } from "../BentoGrid";

/** Bento 01 — Even tiles. A uniform bento grid where every tile is the same size — the most conservative, general-purpose bento. */
export function BentoFeatures(props: BentoGridProps) {
  return (
    <SectionShell name="bento" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-bento otu-bento--even">
          {(props.blocks ?? []).map((tile) => (
            <div className="otu-bento-tile" key={tile.id}>
              <Icon name={asString(tile.icon, "spark")} size={24} />
              <h3>{asString(tile.title)}</h3>
              <p>{asString(tile.text)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
