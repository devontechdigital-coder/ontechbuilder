import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { BentoFeatures } from "./variants/BentoFeatures";
import { BentoAsymmetric } from "./variants/BentoAsymmetric";
import { BentoMosaic } from "./variants/BentoMosaic";
import { BentoStatsMix } from "./variants/BentoStatsMix";
import { BentoPortfolio } from "./variants/BentoPortfolio";

export interface BentoGridProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<BentoGridProps>> = {
  v1: BentoFeatures,
  v2: BentoAsymmetric,
  v3: BentoMosaic,
  v4: BentoStatsMix,
  v5: BentoPortfolio,
};

/**
 * Bento Grid — five modern grid-composition layouts, each with its own
 * CSS Grid template that reflows cleanly to a single column on mobile.
 * v1 Even feature tiles · v2 Asymmetric with one large anchor tile ·
 * v3 Dense photo/text mosaic · v4 Mixed stat + feature tiles · v5
 * Portfolio-style image-forward bento.
 */
export function BentoGrid(props: BentoGridProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default BentoGrid;
