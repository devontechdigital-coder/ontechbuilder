import * as React from "react";
import type { AspectRatio, SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { AboutSplit } from "./variants/AboutSplit";
import { AboutMissionVision } from "./variants/AboutMissionVision";
import { AboutStoryStats } from "./variants/AboutStoryStats";
import { AboutValuesGrid } from "./variants/AboutValuesGrid";
import { AboutImageCollage } from "./variants/AboutImageCollage";

export interface AboutUsProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  body?: string;
  image?: ThemeImage;
  secondaryImage?: ThemeImage;
  tertiaryImage?: ThemeImage;
  imageRatio?: AspectRatio;
  ctaLabel?: string;
  ctaHref?: string;
  missionTitle?: string;
  missionText?: string;
  visionTitle?: string;
  visionText?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<AboutUsProps>> = {
  v1: AboutSplit,
  v2: AboutMissionVision,
  v3: AboutStoryStats,
  v4: AboutValuesGrid,
  v5: AboutImageCollage,
};

/**
 * About Us — five ways to introduce the company.
 * v1 Split image/copy · v2 Mission & vision pair · v3 Story with proof
 * stats · v4 Values grid · v5 Image collage with overlapping frames.
 */
export function AboutUs(props: AboutUsProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default AboutUs;
