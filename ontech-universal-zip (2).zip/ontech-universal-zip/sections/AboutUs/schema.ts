import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { aspectOptions, baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "about-us",
  name: "About Us",
  category: "About Us",
  description: "Five ways to introduce the company: split, mission & vision, story + stats, values grid, image collage.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Split image/copy", "Mission & vision", "Story + stats", "Values grid", "Image collage"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "About Ontech", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Driven by insight, focused on results", group: "Content" },
    { type: "textarea", id: "description", label: "Short description", default: "We provide tailored consulting solutions to help businesses overcome challenges, seize opportunities, and achieve sustainable growth.", group: "Content" },
    { type: "richtext", id: "body", label: "Full story (rich text)", group: "Content" },
    { type: "image", id: "image", label: "Main image", group: "Media" },
    { type: "image", id: "secondaryImage", label: "Secondary image", group: "Media", info: "Collage design only." },
    { type: "image", id: "tertiaryImage", label: "Tertiary image", group: "Media" },
    { type: "select", id: "imageRatio", label: "Image ratio", options: aspectOptions, default: "4:3", group: "Media" },
    { type: "text", id: "ctaLabel", label: "Button label", default: "Meet the team", group: "Content" },
    { type: "url", id: "ctaHref", label: "Button link", default: "/team", group: "Content" },
    { type: "text", id: "missionTitle", label: "Mission title", default: "Our mission", group: "Mission & vision" },
    { type: "textarea", id: "missionText", label: "Mission text", default: "To make expert strategy accessible to companies that don't have an internal strategy team.", group: "Mission & vision" },
    { type: "text", id: "visionTitle", label: "Vision title", default: "Our vision", group: "Mission & vision" },
    { type: "textarea", id: "visionText", label: "Vision text", default: "A world where good decisions don't depend on the size of your budget.", group: "Mission & vision" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "stat", name: "Proof stat", settings: [
      { type: "text", id: "value", label: "Value", default: "260+" },
      { type: "text", id: "label", label: "Label", default: "Companies transformed" },
    ] },
    { type: "value", name: "Company value", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "spark" },
      { type: "text", id: "title", label: "Title", default: "Radical clarity" },
      { type: "textarea", id: "text", label: "Text", default: "We say the true thing, even when it's not the comfortable thing." },
    ] },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "stat", settings: { value: "260+", label: "Companies transformed" } },
    { type: "stat", settings: { value: "95%", label: "Client satisfaction" } },
    { type: "stat", settings: { value: "12", label: "Years in business" } },
  ],
};

export default schema;
