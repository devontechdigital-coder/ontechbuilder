import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString, blocksOfType } from "../../../components/blockHelpers";
import type { AboutUsProps } from "../AboutUs";

/** About 04 — Values grid. Heading + intro, then a grid of value cards ("value" blocks) instead of prose — for a culture-forward about page. */
export function AboutValuesGrid(props: AboutUsProps) {
  const values = blocksOfType(props.blocks ?? [], "value");
  return (
    <SectionShell name="about" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description ?? props.body} align="center" />
        <div className="otu-about__values">
          {values.map((value) => (
            <div className="otu-about__value" key={value.id}>
              <Icon name={asString(value.icon, "spark")} size={22} />
              <h3>{asString(value.title)}</h3>
              <p>{asString(value.text)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
