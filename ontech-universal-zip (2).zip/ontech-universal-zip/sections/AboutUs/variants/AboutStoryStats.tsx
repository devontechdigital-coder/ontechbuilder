import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { RichText } from "../../../components/RichText";
import { asString, blocksOfType } from "../../../components/blockHelpers";
import type { AboutUsProps } from "../AboutUs";

/** About 03 — Story + stats. Narrative copy in a narrow column, with a row of "stat" blocks proving the story beneath it. */
export function AboutStoryStats(props: AboutUsProps) {
  const stats = blocksOfType(props.blocks ?? [], "stat");
  return (
    <SectionShell name="about" {...props}>
      <Container width="narrow">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        {props.heading ? <h2 className="otu-heading--center">{props.heading}</h2> : null}
        <RichText value={props.body ?? props.description} className="otu-prose--center" />
      </Container>
      {stats.length > 0 ? (
        <Container width="default">
          <dl className="otu-about__stats">
            {stats.map((stat) => (
              <div key={stat.id}>
                <dt>{asString(stat.value)}</dt>
                <dd>{asString(stat.label)}</dd>
              </div>
            ))}
          </dl>
        </Container>
      ) : null}
    </SectionShell>
  );
}
