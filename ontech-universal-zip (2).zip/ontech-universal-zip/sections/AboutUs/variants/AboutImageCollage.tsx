import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import type { AboutUsProps } from "../AboutUs";

/** About 05 — Image collage. Three overlapping photo frames on one side, copy on the other — a warmer, more human "about" composition. */
export function AboutImageCollage(props: AboutUsProps) {
  return (
    <SectionShell name="about" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-about__collage">
          <div className="otu-about__collage-media">
            <ThemeImage image={props.image} ratio="3:4" placeholderLabel="Team" className="otu-about__collage-primary" />
            <ThemeImage image={props.secondaryImage} ratio="1:1" placeholderLabel="At work" className="otu-about__collage-secondary" />
            {props.tertiaryImage?.src ? <ThemeImage image={props.tertiaryImage} ratio="1:1" placeholderLabel="Detail" className="otu-about__collage-tertiary" /> : null}
          </div>
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body ?? props.description} />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
