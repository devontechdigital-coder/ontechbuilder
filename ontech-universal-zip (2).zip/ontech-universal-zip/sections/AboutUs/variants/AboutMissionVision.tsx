import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import type { AboutUsProps } from "../AboutUs";

/** About 02 — Mission & vision. A heading above two matched cards — deliberately simple, text-forward. */
export function AboutMissionVision(props: AboutUsProps) {
  return (
    <SectionShell name="about" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-about__mv-grid">
          <div className="otu-about__mv-card">
            <Icon name="target" size={26} />
            <h3>{props.missionTitle || "Our mission"}</h3>
            <p>{props.missionText}</p>
          </div>
          <div className="otu-about__mv-card">
            <Icon name="globe" size={26} />
            <h3>{props.visionTitle || "Our vision"}</h3>
            <p>{props.visionText}</p>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
