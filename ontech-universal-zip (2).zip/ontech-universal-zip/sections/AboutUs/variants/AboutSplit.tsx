import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { RichText } from "../../../components/RichText";
import { MaybeButton } from "../../../components/ThemeButton";
import type { AboutUsProps } from "../AboutUs";

/** About 01 — Split. Image on one side, story copy and a CTA on the other. The standard "who we are" section. */
export function AboutSplit(props: AboutUsProps) {
  return (
    <SectionShell name="about" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-about__split">
          <ThemeImage image={props.image} ratio={props.imageRatio ?? "4:3"} placeholderLabel="About us" />
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <RichText value={props.body ?? props.description} />
            <MaybeButton label={props.ctaLabel} href={props.ctaHref} variant="primary" iconName="arrow-right" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
