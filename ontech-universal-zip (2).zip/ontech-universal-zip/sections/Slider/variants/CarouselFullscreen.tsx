import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { Slider } from "../../../components/Slider";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { SliderSectionProps } from "../SliderSection";

/** Carousel 03 — Fullscreen. One full-bleed slide per view with overlaid text — reads like a hero rotator. */
export function CarouselFullscreen(props: SliderSectionProps) {
  return (
    <SectionShell name="slider" {...props} padded={false}>
      <Slider desktopItems={1} tabletItems={1} mobileItems={1} autoplay={props.autoplay || 6000} loop={props.loop ?? true} gap="none" arrowStyle="minimal" ariaLabel={props.heading || "Carousel"}>
        {(props.blocks ?? []).map((item) => (
          <div className="otu-slide-full" key={item.id}>
            <ThemeImage image={item.image as never} ratio="auto" rounded={false} placeholderLabel={asString(item.title)} />
            <div className="otu-slide-full__content">
              <h3>{asString(item.title)}</h3>
              <p>{asString(item.text)}</p>
            </div>
          </div>
        ))}
      </Slider>
    </SectionShell>
  );
}
