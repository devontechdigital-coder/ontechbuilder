import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { SliderSectionProps } from "../SliderSection";

/** Carousel 05 — Compact card row. Small icon cards, 4/2.5/1.2 items per view — dense and quick to scan, no big media needed. */
export function CarouselCards(props: SliderSectionProps) {
  return (
    <SectionShell name="slider" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <Slider desktopItems={4} tabletItems={2.5} mobileItems={1.2} gap="sm" autoplay={props.autoplay} loop={props.loop} ariaLabel={props.heading || "Carousel"}>
          {(props.blocks ?? []).map((item) => (
            <div className="otu-slide-compact" key={item.id}>
              <Icon name={asString(item.icon, "spark")} size={22} />
              <h4>{asString(item.title)}</h4>
              <p>{asString(item.text)}</p>
            </div>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
