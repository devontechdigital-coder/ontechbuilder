"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { SliderSectionProps } from "../SliderSection";

/** Carousel 04 — Large slide with a thumbnail rail. Click a thumbnail to switch — precise navigation over swipe momentum. */
export function CarouselThumbnailed(props: SliderSectionProps) {
  const items = props.blocks ?? [];
  const [active, setActive] = React.useState(0);
  const current = items[active] ?? items[0];

  return (
    <SectionShell name="slider" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-slide-thumbed">
          <div className="otu-slide-thumbed__main">
            <ThemeImage image={current?.image as never} ratio="16:9" placeholderLabel={asString(current?.title)} />
            <h3>{asString(current?.title)}</h3>
            <p>{asString(current?.text)}</p>
          </div>
          <ul className="otu-slide-thumbed__rail">
            {items.map((item, index) => (
              <li key={item.id}>
                <button type="button" className={index === active ? "is-active" : undefined} onClick={() => setActive(index)}>
                  <ThemeImage image={item.image as never} ratio="1:1" placeholderLabel={asString(item.title)} />
                  <span>{asString(item.title)}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </SectionShell>
  );
}
