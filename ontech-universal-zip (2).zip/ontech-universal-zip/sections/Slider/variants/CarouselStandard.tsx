import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { SliderSectionProps } from "../SliderSection";

/** Carousel 01 — Standard. 3/2/1 items per view desktop/tablet/mobile with arrows top-right. The general-purpose carousel. */
export function CarouselStandard(props: SliderSectionProps) {
  return (
    <SectionShell name="slider" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="left" />
        <Slider desktopItems={3} tabletItems={2} mobileItems={1} autoplay={props.autoplay} loop={props.loop} ariaLabel={props.heading || "Carousel"}>
          {(props.blocks ?? []).map((item) => (
            <div className="otu-slide-card" key={item.id}>
              <ThemeImage image={item.image as never} ratio="4:3" placeholderLabel={asString(item.title)} />
              <h3>{asString(item.title)}</h3>
              <p>{asString(item.text)}</p>
            </div>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
