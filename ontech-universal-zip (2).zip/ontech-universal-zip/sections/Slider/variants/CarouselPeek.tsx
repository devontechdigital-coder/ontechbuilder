import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { SliderSectionProps } from "../SliderSection";

/** Carousel 02 — Peeking. Roughly 1.15 items visible so the next slide's edge peeks in, signalling "more content" without arrows dominating. */
export function CarouselPeek(props: SliderSectionProps) {
  return (
    <SectionShell name="slider" {...props}>
      <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" className="otu-container otu-container--default" />
      <div className="otu-container otu-container--flush otu-slider--peek-wrap">
        <Slider desktopItems={1.15} tabletItems={1.1} mobileItems={1.05} autoplay={props.autoplay} loop={props.loop} arrowPosition="bottom" gap="sm" ariaLabel={props.heading || "Carousel"}>
          {(props.blocks ?? []).map((item) => (
            <div className="otu-slide-visual" key={item.id}>
              <ThemeImage image={item.image as never} ratio="21:9" placeholderLabel={asString(item.title)} />
              <div className="otu-slide-visual__caption">
                <h3>{asString(item.title)}</h3>
                <p>{asString(item.text)}</p>
              </div>
            </div>
          ))}
        </Slider>
      </div>
    </SectionShell>
  );
}
