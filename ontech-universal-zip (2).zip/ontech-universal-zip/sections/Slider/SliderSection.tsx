import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { CarouselStandard } from "./variants/CarouselStandard";
import { CarouselPeek } from "./variants/CarouselPeek";
import { CarouselFullscreen } from "./variants/CarouselFullscreen";
import { CarouselThumbnailed } from "./variants/CarouselThumbnailed";
import { CarouselCards } from "./variants/CarouselCards";

export interface SliderSectionProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  autoplay?: number;
  loop?: boolean;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<SliderSectionProps>> = {
  v1: CarouselStandard,
  v2: CarouselPeek,
  v3: CarouselFullscreen,
  v4: CarouselThumbnailed,
  v5: CarouselCards,
};

/**
 * Slider / Carousel — five carousel treatments, all on the shared
 * scroll-snap Slider primitive (components/Slider.tsx).
 * v1 Standard multi-item · v2 Peeking single item · v3 Fullscreen
 * slides · v4 Large slide + thumbnail rail · v5 Compact card row.
 */
export function SliderSection(props: SliderSectionProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default SliderSection;
