import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "slider",
  name: "Slider / Carousel",
  category: "Slider",
  description: "Five carousel treatments built on native CSS scroll-snap — no carousel library.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Standard multi-item", "Peeking single item", "Fullscreen slides", "Large slide + thumbnails", "Compact card row"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Highlights", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Recent engagements", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "range", id: "autoplay", label: "Autoplay interval", min: 0, max: 10000, step: 500, unit: "ms", default: 0, group: "Behaviour", info: "0 disables autoplay." },
    { type: "checkbox", id: "loop", label: "Loop back to start", default: true, group: "Behaviour" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "slide", name: "Slide", settings: [
      { type: "image", id: "image", label: "Image" },
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "spark" },
      { type: "text", id: "title", label: "Title", default: "Market entry strategy" },
      { type: "textarea", id: "text", label: "Text", default: "A phased go-to-market plan across three new regions." },
    ] },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "slide", settings: { title: "Market entry strategy", text: "A phased go-to-market plan across three new regions." } },
    { type: "slide", settings: { title: "Digital transformation", text: "Modernising core systems without disrupting operations." } },
    { type: "slide", settings: { title: "Operating model redesign", text: "A leaner structure built around customer outcomes." } },
    { type: "slide", settings: { title: "M&A integration", text: "Bringing two teams and two stacks together in 90 days." } },
  ],
};

export default schema;
