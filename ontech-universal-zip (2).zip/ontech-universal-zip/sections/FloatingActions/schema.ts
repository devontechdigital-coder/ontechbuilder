import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "floating-actions",
  name: "Floating Elements",
  category: "Floating Elements",
  placement: "overlay",
  description: "Five configurable action systems: circular buttons, vertical rail, expandable menu, mobile bar, minimal pills. No number is ever hardcoded.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Circular buttons", "Vertical rail", "Expandable menu", "Bottom mobile bar", "Minimal pills"]), default: "v1", group: "Layout" },
    { type: "text", id: "whatsappNumber", label: "WhatsApp number", info: "Include country code, digits only, e.g. 15550102030. Leave blank to hide.", group: "Actions" },
    { type: "text", id: "whatsappMessage", label: "WhatsApp pre-filled message", default: "Hi, I'd like to ask about your services.", group: "Actions" },
    { type: "text", id: "phone", label: "Call number", info: "Leave blank to hide the call action.", group: "Actions" },
    { type: "text", id: "customLabel", label: "Custom action label", group: "Actions" },
    { type: "url", id: "customHref", label: "Custom action link", group: "Actions" },
    { type: "select", id: "customIcon", label: "Custom action icon", options: iconSelectOptions, default: "message-circle", group: "Actions" },
  ],
  blocks: [
    { type: "action", name: "Extra action", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "send" },
      { type: "text", id: "label", label: "Label", default: "Request a quote" },
      { type: "url", id: "href", label: "Link" },
    ] },
  ],
  maxBlocks: 4,
};

export default schema;
