"use client";

import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { FloatingCircularButtons } from "./variants/FloatingCircularButtons";
import { FloatingVerticalRail } from "./variants/FloatingVerticalRail";
import { FloatingExpandableMenu } from "./variants/FloatingExpandableMenu";
import { FloatingMobileBar } from "./variants/FloatingMobileBar";
import { FloatingMinimalPills } from "./variants/FloatingMinimalPills";

export interface FloatingActionsSectionProps extends SectionBaseProps {
  whatsappNumber?: string;
  whatsappMessage?: string;
  phone?: string;
  showBackToTop?: boolean;
  customLabel?: string;
  customHref?: string;
  customIcon?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<FloatingActionsSectionProps>> = {
  v1: FloatingCircularButtons,
  v2: FloatingVerticalRail,
  v3: FloatingExpandableMenu,
  v4: FloatingMobileBar,
  v5: FloatingMinimalPills,
};

/**
 * Floating Elements — five configurable action systems (WhatsApp, call,
 * back-to-top, a custom CTA, and any "enquiry" blocks). No phone or
 * WhatsApp number is ever hardcoded — every number comes from settings.
 * v1 Individual circular buttons · v2 Vertical action rail · v3
 * Expandable floating menu · v4 Bottom mobile action bar · v5 Minimal
 * pill actions.
 */
export function FloatingActionsSection(props: FloatingActionsSectionProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default FloatingActionsSection;
