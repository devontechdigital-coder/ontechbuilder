import * as React from "react";
import { Icon } from "../../../components/Icon";
import { buildActions } from "./floatingUtils";
import type { FloatingActionsSectionProps } from "../FloatingActionsSection";

/** Floating 05 — Minimal pills. Small labelled pill buttons stacked bottom-right — no big filled circles, the lightest visual footprint of the five. */
export function FloatingMinimalPills(props: FloatingActionsSectionProps) {
  const actions = buildActions(props);
  if (actions.length === 0) return null;
  return (
    <div className="otu-floating otu-floating--pills">
      {actions.map((action) => (
        <a key={action.id} href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noopener noreferrer" : undefined}>
          <Icon name={action.icon} size={16} />
          {action.label}
        </a>
      ))}
    </div>
  );
}
