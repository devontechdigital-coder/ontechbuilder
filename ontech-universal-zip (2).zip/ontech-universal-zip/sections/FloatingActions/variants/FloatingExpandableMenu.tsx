"use client";

import * as React from "react";
import { Icon } from "../../../components/Icon";
import { buildActions } from "./floatingUtils";
import type { FloatingActionsSectionProps } from "../FloatingActionsSection";

/** Floating 03 — Expandable menu. One trigger button expands into the full action list — keeps the resting state minimal on content-heavy pages. */
export function FloatingExpandableMenu(props: FloatingActionsSectionProps) {
  const [open, setOpen] = React.useState(false);
  const actions = buildActions(props);
  if (actions.length === 0) return null;

  return (
    <div className={`otu-floating otu-floating--expand${open ? " is-open" : ""}`}>
      <div className="otu-floating__expand-list" hidden={!open}>
        {actions.map((action) => (
          <a key={action.id} href={action.href} aria-label={action.label} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noopener noreferrer" : undefined}>
            <Icon name={action.icon} size={19} />
            <span>{action.label}</span>
          </a>
        ))}
      </div>
      <button type="button" className="otu-floating__trigger" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-label={open ? "Close quick actions" : "Open quick actions"}>
        <Icon name={open ? "close" : "plus"} size={22} />
      </button>
    </div>
  );
}
