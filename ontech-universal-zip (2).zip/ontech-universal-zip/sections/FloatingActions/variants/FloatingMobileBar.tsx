import * as React from "react";
import { Icon } from "../../../components/Icon";
import { buildActions } from "./floatingUtils";
import type { FloatingActionsSectionProps } from "../FloatingActionsSection";

/** Floating 04 — Bottom mobile bar. A full-width bottom bar on small screens (hidden on desktop, where the header CTA already covers this). */
export function FloatingMobileBar(props: FloatingActionsSectionProps) {
  const actions = buildActions(props);
  if (actions.length === 0) return null;
  return (
    <div className="otu-floating otu-floating--mobile-bar">
      {actions.map((action) => (
        <a key={action.id} href={action.href} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noopener noreferrer" : undefined}>
          <Icon name={action.icon} size={20} />
          <span>{action.label}</span>
        </a>
      ))}
    </div>
  );
}
