import * as React from "react";
import { Icon } from "../../../components/Icon";
import { buildActions } from "./floatingUtils";
import type { FloatingActionsSectionProps } from "../FloatingActionsSection";

/** Floating 02 — Vertical rail. All actions share one connected pill-shaped rail rather than separate circles — a tidier, single silhouette. */
export function FloatingVerticalRail(props: FloatingActionsSectionProps) {
  const actions = buildActions(props);
  if (actions.length === 0) return null;
  return (
    <div className="otu-floating otu-floating--rail">
      {actions.map((action) => (
        <a key={action.id} href={action.href} aria-label={action.label} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noopener noreferrer" : undefined}>
          <Icon name={action.icon} size={19} />
        </a>
      ))}
    </div>
  );
}
