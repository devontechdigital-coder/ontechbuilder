import { asString, type RawBlock } from "../../../components/blockHelpers";
import type { FloatingActionsSectionProps } from "../FloatingActionsSection";

export interface FloatingAction {
  id: string;
  icon: string;
  label: string;
  href: string;
}

/** Assembles the WhatsApp, call, custom and "enquiry" blocks into one ordered action list. Numbers/links are never hardcoded — all come from settings. */
export function buildActions(props: FloatingActionsSectionProps): FloatingAction[] {
  const actions: FloatingAction[] = [];

  if (props.whatsappNumber) {
    const digits = props.whatsappNumber.replace(/[^\d]/g, "");
    const message = props.whatsappMessage ? `?text=${encodeURIComponent(props.whatsappMessage)}` : "";
    actions.push({ id: "whatsapp", icon: "whatsapp", label: "Chat on WhatsApp", href: `https://wa.me/${digits}${message}` });
  }
  if (props.phone) {
    actions.push({ id: "call", icon: "phone", label: "Call us", href: `tel:${props.phone.replace(/[^\d+]/g, "")}` });
  }
  if (props.customLabel && props.customHref) {
    actions.push({ id: "custom", icon: props.customIcon || "message-circle", label: props.customLabel, href: props.customHref });
  }

  (props.blocks ?? []).forEach((block: RawBlock) => {
    const label = asString(block.label);
    const href = asString(block.href);
    if (label && href) {
      actions.push({ id: block.id, icon: asString(block.icon, "send"), label, href });
    }
  });

  return actions;
}
