import * as React from "react";
import { Icon } from "../../../components/Icon";
import { buildActions } from "./floatingUtils";
import type { FloatingActionsSectionProps } from "../FloatingActionsSection";

/** Floating 01 — Individual circular buttons. Each action is its own stacked circular button, bottom-right. The default WhatsApp/call cluster. */
export function FloatingCircularButtons(props: FloatingActionsSectionProps) {
  const actions = buildActions(props);
  if (actions.length === 0) return null;
  return (
    <div className="otu-floating otu-floating--circles">
      {actions.map((action) => (
        <a key={action.id} href={action.href} className={`otu-floating__btn otu-floating__btn--${action.icon}`} aria-label={action.label} target={action.href.startsWith("http") ? "_blank" : undefined} rel={action.href.startsWith("http") ? "noopener noreferrer" : undefined}>
          <Icon name={action.icon} size={22} />
        </a>
      ))}
    </div>
  );
}
