import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { containerOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "footer",
  name: "Footer",
  category: "Footer",
  placement: "footer",
  description: "Five layouts: multi-column, minimal, newsletter-forward, centered, mega with a closing CTA band.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Multi-column", "Minimal", "Newsletter-forward", "Centered", "Mega + CTA band"]), default: "v1", group: "Layout" },

    { type: "image", id: "logoImage", label: "Logo", group: "Brand" },
    { type: "text", id: "logoText", label: "Logo text", default: "Ontech", group: "Brand" },
    { type: "textarea", id: "tagline", label: "Tagline", default: "Expert strategy, delivered by people who stay until it's actually working.", group: "Brand" },

    { type: "text", id: "phone", label: "Phone", default: "+1 (555) 010-2030", group: "Contact" },
    { type: "text", id: "email", label: "Email", default: "hello@example.com", group: "Contact" },
    { type: "text", id: "address", label: "Address", default: "400 Michigan Ave, Chicago, IL 60611", group: "Contact" },

    {
      type: "textarea",
      id: "linksText",
      label: "Footer links",
      group: "Links",
      info: "One link per line as Label|/url. Start a line with ## to begin a new column.",
      default:
        "## Company\nAbout|/about\nCareers|/careers\nContact|/contact\n\n## Services\nStrategy|/services/strategy\nImplementation|/services/implementation\nSupport|/services/support\n\n## Resources\nBlog|/blog\nCase studies|/case-studies\nFAQ|/faq",
    },

    { type: "checkbox", id: "showNewsletter", label: "Show newsletter signup", default: true, group: "Newsletter", info: "Newsletter-forward design only." },
    { type: "text", id: "newsletterHeading", label: "Newsletter / CTA band heading", default: "Stay informed", group: "Newsletter" },
    { type: "text", id: "newsletterPlaceholder", label: "Newsletter email placeholder", default: "Enter your email", group: "Newsletter" },
    { type: "url", id: "newsletterActionUrl", label: "Newsletter form action URL", group: "Newsletter", info: "Native POST — the host's own handler." },
    { type: "text", id: "ctaLabel", label: "CTA band button label", default: "Book a consultation", group: "Newsletter", info: "Mega + CTA band design only." },
    { type: "url", id: "ctaHref", label: "CTA band button link", default: "/contact", group: "Newsletter" },

    { type: "text", id: "copyrightText", label: "Copyright text (advanced)", group: "Legal", info: "Leave blank to auto-generate from the logo text and current year." },
    { type: "text", id: "credit", label: "Credit line", default: "Built on Ontech Universal", group: "Legal" },
    { type: "select", id: "containerWidth", label: "Container width", options: containerOptions, default: "wide", group: "Layout" },
  ],
  blocks: [
    { type: "social", name: "Social link", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "linkedin" },
      { type: "text", id: "label", label: "Accessible label", default: "LinkedIn" },
      { type: "url", id: "href", label: "Profile URL" },
    ] },
  ],
  maxBlocks: 6,
};

export default schema;
