import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FooterProps } from "../Footer";
import { FooterColumns, FooterContactLine, FooterLegal, FooterLogo, FooterSocials } from "./footerParts";

/** Footer 05 — Mega with CTA band. A closing call-to-action strip sits above a full multi-column footer — for a large marketing site's final push before the legal fine print. */
export function FooterMegaWithCta(props: FooterProps) {
  return (
    <SectionShell name="footer" {...props} as="footer" padded={false} tone={props.tone ?? "dark"} className="otu-footer--mega">
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-footer__cta-band">
          <h2>{props.newsletterHeading || "Ready to talk strategy?"}</h2>
          <MaybeButton label={props.ctaLabel || "Book a consultation"} href={props.ctaHref || "/contact"} variant="primary" size="lg" iconName="arrow-right" />
        </div>
      </Container>

      <Container width={props.containerWidth ?? "wide"} className="otu-footer__grid">
        <div className="otu-footer__brand">
          <FooterLogo props={props} />
          {props.tagline ? <p>{props.tagline}</p> : null}
          <FooterContactLine props={props} />
          <FooterSocials blocks={props.socialBlocks ?? []} />
        </div>
        <FooterColumns linksText={props.linksText} />
      </Container>

      <Container width={props.containerWidth ?? "wide"}>
        <FooterLegal props={props} />
      </Container>
    </SectionShell>
  );
}
