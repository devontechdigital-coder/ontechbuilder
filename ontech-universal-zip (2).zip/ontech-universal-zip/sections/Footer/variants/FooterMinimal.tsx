import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { parseColumns } from "../../../components/blockHelpers";
import type { FooterProps } from "../Footer";
import { FooterLegal, FooterLogo, FooterSocials } from "./footerParts";

/** Footer 02 — Minimal. A single slim row: logo, a flat list of links, socials, all inline. No columns, no newsletter. For landing pages and portfolios. */
export function FooterMinimal(props: FooterProps) {
  const links = parseColumns(props.linksText).flatMap((column) => column.links);
  return (
    <SectionShell name="footer" {...props} as="footer" padded={false} tone={props.tone ?? "default"} className="otu-footer--minimal">
      <Container width={props.containerWidth ?? "wide"} className="otu-footer__minimal-row">
        <FooterLogo props={props} />
        <nav aria-label="Footer">
          <ul className="otu-footer__minimal-links">
            {links.map((link) => (
              <li key={link.href + link.label}>
                <a href={link.href}>{link.label}</a>
              </li>
            ))}
          </ul>
        </nav>
        <FooterSocials blocks={props.socialBlocks ?? []} />
      </Container>
      <Container width={props.containerWidth ?? "wide"}>
        <FooterLegal props={props} />
      </Container>
    </SectionShell>
  );
}
