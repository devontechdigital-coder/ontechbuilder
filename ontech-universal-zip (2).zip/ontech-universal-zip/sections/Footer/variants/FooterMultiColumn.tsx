import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import type { FooterProps } from "../Footer";
import { FooterColumns, FooterContactLine, FooterLegal, FooterLogo, FooterSocials } from "./footerParts";

/** Footer 01 — Multi-column. Logo/tagline/contact in one column beside several link columns parsed from the Links textarea. The default site footer. */
export function FooterMultiColumn(props: FooterProps) {
  return (
    <SectionShell name="footer" {...props} as="footer" padded={false} tone={props.tone ?? "dark"}>
      <Container width={props.containerWidth ?? "wide"} className="otu-footer__grid">
        <div className="otu-footer__brand">
          <FooterLogo props={props} />
          {props.tagline ? <p>{props.tagline}</p> : null}
          <FooterContactLine props={props} />
          <FooterSocials blocks={props.socialBlocks ?? []} />
        </div>
        <FooterColumns linksText={props.linksText} />
      </Container>
      <Container width={props.containerWidth ?? "wide"}>
        <FooterLegal props={props} />
      </Container>
    </SectionShell>
  );
}
