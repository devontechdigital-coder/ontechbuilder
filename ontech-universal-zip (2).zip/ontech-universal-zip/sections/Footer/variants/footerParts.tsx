import * as React from "react";
import { Icon } from "../../../components/Icon";
import { asString, parseColumns, type RawBlock } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { FooterProps } from "../Footer";

export function FooterColumns({ linksText }: { linksText?: string }) {
  const columns = parseColumns(linksText);
  if (columns.length === 0) return null;
  return (
    <>
      {columns.map((column, index) => (
        <div className="otu-footer__column" key={`${column.heading}-${index}`}>
          {column.heading ? <h4>{column.heading}</h4> : null}
          <ul>
            {column.links.map((link) => (
              <li key={link.href + link.label}>
                <a href={link.href}>{link.label}</a>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </>
  );
}

export function FooterSocials({ blocks }: { blocks: RawBlock[] }) {
  if (blocks.length === 0) return null;
  return (
    <div className="otu-footer__socials">
      {blocks.map((social) => {
        const href = safeHref(social.href as string);
        if (!href) return null;
        return (
          <a key={social.id} href={href} aria-label={asString(social.label, "Social profile")}>
            <Icon name={asString(social.icon, "linkedin")} size={17} />
          </a>
        );
      })}
    </div>
  );
}

export function FooterContactLine({ props }: { props: FooterProps }) {
  if (!props.phone && !props.email && !props.address) return null;
  return (
    <div className="otu-footer__contact">
      {props.address ? (
        <span>
          <Icon name="map-pin" size={15} /> {props.address}
        </span>
      ) : null}
      {props.phone ? (
        <a href={`tel:${props.phone.replace(/[^\d+]/g, "")}`}>
          <Icon name="phone" size={15} /> {props.phone}
        </a>
      ) : null}
      {props.email ? (
        <a href={`mailto:${props.email}`}>
          <Icon name="mail" size={15} /> {props.email}
        </a>
      ) : null}
    </div>
  );
}

export function FooterLogo({ props }: { props: FooterProps }) {
  return (
    <a className="otu-footer__logo" href="/">
      {props.logoImage?.src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={props.logoImage.src} alt={props.logoImage.alt || props.logoText || "Home"} />
      ) : (
        <span>{props.logoText || "Ontech"}</span>
      )}
    </a>
  );
}

export function FooterLegal({ props }: { props: FooterProps }) {
  const year = new Date().getFullYear();
  return (
    <div className="otu-footer__legal">
      <p>{props.copyrightText || `© ${year} ${props.logoText || "Ontech"}. All rights reserved.`}</p>
      {props.credit ? <p className="otu-footer__credit">{props.credit}</p> : null}
    </div>
  );
}
