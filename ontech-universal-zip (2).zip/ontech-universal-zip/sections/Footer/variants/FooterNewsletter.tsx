import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { MaybeButton } from "../../../components/ThemeButton";
import type { FooterProps } from "../Footer";
import { FooterColumns, FooterLegal, FooterLogo, FooterSocials } from "./footerParts";

/** Footer 03 — Newsletter-forward. A signup form banner sits above the standard link columns — for content/media sites building a list. Native form, no JS submission. */
export function FooterNewsletter(props: FooterProps) {
  return (
    <SectionShell name="footer" {...props} as="footer" padded={false} tone={props.tone ?? "dark"}>
      {props.showNewsletter !== false ? (
        <Container width={props.containerWidth ?? "wide"}>
          <div className="otu-footer__newsletter">
            <h3>{props.newsletterHeading || "Stay informed"}</h3>
            <form action={props.newsletterActionUrl || undefined} method="post" className="otu-footer__newsletter-form">
              <label className="otu-visually-hidden" htmlFor="footer-newsletter-email">
                Email address
              </label>
              <input id="footer-newsletter-email" type="email" name="email" placeholder={props.newsletterPlaceholder || "Enter your email"} required />
              <MaybeButton type="submit" label="Subscribe" variant="primary" />
            </form>
          </div>
        </Container>
      ) : null}

      <Container width={props.containerWidth ?? "wide"} className="otu-footer__grid">
        <div className="otu-footer__brand">
          <FooterLogo props={props} />
          {props.tagline ? <p>{props.tagline}</p> : null}
          <FooterSocials blocks={props.socialBlocks ?? []} />
        </div>
        <FooterColumns linksText={props.linksText} />
      </Container>

      <Container width={props.containerWidth ?? "wide"}>
        <FooterLegal props={props} />
      </Container>
    </SectionShell>
  );
}
