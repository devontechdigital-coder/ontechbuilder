import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { parseColumns } from "../../../components/blockHelpers";
import type { FooterProps } from "../Footer";
import { FooterContactLine, FooterLegal, FooterLogo, FooterSocials } from "./footerParts";

/** Footer 04 — Centered, logo-led. Everything stacks and centers around a large logo — a quieter, brand-forward close for a portfolio or studio site. */
export function FooterCentered(props: FooterProps) {
  const links = parseColumns(props.linksText).flatMap((column) => column.links);
  return (
    <SectionShell name="footer" {...props} as="footer" padded={false} tone={props.tone ?? "default"} className="otu-footer--centered">
      <Container width="default" className="otu-footer__centered-inner">
        <FooterLogo props={props} />
        {props.tagline ? <p>{props.tagline}</p> : null}
        <nav aria-label="Footer">
          <ul className="otu-footer__minimal-links otu-footer__minimal-links--center">
            {links.map((link) => (
              <li key={link.href + link.label}>
                <a href={link.href}>{link.label}</a>
              </li>
            ))}
          </ul>
        </nav>
        <FooterContactLine props={props} />
        <FooterSocials blocks={props.socialBlocks ?? []} />
        <FooterLegal props={props} />
      </Container>
    </SectionShell>
  );
}
