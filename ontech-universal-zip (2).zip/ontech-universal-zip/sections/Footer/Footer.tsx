import * as React from "react";
import type { SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { FooterMultiColumn } from "./variants/FooterMultiColumn";
import { FooterMinimal } from "./variants/FooterMinimal";
import { FooterNewsletter } from "./variants/FooterNewsletter";
import { FooterCentered } from "./variants/FooterCentered";
import { FooterMegaWithCta } from "./variants/FooterMegaWithCta";

export interface FooterProps extends SectionBaseProps {
  logoImage?: ThemeImage;
  logoText?: string;
  tagline?: string;
  phone?: string;
  email?: string;
  address?: string;
  /** "Label|/url" per line, "## Heading" starts a new column. */
  linksText?: string;
  showNewsletter?: boolean;
  newsletterHeading?: string;
  newsletterPlaceholder?: string;
  newsletterActionUrl?: string;
  ctaLabel?: string;
  ctaHref?: string;
  credit?: string;
  copyrightText?: string;
  socialBlocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<FooterProps>> = {
  v1: FooterMultiColumn,
  v2: FooterMinimal,
  v3: FooterNewsletter,
  v4: FooterCentered,
  v5: FooterMegaWithCta,
};

/**
 * Footer — five layouts.
 * v1 Multi-column link footer · v2 Minimal single-row footer · v3
 * Newsletter-forward footer · v4 Centered, logo-led footer · v5 Mega
 * footer with a closing CTA band.
 */
export function Footer(props: FooterProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} socialBlocks={asBlocks(props.socialBlocks)} />;
}

export default Footer;
