import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { StatsProps } from "../Stats";

/** Stats 03 — Split with image. A supporting image on one side, a 2×2 stat grid on the other — gives numbers visual context. */
export function StatsSplitImage(props: StatsProps) {
  return (
    <SectionShell name="stats" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-stats__split">
          <ThemeImage image={props.image as never} ratio="4:3" placeholderLabel="Results" />
          <div>
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <dl className="otu-stats__split-grid">
              {(props.blocks ?? []).map((stat) => (
                <div key={stat.id}>
                  <dt>{asString(stat.value)}</dt>
                  <dd>{asString(stat.label)}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
