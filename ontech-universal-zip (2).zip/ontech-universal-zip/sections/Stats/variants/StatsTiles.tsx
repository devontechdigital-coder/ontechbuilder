import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { StatsProps } from "../Stats";

/** Stats 02 — Tiles. Each stat is its own tile alternating between a light and dark tone — visually punchier than a plain row. */
export function StatsTiles(props: StatsProps) {
  return (
    <SectionShell name="stats" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-stats__tiles">
          {(props.blocks ?? []).map((stat, index) => (
            <div key={stat.id} className={`otu-stats__tile ${index % 2 === 1 ? "otu-stats__tile--dark" : ""}`}>
              <p className="otu-stats__tile-eyebrow">{asString(stat.label)}</p>
              <p className="otu-stats__tile-value">{asString(stat.value)}</p>
              <p className="otu-stats__tile-desc">{asString(stat.description)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
