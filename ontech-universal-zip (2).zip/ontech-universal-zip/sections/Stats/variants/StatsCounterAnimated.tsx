"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asNumber, asString } from "../../../components/blockHelpers";
import type { StatsProps } from "../Stats";

/**
 * Stats 04 — Animated counters.
 * Counts up from 0 to each stat's numeric value the first time the
 * section scrolls into view, using one shared IntersectionObserver.
 * Falls back to the static final values immediately under
 * prefers-reduced-motion.
 */
function useCountUp(target: number, active: boolean, duration = 1200) {
  const [value, setValue] = React.useState(0);
  React.useEffect(() => {
    if (!active) return;
    if (typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setValue(target);
      return;
    }
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / duration);
      setValue(Math.round(target * (1 - (1 - progress) ** 3)));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [active, target, duration]);
  return value;
}

function Counter({ value, suffix }: { value: string; suffix?: string }) {
  const numeric = parseFloat(value.replace(/[^0-9.]/g, "")) || 0;
  const prefix = value.match(/^[^0-9]*/)?.[0] ?? "";
  const [ref, setRef] = React.useState<HTMLElement | null>(null);
  const [active, setActive] = React.useState(false);

  React.useEffect(() => {
    if (!ref || typeof IntersectionObserver === "undefined") {
      setActive(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setActive(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 },
    );
    observer.observe(ref);
    return () => observer.disconnect();
  }, [ref]);

  const displayed = useCountUp(numeric, active);
  return (
    <dt ref={setRef}>
      {prefix}
      {displayed}
      {suffix}
    </dt>
  );
}

export function StatsCounterAnimated(props: StatsProps) {
  return (
    <SectionShell name="stats" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <dl className="otu-stats__counters">
          {(props.blocks ?? []).map((stat) => (
            <div key={stat.id}>
              <Counter value={asString(stat.value, "0")} suffix={asString(stat.suffix)} />
              <dd>{asString(stat.label)}</dd>
            </div>
          ))}
        </dl>
      </Container>
    </SectionShell>
  );
}

export { asNumber };
