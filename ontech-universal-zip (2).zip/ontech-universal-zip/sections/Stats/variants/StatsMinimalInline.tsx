import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { StatsProps } from "../Stats";

/** Stats 05 — Minimal inline. Numbers run inline in one line separated by a thin rule — the lightest-weight, most compact of the five. */
export function StatsMinimalInline(props: StatsProps) {
  return (
    <SectionShell name="stats" {...props}>
      <Container width="default">
        <p className="otu-stats__inline">
          {(props.blocks ?? []).map((stat, index) => (
            <React.Fragment key={stat.id}>
              {index > 0 ? <span className="otu-stats__inline-divider" aria-hidden="true" /> : null}
              <span>
                <strong>{asString(stat.value)}</strong> {asString(stat.label)}
              </span>
            </React.Fragment>
          ))}
        </p>
      </Container>
    </SectionShell>
  );
}
