import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { StatsProps } from "../Stats";

/** Stats 01 — Plain row. An even row of number/label pairs with hairline dividers between them. The default counters block. */
export function StatsRow(props: StatsProps) {
  return (
    <SectionShell name="stats" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <dl className="otu-stats__row">
          {(props.blocks ?? []).map((stat) => (
            <div key={stat.id}>
              <dt>{asString(stat.value)}</dt>
              <dd>{asString(stat.label)}</dd>
            </div>
          ))}
        </dl>
      </Container>
    </SectionShell>
  );
}
