import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { StatsRow } from "./variants/StatsRow";
import { StatsTiles } from "./variants/StatsTiles";
import { StatsSplitImage } from "./variants/StatsSplitImage";
import { StatsCounterAnimated } from "./variants/StatsCounterAnimated";
import { StatsMinimalInline } from "./variants/StatsMinimalInline";

export interface StatsProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  image?: unknown;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<StatsProps>> = {
  v1: StatsRow,
  v2: StatsTiles,
  v3: StatsSplitImage,
  v4: StatsCounterAnimated,
  v5: StatsMinimalInline,
};

/**
 * Statistics / Counters — five layouts.
 * v1 Plain row · v2 Alternating tone tiles · v3 Split with a supporting
 * image · v4 Animated count-up on scroll · v5 Minimal inline numbers
 * with dividers.
 */
export function Stats(props: StatsProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Stats;
