import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "stats",
  name: "Statistics / Counters",
  category: "Statistics",
  description: "Five layouts: plain row, tone tiles, split with image, animated count-up, minimal inline.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Plain row", "Tone tiles", "Split with image", "Animated count-up", "Minimal inline"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "By the numbers", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Results our clients can measure", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media", info: "Split with image design only." },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "stat", name: "Stat", settings: [
      { type: "text", id: "value", label: "Value", default: "260" },
      { type: "text", id: "suffix", label: "Suffix", default: "+", info: "Appended after the animated number in the count-up design." },
      { type: "text", id: "label", label: "Label", default: "Companies transformed" },
      { type: "textarea", id: "description", label: "Extra description", info: "Tiles design only." },
    ] },
  ],
  maxBlocks: 6,
  defaultBlocks: [
    { type: "stat", settings: { value: "260", suffix: "+", label: "Companies transformed" } },
    { type: "stat", settings: { value: "95", suffix: "%", label: "Client satisfaction rate" } },
    { type: "stat", settings: { value: "150", suffix: "M", label: "In measured revenue growth" } },
    { type: "stat", settings: { value: "12", suffix: "", label: "Years in business" } },
  ],
};

export default schema;
