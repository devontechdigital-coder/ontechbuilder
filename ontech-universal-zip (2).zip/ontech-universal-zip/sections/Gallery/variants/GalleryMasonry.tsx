import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { GalleryProps } from "../Gallery";

const ratios = ["3:4", "1:1", "4:3", "3:4", "1:1", "3:4"] as const;

/** Gallery 02 — Masonry. CSS columns give varied tile heights, closer to a real photo wall than a grid. */
export function GalleryMasonry(props: GalleryProps) {
  return (
    <SectionShell name="gallery" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-gallery__masonry">
          {(props.blocks ?? []).map((item, index) => (
            <div className="otu-gallery__masonry-item" key={item.id}>
              <ThemeImage image={item.image as never} ratio={ratios[index % ratios.length]} placeholderLabel={asString(item.caption, "Photo")} />
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
