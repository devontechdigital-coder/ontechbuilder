import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { GalleryProps } from "../Gallery";

/** Gallery 04 — One large image with a thumbnail rail beside it. Good for a case-study or portfolio-piece detail page. */
export function GalleryFeatured(props: GalleryProps) {
  const [active, setActive] = React.useState(0);
  const items = props.blocks ?? [];
  const featured = items[active] ?? items[0];

  return (
    <SectionShell name="gallery" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-gallery__featured">
          <ThemeImage image={featured?.image as never} ratio="4:3" placeholderLabel={asString(featured?.caption, "Photo")} className="otu-gallery__featured-main" />
          <div className="otu-gallery__featured-rail">
            {items.map((item, index) => (
              <button
                key={item.id}
                type="button"
                className={`otu-gallery__featured-thumb${index === active ? " is-active" : ""}`}
                onClick={() => setActive(index)}
                aria-label={`Show photo ${index + 1}`}
                aria-pressed={index === active}
              >
                <ThemeImage image={item.image as never} ratio="1:1" placeholderLabel={asString(item.caption, "Photo")} />
              </button>
            ))}
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
