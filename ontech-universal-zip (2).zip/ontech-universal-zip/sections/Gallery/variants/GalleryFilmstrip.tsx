import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { GalleryProps } from "../Gallery";

/** Gallery 03 — Filmstrip. A horizontally scroll-snapping row with visible captions — reads left to right like a contact sheet. */
export function GalleryFilmstrip(props: GalleryProps) {
  return (
    <SectionShell name="gallery" {...props}>
      <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} className="otu-container otu-container--wide" />
      <div className="otu-gallery__filmstrip">
        {(props.blocks ?? []).map((item) => (
          <figure className="otu-gallery__filmstrip-item" key={item.id}>
            <ThemeImage image={item.image as never} ratio="4:3" placeholderLabel={asString(item.caption, "Photo")} />
            {item.caption ? <figcaption>{asString(item.caption)}</figcaption> : null}
          </figure>
        ))}
      </div>
    </SectionShell>
  );
}
