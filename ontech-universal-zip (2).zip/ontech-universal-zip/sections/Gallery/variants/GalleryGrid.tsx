import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { GalleryProps } from "../Gallery";

/** Gallery 01 — Even grid. Uniform squares in a responsive grid — the safest, most scannable layout. */
export function GalleryGrid(props: GalleryProps) {
  return (
    <SectionShell name="gallery" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-gallery__grid">
          {(props.blocks ?? []).map((item) => (
            <ThemeImage key={item.id} image={item.image as never} ratio="1:1" placeholderLabel={asString(item.caption, "Photo")} />
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
