"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import type { GalleryProps } from "../Gallery";

/** Gallery 05 — Before/after slider. A draggable divider reveals the "after" image over the "before" — for renovation, design and construction work. */
export function GalleryBeforeAfter(props: GalleryProps) {
  const [position, setPosition] = React.useState(50);

  return (
    <SectionShell name="gallery" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />

        <div className="otu-before-after">
          <ThemeImage image={props.beforeImage as never} ratio="16:9" placeholderLabel="Before" rounded />
          <div className="otu-before-after__after" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}>
            <ThemeImage image={props.afterImage as never} ratio="16:9" placeholderLabel="After" rounded />
          </div>

          <input
            type="range"
            min={0}
            max={100}
            value={position}
            onChange={(event) => setPosition(Number(event.target.value))}
            className="otu-before-after__slider"
            aria-label="Reveal before and after"
          />
          <div className="otu-before-after__handle" style={{ left: `${position}%` }}>
            <Icon name="chevron-left" size={14} />
            <Icon name="chevron-right" size={14} />
          </div>

          <span className="otu-before-after__tag otu-before-after__tag--left">{props.beforeLabel || "Before"}</span>
          <span className="otu-before-after__tag otu-before-after__tag--right">{props.afterLabel || "After"}</span>
        </div>
      </Container>
    </SectionShell>
  );
}
