import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "gallery",
  name: "Image Gallery",
  category: "Gallery",
  description: "Five presentation styles: even grid, masonry, filmstrip, featured + thumbnails, before/after.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Even grid", "Masonry", "Filmstrip", "Featured + thumbnails", "Before / after"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Gallery", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "A look at recent work", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "image", id: "beforeImage", label: "Before image", group: "Before / after", info: "Design 5 only." },
    { type: "image", id: "afterImage", label: "After image", group: "Before / after", info: "Design 5 only." },
    { type: "text", id: "beforeLabel", label: "Before label", default: "Before", group: "Before / after" },
    { type: "text", id: "afterLabel", label: "After label", default: "After", group: "Before / after" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "photo", name: "Photo", settings: [
      { type: "image", id: "image", label: "Image" },
      { type: "text", id: "caption", label: "Caption" },
    ] },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "photo", settings: { caption: "Reception, Chicago office" } },
    { type: "photo", settings: { caption: "Workshop session" } },
    { type: "photo", settings: { caption: "Client site visit" } },
    { type: "photo", settings: { caption: "Team offsite" } },
  ],
};

export default schema;
