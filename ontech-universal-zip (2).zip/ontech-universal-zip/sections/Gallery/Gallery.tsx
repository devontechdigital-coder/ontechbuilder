import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { GalleryGrid } from "./variants/GalleryGrid";
import { GalleryMasonry } from "./variants/GalleryMasonry";
import { GalleryFilmstrip } from "./variants/GalleryFilmstrip";
import { GalleryFeatured } from "./variants/GalleryFeatured";
import { GalleryBeforeAfter } from "./variants/GalleryBeforeAfter";

export interface GalleryProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  beforeImage?: unknown;
  afterImage?: unknown;
  beforeLabel?: string;
  afterLabel?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<GalleryProps>> = {
  v1: GalleryGrid,
  v2: GalleryMasonry,
  v3: GalleryFilmstrip,
  v4: GalleryFeatured,
  v5: GalleryBeforeAfter,
};

/**
 * Image Gallery — five presentation styles.
 * v1 Even grid · v2 Masonry (varied heights) · v3 Horizontal scroll
 * filmstrip · v4 One large + thumbnail rail · v5 Before/after slider.
 */
export function Gallery(props: GalleryProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Gallery;
