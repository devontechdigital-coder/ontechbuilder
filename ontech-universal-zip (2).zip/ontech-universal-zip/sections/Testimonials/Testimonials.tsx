import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { TestimonialGrid } from "./variants/TestimonialGrid";
import { TestimonialCarousel } from "./variants/TestimonialCarousel";
import { TestimonialSingleFeature } from "./variants/TestimonialSingleFeature";
import { TestimonialWall } from "./variants/TestimonialWall";
import { TestimonialSplitStats } from "./variants/TestimonialSplitStats";

export interface TestimonialsProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  ratingValue?: number;
  ratingCount?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<TestimonialsProps>> = {
  v1: TestimonialGrid,
  v2: TestimonialCarousel,
  v3: TestimonialSingleFeature,
  v4: TestimonialWall,
  v5: TestimonialSplitStats,
};

/**
 * Testimonials — five layouts.
 * v1 Even card grid · v2 Carousel with rating header · v3 One large
 * featured quote · v4 Dense masonry "wall of love" · v5 Split with
 * proof stats beside a single quote.
 */
export function Testimonials(props: TestimonialsProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Testimonials;
