import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "testimonials",
  name: "Testimonials",
  category: "Testimonials",
  description: "Five layouts: even grid, carousel, single featured, dense wall, split with stats.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Even grid", "Carousel", "Single featured", "Wall of quotes", "Split with stats"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Testimonials", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Proven impact, shared experiences", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "range", id: "ratingValue", label: "Aggregate rating", min: 0, max: 5, step: 0.1, default: 4.9, group: "Content" },
    { type: "text", id: "ratingCount", label: "Rating count text", default: "from 420 reviews", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "testimonial", name: "Testimonial", settings: [
      { type: "image", id: "avatar", label: "Photo" },
      { type: "text", id: "name", label: "Name", default: "Amanda Lewis" },
      { type: "text", id: "role", label: "Role / company", default: "Director of Strategy, Meridian Health" },
      { type: "textarea", id: "quote", label: "Quote", default: "Our company was growing fast, but our culture couldn't keep pace. The team helped us rebuild it deliberately." },
      { type: "range", id: "rating", label: "Rating", min: 1, max: 5, step: 1, default: 5 },
    ] },
    { type: "stat", name: "Proof stat (split design)", settings: [
      { type: "text", id: "value", label: "Value", default: "38%" },
      { type: "text", id: "label", label: "Label", default: "Increase in retention within 12 months" },
    ] },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "testimonial", settings: { name: "Amanda Lewis", role: "Director of Strategy, Meridian Health", quote: "Our company was growing fast, but our culture couldn't keep pace. The team helped us rebuild it deliberately.", rating: 5 } },
    { type: "testimonial", settings: { name: "Owen Ricci", role: "COO, Larkspur Manufacturing", quote: "They didn't just hand us a deck — they stayed until the new process was actually running.", rating: 5 } },
    { type: "testimonial", settings: { name: "Priya Nair", role: "Founder, Northloop Retail", quote: "The clearest, most honest advisory relationship we've had.", rating: 5 } },
  ],
};

export default schema;
