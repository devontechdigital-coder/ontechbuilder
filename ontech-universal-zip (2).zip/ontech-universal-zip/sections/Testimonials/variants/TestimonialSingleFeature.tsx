import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TestimonialsProps } from "../Testimonials";

/** Testimonial 03 — Single featured. One large quote centered, oversized quotation mark, with a photo above the attribution. Only the first block renders. */
export function TestimonialSingleFeature(props: TestimonialsProps) {
  const item = (props.blocks ?? [])[0];
  if (!item) return null;
  return (
    <SectionShell name="testimonials" {...props} tone={props.tone ?? "dark"}>
      <Container width="narrow">
        <div className="otu-testimonial-feature">
          <ThemeImage image={item.avatar as never} ratio="1:1" placeholderLabel={asString(item.name, "A")} rounded className="otu-avatar otu-avatar--lg" />
          <Icon name="quote" size={32} className="otu-testimonial-feature__mark" />
          <blockquote>{asString(item.quote)}</blockquote>
          <p className="otu-testimonial-feature__name">{asString(item.name)}</p>
          <p className="otu-testimonial-feature__role">{asString(item.role)}</p>
        </div>
      </Container>
    </SectionShell>
  );
}
