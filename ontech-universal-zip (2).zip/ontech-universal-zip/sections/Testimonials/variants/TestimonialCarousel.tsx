import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Rating } from "../../../components/Badge";
import { Slider } from "../../../components/Slider";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TestimonialsProps } from "../Testimonials";

/** Testimonial 02 — Carousel. Aggregate rating in the heading, quotes scroll 2-up/1-up beneath. */
export function TestimonialCarousel(props: TestimonialsProps) {
  return (
    <SectionShell name="testimonials" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading
          eyebrow={props.eyebrow}
          heading={props.heading}
          description={props.description}
          align="center"
          aside={props.ratingValue ? <Rating value={props.ratingValue} count={props.ratingCount} showValue /> : undefined}
        />
        <Slider desktopItems={2} tabletItems={1.3} mobileItems={1} ariaLabel="Testimonials">
          {(props.blocks ?? []).map((item) => (
            <figure className="otu-testimonial-card otu-testimonial-card--flat" key={item.id}>
              <blockquote>{asString(item.quote)}</blockquote>
              <figcaption>
                <ThemeImage image={item.avatar as never} ratio="1:1" placeholderLabel={asString(item.name, "A")} rounded className="otu-avatar" />
                <span>
                  <strong>{asString(item.name)}</strong>
                  <em>{asString(item.role)}</em>
                </span>
              </figcaption>
            </figure>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
