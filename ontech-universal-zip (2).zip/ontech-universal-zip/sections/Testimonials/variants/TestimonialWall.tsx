import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Rating } from "../../../components/Badge";
import { asNumber, asString } from "../../../components/blockHelpers";
import type { TestimonialsProps } from "../Testimonials";

/** Testimonial 04 — Wall. A dense CSS-columns masonry of short quotes with no avatars — reads as a "wall of love" screenshot collage. */
export function TestimonialWall(props: TestimonialsProps) {
  return (
    <SectionShell name="testimonials" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-testimonial__wall">
          {(props.blocks ?? []).map((item) => (
            <div className="otu-testimonial-wall-card" key={item.id}>
              <Rating value={asNumber(item.rating, 5)} />
              <p>{asString(item.quote)}</p>
              <span className="otu-testimonial-wall-card__name">{asString(item.name)}</span>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
