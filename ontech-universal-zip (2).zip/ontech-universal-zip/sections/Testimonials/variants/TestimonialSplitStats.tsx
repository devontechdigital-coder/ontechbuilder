import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString, blocksOfType } from "../../../components/blockHelpers";
import type { TestimonialsProps } from "../Testimonials";

/** Testimonial 05 — Split with stats. One quote on the left; a column of "stat" blocks proving the claim on the right. */
export function TestimonialSplitStats(props: TestimonialsProps) {
  const quote = blocksOfType(props.blocks ?? [], "quote")[0] ?? (props.blocks ?? [])[0];
  const stats = blocksOfType(props.blocks ?? [], "stat");

  return (
    <SectionShell name="testimonials" {...props} tone={props.tone ?? "surface"}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-testimonial-split">
          <div className="otu-testimonial-split__quote">
            <Icon name="quote" size={28} />
            <blockquote>{asString(quote?.quote)}</blockquote>
            <div className="otu-testimonial-split__attribution">
              <ThemeImage image={quote?.avatar as never} ratio="1:1" placeholderLabel={asString(quote?.name, "A")} rounded className="otu-avatar" />
              <span>
                <strong>{asString(quote?.name)}</strong>
                <em>{asString(quote?.role)}</em>
              </span>
            </div>
          </div>
          <dl className="otu-testimonial-split__stats">
            {stats.map((stat) => (
              <div key={stat.id}>
                <dt>{asString(stat.value)}</dt>
                <dd>{asString(stat.label)}</dd>
              </div>
            ))}
          </dl>
        </div>
      </Container>
    </SectionShell>
  );
}
