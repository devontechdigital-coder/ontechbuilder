import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Rating } from "../../../components/Badge";
import { Icon } from "../../../components/Icon";
import { ThemeImage } from "../../../components/ThemeImage";
import { asNumber, asString } from "../../../components/blockHelpers";
import type { TestimonialsProps } from "../Testimonials";

/** Testimonial 01 — Even grid. Bordered cards, three per row, quote + avatar + rating. The standard proof section. */
export function TestimonialGrid(props: TestimonialsProps) {
  return (
    <SectionShell name="testimonials" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-testimonial__grid">
          {(props.blocks ?? []).map((item) => (
            <figure className="otu-testimonial-card" key={item.id}>
              <Icon name="quote" size={22} className="otu-testimonial-card__mark" />
              <Rating value={asNumber(item.rating, 5)} />
              <blockquote>{asString(item.quote)}</blockquote>
              <figcaption>
                <ThemeImage image={item.avatar as never} ratio="1:1" placeholderLabel={asString(item.name, "A")} rounded className="otu-avatar" />
                <span>
                  <strong>{asString(item.name)}</strong>
                  <em>{asString(item.role)}</em>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
