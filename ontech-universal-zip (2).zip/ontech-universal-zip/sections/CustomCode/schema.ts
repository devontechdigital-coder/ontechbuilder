import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "custom-code",
  name: "Custom Code",
  category: "Custom Code",
  description:
    "An escape hatch for static, sanitized HTML/CSS markup only. No JavaScript execution is supported — see README.md for why and what a host would need to add to offer that safely.",
  settings: [
    {
      type: "code",
      id: "html",
      label: "Custom HTML",
      info: "Sanitized by the host's custom-code field before rendering. No <script> execution — see the theme README for details.",
    },
    { type: "text", id: "customClass", label: "Custom CSS class", group: "Advanced", info: "Available on every section in the theme, not just this one — target it from your own stylesheet." },
    ...baseSectionSettings().filter((setting) => setting.id !== "customClass"),
  ],
};

export default schema;
