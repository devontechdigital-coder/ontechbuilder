import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { SectionShell } from "../../components/SectionShell";
import { Container } from "../../components/Container";

export interface CustomCodeProps extends SectionBaseProps {
  /** Sanitized-on-save HTML from the host's own custom-code field. Rendered as-is — the theme does not sanitize or execute it. */
  html?: string;
}

/**
 * sections/CustomCode/CustomCode.tsx
 *
 * A controlled escape hatch for advanced merchants, scoped to what is
 * actually safe for a theme package to support.
 *
 * WHAT THIS SUPPORTS: static, sanitized HTML markup and inline CSS via
 * class names on components/SectionShell.tsx's `customClass` prop
 * (available on every section, not just this one).
 *
 * WHAT THIS DELIBERATELY DOES NOT SUPPORT: arbitrary JavaScript
 * execution. The theme performs no dynamic code evaluation, no runtime
 * function construction from strings, no dynamic `<script>` injection,
 * and has no mechanism for a merchant-supplied string to run as code in
 * the visitor's browser. This is a limitation,
 * not an oversight — see README.md → "Custom Code limitations" for the
 * reasoning and for what a host platform would need to add (its own
 * sanitization + CSP-scoped script execution) if it wants to offer
 * that safely itself.
 *
 * `html` is expected to already be sanitized by the host's own
 * custom-code field before it reaches this component — the same
 * contract as RichText's `html` mode.
 */
export function CustomCode(props: CustomCodeProps) {
  if (!props.html?.trim()) return null;
  return (
    <SectionShell name="custom-code" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <div className="otu-custom-code" dangerouslySetInnerHTML={{ __html: props.html }} />
      </Container>
    </SectionShell>
  );
}

export default CustomCode;
