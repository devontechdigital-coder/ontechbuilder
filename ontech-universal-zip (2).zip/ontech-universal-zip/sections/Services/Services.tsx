import * as React from "react";
import type { ColumnCount, SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { ServicesIconGrid } from "./variants/ServicesIconGrid";
import { ServicesPhotoCards } from "./variants/ServicesPhotoCards";
import { ServicesAccordionList } from "./variants/ServicesAccordionList";
import { ServicesNumberedRows } from "./variants/ServicesNumberedRows";
import { ServicesTabbed } from "./variants/ServicesTabbed";

export interface ServicesProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  columns?: ColumnCount;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<ServicesProps>> = {
  v1: ServicesIconGrid,
  v2: ServicesPhotoCards,
  v3: ServicesAccordionList,
  v4: ServicesNumberedRows,
  v5: ServicesTabbed,
};

/**
 * Services — five ways to present a service catalogue.
 * v1 Icon grid · v2 Full-bleed photo cards · v3 Expandable accordion
 * list · v4 Numbered horizontal rows · v5 Tabbed browser with detail
 * panel.
 */
export function Services(props: ServicesProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Services;
