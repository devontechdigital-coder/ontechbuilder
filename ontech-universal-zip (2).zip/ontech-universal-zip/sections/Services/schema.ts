import { iconSelectOptions } from "../../components/Icon";
import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, columnOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "services",
  name: "Services",
  category: "Services",
  description: "Five service-catalogue layouts: icon grid, photo cards, expandable list, numbered rows, tabbed browser.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Icon grid", "Photo cards", "Expandable list", "Numbered rows", "Tabbed browser"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "What we offer", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Our core consulting services", group: "Content" },
    { type: "textarea", id: "description", label: "Description", default: "Tailored solutions to help businesses overcome challenges and achieve sustainable growth.", group: "Content" },
    { type: "select", id: "columns", label: "Columns", options: columnOptions, default: "3", group: "Layout" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "service", name: "Service", settings: [
      { type: "select", id: "icon", label: "Icon", options: iconSelectOptions, default: "briefcase" },
      { type: "image", id: "image", label: "Image" },
      { type: "text", id: "title", label: "Title", default: "Business strategy" },
      { type: "textarea", id: "text", label: "Description", default: "Long-range planning that connects today's decisions to where you want the business to be in five years." },
      { type: "url", id: "href", label: "Link" },
    ] },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "service", settings: { icon: "target", title: "Business strategy", text: "Long-range planning connected to real execution." } },
    { type: "service", settings: { icon: "settings", title: "Process optimization", text: "Cutting the friction between decision and delivery." } },
    { type: "service", settings: { icon: "trending-up", title: "Financial advisory", text: "Clear-eyed modelling for growth and resilience." } },
    { type: "service", settings: { icon: "users", title: "Change management", text: "Bringing the whole organisation along with the plan." } },
  ],
};

export default schema;
