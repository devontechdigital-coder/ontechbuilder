import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { ServicesProps } from "../Services";

/** Services 02 — Photo cards. Full-bleed photography with a title pill over the bottom edge. Editorial, image-led. */
export function ServicesPhotoCards(props: ServicesProps) {
  return (
    <SectionShell name="services" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-services__grid otu-grid-cols-${props.columns ?? 4}`}>
          {(props.blocks ?? []).map((service) => (
            <div className="otu-service-photo-card" key={service.id}>
              <ThemeImage image={service.image as never} ratio="3:4" placeholderLabel={asString(service.title)} rounded={false} />
              <span>{asString(service.title)}</span>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
