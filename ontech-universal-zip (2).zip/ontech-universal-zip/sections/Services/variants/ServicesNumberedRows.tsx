import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import type { ServicesProps } from "../Services";

/** Services 04 — Numbered rows. Plain hairline-separated rows, number/title/text/link across the width — dense and text-forward. */
export function ServicesNumberedRows(props: ServicesProps) {
  return (
    <SectionShell name="services" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-services__rows">
          {(props.blocks ?? []).map((service, index) => (
            <div className="otu-services__row" key={service.id}>
              <span className="otu-services__row-index">{String(index + 1).padStart(2, "0")}</span>
              <h3>{asString(service.title)}</h3>
              <p>{asString(service.text)}</p>
              <MaybeButton label="View" href={asString(service.href) || undefined} variant="ghost" size="sm" iconName="arrow-up-right" />
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
