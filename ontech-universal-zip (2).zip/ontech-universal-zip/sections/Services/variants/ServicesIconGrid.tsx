import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import type { ServicesProps } from "../Services";

/** Services 01 — Icon grid. Bordered cards with icon, title, blurb and a "learn more" link. The general-purpose services block. */
export function ServicesIconGrid(props: ServicesProps) {
  return (
    <SectionShell name="services" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-services__grid otu-grid-cols-${props.columns ?? 3}`}>
          {(props.blocks ?? []).map((service) => (
            <div className="otu-service-card" key={service.id}>
              <span className="otu-service-card__icon">
                <Icon name={asString(service.icon, "briefcase")} size={24} />
              </span>
              <h3>{asString(service.title)}</h3>
              <p>{asString(service.text)}</p>
              <MaybeButton label="Learn more" href={asString(service.href) || undefined} variant="link" size="sm" iconName="arrow-right" />
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
