"use client";

import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { ServicesProps } from "../Services";

/** Services 03 — Expandable list. Numbered rows expand in place on click to reveal an image and longer description — one open at a time. */
export function ServicesAccordionList(props: ServicesProps) {
  const [active, setActive] = React.useState(0);
  const items = props.blocks ?? [];

  return (
    <SectionShell name="services" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-services__accordion">
          {items.map((service, index) => {
            const open = index === active;
            return (
              <div key={service.id} className={`otu-services__accordion-row${open ? " is-open" : ""}`}>
                <button type="button" className="otu-services__accordion-head" onClick={() => setActive(open ? -1 : index)} aria-expanded={open}>
                  <span className="otu-services__accordion-index">{String(index + 1).padStart(2, "0")}</span>
                  <span className="otu-services__accordion-title">{asString(service.title)}</span>
                  <Icon name={open ? "minus" : "plus"} size={18} />
                </button>
                {open ? (
                  <div className="otu-services__accordion-panel">
                    <ThemeImage image={service.image as never} ratio="16:9" placeholderLabel={asString(service.title)} />
                    <p>{asString(service.text)}</p>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </Container>
    </SectionShell>
  );
}
