import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Tabs } from "../../../components/Tabs";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { ServicesProps } from "../Services";

/** Services 05 — Tabbed. Service names as a vertical rail of tabs; selecting one shows its image and description in a detail panel. */
export function ServicesTabbed(props: ServicesProps) {
  const items = (props.blocks ?? []).map((service) => ({
    id: service.id,
    label: asString(service.title),
    icon: asString(service.icon, "briefcase"),
    content: (
      <div className="otu-services__tab-panel">
        <ThemeImage image={service.image as never} ratio="16:9" placeholderLabel={asString(service.title)} />
        <p>{asString(service.text)}</p>
      </div>
    ),
  }));

  return (
    <SectionShell name="services" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Tabs items={items} orientation="vertical" listStyle="rail" idPrefix="services" />
      </Container>
    </SectionShell>
  );
}
