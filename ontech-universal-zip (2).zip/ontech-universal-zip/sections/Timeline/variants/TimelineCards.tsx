import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TimelineProps } from "../Timeline";

/** Timeline 04 — Milestone cards. Each entry is a full bordered card with an optional image, in a two-column grid — for a project's build phases. */
export function TimelineCards(props: TimelineProps) {
  return (
    <SectionShell name="timeline" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-timeline__cards">
          {(props.blocks ?? []).map((item, index) => (
            <div className="otu-timeline__milestone-card" key={item.id}>
              <span className="otu-timeline__milestone-index">{String(index + 1).padStart(2, "0")}</span>
              {item.image ? <ThemeImage image={item.image as never} ratio="16:9" placeholderLabel={asString(item.title)} /> : null}
              <span className="otu-timeline__date">{asString(item.date)}</span>
              <h3>{asString(item.title)}</h3>
              <p>{asString(item.description)}</p>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
