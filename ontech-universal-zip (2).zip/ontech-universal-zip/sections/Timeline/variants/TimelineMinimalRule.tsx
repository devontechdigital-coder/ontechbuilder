import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { TimelineProps } from "../Timeline";

/** Timeline 05 — Minimal rule. Text-only rows separated by hairlines, date and title on one line — for a dense changelog-style history. */
export function TimelineMinimalRule(props: TimelineProps) {
  return (
    <SectionShell name="timeline" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-timeline__minimal">
          {(props.blocks ?? []).map((item) => (
            <div className="otu-timeline__minimal-row" key={item.id}>
              <span className="otu-timeline__date">{asString(item.date)}</span>
              <div>
                <h3>{asString(item.title)}</h3>
                <p>{asString(item.description)}</p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
