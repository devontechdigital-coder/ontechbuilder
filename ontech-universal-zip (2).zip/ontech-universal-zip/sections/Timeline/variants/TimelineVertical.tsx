import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { TimelineProps } from "../Timeline";

/** Timeline 01 — Vertical rail. A single left-hand line with dots and dates, entries stacked below each other. Reads top-to-bottom like a history log. */
export function TimelineVertical(props: TimelineProps) {
  return (
    <SectionShell name="timeline" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <ol className="otu-timeline__vertical">
          {(props.blocks ?? []).map((item) => (
            <li key={item.id}>
              <span className="otu-timeline__dot" />
              <span className="otu-timeline__date">{asString(item.date)}</span>
              <h3>{asString(item.title)}</h3>
              <p>{asString(item.description)}</p>
            </li>
          ))}
        </ol>
      </Container>
    </SectionShell>
  );
}
