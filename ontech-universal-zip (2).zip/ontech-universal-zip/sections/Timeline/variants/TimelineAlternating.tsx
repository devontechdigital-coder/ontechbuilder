import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { TimelineProps } from "../Timeline";

/** Timeline 02 — Alternating. A centered spine with entries alternating left/right — the classic "company history" layout. */
export function TimelineAlternating(props: TimelineProps) {
  return (
    <SectionShell name="timeline" {...props}>
      <Container width={props.containerWidth ?? "default"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <ol className="otu-timeline__alternating">
          {(props.blocks ?? []).map((item, index) => (
            <li key={item.id} className={index % 2 === 0 ? "is-left" : "is-right"}>
              <div className="otu-timeline__alternating-card">
                <span className="otu-timeline__date">{asString(item.date)}</span>
                <h3>{asString(item.title)}</h3>
                <p>{asString(item.description)}</p>
              </div>
              <span className="otu-timeline__dot" />
            </li>
          ))}
        </ol>
      </Container>
    </SectionShell>
  );
}
