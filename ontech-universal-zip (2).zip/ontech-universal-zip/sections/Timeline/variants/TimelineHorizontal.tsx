import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { TimelineProps } from "../Timeline";

/** Timeline 03 — Horizontal. A scroll-snapping row along a single rule — for a roadmap or process that reads left-to-right. */
export function TimelineHorizontal(props: TimelineProps) {
  return (
    <SectionShell name="timeline" {...props}>
      <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" className="otu-container otu-container--default" />
      <div className="otu-timeline__horizontal">
        {(props.blocks ?? []).map((item) => (
          <div className="otu-timeline__horizontal-item" key={item.id}>
            <span className="otu-timeline__dot" />
            <span className="otu-timeline__date">{asString(item.date)}</span>
            <h3>{asString(item.title)}</h3>
            <p>{asString(item.description)}</p>
          </div>
        ))}
      </div>
    </SectionShell>
  );
}
