import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "timeline",
  name: "Timeline",
  category: "Timeline",
  description: "Five ways to present a dated, ordered sequence: vertical, alternating, horizontal, milestone cards, minimal rule.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Vertical rail", "Alternating", "Horizontal scroll", "Milestone cards", "Minimal rule"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our story", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "A decade of growth", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "milestone", name: "Milestone", settings: [
      { type: "text", id: "date", label: "Date / step", default: "2019" },
      { type: "text", id: "title", label: "Title", default: "Founded in Chicago" },
      { type: "textarea", id: "description", label: "Description", default: "Started as a two-person advisory practice focused on mid-market manufacturing." },
      { type: "image", id: "image", label: "Image", info: "Milestone cards design only." },
    ] },
  ],
  maxBlocks: 10,
  defaultBlocks: [
    { type: "milestone", settings: { date: "2019", title: "Founded in Chicago", description: "Started as a two-person advisory practice." } },
    { type: "milestone", settings: { date: "2021", title: "First enterprise client", description: "Expanded into full transformation programs." } },
    { type: "milestone", settings: { date: "2023", title: "Opened a second office", description: "Grew the team to 40 consultants across two cities." } },
    { type: "milestone", settings: { date: "2025", title: "260+ engagements delivered", description: "Reached a decade milestone across six industries." } },
  ],
};

export default schema;
