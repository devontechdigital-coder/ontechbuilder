import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { TimelineVertical } from "./variants/TimelineVertical";
import { TimelineAlternating } from "./variants/TimelineAlternating";
import { TimelineHorizontal } from "./variants/TimelineHorizontal";
import { TimelineCards } from "./variants/TimelineCards";
import { TimelineMinimalRule } from "./variants/TimelineMinimalRule";

export interface TimelineProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<TimelineProps>> = {
  v1: TimelineVertical,
  v2: TimelineAlternating,
  v3: TimelineHorizontal,
  v4: TimelineCards,
  v5: TimelineMinimalRule,
};

/**
 * Timeline — five ways to present a dated/ordered sequence (company
 * history, roadmap, project phases). Numbering is used here because the
 * content genuinely is sequential.
 * v1 Left-aligned vertical rail · v2 Alternating left/right · v3
 * Horizontal scrolling timeline · v4 Card-per-milestone · v5 Minimal
 * rule with inline dates.
 */
export function Timeline(props: TimelineProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Timeline;
