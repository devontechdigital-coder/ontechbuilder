import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "logo-cloud",
  name: "Logo / Client / Partner",
  category: "Logos",
  description: "Five presentation styles: plain grid, marquee strip, bordered grid, large heading, carousel with dots.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Plain grid", "Marquee strip", "Bordered grid", "Large heading", "Carousel with dots"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Trusted by", group: "Content", info: "Large heading design only." },
    { type: "text", id: "heading", label: "Heading", default: "Companies who rely on our expertise", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "logo", name: "Logo", settings: [
      { type: "text", id: "name", label: "Company name", default: "Client" },
      { type: "image", id: "image", label: "Logo image" },
    ] },
  ],
  maxBlocks: 16,
  defaultBlocks: [
    { type: "logo", settings: { name: "Meridian" } },
    { type: "logo", settings: { name: "Larkspur" } },
    { type: "logo", settings: { name: "Northloop" } },
    { type: "logo", settings: { name: "Calderon Group" } },
    { type: "logo", settings: { name: "Fieldstone" } },
    { type: "logo", settings: { name: "Amber & Co" } },
  ],
};

export default schema;
