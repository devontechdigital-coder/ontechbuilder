import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { LogoGrid } from "./variants/LogoGrid";
import { LogoMarqueeStrip } from "./variants/LogoMarqueeStrip";
import { LogoBordered } from "./variants/LogoBordered";
import { LogoWithHeading } from "./variants/LogoWithHeading";
import { LogoCarouselDots } from "./variants/LogoCarouselDots";

export interface LogoCloudProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<LogoCloudProps>> = {
  v1: LogoGrid,
  v2: LogoMarqueeStrip,
  v3: LogoBordered,
  v4: LogoWithHeading,
  v5: LogoCarouselDots,
};

/**
 * Logo / Client / Partner — five presentation styles.
 * v1 Plain even grid · v2 Continuous marquee strip · v3 Bordered grid
 * cells · v4 Large heading with logos beneath · v5 Carousel with dots
 * for a long partner list.
 */
export function LogoCloud(props: LogoCloudProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default LogoCloud;
