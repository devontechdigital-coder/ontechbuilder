import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { LogoCloudProps } from "../LogoCloud";

/** Logo 03 — Bordered grid. Each logo sits in its own hairline-bordered cell, full-bleed to the container — a denser, more structured feel. */
export function LogoBordered(props: LogoCloudProps) {
  return (
    <SectionShell name="logos" {...props}>
      {props.heading ? <p className="otu-logos__heading otu-container otu-container--wide">{props.heading}</p> : null}
      <div className="otu-container otu-container--wide">
        <div className="otu-logos__bordered">
          {(props.blocks ?? []).map((logo) => {
            const image = logo.image as { src?: string; alt?: string } | undefined;
            return (
              <div className="otu-logos__bordered-cell" key={logo.id}>
                {image?.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={image.src} alt={image.alt || asString(logo.name, "Client logo")} loading="lazy" />
                ) : (
                  <span>{asString(logo.name, "Client")}</span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </SectionShell>
  );
}
