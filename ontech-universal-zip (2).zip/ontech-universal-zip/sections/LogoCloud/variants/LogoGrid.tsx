import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { LogoCloudProps } from "../LogoCloud";

/** Logo 01 — Plain grid. Grayscale-on-hover-color logos in an even row. The default trust strip. */
export function LogoGrid(props: LogoCloudProps) {
  return (
    <SectionShell name="logos" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        {props.heading ? <p className="otu-logos__heading">{props.heading}</p> : null}
        <div className="otu-logos__grid">
          {(props.blocks ?? []).map((logo) => {
            const image = logo.image as { src?: string; alt?: string } | undefined;
            return (
              <div className="otu-logos__item" key={logo.id}>
                {image?.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={image.src} alt={image.alt || asString(logo.name, "Client logo")} loading="lazy" />
                ) : (
                  <span>{asString(logo.name, "Client")}</span>
                )}
              </div>
            );
          })}
        </div>
      </Container>
    </SectionShell>
  );
}
