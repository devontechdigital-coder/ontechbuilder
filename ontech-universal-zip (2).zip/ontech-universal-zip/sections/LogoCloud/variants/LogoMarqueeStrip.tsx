import * as React from "react";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { LogoCloudProps } from "../LogoCloud";

/** Logo 02 — Marquee strip. Logos scroll continuously in a seamless CSS-only loop — for a long client list that shouldn't take vertical space. */
export function LogoMarqueeStrip(props: LogoCloudProps) {
  const items = props.blocks ?? [];
  const doubled = [...items, ...items];
  return (
    <SectionShell name="logos" {...props} padded={false} className="otu-marquee-section">
      {props.heading ? (
        <p className="otu-logos__heading otu-container otu-container--wide">{props.heading}</p>
      ) : null}
      <div className="otu-marquee" aria-label="Client logos">
        <div className="otu-marquee__track">
          {doubled.map((logo, index) => {
            const image = logo.image as { src?: string; alt?: string } | undefined;
            return (
              <span className="otu-marquee__item" key={`${logo.id}-${index}`} aria-hidden={index >= items.length}>
                {image?.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={image.src} alt={image.alt || asString(logo.name, "Client logo")} loading="lazy" />
                ) : (
                  asString(logo.name, "Client")
                )}
              </span>
            );
          })}
        </div>
      </div>
    </SectionShell>
  );
}
