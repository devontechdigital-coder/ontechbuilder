import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Slider } from "../../../components/Slider";
import { asString } from "../../../components/blockHelpers";
import type { LogoCloudProps } from "../LogoCloud";

/** Logo 05 — Carousel with dots. Logos page through a controlled carousel rather than scrolling continuously — better when the person wants to browse deliberately. */
export function LogoCarouselDots(props: LogoCloudProps) {
  return (
    <SectionShell name="logos" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        {props.heading ? <p className="otu-logos__heading">{props.heading}</p> : null}
        <Slider desktopItems={5} tabletItems={3} mobileItems={2} showArrows={false} gap="sm" ariaLabel="Client logos">
          {(props.blocks ?? []).map((logo) => {
            const image = logo.image as { src?: string; alt?: string } | undefined;
            return (
              <div className="otu-logos__item" key={logo.id}>
                {image?.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={image.src} alt={image.alt || asString(logo.name, "Client logo")} loading="lazy" />
                ) : (
                  <span>{asString(logo.name, "Client")}</span>
                )}
              </div>
            );
          })}
        </Slider>
      </Container>
    </SectionShell>
  );
}
