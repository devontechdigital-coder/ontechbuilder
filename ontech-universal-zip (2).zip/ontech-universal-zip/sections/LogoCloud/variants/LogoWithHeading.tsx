import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { asString } from "../../../components/blockHelpers";
import type { LogoCloudProps } from "../LogoCloud";

/** Logo 04 — Large heading. A big centered statement above a smaller, tighter logo row — foregrounds the claim, logos are supporting proof. */
export function LogoWithHeading(props: LogoCloudProps) {
  return (
    <SectionShell name="logos" {...props} tone={props.tone ?? "surface"}>
      <Container width="default">
        {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--center">{props.eyebrow}</p> : null}
        {props.heading ? <h2 className="otu-heading--center">{props.heading}</h2> : null}
        <div className="otu-logos__tight-row">
          {(props.blocks ?? []).map((logo) => {
            const image = logo.image as { src?: string; alt?: string } | undefined;
            return (
              <span key={logo.id}>
                {image?.src ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={image.src} alt={image.alt || asString(logo.name, "Client logo")} loading="lazy" />
                ) : (
                  asString(logo.name, "Client")
                )}
              </span>
            );
          })}
        </div>
      </Container>
    </SectionShell>
  );
}
