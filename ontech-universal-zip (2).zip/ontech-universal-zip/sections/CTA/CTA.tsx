import * as React from "react";
import type { SectionBaseProps, ThemeImage } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { CtaCentered } from "./variants/CtaCentered";
import { CtaSplitImage } from "./variants/CtaSplitImage";
import { CtaBanner } from "./variants/CtaBanner";
import { CtaCard } from "./variants/CtaCard";
import { CtaGradientEdge } from "./variants/CtaGradientEdge";

export interface CTAProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
  image?: ThemeImage;
  avatarLabel?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<CTAProps>> = {
  v1: CtaCentered,
  v2: CtaSplitImage,
  v3: CtaBanner,
  v4: CtaCard,
  v5: CtaGradientEdge,
};

/**
 * CTA — five closing-call layouts.
 * v1 Centered dark · v2 Split with image · v3 Slim inline banner ·
 * v4 Card floating on a tinted section · v5 Gradient-edge statement.
 */
export function CTA(props: CTAProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default CTA;
