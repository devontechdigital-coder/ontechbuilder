import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { MaybeButton } from "../../../components/ThemeButton";
import type { CTAProps } from "../CTA";

/** CTA 05 — Gradient edge. A large statement heading with a soft radial accent glow at one corner — for a bolder, more atmospheric close. */
export function CtaGradientEdge(props: CTAProps) {
  return (
    <SectionShell name="cta" {...props} tone={props.tone ?? "dark"} className="otu-cta--gradient">
      <Container width="default">
        <div className="otu-cta__gradient">
          {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
          <h2>{props.heading}</h2>
          {props.description ? <p>{props.description}</p> : null}
          <div className="otu-cta__actions">
            <MaybeButton label={props.primaryLabel || "Start the conversation"} href={props.primaryHref} variant="primary" size="lg" iconName="arrow-right" />
            <MaybeButton label={props.secondaryLabel} href={props.secondaryHref} variant="ghost" size="lg" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
