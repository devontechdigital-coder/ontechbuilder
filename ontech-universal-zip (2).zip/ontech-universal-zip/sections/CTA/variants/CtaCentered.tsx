import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { MaybeButton, ThemeButton } from "../../../components/ThemeButton";
import { asString } from "../../../components/blockHelpers";
import type { CTAProps } from "../CTA";

/** CTA 01 — Centered dark. A dark full-width band with centered heading and two buttons. The default closing call-to-action. */
export function CtaCentered(props: CTAProps) {
  return (
    <SectionShell name="cta" {...props} tone={props.tone ?? "dark"}>
      <Container width="default">
        <div className="otu-cta__centered">
          {props.eyebrow ? <p className="otu-eyebrow otu-eyebrow--light">{props.eyebrow}</p> : null}
          {props.heading ? <h2>{props.heading}</h2> : null}
          {props.description ? <p>{props.description}</p> : null}
          <div className="otu-cta__actions">
            <ThemeButton href={props.primaryHref || asString((props.blocks ?? [])[0]?.href)} variant="primary" size="lg" iconName="arrow-right">
              {props.primaryLabel || "Get started now"}
            </ThemeButton>
            <MaybeButton label={props.secondaryLabel} href={props.secondaryHref} variant="light" size="lg" />
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
