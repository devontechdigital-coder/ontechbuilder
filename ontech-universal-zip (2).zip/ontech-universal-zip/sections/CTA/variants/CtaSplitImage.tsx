import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { MaybeButton } from "../../../components/ThemeButton";
import type { CTAProps } from "../CTA";

/** CTA 02 — Split with image. Photography on one side lends real context; heading/buttons sit on the other. Less abstract than a plain color band. */
export function CtaSplitImage(props: CTAProps) {
  return (
    <SectionShell name="cta" {...props}>
      <Container width={props.containerWidth ?? "wide"} flush>
        <div className="otu-cta__split">
          <ThemeImage image={props.image} ratio="auto" rounded={false} placeholderLabel="Get in touch" />
          <div className="otu-cta__split-content">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            {props.description ? <p>{props.description}</p> : null}
            <div className="otu-cta__actions">
              <MaybeButton label={props.primaryLabel || "Book a call"} href={props.primaryHref} variant="primary" iconName="arrow-right" />
              <MaybeButton label={props.secondaryLabel} href={props.secondaryHref} variant="outline" />
            </div>
          </div>
        </div>
      </Container>
    </SectionShell>
  );
}
