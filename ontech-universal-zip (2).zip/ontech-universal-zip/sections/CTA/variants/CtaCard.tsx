import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { MaybeButton } from "../../../components/ThemeButton";
import { asString, blocksOfType } from "../../../components/blockHelpers";
import type { CTAProps } from "../CTA";

/** CTA 04 — Floating card. An elevated card sits on a tinted section background with a stacked row of avatar thumbnails beside the label — a social-proof-flavoured CTA. */
export function CtaCard(props: CTAProps) {
  const avatars = blocksOfType(props.blocks ?? [], "avatar");
  return (
    <SectionShell name="cta" {...props} tone={props.tone ?? "surface"}>
      <Container width="default">
        <div className="otu-cta__card">
          {props.heading ? <h2>{props.heading}</h2> : null}
          {avatars.length > 0 || props.avatarLabel ? (
            <div className="otu-cta__avatars">
              <span className="otu-cta__avatar-stack">
                {avatars.slice(0, 4).map((avatar) => (
                  <ThemeImage key={avatar.id} image={avatar.image as never} ratio="1:1" placeholderLabel="Team" className="otu-avatar" />
                ))}
              </span>
              {props.avatarLabel ? <span>{props.avatarLabel}</span> : null}
            </div>
          ) : null}
          <MaybeButton label={props.primaryLabel || "Get started now"} href={props.primaryHref} variant="primary" size="lg" iconName="arrow-right" />
        </div>
      </Container>
    </SectionShell>
  );
}

export { asString };
