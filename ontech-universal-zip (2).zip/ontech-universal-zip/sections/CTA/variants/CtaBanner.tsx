import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { MaybeButton } from "../../../components/ThemeButton";
import type { CTAProps } from "../CTA";

/** CTA 03 — Slim banner. A single-line, low-height strip — heading and one button on the same row. Minimal vertical footprint, good above a footer. */
export function CtaBanner(props: CTAProps) {
  return (
    <SectionShell name="cta" {...props} tone={props.tone ?? "primary"}>
      <Container width={props.containerWidth ?? "wide"}>
        <div className="otu-cta__banner">
          <p>{props.heading}</p>
          <MaybeButton label={props.primaryLabel || "Get started"} href={props.primaryHref} variant="light" iconName="arrow-right" />
        </div>
      </Container>
    </SectionShell>
  );
}
