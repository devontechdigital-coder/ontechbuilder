import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "cta",
  name: "CTA",
  category: "CTA",
  description: "Five closing call-to-action layouts: centered dark, split with image, slim banner, floating card, gradient edge.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Centered dark", "Split with image", "Slim banner", "Floating card", "Gradient edge"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Ready when you are", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Let's build something that moves your business forward", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "text", id: "primaryLabel", label: "Primary button label", default: "Get started now", group: "Content" },
    { type: "url", id: "primaryHref", label: "Primary button link", default: "/contact", group: "Content" },
    { type: "text", id: "secondaryLabel", label: "Secondary button label", group: "Content" },
    { type: "url", id: "secondaryHref", label: "Secondary button link", group: "Content" },
    { type: "image", id: "image", label: "Image", group: "Media", info: "Split design only." },
    { type: "text", id: "avatarLabel", label: "Avatar row label", default: "Talk to our experts", group: "Content", info: "Floating card design only." },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "avatar", name: "Avatar (floating card design)", settings: [{ type: "image", id: "image", label: "Photo" }] },
  ],
  maxBlocks: 6,
};

export default schema;
