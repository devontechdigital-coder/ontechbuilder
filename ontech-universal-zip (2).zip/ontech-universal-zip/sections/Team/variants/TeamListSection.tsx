import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TeamProps } from "../Team";

/** Team 03 — Horizontal list. A square photo beside name/role/bio in a single-column list — room for a short bio per person. */
export function TeamListSection(props: TeamProps) {
  return (
    <SectionShell name="team" {...props}>
      <Container width="default">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-team__list">
          {(props.blocks ?? []).map((member) => (
            <div className="otu-team-row" key={member.id}>
              <ThemeImage image={member.image as never} ratio="1:1" placeholderLabel={asString(member.name, "Team member")} className="otu-team-row__thumb" />
              <div>
                <h3>{asString(member.name)}</h3>
                <p className="otu-team-row__role">{asString(member.role)}</p>
                <p className="otu-team-row__bio">{asString(member.bio)}</p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
