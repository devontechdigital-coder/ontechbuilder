import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { ThemeImage } from "../../../components/ThemeImage";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import { safeHref } from "../../../components/utils";
import type { TeamProps } from "../Team";

/** Team 01 — Photo grid. Portrait photo, name, role and social links per card. The standard team page block. */
export function TeamGridSection(props: TeamProps) {
  return (
    <SectionShell name="team" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className={`otu-team__grid otu-grid-cols-${props.columns ?? 4}`}>
          {(props.blocks ?? []).map((member) => (
            <div className="otu-team-card" key={member.id}>
              <ThemeImage image={member.image as never} ratio="3:4" placeholderLabel={asString(member.name, "Team member")} />
              <h3>{asString(member.name)}</h3>
              <p>{asString(member.role)}</p>
              <div className="otu-team-card__socials">
                {safeHref(member.linkedin as string) ? (
                  <a href={safeHref(member.linkedin as string)} aria-label={`${asString(member.name)} on LinkedIn`}>
                    <Icon name="linkedin" size={16} />
                  </a>
                ) : null}
                {safeHref(member.email ? `mailto:${asString(member.email)}` : undefined) ? (
                  <a href={`mailto:${asString(member.email)}`} aria-label={`Email ${asString(member.name)}`}>
                    <Icon name="mail" size={16} />
                  </a>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
