import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Slider } from "../../../components/Slider";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TeamProps } from "../Team";

/** Team 02 — Carousel. 4/2/1.3 members per view — for larger teams that would otherwise sprawl down the page. */
export function TeamCarouselSection(props: TeamProps) {
  return (
    <SectionShell name="team" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <Slider desktopItems={4} tabletItems={2} mobileItems={1.3} gap="sm" ariaLabel="Team">
          {(props.blocks ?? []).map((member) => (
            <div className="otu-team-card otu-team-card--flat" key={member.id}>
              <ThemeImage image={member.image as never} ratio="1:1" placeholderLabel={asString(member.name, "Team member")} rounded />
              <h3>{asString(member.name)}</h3>
              <p>{asString(member.role)}</p>
            </div>
          ))}
        </Slider>
      </Container>
    </SectionShell>
  );
}
