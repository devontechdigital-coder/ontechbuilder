import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { ThemeImage } from "../../../components/ThemeImage";
import { asString } from "../../../components/blockHelpers";
import type { TeamProps } from "../Team";

/** Team 04 — Leadership spotlight. The first member gets a large featured treatment with bio; the rest fall into a smaller supporting grid. */
export function TeamSpotlightSection(props: TeamProps) {
  const [lead, ...rest] = props.blocks ?? [];
  if (!lead) return null;

  return (
    <SectionShell name="team" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
        {props.heading ? <h2>{props.heading}</h2> : null}

        <div className="otu-team__spotlight">
          <ThemeImage image={lead.image as never} ratio="3:4" placeholderLabel={asString(lead.name, "Leader")} />
          <div>
            <h3>{asString(lead.name)}</h3>
            <p className="otu-team-row__role">{asString(lead.role)}</p>
            <p>{asString(lead.bio)}</p>
          </div>
        </div>

        {rest.length > 0 ? (
          <div className="otu-team__grid otu-grid-cols-4 otu-team__spotlight-rest">
            {rest.map((member) => (
              <div className="otu-team-card" key={member.id}>
                <ThemeImage image={member.image as never} ratio="1:1" placeholderLabel={asString(member.name, "Team member")} />
                <h3>{asString(member.name)}</h3>
                <p>{asString(member.role)}</p>
              </div>
            ))}
          </div>
        ) : null}
      </Container>
    </SectionShell>
  );
}
