import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { asString } from "../../../components/blockHelpers";
import type { TeamProps } from "../Team";

/** Team 05 — Minimal roster. No photos — a text-only, hairline-separated list of name/role pairs. For large teams or a fast-loading footer-adjacent page. */
export function TeamMinimalSection(props: TeamProps) {
  return (
    <SectionShell name="team" {...props}>
      <Container width="narrow">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <ul className="otu-team__minimal">
          {(props.blocks ?? []).map((member) => (
            <li key={member.id}>
              <span>{asString(member.name)}</span>
              <span className="otu-team__minimal-role">{asString(member.role)}</span>
            </li>
          ))}
        </ul>
      </Container>
    </SectionShell>
  );
}
