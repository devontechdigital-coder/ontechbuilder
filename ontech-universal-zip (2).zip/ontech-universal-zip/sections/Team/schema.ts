import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, columnOptions, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "team",
  name: "Team",
  category: "Team",
  description: "Five ways to introduce people: photo grid, carousel, list rows, leadership spotlight, minimal roster.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Photo grid", "Carousel", "Horizontal list", "Leadership spotlight", "Minimal roster"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Our team", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Meet the people behind the work", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "select", id: "columns", label: "Columns", options: columnOptions, default: "4", group: "Layout" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "member", name: "Team member", settings: [
      { type: "image", id: "image", label: "Photo" },
      { type: "text", id: "name", label: "Name", default: "Sofia Grant" },
      { type: "text", id: "role", label: "Role", default: "Director of Strategy" },
      { type: "textarea", id: "bio", label: "Short bio", default: "Twelve years advising mid-market operators on growth strategy and organisational design." },
      { type: "url", id: "linkedin", label: "LinkedIn URL" },
      { type: "text", id: "email", label: "Email address" },
    ] },
  ],
  maxBlocks: 12,
  defaultBlocks: [
    { type: "member", settings: { name: "Sofia Grant", role: "Director of Strategy", bio: "Twelve years advising mid-market operators on growth and org design." } },
    { type: "member", settings: { name: "Marcus Webb", role: "Head of Delivery", bio: "Runs implementation across every active engagement." } },
    { type: "member", settings: { name: "Elena Ruiz", role: "Principal Consultant", bio: "Focuses on financial advisory and M&A integration." } },
    { type: "member", settings: { name: "James Okafor", role: "Consultant", bio: "Specialises in operating-model redesign." } },
  ],
};

export default schema;
