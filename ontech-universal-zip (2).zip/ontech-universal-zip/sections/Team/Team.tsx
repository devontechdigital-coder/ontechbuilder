import * as React from "react";
import type { ColumnCount, SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { TeamGridSection } from "./variants/TeamGridSection";
import { TeamCarouselSection } from "./variants/TeamCarouselSection";
import { TeamListSection } from "./variants/TeamListSection";
import { TeamSpotlightSection } from "./variants/TeamSpotlightSection";
import { TeamMinimalSection } from "./variants/TeamMinimalSection";

export interface TeamProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  columns?: ColumnCount;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<TeamProps>> = {
  v1: TeamGridSection,
  v2: TeamCarouselSection,
  v3: TeamListSection,
  v4: TeamSpotlightSection,
  v5: TeamMinimalSection,
};

/**
 * Team — five ways to introduce people.
 * v1 Photo grid with socials · v2 Carousel · v3 Horizontal list rows ·
 * v4 One large leadership spotlight + supporting grid · v5 Minimal
 * text-only roster.
 */
export function Team(props: TeamProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Team;
