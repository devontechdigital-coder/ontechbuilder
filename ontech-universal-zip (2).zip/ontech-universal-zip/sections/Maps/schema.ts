import type { SectionSchema } from "../../config/settings.schema";
import { baseSectionSettings, variantOptions } from "../../config/settings.schema";

const schema: SectionSchema = {
  id: "map",
  name: "Maps / Location",
  category: "Maps",
  description: "Five location layouts. No Maps SDK or API key — embedUrl accepts a plain https embed link you already have.",
  settings: [
    { type: "select", id: "variant", label: "Design", options: variantOptions(["Map + floating card", "Full-width banner", "Multi-location cards", "Contact details + map", "Location directory"]), default: "v1", group: "Layout" },
    { type: "text", id: "eyebrow", label: "Eyebrow", default: "Visit us", group: "Content" },
    { type: "text", id: "heading", label: "Heading", default: "Find our office", group: "Content" },
    { type: "textarea", id: "description", label: "Description", group: "Content" },
    { type: "url", id: "embedUrl", label: "Map embed URL", group: "Content", info: "Paste an existing https embed link (e.g. from Google Maps' Share > Embed). No API key required or stored." },
    { type: "text", id: "address", label: "Address", default: "400 Michigan Ave, Chicago, IL 60611", group: "Content" },
    { type: "text", id: "phone", label: "Phone", default: "+1 (555) 010-2030", group: "Content" },
    { type: "text", id: "email", label: "Email", default: "hello@example.com", group: "Content" },
    { type: "text", id: "hours", label: "Hours", default: "Mon–Fri, 9am–6pm", group: "Content" },
    ...baseSectionSettings(),
  ],
  blocks: [
    { type: "location", name: "Location", settings: [
      { type: "text", id: "name", label: "Location name", default: "Chicago HQ" },
      { type: "text", id: "address", label: "Address", default: "400 Michigan Ave, Chicago, IL 60611" },
      { type: "text", id: "phone", label: "Phone" },
      { type: "text", id: "hours", label: "Hours", default: "Mon–Fri, 9am–6pm" },
    ] },
  ],
  maxBlocks: 8,
  defaultBlocks: [
    { type: "location", settings: { name: "Chicago HQ", address: "400 Michigan Ave, Chicago, IL 60611", phone: "+1 (555) 010-2030", hours: "Mon–Fri, 9am–6pm" } },
    { type: "location", settings: { name: "Austin office", address: "820 Congress Ave, Austin, TX 78701", phone: "+1 (555) 040-1188", hours: "Mon–Fri, 9am–6pm" } },
  ],
};

export default schema;
