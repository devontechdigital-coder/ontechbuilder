import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import { MapEmbed } from "./MapEmbed";
import type { MapsProps } from "../Maps";

/** Maps 04 — Contact details beside map. A structured contact-info column (address, phone, email, hours) beside the map, roughly even width. */
export function MapContactDetails(props: MapsProps) {
  return (
    <SectionShell name="map" {...props}>
      <Container width={props.containerWidth ?? "wide"} flush>
        <div className="otu-map__contact-split">
          <div className="otu-map__contact-info">
            {props.eyebrow ? <p className="otu-eyebrow">{props.eyebrow}</p> : null}
            {props.heading ? <h2>{props.heading}</h2> : null}
            <dl>
              {props.address ? (
                <div>
                  <dt><Icon name="map-pin" size={17} /> Address</dt>
                  <dd>{props.address}</dd>
                </div>
              ) : null}
              {props.phone ? (
                <div>
                  <dt><Icon name="phone" size={17} /> Phone</dt>
                  <dd>{props.phone}</dd>
                </div>
              ) : null}
              {props.email ? (
                <div>
                  <dt><Icon name="mail" size={17} /> Email</dt>
                  <dd>{props.email}</dd>
                </div>
              ) : null}
              {props.hours ? (
                <div>
                  <dt><Icon name="clock" size={17} /> Hours</dt>
                  <dd>{props.hours}</dd>
                </div>
              ) : null}
            </dl>
          </div>
          <MapEmbed embedUrl={props.embedUrl} label={props.heading} />
        </div>
      </Container>
    </SectionShell>
  );
}
