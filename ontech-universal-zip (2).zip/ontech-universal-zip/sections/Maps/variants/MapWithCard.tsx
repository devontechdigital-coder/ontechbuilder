import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { Icon } from "../../../components/Icon";
import { MapEmbed } from "./MapEmbed";
import type { MapsProps } from "../Maps";

/** Maps 01 — Map + floating card. A tall map with an elevated address/hours card overlapping its corner. The default "find us" section. */
export function MapWithCard(props: MapsProps) {
  return (
    <SectionShell name="map" {...props} padded={false}>
      <div className="otu-map__with-card">
        <MapEmbed embedUrl={props.embedUrl} label={props.heading} />
        <div className="otu-map__card">
          {props.heading ? <h3>{props.heading}</h3> : null}
          {props.address ? (
            <p>
              <Icon name="map-pin" size={16} /> {props.address}
            </p>
          ) : null}
          {props.phone ? (
            <p>
              <Icon name="phone" size={16} /> {props.phone}
            </p>
          ) : null}
          {props.hours ? (
            <p>
              <Icon name="clock" size={16} /> {props.hours}
            </p>
          ) : null}
        </div>
      </div>
    </SectionShell>
  );
}
