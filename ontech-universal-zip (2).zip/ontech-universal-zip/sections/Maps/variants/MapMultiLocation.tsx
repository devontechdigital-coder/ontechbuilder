import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { MapsProps } from "../Maps";

/** Maps 03 — Multi-location cards. A grid of office/branch cards, each with its own address and hours — for a company with several locations. */
export function MapMultiLocation(props: MapsProps) {
  return (
    <SectionShell name="map" {...props}>
      <Container width={props.containerWidth ?? "wide"}>
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" />
        <div className="otu-map__locations">
          {(props.blocks ?? []).map((location) => (
            <div className="otu-map__location-card" key={location.id}>
              <h3>{asString(location.name)}</h3>
              <p>
                <Icon name="map-pin" size={16} /> {asString(location.address)}
              </p>
              {location.phone ? (
                <p>
                  <Icon name="phone" size={16} /> {asString(location.phone)}
                </p>
              ) : null}
              {location.hours ? (
                <p>
                  <Icon name="clock" size={16} /> {asString(location.hours)}
                </p>
              ) : null}
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
