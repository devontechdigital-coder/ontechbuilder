import * as React from "react";
import { Icon } from "../../../components/Icon";

/** Renders a plain, sandboxed iframe when a safe embed URL is supplied, or a labelled placeholder otherwise. No Maps SDK, no API key. */
export function MapEmbed({ embedUrl, label = "Map" }: { embedUrl?: string; label?: string }) {
  if (embedUrl && /^https:\/\//i.test(embedUrl)) {
    return <iframe className="otu-map__embed" src={embedUrl} title={label} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />;
  }
  return (
    <div className="otu-map__placeholder" role="img" aria-label={label}>
      <Icon name="map-pin" size={28} />
      <span>{label}</span>
    </div>
  );
}
