import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { Icon } from "../../../components/Icon";
import { asString } from "../../../components/blockHelpers";
import type { MapsProps } from "../Maps";

/** Maps 05 — Location directory. A scannable hairline-separated list of locations, most compact of the five — for a large multi-city footprint. */
export function MapDirectory(props: MapsProps) {
  return (
    <SectionShell name="map" {...props}>
      <Container width="default">
        <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} />
        <div className="otu-map__directory">
          {(props.blocks ?? []).map((location) => (
            <div className="otu-map__directory-row" key={location.id}>
              <div>
                <h3>{asString(location.name)}</h3>
                <p>{asString(location.address)}</p>
              </div>
              {location.phone ? (
                <a href={`tel:${asString(location.phone).replace(/[^\d+]/g, "")}`}>
                  <Icon name="phone" size={16} /> {asString(location.phone)}
                </a>
              ) : null}
            </div>
          ))}
        </div>
      </Container>
    </SectionShell>
  );
}
