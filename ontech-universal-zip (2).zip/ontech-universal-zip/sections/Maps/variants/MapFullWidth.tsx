import * as React from "react";
import { Container } from "../../../components/Container";
import { SectionShell } from "../../../components/SectionShell";
import { SectionHeading } from "../../../components/SectionHeading";
import { MapEmbed } from "./MapEmbed";
import type { MapsProps } from "../Maps";

/** Maps 02 — Full-width banner. Heading above a full-bleed map strip, no overlapping card — for a simple "visit us" section. */
export function MapFullWidth(props: MapsProps) {
  return (
    <SectionShell name="map" {...props} padded={false}>
      <SectionHeading eyebrow={props.eyebrow} heading={props.heading} description={props.description} align="center" className="otu-container otu-container--default otu-map__heading" />
      <MapEmbed embedUrl={props.embedUrl} label={props.heading} />
    </SectionShell>
  );
}
