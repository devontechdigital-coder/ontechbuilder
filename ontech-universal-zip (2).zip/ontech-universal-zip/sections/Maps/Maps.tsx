import * as React from "react";
import type { SectionBaseProps } from "../../types";
import { asBlocks, type RawBlock } from "../../components/blockHelpers";
import { MapWithCard } from "./variants/MapWithCard";
import { MapFullWidth } from "./variants/MapFullWidth";
import { MapMultiLocation } from "./variants/MapMultiLocation";
import { MapContactDetails } from "./variants/MapContactDetails";
import { MapDirectory } from "./variants/MapDirectory";

export interface MapsProps extends SectionBaseProps {
  eyebrow?: string;
  heading?: string;
  description?: string;
  /** Safe embed URL (e.g. an existing Google Maps embed link) forwarded verbatim to an iframe. No Maps SDK or API key involved. */
  embedUrl?: string;
  address?: string;
  phone?: string;
  email?: string;
  hours?: string;
  blocks?: RawBlock[];
}

const variants: Record<string, React.ComponentType<MapsProps>> = {
  v1: MapWithCard,
  v2: MapFullWidth,
  v3: MapMultiLocation,
  v4: MapContactDetails,
  v5: MapDirectory,
};

/**
 * Maps / Location — five layouts. No Maps SDK or API key is bundled;
 * `embedUrl` is a plain iframe src the merchant supplies (e.g. from
 * Google Maps' own "Share > Embed" link), rendered as-is.
 * v1 Map + floating address card · v2 Full-width map banner · v3
 * Multi-location cards · v4 Contact details beside the map · v5
 * Location directory list.
 */
export function Maps(props: MapsProps) {
  const Variant = variants[props.variant ?? "v1"] ?? variants.v1;
  return <Variant {...props} blocks={asBlocks(props.blocks)} />;
}

export default Maps;
